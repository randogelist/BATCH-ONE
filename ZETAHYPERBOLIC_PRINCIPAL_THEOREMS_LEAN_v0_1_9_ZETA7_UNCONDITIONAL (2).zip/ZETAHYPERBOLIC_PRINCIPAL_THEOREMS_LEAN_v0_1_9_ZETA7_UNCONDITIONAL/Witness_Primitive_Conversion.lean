import Equation_4_3_Paper_Witness
import Theorem_2_4_Primitive_Normalization_Minimality

/-!
# Minimal, primitive alternative for the sole conditional input

All primitive polynomials are constructed internally by the algebraic
normalization theorem. Only their eventual *quadratic upper bound* is
left as a witness. This is weaker than demanding an explicit sequence
of paper multipliers: any admissible explicit positive integer scaling
of the same rational determinant would suffice to establish the bound.
-/

noncomputable section
open Polynomial

namespace PaperWitnessOnly
open ManuscriptChain
open ManuscriptChain.MainChain
open ManuscriptChain.RealTransfer

/-- The smallest convenient input: one eventual decay assertion on the
explicitly constructed canonical primitive polynomial sequence. -/
structure PrimitiveWitness where
  start : ℕ
  bound : ∀ n : ℕ, start + 1 ≤ n →
    |RealTransfer.evalReal ((MainChain.primitiveMainNormalization start).Q n)
      MainChain.zeta5| ≤ MainChain.decayBudget n

/-- No extra mathematical hypotheses: strict positivity, exact integer
normalization and linear degree growth are earlier theorems. -/
theorem ZETA5_IRRATIONALITY_FROM_PRIMITIVE_WITNESS
    (w : PrimitiveWitness) : Irrational (riemannZeta (5 : ℂ)).re :=
  ManuscriptChain.ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY w.start w.bound

/-- A paper-style witness gives the primitive witness, by minimality of
positive primitive normalization (no new decay theorem is assumed). -/
theorem primitive_of_paper (w : PaperWitness) : PrimitiveWitness := by
  refine ⟨w.start, ?_⟩
  intro n hn
  have hscale :=
    BasisInvariance.primitiveNormalization_abs_eval_int_le
      (MainChain.primitiveMainPolynomialNormalization n)
      (w.m_pos n hn)
      (w.value_identity n hn)
      MainChain.zeta5
  have hcompare :
      |RealTransfer.evalReal ((MainChain.primitiveMainNormalization w.start).Q n)
        MainChain.zeta5| ≤
      |RealTransfer.evalReal (w.Q n) MainChain.zeta5| := by
    simpa only [RealTransfer.evalReal, MainChain.primitiveMainNormalization,
      algebraMap_int_eq] using hscale
  exact hcompare.trans (w.quadratic_decay n hn)

end PaperWitnessOnly

#print axioms PaperWitnessOnly.ZETA5_IRRATIONALITY_FROM_PRIMITIVE_WITNESS
#print axioms PaperWitnessOnly.primitive_of_paper
