# FIX22: MAIN_CHAIN module 81

The name `dualSlopeMatrix` is defined in `PaperOrder.CoreAlgebra`, not `ManuscriptChain.Real`. The main chain now references `dualSlopeMatrix c` in its current namespace.

This is a source-only patch. Compiler verification is performed only by the user's native Windows Lean 4.33.0 runner.
