# V3: Reasoned core-algebra extension (not yet compiler verified)

Exact changes after v0.5.2 (84 modules):

- **85** Selected coordinate-monomial dual Beukers pencils: derivative is exactly the identity, determinant monic of exact degree h for any injective selection.
- **86** Dual coefficient-row separation gives positive-definite slope quadratic form via a sum-of-squares argument.
- **87** Genuine normalized pole derivative quadratic form is exactly the sum of pole-weighted coordinate squares.
- **88** Real mathematical V3 endpoint for selected-monomial degree and genuine pole quadratic form.

All modules 1–84 retain byte-for-byte identical .lean source content.
Latest user compiler checkpoint reported 60 PASS (61–88 unverified).
No local Lean compilation was run. This does NOT establish the paper's remaining analytic or general interlacing statements, nor 95% coverage.
The runner reuses the persistent native Lean 4.33.0 cache when source, imports, and environment match.
