import PaperOrder.Theorem_5_2_Full_Monomial_Dual_Monicity

/-!
# Chronological algebraic base — dual Gram and monic family integrated

The previously verified 59 modules and the unverified 60-80 source files
are untouched. This endpoint adds unconditional positivity semidefiniteness
of the dual slope and exact monicity of its full monomial specialization.
-/

noncomputable section
namespace PaperOrder.CoreAlgebra

/-- The core algebraic chain with explicit universal dual-penciled results. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V2
    (p : ManuscriptChain.Real.Parameters) :
    ((ManuscriptChain.Real.delta p).natDegree = p.h) ∧
    (∀ (h K : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
      (v : Fin h → ℚ), 0 ≤ dualSlopeQuadraticForm c v) ∧
    (∀ (K s : ℕ),
      (ManuscriptChain.Real.dualDelta s
        (dualFullMonomialCoefficients K)).natDegree = K + 1) := by
  refine ⟨ManuscriptChain.PoleDiagonalization.delta_natDegree p, ?_, ?_⟩
  · intro h K c v
    exact dualSlopeQuadraticForm_nonneg c v
  · intro K s
    exact dualFullMonomialDelta_degree K s

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V2
