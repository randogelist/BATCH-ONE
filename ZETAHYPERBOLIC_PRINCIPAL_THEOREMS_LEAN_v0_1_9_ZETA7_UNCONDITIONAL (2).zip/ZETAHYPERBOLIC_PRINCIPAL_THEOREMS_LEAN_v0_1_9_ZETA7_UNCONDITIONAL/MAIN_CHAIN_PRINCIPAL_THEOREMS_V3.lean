import MAIN_CHAIN_PRINCIPAL_THEOREMS_V2
import PaperOrder.Principal_Theorem_5_2_ZetaSeven_Elementary_Bound

/-!
# Principal theorems V3: unconditional ζ(7) signed scalar witness

The existing direct all-dimensional spectral factorization, corrected
finite principal-minor real-rootedness, and finite Krein identities remain
frozen, compiler-verified. V3 discharges exactly the missing scalar
analytic bound ζ(7)<38/37, giving two explicit positive/negative
1×1 rational Beukers witnesses at the actual ζ(7).

No infinite-tail Krein cone, complete paper, or irrationality theorem
is claimed by this finite analytic closure.
-/

noncomputable section
open scoped BigOperators
namespace PaperOrder.PrincipalTheorems

/-- All three rank-one conclusions are unconditional. -/
theorem MAIN_PRINCIPAL_THEOREMS_V3_UNCONDITIONAL_ZETA7_WITNESS :
    (ManuscriptChain.Real.dualDelta 7 negativeWeightSevenRow).eval
       (38 / 37 : ℚ) = 0 ∧
    ManuscriptChain.Real.evalQ
        (ManuscriptChain.Real.dualDelta 7 negativeWeightSevenRow)
        (ManuscriptChain.Real.zeta 7) < 0 ∧
    0 < ManuscriptChain.Real.evalQ
        (ManuscriptChain.Real.dualDelta 7 positiveWeightSevenRow)
        (ManuscriptChain.Real.zeta 7) := by
  exact MAIN_PRINCIPAL_ONE_DIMENSIONAL_WITNESSES zetaSeven_lt_38_div_37

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.MAIN_PRINCIPAL_THEOREMS_V3_UNCONDITIONAL_ZETA7_WITNESS
