# FIX17 — Theorem 5.2 monomial coefficient dimensions

At module 79, the original proof defined `dualMonomialCoefficients h : Fin h → Fin h → ℚ`, while `dualSlopeMatrix (K := h - 1)` requires `Fin h → Fin (h - 1 + 1) → ℚ`. Lean cannot identify those types for an arbitrary `h` because the equality fails when `h = 0`.

We preserve the exact first `h` monomials by padding the coefficient matrix with a final zero column (`Fin h → Fin (h+1) → ℚ`). The coefficient matrix has orthonormal rows, and the derivative Gram matrix is `1`. The proof follows the same coordinate-vector pattern used in the later selected-monomial theorem, without a positivity or analytic hypothesis.

Only the unverified module 79 has changed. Modules 1–78 stay byte-for-byte unchanged and remain eligible for reuse from the user's persistent `.olean` cache. No Lean compilation has been performed here. The user Windows Lean 4.33.0 compiler is the sole authority.
