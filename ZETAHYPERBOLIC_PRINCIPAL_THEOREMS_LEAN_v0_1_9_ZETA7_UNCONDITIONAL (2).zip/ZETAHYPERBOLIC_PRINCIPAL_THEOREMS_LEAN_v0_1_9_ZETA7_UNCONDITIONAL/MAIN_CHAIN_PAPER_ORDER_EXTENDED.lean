import MAIN_CHAIN_PAPER_ORDER
import PaperOrder.Theorem_3_3_Leading_Sign_Exponent
import PaperOrder.Theorem_3_4_Dodgson_Base_Case_Corrected
import PaperOrder.Corollary_3_5_Normalized_JFraction_Base_Case
import PaperOrder.Corollary_3_6_Finite_Stieltjes_Correction

/-!
# Continued manuscript order: Theorem 3.3 through Corollary 3.6

The 38 previously checked modules (including MAIN_CHAIN_PAPER_ORDER) are
imported unchanged. These additional modules prove unconditional finite
substatements and make explicit where the printed manuscript requires repair.
This does NOT certify the complete claims of 3.3--3.6 or the entire PDF.
-/

namespace PaperOrder

/-- Original unconditional odd-weight main statement is preserved exactly. -/
theorem MAIN_CHAIN_PAPER_ORDER_EXTENDED
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  MAIN_CHAIN_PAPER_ORDER p hp

end PaperOrder

#print axioms PaperOrder.MAIN_CHAIN_PAPER_ORDER_EXTENDED
#print axioms PaperOrder.Section3.theorem_3_3_weight_five_exponent_decomposition
#print axioms PaperOrder.Section3.theorem_3_4_dodgson_order_two_nonpositive
#print axioms PaperOrder.Section3.corollary_3_5_two_level_schur_identity
#print axioms PaperOrder.Section3.corollary_3_6_finite_hankel_factorization
#print axioms PaperOrder.Section3.corollary_3_6_single_atom_hankel_det_zero
