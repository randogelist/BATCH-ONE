# Chronological Section 3 extension: v0.4.0

## User verified checkpoints

- 1–38: previously compiler verified.
- 39: compiler verified in v0.3.7 (unchanged).
- 40: prior failures; v0.3.9 FIX5 source retained, **not yet reported PASS**.
- 41–43: unverified, retained unchanged from v0.3.9.
- 44–47: NEW modules in this package; **not yet compiler checked**.

## New finite proofs

- `Theorem_3_7_Turanian_And_Newton_Quadratic_Case.lean`:
  exact real-rooted quadratic Turanian identity and Newton inequality.
- `Theorem_3_8_Finite_Christoffel_Darboux_Pole_Kernel.lean`:
  symmetric finite inverse-Gram kernel and sum-of-squares diagonal positivity.
- `Theorem_3_9_Dirichlet_Fekete_Factorizations.lean`:
  five polynomial factorization identities and their strict positivity for 0<z<1.
- `MAIN_CHAIN_PAPER_ORDER_SECTION3.lean`: chronological import checkpoint.

These are **partial** statements of Theorems 3.7–3.9. No general
analytic CD-kernel identity, Dirichlet L-function integral bridge,
or fully arbitrary-degree Newton system is claimed.

## Build instructions

Extract this one ZIP and execute its one `run.cmd` in Windows CMD.
Existing frozen `.olean` artifacts remain in the same persistent cache.
Lean compilation is deliberately **not performed** by the packager.

## Remaining mathematical frontier

- Paper Theorems 3.3–3.9 are not all entirely formalized.
- The printed 3.4 and Corollaries 3.5–3.6 require precise corrections.
- Section 4 quantitative estimates, and the rest of the paper, remain pending.
