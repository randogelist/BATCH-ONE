import MAIN_CHAIN_PAPER_ORDER_SECTION3
import PaperOrder.Theorem_4_4_Exponent_Arithmetic_Certificate

/-!
# Chronological manuscript checkpoint through the first part of Section 4

The general odd-weight pencil theorem and all already-verified finite
Section 3 results remain frozen. The new part establishes the finite
spectral integer-denominator contradiction (Theorem 4.1), conditional
uniform transfer, the finite resultant obstruction (Proposition 4.2),
and an abstract ultrametric zero-free disc (Proposition 4.3).

The paper's concrete Archimedean/p-adic asymptotic inequalities are not
silently assumed or labelled proved. The exact exponent arithmetic of
Theorem 4.4 is certified, not its full quantitative analytic statement.
-/

noncomputable section
namespace PaperOrder

/-- Previously verified unconditional spectral result remains available. -/
theorem MAIN_CHAIN_PAPER_ORDER_SECTION4A
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  MAIN_CHAIN_PAPER_ORDER_SECTION3 p hp

/-- The rational-measure transfer endpoint, with exactly the conditions
visible in the general Theorem 4.1 interface. -/
theorem MAIN_CHAIN_PAPER_ORDER_SECTION4A_TRANSFER
    {Q : ℕ → Polynomial ℤ} {ξ : ℝ} {radius budget : ℕ → ℝ}
    {n₀ μ b₀ : ℕ}
    (comparison : ManuscriptChain.RealTransfer.LocalComparison Q ξ radius n₀)
    (decay : ManuscriptChain.RealTransfer.Decay Q ξ budget n₀)
    (index : ManuscriptChain.RealTransfer.IndexBudget Q radius budget n₀ μ b₀) :
    ManuscriptChain.RealTransfer.RationalMeasure ξ μ b₀ ∧ Irrational ξ :=
  Section4.theorem_4_1_uniform_measure_and_irrationality comparison decay index

end PaperOrder

#print axioms PaperOrder.MAIN_CHAIN_PAPER_ORDER_SECTION4A
#print axioms PaperOrder.MAIN_CHAIN_PAPER_ORDER_SECTION4A_TRANSFER
