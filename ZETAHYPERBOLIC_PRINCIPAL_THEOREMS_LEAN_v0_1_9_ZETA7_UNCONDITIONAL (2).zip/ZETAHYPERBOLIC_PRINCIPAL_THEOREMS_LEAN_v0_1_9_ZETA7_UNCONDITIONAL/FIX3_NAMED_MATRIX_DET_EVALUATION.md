# FIX3 — named polynomial matrix for `map_det`

The Lean 4.33 user log fails at module 109 inside
`PositiveSlopePencil.eval_detPolynomial` because the expression
`Matrix.det (fun i j => ...)` is unfolded before the `RingHom.map_det`
rewrite, which makes dependent-matrix elaboration fail.

This patch introduces the *definitionally identical* named
`PositiveSlopePencil.polynomialMatrix`, matching the already compiler-verified
`SymmetricAffinePencil.polynomialMatrix` + `eval_detPolynomial` proof pattern.
It does not edit any of the first 108 frozen-certified modules.

Only module 109 and its actual transitive dependents are expected to build.
No Lean compilation was performed in this packaging environment; the native
Windows Lean 4.33 run.cmd remains the sole authoritative test.
