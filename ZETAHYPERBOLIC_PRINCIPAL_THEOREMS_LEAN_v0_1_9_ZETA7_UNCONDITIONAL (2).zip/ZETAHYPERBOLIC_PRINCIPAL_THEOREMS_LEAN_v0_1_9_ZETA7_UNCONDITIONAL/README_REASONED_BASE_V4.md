# V4. Lean 4.33.0, 95% core-algebra program

- 92 dependency-ordered modules. Existing 88 module sources unchanged; the weight-change source already existed but was not part of the build order.
- Added cross-weight determinant scaling/sign preservation and odd-weight degree invariance for the actual one-variable rational Hankel pencil.
- Added dual two-variable Beukers slope and top-degree coefficient independence of weight.
- All additional mathematical results are proposed Lean proofs, not compiler-verified.
- The last user-confirmed full package was 59/59. Modules 60–92 still require the user's compiler unless individually verified since then.
- No local Lean compilation; single native Windows run.cmd; 16 threads and persistent cached Mathlib.
- The 95% core-algebra gate remains open and must be assessed on actual proof strength rather than module count.
