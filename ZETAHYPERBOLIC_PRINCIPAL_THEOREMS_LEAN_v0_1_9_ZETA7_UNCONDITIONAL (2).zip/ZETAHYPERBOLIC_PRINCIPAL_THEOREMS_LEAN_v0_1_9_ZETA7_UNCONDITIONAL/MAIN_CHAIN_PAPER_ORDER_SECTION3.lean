import MAIN_CHAIN_PAPER_ORDER_EXTENDED
import PaperOrder.Theorem_3_7_Turanian_And_Newton_Quadratic_Case
import PaperOrder.Theorem_3_8_Finite_Christoffel_Darboux_Pole_Kernel
import PaperOrder.Theorem_3_9_Dirichlet_Fekete_Factorizations

/-!
# Chronological manuscript checkpoint through Theorem 3.9

This entry point imports the unconditional main theorem of the odd-weight
Hankel pencil and the finite algebraic subresults of manuscript Sections
3.3–3.9. Importing those results does not certify the full, stronger
claims of those numbered theorems. Theorems 3.4, Corollary 3.5 and
Corollary 3.6 require the recorded paper corrections.
-/

namespace PaperOrder

theorem MAIN_CHAIN_PAPER_ORDER_SECTION3
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  MAIN_CHAIN_PAPER_ORDER_EXTENDED p hp

end PaperOrder

#print axioms PaperOrder.MAIN_CHAIN_PAPER_ORDER_SECTION3
#print axioms PaperOrder.Section3.theorem_3_7_quadratic_turan_nonnegative
#print axioms PaperOrder.Section3.theorem_3_8_finite_pole_kernel_symmetric
#print axioms PaperOrder.Section3.theorem_3_9_fekete_eight_positive
