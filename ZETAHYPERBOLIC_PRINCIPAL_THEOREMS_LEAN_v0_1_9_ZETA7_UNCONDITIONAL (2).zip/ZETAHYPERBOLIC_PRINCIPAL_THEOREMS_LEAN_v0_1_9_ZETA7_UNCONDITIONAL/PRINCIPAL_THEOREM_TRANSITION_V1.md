# Principal-theorem transition, 2026-10-24

## What this package proves (subject to native Windows Lean verification)

**Theorem 5.2(1): the full finite-dimensional spectral algebra.** For every
integer dimension `h`, every rectangular real coefficient array `c`, and
any symmetric constant matrix `A`, assume precisely that the coefficient
rows of `c` separate nonzero real row vectors. The new Lean statements prove:

1. `CCᵀ` is positive definite (not merely semidefinite), with an exact
   finite sum-of-squares certificate.
2. The genuine degree-`h` determinant `det(A + X CCᵀ)` factors as
   `det(CCᵀ) · ∏ᵢ (X + βᵢ)` for actual **real** βᵢ constructed by the
   Hermitian spectral theorem.
3. The determinant has exact degree `h`, each `-βᵢ` is a real root, and
   *every* complex root has imaginary part zero.

**Corrected Theorem 3.4:** for any injective choice of principal indices,
a positive-definite base remains positive definite on that principal
submatrix. Its determinant polynomial has no nonreal complex roots, and
does not vanish at the center, even if its slope is singular and the
polynomial degree drops below its matrix dimension. Full Cauchy interlacing
of *finite nonzero roots* is not asserted.

This replaces the earlier dimension-2-only spectral/discriminant frontier
by the actual general-dimensional algebraic conclusion. It does NOT
prove the printed infinite-dimensional Krein decomposition or positive and
negative rational subspace construction (Theorem 5.2(2)-(3)).

## What remains principal, not artificially assumed away

| Printed theorem | Exact next mathematical obligation |
|---|---|
| 3.1 universal hyperbolicity | Establish the concrete analytic positive-moment identity / Gram positivity uniformly in the manuscript parameters |
| 3.3 total positivity and inertia | Prove generalized Andréief positivity for all minors and the actual alternating signs of every rational pole weight, not only its nonvanishing |
| 3.4 principal interlacing | Correct the printed false nonzero-root claim when a principal slope is singular; prove the valid rank-sensitive interlacing law |
| 3.5 and 3.6 | Establish correctly normalized J-fractions and reciprocal root sums under the necessary nondegeneracy conditions |
| 3.7 and 3.8 | General Newton inequalities, full Christoffel–Darboux and arbitrary-rank Jacobi derivatives |
| 4.1--4.8 | Discharge actual spectral radius bounds, integral normalizations and uniform exponential denominator/height budgets |
| 5.2(2)-(3) | Construct and control the entire infinite signed-tail Krein form; a finite truncation cannot alone certify a sign for the full kernel |
| 6.10 | Prove the exact analytic potential-gap identity and the derivative-growth estimate in the paper's two-variable measure |

## Certification boundaries

- The 97 original Lean modules were reported PASS by the **user's** native
  Lean 4.33.0 compiler. Their sources have been preserved unchanged.
- Old extensions 98--107, including the separate FIX25 repair of module 98,
  have not yet been confirmed PASS in the provided log.
- New proof sources 108--111 must still pass **the user's** compiler and
  `#print axioms` checks. No Lean compiler was run during packaging.
- The present package neither proves the complete manuscript nor asserts
  19/20 core-algebra gates without a theorem-level comparison audit.
