# Theorem-level coverage ledger (paper order)

Status is about **exact printed theorem** compared with this source graph, not about the existence of similar-looking declarations. "Checked" refers to preserved upstream Lean 4.33 validation records. Newly added modules were not compiled in this session.

| PDF | Kind | Status | Boundary |
|---|---|---|---|
| 2.1 | Definition | constructed | Actual rational moments, pencil, determinant |
| 2.2 | Lemma | not fully matched | Auxiliary tau pullback not found as complete theorem in assembled active chain |
| 2.3 | Lemma | not fully matched | Auxiliary reflection and difference identities not complete |
| 2.4 | Theorem | checked core | Basis invariance and positive primitive normalization |
| 2.5 | Theorem | checked core / partial | Derivative Vandermonde factorization and degree; explicit interpolation representation incomplete |
| 3.1 | Theorem | checked core | Full odd weight Gram positivity and hyperbolicity, exact root-free radius |
| 3.2 | Proposition | needs correction | Continuous-weight prefactor inconsistent with odd-weight specialization |
| 3.3 | Theorem | partial | Bilateral signature and total positivity beyond main spectral endpoint |
| 3.4 | Theorem | FALSE AS PRINTED | Principal derivative may be zero; K=30,N=3,m=3,s=5 gives M00=0 |
| 3.5 | Corollary | needs correction | Gram determinant factor omitted and I+tT vs T+tI confusion; cyclicity needed |
| 3.6 | Corollary | not fully formalized | Even reciprocal-root power sums |
| 3.7 | Theorem | not fully formalized | Turan/Newton refinements |
| 3.8 | Theorem | not fully formalized | Christoffel-Darboux and Jacobi differential |
| 3.9 | Theorem | not fully formalized | Hurwitz/Dirichlet extensions |
| 3.10 | Remark | not a Lean theorem | Non-classicality argument needs corrected formulation |
| 4.1 | Theorem | checked conditional transfer | Generic transfer theorem proved; numeric input must be constructed |
| 4.2 | Proposition | not fully formalized | Algebraic approximation transfer |
| 4.3 | Proposition | not fully formalized | p-adic root-free disk |
| 4.4 | Theorem | conditional interface | Multiplier, archimedean and uniform spectral-growth inputs open |
| 4.5 | Theorem | not fully formalized | Two-weight ζ(5)/ζ(3) quantitative arithmetic |
| 4.6 | Theorem | not fully formalized | Two-sided determinant/height asymptotics |
| 4.7 | Theorem | not fully formalized | Root collapse quantitative rate |
| 4.8 | Proposition | not fully formalized | Cluster factor degree/rational root bounds |
| 4.9 | Remark | not fully formalized | Variational spectral bounds |
| 4.10 | Remark | not fully formalized | Free-energy phase transition |
| 4.11 | Conjecture | CONJECTURE | Not established by manuscript |
| 5.1 | Theorem | definitions only | Exact two-variable integral identification unproved in assembled source |
| 5.2 | Theorem | conditional replacement | Finite certificate/tail control not constructed |
| 5.3 | Proposition | not fully formalized | Beta(4) two-variable measure |
| 5.4 | Theorem | finite pole formula added | Cancellation of defining +/- pole values, not entire tau functional |
| 5.5 | Remark | scope statement | Simple-pole domain only |
| 5.6 | Theorem | not fully formalized | Prime-sum integral and local determinant improvement |
| 5.7 | Theorem | not fully formalized | Double-pole q-adic determinant valuation |
| 6.1 | Theorem | not fully formalized | Divided-difference p-adic valuation |
| 6.2 | Theorem | not fully formalized | Weight (6,7) coupled Beukers family |
| 6.3 | Theorem | conditional replacement | Analytic tail and positive basis existence remain inputs |
| 6.4 | Theorem | conditional interface | Beta derivative sign / analytic weight bridge not closed |
| 6.5 | Theorem | not fully formalized | q-adic nonvanishing |
| 6.6 | Theorem | not fully formalized | General multiweight matrix positivity |
| 6.7 | Theorem | not fully formalized | Universal Krein decomposition |
| 6.8 | Corollary | not fully formalized | Three-term independence cone |
| 6.9 | Theorem | finite repair only | Triple-pole Hermite arithmetic, actual p-adic endpoint unproved |
| 6.10 | Theorem | rate direction corrected | Energy identification not proved; printed ratio inference invalid |
| 6.11 | Theorem | not fully formalized | Beta distribution denominator |
| 6.12 | Theorem | not fully formalized | Sign flip restoration / q-adic bound |
| 6.13 | Theorem | not fully formalized | Central factorial differential |
| 6.14 | Theorem | not fully formalized | Even pole scaling |
| 6.15 | Theorem | not fully formalized | Transcendence / measures |
| 6.16 | Theorem | conditional ratio lemma | Requires actual continuous compactified ratio and endpoint positivity |
| 6.17 | Theorem | finite index repair only | Exact congruence windows; determinant valuation not proved |
| 6.18 | Theorem | finite quotient repair only | Boundary index and polynomial division, no full measure |
