import Theorem_2_5_Weight_Change

/-!
# Theorem 2.5 — universal cross-weight determinant sign

The true residue-defined derivative determinant transforms under an increase
of the odd-weight index by an explicit positive product. Consequently it
preserves its sign and its nonvanishing. These results involve no integral
estimate, no approximation witness, and no change in the pole geometry.
-/

noncomputable section
open scoped BigOperators
namespace ManuscriptChain.PoleDiagonalization

/-- The quotient of determinants of successive odd-weight derivatives is
strictly positive. The denominator is automatically nonzero. -/
theorem derivative_det_reweight_ratio_pos
    (p : Real.Parameters) (k step : ℕ) :
    (0 : ℚ) <
      (rationalDerivativeMatrix (reweight p (k + step))).det /
      (rationalDerivativeMatrix (reweight p k)).det := by
  rw [rationalDerivativeMatrix_det_reweight_ratio]
  exact reweight_factor_pos p step

/-- Increasing the odd-weight index cannot alter the sign of the actual
slope determinant of the one-variable Hankel pencil. -/
theorem derivative_det_reweight_pos_iff
    (p : Real.Parameters) (k step : ℕ) :
    (0 : ℚ) < (rationalDerivativeMatrix (reweight p (k + step))).det ↔
      (0 : ℚ) < (rationalDerivativeMatrix (reweight p k)).det := by
  rw [rationalDerivativeMatrix_det_reweight_add]
  have hfac : (0 : ℚ) <
      ∏ a : Fin p.h, (poleIndex p a : ℚ) ^ (2 * step) :=
    reweight_factor_pos p step
  constructor
  · intro hp
    by_contra hn
    have hnonpos : (rationalDerivativeMatrix (reweight p k)).det ≤ 0 :=
      le_of_not_gt hn
    have hmul : (rationalDerivativeMatrix (reweight p k)).det *
        (∏ a : Fin p.h, (poleIndex p a : ℚ) ^ (2 * step)) ≤ 0 :=
      mul_nonpos_of_nonpos_of_nonneg hnonpos (le_of_lt hfac)
    exact (not_le_of_gt hp) hmul
  · intro hp
    exact mul_pos hp hfac

/-- The full Hankel determinant polynomial has the same degree at every
odd-weight index because the number of poles is unchanged. -/
theorem delta_natDegree_reweight_invariant
    (p : Real.Parameters) (k l : ℕ) :
    (Real.delta (reweight p k)).natDegree =
      (Real.delta (reweight p l)).natDegree := by
  rw [delta_natDegree, delta_natDegree]
  rfl

end ManuscriptChain.PoleDiagonalization

#print axioms ManuscriptChain.PoleDiagonalization.derivative_det_reweight_ratio_pos
#print axioms ManuscriptChain.PoleDiagonalization.derivative_det_reweight_pos_iff
#print axioms ManuscriptChain.PoleDiagonalization.delta_natDegree_reweight_invariant
