import PaperOrder.Theorem_3_3_Abstract_Inertia_Sign_Certificate

/-!
# Theorem 3.3: genuine pole-coordinate quadratic form

The actual odd-weight rational derivative matrix is congruent over Q to a
diagonal matrix of its pole weights. This module spells out the resulting
quadratic form for EVERY vector in the genuine pole-coordinate space.
No assumed inertia or sign pattern is introduced. The diagonal weights
are the actual constructed rational residues.
-/

noncomputable section
open scoped BigOperators
namespace PaperOrder.CoreAlgebra
open ManuscriptChain.PoleDiagonalization

/-- Quadratic form after the genuine Vandermonde inverse change of basis. -/
def normalizedPoleSlopeQuadraticForm
    (p : ManuscriptChain.Real.Parameters) (v : Fin p.h → ℚ) : ℚ :=
  ∑ a : Fin p.h, ∑ b : Fin p.h,
    v a * (((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
      ((poleVandermonde p)⁻¹).transpose) a b) * v b

/-- Exact sum of signed coordinate squares for the actual pole pencil.
This is the constructive matrix-congruence foundation for Sylvester inertia. -/
theorem normalizedPoleSlopeQuadraticForm_eq_diagonal
    (p : ManuscriptChain.Real.Parameters) (v : Fin p.h → ℚ) :
    normalizedPoleSlopeQuadraticForm p v =
      ∑ a : Fin p.h, poleWeight p a * (v a)^2 := by
  classical
  unfold normalizedPoleSlopeQuadraticForm
  rw [pole_slope_diagonal]
  simp only [Matrix.diagonal_apply]
  apply Finset.sum_congr rfl
  intro a ha
  simp [mul_ite, pow_two]
  ring

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.normalizedPoleSlopeQuadraticForm_eq_diagonal
