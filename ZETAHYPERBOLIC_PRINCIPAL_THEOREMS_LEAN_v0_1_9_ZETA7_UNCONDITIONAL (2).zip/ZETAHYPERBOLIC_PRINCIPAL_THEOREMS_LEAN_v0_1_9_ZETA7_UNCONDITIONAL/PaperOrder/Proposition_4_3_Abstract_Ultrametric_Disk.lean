import PaperOrder.Proposition_4_2_Resultant_Product_Barrier
import Mathlib.Tactic

/-!
# Proposition 4.3: nonarchimedean polynomial stability

A genuinely proved abstract ultrametric lemma for finite Horner polynomials:
when coefficients and the two arguments have norm at most one, evaluation
is 1-Lipschitz, so a displacement smaller than the original nonzero value
cannot create a zero. In a p-adic specialization the coefficients of an
integer polynomial have norm at most one. The passage to Mathlib's Cp
and the precise paper radius are still separate from this module.
-/

noncomputable section
namespace PaperOrder.Section4

variable {R : Type*} [CommRing R]

/-- Evaluation of a finite polynomial coefficient list by Horner recursion,
with the constant coefficient first. -/
def ultrametricHorner (x : R) : List R → R
  | [] => 0
  | c :: cs => c + x * ultrametricHorner x cs

/-- Ultrametric unit-disc bound for a polynomial with unit-disc coefficients. -/
theorem proposition_4_3_horner_unit_bound
    (v : R → ℝ) (hzero : v 0 = 0)
    (hadd : ∀ a b : R, v (a + b) ≤ max (v a) (v b))
    (hmul : ∀ a b : R, v (a * b) ≤ v a * v b)
    (hnonneg : ∀ a : R, 0 ≤ v a)
    (x : R) (hx : v x ≤ 1) (cs : List R) :
    (∀ c ∈ cs, v c ≤ 1) → v (ultrametricHorner x cs) ≤ 1 := by
  induction cs with
  | nil =>
      intro _
      simp [ultrametricHorner, hzero]
  | cons c cs ih =>
      intro hcoeff
      have hc : v c ≤ 1 := hcoeff c (by simp)
      have htailcoeff : ∀ z ∈ cs, v z ≤ 1 := by
        intro z hz
        exact hcoeff z (by simp [hz])
      have htail : v (ultrametricHorner x cs) ≤ 1 := ih htailcoeff
      have hprod : v (x * ultrametricHorner x cs) ≤ 1 := by
        calc
          v (x * ultrametricHorner x cs)
              ≤ v x * v (ultrametricHorner x cs) := hmul _ _
          _ ≤ 1 * v (ultrametricHorner x cs) :=
            mul_le_mul_of_nonneg_right hx (hnonneg _)
          _ ≤ 1 * 1 := mul_le_mul_of_nonneg_left htail (by norm_num)
          _ = 1 := by ring
      calc
        v (ultrametricHorner x (c :: cs))
            = v (c + x * ultrametricHorner x cs) := rfl
        _ ≤ max (v c) (v (x * ultrametricHorner x cs)) := hadd _ _
        _ ≤ 1 := max_le hc hprod

/-- Unit-disc Lipschitz inequality for finite polynomial evaluation. -/
theorem proposition_4_3_horner_lipschitz
    (v : R → ℝ) (hzero : v 0 = 0)
    (hadd : ∀ a b : R, v (a + b) ≤ max (v a) (v b))
    (hmul : ∀ a b : R, v (a * b) ≤ v a * v b)
    (hnonneg : ∀ a : R, 0 ≤ v a)
    (x y : R) (hx : v x ≤ 1) (hy : v y ≤ 1) (cs : List R) :
    (∀ c ∈ cs, v c ≤ 1) →
      v (ultrametricHorner x cs - ultrametricHorner y cs) ≤ v (x - y) := by
  induction cs with
  | nil =>
      intro _
      simpa [ultrametricHorner, hzero] using hnonneg (x - y)
  | cons c cs ih =>
      intro hcoeff
      have htailcoeff : ∀ z ∈ cs, v z ≤ 1 := by
        intro z hz
        exact hcoeff z (by simp [hz])
      have htailbound : v (ultrametricHorner x cs) ≤ 1 :=
        proposition_4_3_horner_unit_bound v hzero hadd hmul hnonneg
          x hx cs htailcoeff
      have htaildiff :
          v (ultrametricHorner x cs - ultrametricHorner y cs) ≤ v (x-y) :=
        ih htailcoeff
      have hidentity :
          ultrametricHorner x (c :: cs) - ultrametricHorner y (c :: cs) =
            (x-y) * ultrametricHorner x cs +
              y * (ultrametricHorner x cs - ultrametricHorner y cs) := by
        simp only [ultrametricHorner]
        ring
      have hleft : v ((x-y) * ultrametricHorner x cs) ≤ v (x-y) := by
        calc
          v ((x-y) * ultrametricHorner x cs)
              ≤ v (x-y) * v (ultrametricHorner x cs) := hmul _ _
          _ ≤ v (x-y) * 1 :=
            mul_le_mul_of_nonneg_left htailbound (hnonneg _)
          _ = v (x-y) := by ring
      have hright :
          v (y * (ultrametricHorner x cs - ultrametricHorner y cs)) ≤ v (x-y) := by
        calc
          v (y * (ultrametricHorner x cs - ultrametricHorner y cs))
              ≤ v y * v (ultrametricHorner x cs - ultrametricHorner y cs) := hmul _ _
          _ ≤ 1 * v (ultrametricHorner x cs - ultrametricHorner y cs) :=
            mul_le_mul_of_nonneg_right hy (hnonneg _)
          _ ≤ 1 * v (x-y) := mul_le_mul_of_nonneg_left htaildiff (by norm_num)
          _ = v (x-y) := by ring
      rw [hidentity]
      calc
        v ((x-y) * ultrametricHorner x cs +
            y * (ultrametricHorner x cs - ultrametricHorner y cs))
            ≤ max (v ((x-y) * ultrametricHorner x cs))
                (v (y * (ultrametricHorner x cs - ultrametricHorner y cs))) := hadd _ _
        _ ≤ v (x-y) := max_le hleft hright

/-- A strict ultrametric perturbation cannot change the norm. -/
theorem proposition_4_3_ultrametric_stability
    (v : R → ℝ)
    (hadd : ∀ a b : R, v (a + b) ≤ max (v a) (v b))
    (hneg : ∀ a : R, v (-a) = v a)
    (a b : R) (hsmall : v (a-b) < v b) : v a = v b := by
  have ha : v a ≤ v b := by
    calc
      v a = v ((a-b) + b) := by congr 1; abel
      _ ≤ max (v (a-b)) (v b) := hadd _ _
      _ = v b := max_eq_right (le_of_lt hsmall)
  have hb : v b ≤ v a := by
    by_contra hnot
    have hlt : v a < v b := lt_of_not_ge hnot
    have hsmallrev : v (b-a) < v b := by
      have hrev : b-a = -(a-b) := by abel
      rw [hrev, hneg]
      exact hsmall
    have htri : v b ≤ max (v (b-a)) (v a) := by
      calc
        v b = v ((b-a) + a) := by congr 1; abel
        _ ≤ max (v (b-a)) (v a) := hadd _ _
    exact (not_le_of_gt (max_lt hsmallrev hlt)) htri
  exact le_antisymm ha hb

/-- Abstract ultrametric zero-free disc for an integral-type polynomial.
Only finite coefficient norm bounds and ultrametric laws are assumed. -/
theorem proposition_4_3_horner_zero_free_disk
    (v : R → ℝ) (hzero : v 0 = 0)
    (hadd : ∀ a b : R, v (a + b) ≤ max (v a) (v b))
    (hneg : ∀ a : R, v (-a) = v a)
    (hmul : ∀ a b : R, v (a * b) ≤ v a * v b)
    (hnonneg : ∀ a : R, 0 ≤ v a)
    (x y : R) (hx : v x ≤ 1) (hy : v y ≤ 1) (cs : List R)
    (hcoeff : ∀ c ∈ cs, v c ≤ 1)
    (hyval : 0 < v (ultrametricHorner y cs))
    (hradius : v (x-y) < v (ultrametricHorner y cs)) :
    ultrametricHorner x cs ≠ 0 := by
  have hdiff :
      v (ultrametricHorner x cs - ultrametricHorner y cs) ≤ v (x-y) :=
    proposition_4_3_horner_lipschitz v hzero hadd hmul hnonneg x y hx hy cs hcoeff
  have hsame : v (ultrametricHorner x cs) = v (ultrametricHorner y cs) :=
    proposition_4_3_ultrametric_stability v hadd hneg _ _
      (lt_of_le_of_lt hdiff hradius)
  intro hvanish
  have hzeroeval : v (ultrametricHorner x cs) = 0 := by
    rw [hvanish, hzero]
  rw [hzeroeval] at hsame
  linarith

end PaperOrder.Section4

#print axioms PaperOrder.Section4.proposition_4_3_horner_unit_bound
#print axioms PaperOrder.Section4.proposition_4_3_horner_lipschitz
#print axioms PaperOrder.Section4.proposition_4_3_ultrametric_stability
#print axioms PaperOrder.Section4.proposition_4_3_horner_zero_free_disk
