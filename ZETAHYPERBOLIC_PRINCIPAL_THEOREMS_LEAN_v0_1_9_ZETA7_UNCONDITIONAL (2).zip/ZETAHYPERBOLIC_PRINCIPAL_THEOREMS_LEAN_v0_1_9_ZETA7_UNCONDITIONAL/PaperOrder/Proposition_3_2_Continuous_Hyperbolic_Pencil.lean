import PaperOrder.Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk

/-!
# Proposition 3.2 — Continuous hyperbolic pencil for all real s > 1

This file establishes the COMPLETE FINITE SPECTRAL IMPLICATION in Proposition
3.2: any real symmetric affine pencil with positive-definite center and
invertible derivative has a degree-n determinant and exclusively real roots.
It does NOT assert the PDF's full continuous positive weight and its claimed
odd-integer specialization; its displayed prefactor requires correction.
Thus Proposition 3.2 remains PARTIAL, not witness-free fully formalized.
-/

noncomputable section
open Polynomial

namespace PaperOrder.Section3

/-- The generic spectral transfer, with independently checkable premises. -/
theorem proposition_3_2_abstract_degree {n : ℕ}
    (p : ManuscriptChain.Spectral.SymmetricAffinePencil n)
    (hG : p.base.PosDef)
    (hM : Matrix.det p.direction ≠ 0) :
    p.detPolynomial.natDegree = n :=
  ManuscriptChain.Spectral.theorem_3_1_degree_of_posDef p hG hM

/-- Roots of the generic positive real pencil are real. -/
theorem proposition_3_2_abstract_roots_real {n : ℕ}
    (p : ManuscriptChain.Spectral.SymmetricAffinePencil n)
    (hG : p.base.PosDef)
    (hM : Matrix.det p.direction ≠ 0)
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial = 0) :
    z.im = 0 :=
  ManuscriptChain.Spectral.theorem_3_1_hyperbolicity_of_posDef p hG hM z hz

end PaperOrder.Section3

#print axioms PaperOrder.Section3.proposition_3_2_abstract_degree
#print axioms PaperOrder.Section3.proposition_3_2_abstract_roots_real
