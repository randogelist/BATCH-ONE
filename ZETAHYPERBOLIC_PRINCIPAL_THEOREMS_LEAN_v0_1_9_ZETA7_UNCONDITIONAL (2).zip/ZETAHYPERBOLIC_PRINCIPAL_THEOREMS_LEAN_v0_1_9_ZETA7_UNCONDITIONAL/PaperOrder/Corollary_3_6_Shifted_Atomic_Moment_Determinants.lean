import PaperOrder.Corollary_3_6_Rectangular_Moment_Gram

/-!
# Corollary 3.6 — shifted finite Hankel determinant positivity

For n distinct positive real atoms with positive weights, ALL uniform
nonnegative shifts of the n-by-n moment determinant remain strictly
positive. Algebraically a shift is absorbed into new masses w_k*x_k^(2q).
This is a precise finite positive moment statement, not an assertion about
the manuscript's continuous moment measure or infinite Hankel orders.
-/

noncomputable section
open scoped BigOperators
namespace PaperOrder.CoreAlgebra

/-- Moment determinant formed from degrees q through q+n-1. -/
def shiftedAtomicMomentMatrix {n : ℕ}
    (x w : Fin n → ℝ) (q : ℕ) : Matrix (Fin n) (Fin n) ℝ :=
  fun i j => ∑ k : Fin n, w k * x k ^ (2 * q + (i.val + j.val))

/-- A shift by q in both degree indices scales each atomic mass by x_k^(2q). -/
theorem shiftedAtomicMomentMatrix_eq {n : ℕ}
    (x w : Fin n → ℝ) (q : ℕ) :
    shiftedAtomicMomentMatrix x w q =
      atomicMomentMatrix x (fun k => w k * x k ^ (2 * q)) := by
  ext i j
  simp only [shiftedAtomicMomentMatrix, atomicMomentMatrix]
  apply Finset.sum_congr rfl
  intro k hk
  rw [pow_add]
  ring

/-- Every uniform shift preserves strict positivity of the full-size
finite Hankel determinant of distinct POSITIVE atoms. -/
theorem shiftedAtomicMomentMatrix_det_pos {n : ℕ}
    (x w : Fin n → ℝ)
    (hx : Function.Injective x)
    (hxpos : ∀ k : Fin n, 0 < x k)
    (hw : ∀ k : Fin n, 0 < w k)
    (q : ℕ) : 0 < (shiftedAtomicMomentMatrix x w q).det := by
  rw [shiftedAtomicMomentMatrix_eq]
  exact atomicMomentMatrix_det_pos x (fun k => w k * x k ^ (2 * q))
    hx (fun k => mul_pos (hw k) (pow_pos (hxpos k) _))

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.shiftedAtomicMomentMatrix_eq
#print axioms PaperOrder.CoreAlgebra.shiftedAtomicMomentMatrix_det_pos
