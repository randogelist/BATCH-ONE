import MAIN_CHAIN_CORE_ALGEBRA_95_FRONTIER
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

/-!
# Corollary 3.6 — General finite atomic Hankel determinants

This replaces the two-atom example by a theorem for EVERY finite number
of distinct real support points with positive masses.  It constructs the
moment matrix with entries Σ w_k x_k^(i+j), proves its exact Vandermonde
Gram factorization, and proves strict positivity of the full-size
Hankel determinant.  This is a finite atomic theorem, not the paper's
continuous-measure strict-total-positivity theorem.
-/

noncomputable section
open scoped BigOperators

namespace PaperOrder.CoreAlgebra

/-- Matrix of monomials evaluated at n support points (rows are degrees). -/
def atomicVandermonde {n : ℕ} (x : Fin n → ℝ) :
    Matrix (Fin n) (Fin n) ℝ := fun i k => x k ^ i.val

/-- The full n-by-n Hankel matrix of a finite weighted atomic measure. -/
def atomicMomentMatrix {n : ℕ} (x w : Fin n → ℝ) :
    Matrix (Fin n) (Fin n) ℝ :=
  fun i j => ∑ k : Fin n, w k * x k ^ (i.val + j.val)

/-- Exact Gram/Vandermonde decomposition, for arbitrary real node values
and masses (positivity is NOT needed for the identity). -/
theorem atomicMomentMatrix_factorization {n : ℕ} (x w : Fin n → ℝ) :
    atomicMomentMatrix x w =
      atomicVandermonde x * Matrix.diagonal w *
        (atomicVandermonde x).transpose := by
  ext i j
  unfold atomicMomentMatrix
  rw [Matrix.mul_apply]
  simp only [Matrix.mul_diagonal, Matrix.transpose_apply]
  change (∑ k : Fin n, w k * x k ^ (i.val + j.val)) =
    ∑ k : Fin n, (x k ^ i.val * w k) * x k ^ j.val
  apply Finset.sum_congr rfl
  intro k hk
  rw [pow_add]
  ring

/-- The determinant is the square of the Vandermonde times the mass product. -/
theorem atomicMomentMatrix_det {n : ℕ} (x w : Fin n → ℝ) :
    (atomicMomentMatrix x w).det =
      (atomicVandermonde x).det ^ 2 * ∏ k : Fin n, w k := by
  rw [atomicMomentMatrix_factorization, Matrix.det_mul, Matrix.det_mul,
    Matrix.det_diagonal, Matrix.det_transpose]
  ring

/-- Exactly n distinct support nodes and n strictly positive masses
imply a strictly positive n-by-n moment determinant, for ALL n. -/
theorem atomicMomentMatrix_det_pos {n : ℕ} (x w : Fin n → ℝ)
    (hx : Function.Injective x) (hw : ∀ k : Fin n, 0 < w k) :
    0 < (atomicMomentMatrix x w).det := by
  have hV : (atomicVandermonde x).det ≠ 0 := by
    have htrans : atomicVandermonde x = (Matrix.vandermonde x).transpose := rfl
    rw [htrans, Matrix.det_transpose]
    exact Matrix.det_vandermonde_ne_zero_iff.mpr hx
  have hmass : 0 < ∏ k : Fin n, w k :=
    Finset.prod_pos (fun k _ => hw k)
  rw [atomicMomentMatrix_det]
  exact mul_pos (sq_pos_of_ne_zero hV) hmass

/-- In particular the corresponding atomic Hankel determinant is nonzero. -/
theorem atomicMomentMatrix_det_ne_zero {n : ℕ} (x w : Fin n → ℝ)
    (hx : Function.Injective x) (hw : ∀ k : Fin n, 0 < w k) :
    (atomicMomentMatrix x w).det ≠ 0 :=
  ne_of_gt (atomicMomentMatrix_det_pos x w hx hw)

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.atomicMomentMatrix_factorization
#print axioms PaperOrder.CoreAlgebra.atomicMomentMatrix_det_pos
