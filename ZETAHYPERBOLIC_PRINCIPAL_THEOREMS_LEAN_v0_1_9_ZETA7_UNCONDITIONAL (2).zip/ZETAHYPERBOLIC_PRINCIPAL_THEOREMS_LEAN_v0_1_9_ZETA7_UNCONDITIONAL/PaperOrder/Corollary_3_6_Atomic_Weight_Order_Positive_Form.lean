import PaperOrder.Corollary_3_6_Rectangular_Atomic_Quadratic_SOS

/-!
# Corollary 3.6: order structure on arbitrary finite atomic Hankel forms

The quadratic form of an arbitrary rectangular atomic Hankel matrix is
linear in its masses, and monotone under pointwise increasing masses.
Strict positivity persists under nonnegative increases of a separating,
strictly positive-weight atomic measure. These are genuine n-atom,
r-by-r algebraic theorems, not a claim about a continuous measure.
-/

noncomputable section
open scoped BigOperators
namespace PaperOrder.CoreAlgebra

/-- Additivity of the entire Hankel quadratic form in atomic masses. -/
theorem rectangularAtomicQuadraticForm_mass_add {r n : ℕ}
    (x w u : Fin n → ℝ) (v : Fin r → ℝ) :
    rectangularAtomicQuadraticForm x (fun k => w k + u k) v =
      rectangularAtomicQuadraticForm x w v +
        rectangularAtomicQuadraticForm x u v := by
  simp only [rectangularAtomicQuadraticForm_sos, add_mul,
    Finset.sum_add_distrib]

/-- Quadratic-form Loewner order of finite atomic moment matrices is
monotone in every individual atom weight. -/
theorem rectangularAtomicQuadraticForm_mass_mono {r n : ℕ}
    (x w u : Fin n → ℝ)
    (hw : ∀ k : Fin n, w k ≤ u k) (v : Fin r → ℝ) :
    rectangularAtomicQuadraticForm x w v ≤
      rectangularAtomicQuadraticForm x u v := by
  rw [rectangularAtomicQuadraticForm_sos,
    rectangularAtomicQuadraticForm_sos]
  apply Finset.sum_le_sum
  intro k hk
  exact mul_le_mul_of_nonneg_right (hw k) (sq_nonneg _)

/-- Every strict finite Gram positivity certificate survives a
pointwise increase of the atomic weights. -/
theorem rectangularAtomicQuadraticForm_pos_of_mass_increase {r n : ℕ}
    (x w u : Fin n → ℝ)
    (hx : atomicEvaluationSeparates (r := r) x)
    (hw : ∀ k : Fin n, 0 < w k)
    (hwu : ∀ k : Fin n, w k ≤ u k)
    (v : Fin r → ℝ) (hv : v ≠ 0) :
    0 < rectangularAtomicQuadraticForm x u v := by
  exact lt_of_lt_of_le
    (rectangularAtomicQuadraticForm_pos_of_separation x w hx hw v hv)
    (rectangularAtomicQuadraticForm_mass_mono x w u hwu v)

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.rectangularAtomicQuadraticForm_mass_add
#print axioms PaperOrder.CoreAlgebra.rectangularAtomicQuadraticForm_mass_mono
#print axioms PaperOrder.CoreAlgebra.rectangularAtomicQuadraticForm_pos_of_mass_increase
