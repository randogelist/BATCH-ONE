import PaperOrder.Theorem_3_8_Finite_Christoffel_Darboux_Pole_Kernel

/-!
# Theorem 3.9 — Dirichlet-character Fekete polynomial factorizations

These are the five explicit character-polynomial identities used in the
paper for q in {3, 4, 5, 8}. We prove their positivity for 0<z<1,
including both primitive real characters modulo 8. The analytic
Dirichlet L-function moment realization and global real-rootedness
are not concluded here.
-/

namespace PaperOrder.Section3

/-- The conductor-3 character polynomial. -/
theorem theorem_3_9_fekete_minus_three (z : ℝ) :
    z - z^2 = z*(1-z) := by ring

/-- The conductor-4 character polynomial. -/
theorem theorem_3_9_fekete_minus_four (z : ℝ) :
    z - z^3 = z*(1-z^2) := by ring

/-- The primitive even character modulo 5. -/
theorem theorem_3_9_fekete_five (z : ℝ) :
    z - z^2 - z^3 + z^4 = z*(1-z)^2*(1+z) := by ring

/-- The primitive even character modulo 8. -/
theorem theorem_3_9_fekete_eight (z : ℝ) :
    z - z^3 - z^5 + z^7 = z*(1-z^2)*(1-z^4) := by ring

/-- The primitive odd character modulo 8. -/
theorem theorem_3_9_fekete_minus_eight (z : ℝ) :
    z + z^3 - z^5 - z^7 = z*(1+z^2)*(1-z^4) := by ring

private theorem unit_interval_square_gap (z : ℝ) (hz : 0 < z) (h1 : z < 1) :
    0 < 1 - z^2 := by
  have hp : 0 < 1 - z := sub_pos.mpr h1
  have hq : 0 < 1 + z := by linarith
  have hh := mul_pos hp hq
  nlinarith

private theorem unit_interval_fourth_gap (z : ℝ) (hz : 0 < z) (h1 : z < 1) :
    0 < 1 - z^4 := by
  have h2 := unit_interval_square_gap z hz h1
  have hp : 0 < 1 + z^2 := by positivity
  have hh := mul_pos h2 hp
  nlinarith

/-- Positivity of the conductor-3 Fekete polynomial on (0,1). -/
theorem theorem_3_9_fekete_minus_three_positive (z : ℝ)
    (hz : 0 < z) (h1 : z < 1) : 0 < z - z^2 := by
  rw [theorem_3_9_fekete_minus_three]
  exact mul_pos hz (sub_pos.mpr h1)

/-- Positivity of the conductor-4 Fekete polynomial on (0,1). -/
theorem theorem_3_9_fekete_minus_four_positive (z : ℝ)
    (hz : 0 < z) (h1 : z < 1) : 0 < z - z^3 := by
  rw [theorem_3_9_fekete_minus_four]
  exact mul_pos hz (unit_interval_square_gap z hz h1)

/-- Positivity of the conductor-5 Fekete polynomial on (0,1). -/
theorem theorem_3_9_fekete_five_positive (z : ℝ)
    (hz : 0 < z) (h1 : z < 1) : 0 < z - z^2 - z^3 + z^4 := by
  rw [theorem_3_9_fekete_five]
  have hm : 0 < 1-z := sub_pos.mpr h1
  have hp : 0 < 1+z := by linarith
  exact mul_pos (mul_pos hz (pow_pos hm 2)) hp

/-- Positivity of the even character modulo 8 Fekete polynomial. -/
theorem theorem_3_9_fekete_eight_positive (z : ℝ)
    (hz : 0 < z) (h1 : z < 1) : 0 < z - z^3 - z^5 + z^7 := by
  rw [theorem_3_9_fekete_eight]
  exact mul_pos (mul_pos hz (unit_interval_square_gap z hz h1))
    (unit_interval_fourth_gap z hz h1)

/-- Positivity of the odd character modulo 8 Fekete polynomial. -/
theorem theorem_3_9_fekete_minus_eight_positive (z : ℝ)
    (hz : 0 < z) (h1 : z < 1) : 0 < z + z^3 - z^5 - z^7 := by
  rw [theorem_3_9_fekete_minus_eight]
  have hp : 0 < 1 + z^2 := by positivity
  exact mul_pos (mul_pos hz hp) (unit_interval_fourth_gap z hz h1)

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_9_fekete_minus_three_positive
#print axioms PaperOrder.Section3.theorem_3_9_fekete_minus_four_positive
#print axioms PaperOrder.Section3.theorem_3_9_fekete_five_positive
#print axioms PaperOrder.Section3.theorem_3_9_fekete_eight_positive
#print axioms PaperOrder.Section3.theorem_3_9_fekete_minus_eight_positive
