import PaperOrder.Theorem_3_4_Singular_Principal_Slope_Degree_Drop

/-!
# Dodgson condensation: symmetric 3-by-3 scalar form

This is the exact three-level Desnanot-Jacobi identity written in the
independent entries of a symmetric 3x3 matrix. It adds a nontrivial level
to the previously checked order-two base case without requiring any false
assumption that all principal derivatives are invertible.
-/

namespace PaperOrder.CoreAlgebra

/-- Expanded determinant expression of [[a,b,c],[b,d,e],[c,e,f]]. -/
def symmetricThreeDetExpr (a b c d e f : ℝ) : ℝ :=
  a * d * f + 2 * b * c * e - a * e^2 - d * c^2 - f * b^2

/-- The 3x3 Dodgson identity pivoted at its central entry d. -/
theorem dodgson_three_by_three (a b c d e f : ℝ) :
    d * symmetricThreeDetExpr a b c d e f =
      (a*d-b^2)*(d*f-e^2) - (b*e-c*d)^2 := by
  unfold symmetricThreeDetExpr
  ring

/-- If the first 2x2 minor vanishes at a point where the central pivot
is positive, the full 3x3 determinant expression cannot be positive. -/
theorem dodgson_three_at_root_nonpositive
    (a b c d e f : ℝ)
    (hd : 0 < d) (hroot : a*d-b^2 = 0) :
    symmetricThreeDetExpr a b c d e f ≤ 0 := by
  have h := dodgson_three_by_three a b c d e f
  rw [hroot, zero_mul, zero_sub] at h
  by_contra hbad
  have hpos : 0 < symmetricThreeDetExpr a b c d e f :=
    lt_of_not_ge hbad
  have hmul : 0 < d * symmetricThreeDetExpr a b c d e f :=
    mul_pos hd hpos
  nlinarith [sq_nonneg (b*e-c*d)]

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.dodgson_three_by_three
#print axioms PaperOrder.CoreAlgebra.dodgson_three_at_root_nonpositive
