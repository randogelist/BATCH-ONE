import PaperOrder.Theorem_3_7_Turanian_And_Newton_Quadratic_Case

/-!
# Theorem 3.8 — finite Christoffel–Darboux pole-kernel algebra

The paper identifies the normalized pencil with its finite pole kernel
through V^T G^{-1} V. This module proves general finite kernel symmetry
when the inverse Gram coefficients are symmetric, as well as positivity
of explicitly factorized diagonal kernels. Establishing the analytical
inverse-Gram representation for the actual odd-zeta measure remains a
separate part of the manuscript theorem.
-/

open scoped BigOperators
namespace PaperOrder.Section3

/-- Bilinear finite pole kernel associated with a coefficient matrix. -/
def finitePoleKernel {n : ℕ}
    (M : Matrix (Fin n) (Fin n) ℝ)
    (u v : Fin n → ℝ) : ℝ :=
  ∑ i : Fin n, ∑ j : Fin n, u i * M i j * v j

/-- Symmetry follows from symmetry of the finite inverse-Gram matrix. -/
theorem theorem_3_8_finite_pole_kernel_symmetric {n : ℕ}
    (M : Matrix (Fin n) (Fin n) ℝ)
    (hM : ∀ i j, M i j = M j i)
    (u v : Fin n → ℝ) :
    finitePoleKernel M u v = finitePoleKernel M v u := by
  unfold finitePoleKernel
  calc
    (∑ i : Fin n, ∑ j : Fin n, u i * M i j * v j)
        = ∑ j : Fin n, ∑ i : Fin n, u i * M i j * v j := by
          rw [Finset.sum_comm]
    _ = ∑ j : Fin n, ∑ i : Fin n, v j * M j i * u i := by
          apply Finset.sum_congr rfl
          intro j hj
          apply Finset.sum_congr rfl
          intro i hi
          rw [hM i j]
          ring

/-- Nonnegativity of the diagonal of a finite factorized (Gram) kernel.
This is the finite sum-of-squares mechanism behind the CD kernel. -/
theorem theorem_3_8_finite_gram_kernel_nonnegative
    {n r : ℕ} (V : Matrix (Fin r) (Fin n) ℝ) (u : Fin n → ℝ) :
    0 ≤ ∑ k : Fin r, (∑ i : Fin n, V k i * u i)^2 := by
  apply Finset.sum_nonneg
  intro k hk
  exact sq_nonneg _

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_8_finite_pole_kernel_symmetric
#print axioms PaperOrder.Section3.theorem_3_8_finite_gram_kernel_nonnegative
