import PaperOrder.Theorem_2_4_Canonical_Basis_Invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization
import Zetahyperbolic.LagrangeBasis

/-!
# Theorem 2.5 — Lagrange pole diagonalization (PDF pp. 6-7)

Includes genuine Lagrange interpolation at -a², the rational Vandermonde
congruence, nonzero pole weights, diagonal/constant decomposition of the
X-dependence and exact determinant degree.
-/

noncomputable section
open Polynomial

namespace PaperOrder.Section2

/-- Formula (2.10), evaluated on the negative-square pole lattice. -/
theorem theorem_2_5_lagrange_evaluation (N K a b : ℕ)
    (ha : a ∈ Finset.Icc (N + 1) K)
    (hb : b ∈ Finset.Icc (N + 1) K) :
    Polynomial.eval (-((b : ℚ) ^ 2))
        (Zetahyperbolic.lagrangePolePolynomial N K a) =
      if a = b then 1 else 0 :=
  Zetahyperbolic.lagrangePolePolynomial_eval N K a b ha hb

/-- Formula (2.11), X-diagonalization, and exact polynomial degree. -/
theorem theorem_2_5_pencil_and_degree (p : ManuscriptChain.Real.Parameters) :
    ((∀ a b : Fin p.h, a ≠ b →
      ManuscriptChain.PoleDiagonalization.poleDiagonalPencil p a b =
        Polynomial.C (ManuscriptChain.PoleDiagonalization.poleConstantMatrix p a b)) ∧
    (∀ a : Fin p.h,
      ManuscriptChain.PoleDiagonalization.poleDiagonalPencil p a a =
        Polynomial.C (ManuscriptChain.PoleDiagonalization.poleWeight p a) *
          (Polynomial.X - Polynomial.C
            (ManuscriptChain.Real.harmonic p.weight
              (ManuscriptChain.PoleDiagonalization.poleIndex p a))) +
          Polynomial.C (ManuscriptChain.PoleDiagonalization.poleDiagonalRemainder p a) ∧
      ManuscriptChain.PoleDiagonalization.poleWeight p a ≠ 0)) ∧
    (ManuscriptChain.Real.delta p).natDegree = p.h := by
  have h := ManuscriptChain.PoleDiagonalization.theorem_2_5_lagrange_pole_diagonalization p
  exact ⟨h, ManuscriptChain.PoleDiagonalization.delta_natDegree p⟩

end PaperOrder.Section2

#print axioms PaperOrder.Section2.theorem_2_5_lagrange_evaluation
#print axioms PaperOrder.Section2.theorem_2_5_pencil_and_degree
