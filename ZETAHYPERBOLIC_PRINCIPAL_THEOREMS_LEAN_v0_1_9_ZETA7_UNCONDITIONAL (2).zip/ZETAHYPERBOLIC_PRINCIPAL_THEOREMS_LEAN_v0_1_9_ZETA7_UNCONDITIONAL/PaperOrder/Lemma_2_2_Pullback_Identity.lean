import PaperOrder.Definition_2_1_Order_s_Rational_Moment_Functional

/-!
# Lemma 2.2 — Pullback identity (PDF p. 4)

The existing Section2Checked source establishes the two generator cases.
By ℚ-linearity we assemble them into a single equality on every finite
polynomial-plus-simple-pole normal form `RatMomentElem`.  This is the actual
functional's normal-form representation, not an assumed identity. The map
`tauPullbackNormalForm` records the tau-evaluation of x^(2k+1) R(-x²)
via the explicit generator decomposition; no analytic assumption is used.
-/

noncomputable section
open Polynomial
open scoped BigOperators

namespace PaperOrder.Section2
open Zetahyperbolic

/-- Paper (2.5), monomial generator. -/
theorem lemma_2_2_monomial (k e : ℕ) (hk : 1 ≤ k) :
    muMonomial k e = (-1 : ℚ) ^ e * tauMonomial k (2 * e + 2 * k + 1) :=
  Zetahyperbolic.pullback_identity_monomial k e hk

/-- Paper (2.5), simple-pole generator. -/
theorem lemma_2_2_pole (k j : ℕ) (hk : 1 ≤ k) (hj : 1 ≤ j) :
    muPolePoly k j =
      Polynomial.C (-tauMonomial k (2 * k - 1)) -
        Polynomial.C ((j : ℚ) ^ (2 * k) / 2) *
          (tauPolePoly k (j : ℤ) + tauPolePoly k (-(j : ℤ))) :=
  Zetahyperbolic.pullback_identity_pole k j hk hj

/-- Tau evaluation of the transformed *finite normal form*. -/
noncomputable def tauPullbackNormalForm (k : ℕ) (R : RatMomentElem) : ℚ[X] :=
  (∑ e ∈ Finset.range (R.polyPart.natDegree + 1),
    Polynomial.C (R.polyPart.coeff e *
      ((-1 : ℚ) ^ e * tauMonomial k (2 * e + 2 * k + 1)))) +
  ∑ j ∈ Finset.Icc 1 R.maxPole,
    Polynomial.C (R.poleRes j) *
      (Polynomial.C (-tauMonomial k (2 * k - 1)) -
        Polynomial.C ((j : ℚ) ^ (2 * k) / 2) *
          (tauPolePoly k (j : ℤ) + tauPolePoly k (-(j : ℤ))))

/-- Full ℚ-linear assembly on the decomposition used by the paper. -/
theorem lemma_2_2_normal_form (k : ℕ) (hk : 1 ≤ k) (R : RatMomentElem) :
    muFunctionalPoly k R = tauPullbackNormalForm k R := by
  unfold muFunctionalPoly tauPullbackNormalForm
  apply congrArg₂ (· + ·)
  · apply Finset.sum_congr rfl
    intro e he
    rw [lemma_2_2_monomial k e hk]
  · apply Finset.sum_congr rfl
    intro j hj
    have hj1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
    rw [lemma_2_2_pole k j hk hj1]

end PaperOrder.Section2

#print axioms PaperOrder.Section2.lemma_2_2_monomial
#print axioms PaperOrder.Section2.lemma_2_2_pole
#print axioms PaperOrder.Section2.lemma_2_2_normal_form
