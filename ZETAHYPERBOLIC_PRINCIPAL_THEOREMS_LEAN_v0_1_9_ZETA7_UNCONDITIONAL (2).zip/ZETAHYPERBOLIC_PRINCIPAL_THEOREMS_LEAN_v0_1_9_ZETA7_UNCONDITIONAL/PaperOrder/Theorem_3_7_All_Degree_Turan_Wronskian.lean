import PaperOrder.Theorem_3_4_Degenerate_Pencil_Consequences
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

/-!
# Theorem 3.7: universal first Turán Wronskian for real-rooted polynomials

This is genuinely for every finite degree, unlike the earlier quadratic and
cubic special cases. The argument is a polynomial identity preserved under
multiplication by each real linear factor. No analyticity or spectral bounds.

T(P) := (P')² - P P''.
T((X-a)P) = (X-a)² T(P) + P².
The latter identity makes nonnegativity immediate by induction on the list of
real roots; multiplicities are allowed. Only m=1 is proved, not every
higher derivative order asserted in the paper.
-/

noncomputable section
open Polynomial

namespace PaperOrder.CoreAlgebra

/-- Polynomial represented by its complete list of real roots. -/
def rootListPolynomial : List ℝ → Polynomial ℝ
  | [] => 1
  | a :: as => (X - C a) * rootListPolynomial as

/-- First Turán/Laguerre Wronskian. -/
def turanWronskian (P : Polynomial ℝ) : Polynomial ℝ :=
  derivative P * derivative P - P * derivative (derivative P)

/-- Exact one-factor induction step, in polynomial equality (not merely
an inequality after evaluation). -/
theorem turanWronskian_mul_linear (a : ℝ) (P : Polynomial ℝ) :
    turanWronskian ((X - C a) * P) =
      (X - C a)^2 * turanWronskian P + P^2 := by
  unfold turanWronskian
  -- The second derivative of a product contains the derivative of a sum.
  -- The previous simplifier omitted `derivative_add`, so `ring` was left
  -- with a non-expanded derivative and the induction acquired `sorryAx`.
  simp only [derivative_mul, derivative_add, derivative_sub,
    derivative_X, derivative_C, sub_zero, zero_mul,
    zero_add, one_mul]
  ring

/-- All-degree real-rooted Turán inequality for the first derivative. -/
theorem turanWronskian_rootList_nonneg (roots : List ℝ) (x : ℝ) :
    0 ≤ (turanWronskian (rootListPolynomial roots)).eval x := by
  induction roots with
  | nil =>
      simp [rootListPolynomial, turanWronskian]
  | cons a tail ih =>
      change 0 ≤ (turanWronskian ((X - C a) * rootListPolynomial tail)).eval x
      rw [turanWronskian_mul_linear]
      simp only [eval_add, eval_mul, eval_pow, eval_sub, eval_X, eval_C]
      exact add_nonneg (mul_nonneg (sq_nonneg _) ih) (sq_nonneg _)

/-- Strict positivity away from all real roots (for positive degree). -/
theorem turanWronskian_rootList_strict (a : ℝ) (tail : List ℝ)
    (x : ℝ) (hx : (rootListPolynomial (a :: tail)).eval x ≠ 0) :
    0 < (turanWronskian (rootListPolynomial (a :: tail))).eval x := by
  have htail : (rootListPolynomial tail).eval x ≠ 0 := by
    intro ht
    apply hx
    simp [rootListPolynomial, ht]
  have hpos : 0 < ((rootListPolynomial tail).eval x)^2 :=
    sq_pos_of_ne_zero htail
  have hnonneg := turanWronskian_rootList_nonneg tail x
  change 0 < (turanWronskian ((X - C a) * rootListPolynomial tail)).eval x
  rw [turanWronskian_mul_linear]
  simp only [eval_add, eval_mul, eval_pow, eval_sub, eval_X, eval_C]
  exact add_pos_of_nonneg_of_pos (mul_nonneg (sq_nonneg _) hnonneg) hpos

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.turanWronskian_rootList_nonneg
#print axioms PaperOrder.CoreAlgebra.turanWronskian_rootList_strict
