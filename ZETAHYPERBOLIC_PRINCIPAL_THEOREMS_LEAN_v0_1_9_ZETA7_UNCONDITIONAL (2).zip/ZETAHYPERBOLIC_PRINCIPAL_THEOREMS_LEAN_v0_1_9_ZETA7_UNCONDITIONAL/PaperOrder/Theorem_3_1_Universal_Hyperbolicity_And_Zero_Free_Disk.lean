import PaperOrder.Theorem_2_5_Lagrange_Pole_Diagonalization
import MAIN_CHAIN_ASSEMBLED

/-!
# Theorem 3.1 — Universal hyperbolicity and zero-free disk (PDF pp. 7-8)

The concrete positive integral representation is already constructed in the
assembled source. This endpoint has NO analytic hypothesis and applies to
all admissible odd weights; it is not specialized to zeta(5).
-/

noncomputable section
namespace PaperOrder.Section3

/-- General odd weight statement for the paper's actual Hankel pencil. -/
theorem theorem_3_1_universal_hyperbolicity
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- Exact positive zero-free disk, with a root attaining its radius. -/
theorem theorem_3_1_exact_zero_free_disk
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ < radius →
        ¬ ManuscriptChain.General.ComplexRoot p z) ∧
      (∃ z : ℂ, ManuscriptChain.General.ComplexRoot p z ∧
        ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ = radius) :=
  ManuscriptChain.EXACT_ZERO_FREE_DISK p hp

end PaperOrder.Section3

#print axioms PaperOrder.Section3.theorem_3_1_universal_hyperbolicity
#print axioms PaperOrder.Section3.theorem_3_1_exact_zero_free_disk
