import MAIN_CHAIN_PAPER_ORDER_SECTION4A

/-!
# Theorem 4.4 — exact finite spectral zero-free disk

This is the algebraic part of the manuscript's gap inequality: the
relative eigenvalue beta obeys beta*(xi-root)=1, so a positive upper
bound on |beta| gives a positive lower bound for |root-xi|. The full
exponential matrix-norm estimate is NOT asserted in this module.
-/

namespace PaperOrder.Section4

/-- A bounded nonzero relative eigenvalue gives a quantitative zero-free
radius around the center. The nonzero property follows from the root
relation itself, and is not an assumed analytic estimate. -/
theorem theorem_4_4_root_gap_of_bounded_beta
    (ξ β r B : ℝ) (hB : 0 < B)
    (hβ : |β| ≤ B) (hroot : β * (ξ - r) = 1) :
    1 / B ≤ |ξ - r| := by
  have hproduct : |β| * |ξ - r| = 1 := by
    rw [← abs_mul, hroot, abs_one]
  have hbound : (1 : ℝ) ≤ B * |ξ - r| := by
    calc
      (1 : ℝ) = |β| * |ξ - r| := hproduct.symm
      _ ≤ B * |ξ - r| := mul_le_mul_of_nonneg_right hβ (abs_nonneg _)
  exact (div_le_iff₀ hB).2 (by nlinarith [hbound])

/-- Two roots separated by the center and obeying the same spectral gap
have an exact two-sided separation, without asymptotic assumptions. -/
theorem theorem_4_4_opposite_root_separation
    (ξ rminus rplus δ : ℝ)
    (hleft : rminus ≤ ξ - δ) (hright : ξ + δ ≤ rplus) :
    2 * δ ≤ rplus - rminus := by
  linarith

end PaperOrder.Section4

#print axioms PaperOrder.Section4.theorem_4_4_root_gap_of_bounded_beta
#print axioms PaperOrder.Section4.theorem_4_4_opposite_root_separation
