import PaperOrder.Theorem_3_4_Degenerate_Pencil_Consequences

/-!
# Principal theorem 3.4 — corrected arbitrary-principal-minor hyperbolicity

The printed stronger assertion of universal root interlacing requires
correction: a principal slope can be singular, and such a minor need not
have r finite roots. What DOES follow in every rank is proved here:

For every injective selection of principal rows/columns from a symmetric
pencil with positive definite Gram base, the selected principal pencil
has a positive definite base, all its complex determinant zeros are real,
and its determinant is nonzero at the center. No slope determinant is
assumed nonzero; no nonexistent roots are introduced.
-/

noncomputable section
open ManuscriptChain.Spectral

namespace PaperOrder.PrincipalTheorems

/-- Genuine symmetric affine pencil of an arbitrary principal submatrix. -/
def selectedPrincipalPencil {n r : ℕ}
    (p : SymmetricAffinePencil n) (e : Fin r → Fin n) :
    SymmetricAffinePencil r where
  center := p.center
  base := p.base.submatrix e e
  direction := p.direction.submatrix e e
  base_symmetric := by
    ext i j
    have h := congrArg (fun M : Matrix (Fin n) (Fin n) ℝ => M (e i) (e j))
      p.base_symmetric
    simpa [Matrix.transpose_apply, Matrix.submatrix] using h
  direction_symmetric := by
    ext i j
    have h := congrArg (fun M : Matrix (Fin n) (Fin n) ℝ => M (e i) (e j))
      p.direction_symmetric
    simpa [Matrix.transpose_apply, Matrix.submatrix] using h

/-- The new pencil is exactly the selected principal submatrix at x. -/
theorem selectedPrincipalPencil_matrixAt {n r : ℕ}
    (p : SymmetricAffinePencil n) (e : Fin r → Fin n) (x : ℝ) :
    (selectedPrincipalPencil p e).matrixAt x =
      (p.matrixAt x).submatrix e e := by
  ext i j
  simp [selectedPrincipalPencil, SymmetricAffinePencil.matrixAt,
    Matrix.submatrix, Matrix.add_apply, Matrix.smul_apply]

/-- The positive Gram base remains positive on every (possibly lower-order)
    principal submatrix. This is the necessary hypothesis for the correct
    real-rootedness statement, even in the rank-deficient slope case. -/
theorem selectedPrincipalPencil_base_posDef {n r : ℕ}
    (p : SymmetricAffinePencil n) (hbase : p.base.PosDef)
    (e : Fin r → Fin n) (he : Function.Injective e) :
    (selectedPrincipalPencil p e).base.PosDef := by
  exact hbase.submatrix he

/-- Every complex root of EVERY principal minor is real, even if the
    corresponding slope is singular and some expected roots disappear. -/
theorem corrected_theorem_3_4_all_principal_zeros_real {n r : ℕ}
    (p : SymmetricAffinePencil n) (hbase : p.base.PosDef)
    (e : Fin r → Fin n) (he : Function.Injective e)
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (selectedPrincipalPencil p e).detPolynomial = 0) :
    z.im = 0 :=
  PaperOrder.CoreAlgebra.all_complex_roots_real_even_if_slope_singular
    (selectedPrincipalPencil p e)
    (selectedPrincipalPencil_base_posDef p hbase e he) z hz

/-- Every principal minor polynomial is nonzero at the center; its
    positivity at the center is independent of derivative rank. -/
theorem corrected_theorem_3_4_principal_center_nonzero {n r : ℕ}
    (p : SymmetricAffinePencil n) (hbase : p.base.PosDef)
    (e : Fin r → Fin n) (he : Function.Injective e) :
    (selectedPrincipalPencil p e).detPolynomial.eval p.center ≠ 0 := by
  exact PaperOrder.CoreAlgebra.weak_pencil_center_nonzero
    (selectedPrincipalPencil p e)
    (selectedPrincipalPencil_base_posDef p hbase e he)

end PaperOrder.PrincipalTheorems

#print axioms PaperOrder.PrincipalTheorems.selectedPrincipalPencil_base_posDef
#print axioms PaperOrder.PrincipalTheorems.corrected_theorem_3_4_all_principal_zeros_real
#print axioms PaperOrder.PrincipalTheorems.corrected_theorem_3_4_principal_center_nonzero
