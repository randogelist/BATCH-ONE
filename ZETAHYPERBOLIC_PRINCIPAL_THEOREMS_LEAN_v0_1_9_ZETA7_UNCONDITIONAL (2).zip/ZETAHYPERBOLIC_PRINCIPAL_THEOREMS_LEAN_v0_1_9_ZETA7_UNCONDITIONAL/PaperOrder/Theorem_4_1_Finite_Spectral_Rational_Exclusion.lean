import MAIN_CHAIN_PAPER_ORDER_SECTION3
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion

/-!
# Theorem 4.1: finite integer–spectral exclusion

The integer-value obstruction is a theorem, not an additional hypothesis.
It applies to the actual spectral factorization and an integral polynomial
normalization whenever the finite evaluation budget is small enough.

This proves a finite component of manuscript Theorem 4.1. Uniform
asymptotic selection of the index remains in the existing IndexBudget lemma.
-/

noncomputable section
open Polynomial

namespace PaperOrder.Section4
open ManuscriptChain.RealTransfer
open ManuscriptChain.Spectral

/-- Finite rational-point exclusion from an integral polynomial and a
controlled comparison with its value at the center. No root positions or
asymptotic limits are needed in this arithmetic lemma. -/
theorem theorem_4_1_finite_rational_exclusion
    (P : Polynomial ℤ) (ξ radius : ℝ) (a : ℤ) (b : ℕ)
    (hb : 0 < b)
    (hcompare : ∀ x : ℝ, |x - ξ| ≤ radius →
      evalReal P x ≠ 0 ∧ |evalReal P x| ≤ 2 * |evalReal P ξ|)
    (hbudget : 2 * (b : ℝ) ^ P.natDegree * |evalReal P ξ| < 1) :
    radius < |ξ - (a : ℝ) / b| := by
  by_contra hnot
  have hclose : |(a : ℝ) / b - ξ| ≤ radius := by
    rw [abs_sub_comm]
    exact le_of_not_gt hnot
  obtain ⟨hne, hupper⟩ := hcompare ((a : ℝ) / b) hclose
  have hbnonneg : 0 ≤ (b : ℝ) ^ P.natDegree := by positivity
  apply polynomial_integer_squeeze P a b hb hne
  calc
    (b : ℝ) ^ P.natDegree * |evalReal P ((a : ℝ) / b)|
        ≤ (b : ℝ) ^ P.natDegree * (2 * |evalReal P ξ|) :=
          mul_le_mul_of_nonneg_left hupper hbnonneg
    _ = 2 * (b : ℝ) ^ P.natDegree * |evalReal P ξ| := by ring
    _ < 1 := hbudget

/-- The paper's finite spectral-to-arithmetic step. The beta bounds,
actual polynomial normalization, and small determinant value are visible
arguments; none is silently introduced as an axiom. -/
theorem theorem_4_1_spectral_rational_exclusion
    {n : ℕ} (p : SymmetricAffinePencil n) (factor : RootFactorization p)
    (P : Polynomial ℤ) (scale bound : ℝ) (a : ℤ) (b : ℕ)
    (hb : 0 < b)
    (hscale : scale ≠ 0)
    (hnormalize : p.detPolynomial =
      Polynomial.C scale * P.map (algebraMap ℤ ℝ))
    (hbound : 0 < bound)
    (hbeta : ∀ i, |factor.beta i| ≤ bound)
    (hbudget : 2 * (b : ℝ) ^ P.natDegree *
      |evalReal P p.center| < 1) :
    comparisonRadius n bound < |p.center - (a : ℝ) / b| := by
  apply theorem_4_1_finite_rational_exclusion
    P p.center (comparisonRadius n bound) a b hb
  · intro x hx
    exact factor.normalized_comparison_of_radius
      P scale bound x hscale hnormalize hbound hbeta hx
  · exact hbudget

end PaperOrder.Section4

#print axioms PaperOrder.Section4.theorem_4_1_finite_rational_exclusion
#print axioms PaperOrder.Section4.theorem_4_1_spectral_rational_exclusion
