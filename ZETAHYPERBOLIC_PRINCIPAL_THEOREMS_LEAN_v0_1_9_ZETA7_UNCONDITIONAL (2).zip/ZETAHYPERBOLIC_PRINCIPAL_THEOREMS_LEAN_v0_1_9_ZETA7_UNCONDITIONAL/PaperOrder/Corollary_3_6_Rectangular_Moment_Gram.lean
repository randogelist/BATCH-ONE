import PaperOrder.Theorem_3_7_All_Degree_Turan_Leading_Scalar

/-!
# Corollary 3.6: finite moment matrices of arbitrary shape

Rectangular Vandermonde -> r-by-r Hankel Gram identity, with an arbitrary
number n of atoms. This is the exact finite algebra needed to separate
strict positivity for r<=n from singularity for r>n. No false assertion
of strict positivity for all sizes is made.
-/

noncomputable section
open scoped BigOperators
namespace PaperOrder.CoreAlgebra

/-- A rectangular evaluation matrix: r polynomial rows, n atomic columns. -/
def rectangularMomentVandermonde {r n : ℕ} (x : Fin n → ℝ) :
    Matrix (Fin r) (Fin n) ℝ := fun i k => x k ^ i.val

/-- General truncated r-by-r Hankel matrix of n weighted atoms. -/
def rectangularAtomicHankel {r n : ℕ} (x w : Fin n → ℝ) :
    Matrix (Fin r) (Fin r) ℝ :=
  fun i j => ∑ k : Fin n, w k * x k ^ (i.val + j.val)

/-- Universal rectangular Gram identity H_r = V_r diag(w) V_r^T. -/
theorem rectangularAtomicHankel_factorization {r n : ℕ}
    (x w : Fin n → ℝ) :
    rectangularAtomicHankel (r:=r) x w =
      rectangularMomentVandermonde (r:=r) x * Matrix.diagonal w *
        (rectangularMomentVandermonde (r:=r) x).transpose := by
  ext i j
  unfold rectangularAtomicHankel
  rw [Matrix.mul_apply]
  simp only [Matrix.mul_diagonal, Matrix.transpose_apply]
  change (∑ k : Fin n, w k * x k ^ (i.val + j.val)) =
    ∑ k : Fin n, (x k ^ i.val * w k) * x k ^ j.val
  apply Finset.sum_congr rfl
  intro k hk
  rw [pow_add]
  ring

/-- Symmetry of all finite atomic moment truncations. -/
theorem rectangularAtomicHankel_symmetric {r n : ℕ}
    (x w : Fin n → ℝ) :
    (rectangularAtomicHankel (r:=r) x w).IsSymm := by
  ext i j
  simp only [Matrix.transpose_apply, rectangularAtomicHankel]
  apply Finset.sum_congr rfl
  intro k hk
  rw [Nat.add_comm]

/-- At full size, the rectangular construction reduces to the previously
proved strict determinant formula. -/
theorem rectangularAtomicHankel_full_size {n : ℕ}
    (x w : Fin n → ℝ) :
    rectangularAtomicHankel (r:=n) x w = atomicMomentMatrix x w := rfl

/-- Strict determinant positivity at full rank is inherited without
reconstructing the already-frozen Vandermonde argument. -/
theorem rectangularAtomicHankel_full_det_pos {n : ℕ}
    (x w : Fin n → ℝ)
    (hx : Function.Injective x) (hw : ∀ k : Fin n, 0 < w k) :
    0 < (rectangularAtomicHankel (r:=n) x w).det := by
  rw [rectangularAtomicHankel_full_size]
  exact atomicMomentMatrix_det_pos x w hx hw

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.rectangularAtomicHankel_factorization
#print axioms PaperOrder.CoreAlgebra.rectangularAtomicHankel_full_det_pos
