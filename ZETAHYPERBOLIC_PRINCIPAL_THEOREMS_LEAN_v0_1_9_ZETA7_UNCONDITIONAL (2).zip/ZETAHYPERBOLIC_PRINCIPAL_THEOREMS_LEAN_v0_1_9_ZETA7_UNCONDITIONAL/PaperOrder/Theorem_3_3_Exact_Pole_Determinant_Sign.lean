import MAIN_CHAIN_PAPER_ORDER_SECTION4B

/-!
# Theorem 3.3: exact nonzero-sign certificate for the paper's derivative

This is the actual manuscript rational derivative matrix and pole lattice.
It does not assume a spectral-sign hypothesis. The individual alternating
pole signs and full inertia count are deliberately separate obligations.
-/

namespace PaperOrder.CoreAlgebra

open scoped BigOperators
open ManuscriptChain.PoleDiagonalization

/-- The Vandermonde square makes the determinant sign equal the sign of the
product of the pole weights. The product of the two is strictly positive. -/
theorem pole_derivative_det_times_weights_pos
    (p : ManuscriptChain.Real.Parameters) :
    0 < (rationalDerivativeMatrix p).det *
      (∏ a : Fin p.h, poleWeight p a) := by
  have hV : (poleVandermonde p).det ≠ 0 :=
    poleVandermonde_det_ne_zero p
  have hw : (∏ a : Fin p.h, poleWeight p a) ≠ 0 := by
    apply Finset.prod_ne_zero_iff.mpr
    intro a ha
    exact poleWeight_ne_zero p a
  calc
    (rationalDerivativeMatrix p).det * (∏ a : Fin p.h, poleWeight p a) =
        (poleVandermonde p).det ^ 2 *
          (∏ a : Fin p.h, poleWeight p a) ^ 2 := by
      rw [rationalDerivativeMatrix_det]
      ring
    _ > 0 := mul_pos (sq_pos_of_ne_zero hV) (sq_pos_of_ne_zero hw)

/-- Each pole coordinate is exactly a diagonal coordinate of the true
congruence-normalized derivative matrix, with no extra assumptions. -/
theorem pole_derivative_diagonal_entry
    (p : ManuscriptChain.Real.Parameters) (a : Fin p.h) :
    (((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
      ((poleVandermonde p)⁻¹).transpose) a a) = poleWeight p a := by
  rw [pole_slope_diagonal]
  simp

/-- The normalized derivative is nonzero on every pole coordinate. -/
theorem pole_derivative_diagonal_entry_ne_zero
    (p : ManuscriptChain.Real.Parameters) (a : Fin p.h) :
    (((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
      ((poleVandermonde p)⁻¹).transpose) a a) ≠ 0 := by
  rw [pole_derivative_diagonal_entry]
  exact poleWeight_ne_zero p a

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.pole_derivative_det_times_weights_pos
#print axioms PaperOrder.CoreAlgebra.pole_derivative_diagonal_entry_ne_zero
