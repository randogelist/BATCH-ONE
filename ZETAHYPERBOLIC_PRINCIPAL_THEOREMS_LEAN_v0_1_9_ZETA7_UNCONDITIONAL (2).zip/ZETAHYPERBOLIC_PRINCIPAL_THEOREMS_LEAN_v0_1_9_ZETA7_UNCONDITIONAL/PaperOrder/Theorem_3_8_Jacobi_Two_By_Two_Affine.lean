import PaperOrder.Theorem_3_7_Cubic_Newton
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Tactic.Ring

/-!
# Theorem 3.8 — Two-by-two Jacobi identity for affine pencils

The exact determinant derivative identity is proved for a fully general
2-by-2 rational affine pencil, including its matrix determinant form.
This is a genuine special case of the Jacobi identity, not a claim that
the full arbitrary-size or analytic-weight statement is proved.
-/

noncomputable section
open Polynomial

namespace PaperOrder.CoreAlgebra

/-- Explicit determinant of an arbitrary 2x2 affine polynomial pencil. -/
def affineTwoDet (a b c d α β γ δ : ℚ) : Polynomial ℚ :=
  (C a + C α * X) * (C d + C δ * X) -
  (C b + C β * X) * (C c + C γ * X)

/-- The affine determinant is the determinant of the genuine 2x2 matrix. -/
theorem affineTwoDet_eq_matrix (a b c d α β γ δ : ℚ) :
    ( !![C a + C α * X, C b + C β * X;
          C c + C γ * X, C d + C δ * X] :
      Matrix (Fin 2) (Fin 2) (Polynomial ℚ)).det =
      affineTwoDet a b c d α β γ δ := by
  unfold affineTwoDet
  exact Matrix.det_fin_two_of _ _ _ _

/-- Exact polynomial derivative, including the slope determinant term. -/
theorem affineTwoDet_derivative (a b c d α β γ δ : ℚ) :
    derivative (affineTwoDet a b c d α β γ δ) =
      C (α*d + a*δ - β*c - b*γ) +
        C (2*(α*δ - β*γ)) * X := by
  unfold affineTwoDet
  -- Differentiate the four affine factors first, then expose that
  -- `Polynomial.C` is a ring homomorphism before ring normalization.
  -- Without `map_add`/`map_mul`, `ring` treats the RHS constant
  -- coefficients as opaque polynomial atoms.
  simp only [derivative_sub, derivative_mul, derivative_add,
    derivative_C, derivative_X, zero_mul, add_zero,
    zero_add, mul_zero, one_mul, mul_one] <;>
    simp only [map_add, map_sub, map_mul, map_ofNat] <;>
    ring

/-- The 2x2 Jacobi trace/adjugate formula, evaluated at any rational t. -/
theorem affineTwoDet_jacobi_eval (a b c d α β γ δ t : ℚ) :
    (derivative (affineTwoDet a b c d α β γ δ)).eval t =
      α * (d + δ*t) + δ * (a + α*t) -
      β * (c + γ*t) - γ * (b + β*t) := by
  rw [affineTwoDet_derivative]
  simp only [eval_add, eval_mul, eval_C, eval_X]
  ring

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.affineTwoDet_derivative
#print axioms PaperOrder.CoreAlgebra.affineTwoDet_jacobi_eval
