import ZETA5_DIRECT_IRRATIONALITY
import MAIN_CHAIN_ASSEMBLED

/-!
# Paper witness: the unique conditional input for ζ(5) irrationality

The manuscript's formula (4.2) sets `mainF n = S_(30n) * delta_(30n)`.
Equation (4.3) asserts the existence of positive rational multipliers
`m_n` such that `Q_n = m_n * mainF n` has *integer* coefficients, and
`Q_n(ζ(5)) <= exp(-(30n)^2/2500)` for all sufficiently large n.

The positivity and nonzero evaluation of `Q_n` are NOT witness fields;
they are proved from the genuine Gram matrix and the positive multiplier.

This module uses a STRUCTURE and does not declare any custom Lean `axiom`.
Importing/using `PaperWitness` is CONDITIONAL: it has not been constructed.
The existence statement is not claimed to follow merely from the PDF.
-/

noncomputable section
open Polynomial

namespace PaperWitnessOnly
open ManuscriptChain
open ManuscriptChain.MainChain
open ManuscriptChain.RealTransfer

/-- A paper-shaped certificate for equation (4.3). The tail starts at
`w.start + 1`, so every matrix has positive dimension. The polynomial
identity explicitly identifies the certificate with the actual rational
moment determinant; arbitrary unrelated integer polynomials do not qualify. -/
structure PaperWitness where
  start : ℕ
  Q : ℕ → Polynomial ℤ
  m : ℕ → ℚ
  m_pos : ∀ n : ℕ, start + 1 ≤ n → 0 < m n
  value_identity : ∀ n : ℕ, start + 1 ≤ n →
    (Q n).map (algebraMap ℤ ℚ) = C (m n) * Real.mainF n
  quadratic_decay : ∀ n : ℕ, start + 1 ≤ n →
    |RealTransfer.evalReal (Q n) MainChain.zeta5| ≤
      MainChain.decayBudget n

/-- The sole externally supplied certificate, under the requested name. -/
abbrev Witness := PaperWitness

/-- No normalization is assumed as an additional theorem: the witness's
exact identity and positivity instantiate the *paper-defined* normalization. -/
def normalization (w : PaperWitness) : MainChain.MainNormalization where
  Q := w.Q
  multiplier := w.m
  onset := w.start + 1
  onset_ge_one := by omega
  multiplier_pos := by
    intro n hn
    exact w.m_pos n hn
  polynomial_identity := by
    intro n hn
    exact w.value_identity n hn

/-- The assembled archimedean proof, not the witness, supplies strict
nonvanishing at the genuine value ζ(5). -/
theorem normalized_value_positive (w : PaperWitness) (n : ℕ)
    (hn : (normalization w).onset ≤ n) :
    0 < RealTransfer.evalReal (w.Q n) MainChain.zeta5 := by
  have hpos := MainChain.normalized_value_pos (normalization w)
    (MainChain.main_baseValuePositive (normalization w).onset
      (normalization w).onset_ge_one) n hn
  exact hpos

/-- This is the only required decay record for the existing integer-polynomial
transfer; the nonzero clause is proved, never stipulated. -/
theorem decay_of_witness (w : PaperWitness) :
    RealTransfer.Decay (normalization w).Q MainChain.zeta5
      MainChain.decayBudget (normalization w).onset := by
  constructor
  · intro n hn
    exact ne_of_gt (normalized_value_positive w n hn)
  · intro n hn
    exact w.quadratic_decay n hn

/-- Paper's ζ(5) irrationality consequence, with EXACTLY ONE assumption,
`w : PaperWitness`. There are no analytic, spectral, Gram, normalization,
or independent arithmetic estimates passed as theorem arguments. -/
theorem ZETA5_IRRATIONALITY_FROM_PAPER_WITNESS (w : PaperWitness) :
    Irrational (riemannZeta (5 : ℂ)).re :=
  ManuscriptChain.zeta5_irrational_of_normalized_decay
    (normalization w) (decay_of_witness w)

end PaperWitnessOnly

#print axioms PaperWitnessOnly.normalized_value_positive
#print axioms PaperWitnessOnly.decay_of_witness
#print axioms PaperWitnessOnly.ZETA5_IRRATIONALITY_FROM_PAPER_WITNESS
