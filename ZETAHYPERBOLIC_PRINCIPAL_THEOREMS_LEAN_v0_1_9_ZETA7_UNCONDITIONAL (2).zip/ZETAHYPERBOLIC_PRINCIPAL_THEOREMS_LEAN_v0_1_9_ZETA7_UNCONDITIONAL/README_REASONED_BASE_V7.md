# V7: targeted theorem-level core algebra extension (not yet compiler-verified)

User Windows Lean 4.33.0 authority: **97/97 V5 verified**. Modules 1-97 are
copied byte-for-byte from the previous v6 archive, which itself copied them
unchanged from the user-certified V5 archive. Modules 98-102 were added in
V6 and are *not* yet compiler-verified; 103-107 are NEW V7 proofs.

Added genuine mathematical developments:

- **103:** Exact full degree of the actual dual determinant given
  nonsingular rational slope; nonvanishing leading coefficient equivalent
  across nonsingular rational polynomial basis changes.
- **104:** Arbitrary-size atomic Hankel quadratic forms are additive and
  monotone in their weights; strict Gram positivity survives increasing
  the weights.
- **105:** Constructive real quadratic formula and an actual real zero of
  each symmetric 2×2 affine pencil with positive definite slope.
- **106:** Strict discriminant (generic nonproportionality), using the
  existing exact sum-of-squares certificate.
- **107:** New all-or-nothing V7 endpoint with degree and real-root claims.

The PDF's continuous total positivity, full principal-minor interlacing,
full general finite J-fraction construction, quantitative zeta(5) estimates
and exact 19/20 audit remain open. The witness-only eventual endpoint is
separate; no custom axioms, sorry or admit are introduced here.

Single `run.cmd`, direct native cached Windows Lean 4.33.0, persistent
frozen dependency cache; no Lean compilation was run during packaging.
