import PaperOrder.Theorem_3_8_Exact_Finite_Pole_Kernel_Matrix

/-!
# Core algebra toward the explicit 95% target

This is a genuine conjunction of stronger mathematical statements about the
actual pole-diagonalized derivative pencil. It does not assert the whole
manuscript's total positivity, general interlacing, or full inertia theorem.
The percentage target is an audit goal, not itself a theorem of Lean.
-/

namespace PaperOrder.CoreAlgebra

open ManuscriptChain.PoleDiagonalization
open scoped BigOperators

/-- Exact polynomial degree plus signed derivative determinant plus
nonzero diagonal directions of the actual odd-weight construction. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_FRONTIER
    (p : ManuscriptChain.Real.Parameters) :
    ((ManuscriptChain.Real.delta p).natDegree = p.h) ∧
    (0 < (rationalDerivativeMatrix p).det *
      (∏ a : Fin p.h, poleWeight p a)) ∧
    (∀ a : Fin p.h,
       (((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
         ((poleVandermonde p)⁻¹).transpose) a a) ≠ 0) := by
  exact ⟨delta_natDegree p,
    pole_derivative_det_times_weights_pos p,
    pole_derivative_diagonal_entry_ne_zero p⟩

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_FRONTIER
