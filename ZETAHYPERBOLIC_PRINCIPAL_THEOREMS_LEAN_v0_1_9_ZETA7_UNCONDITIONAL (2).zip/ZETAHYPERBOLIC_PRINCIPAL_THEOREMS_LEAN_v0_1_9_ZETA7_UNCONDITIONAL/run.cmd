@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0"
if errorlevel 1 (echo ERROR=CANNOT_ENTER_PACKAGE_DIRECTORY&exit /b 1)

set "PACKAGE=ZETAHYPERBOLIC_PRINCIPAL_THEOREMS_LEAN_v0_1_9_ZETA7_UNCONDITIONAL"
set "RUNNER=NATIVE_WINDOWS_LEAN433_FROZEN_FASTCORE_SAFE_PUBLISH"
set "GOAL=MAIN_CHAIN_PRINCIPAL_THEOREMS_V3"
set "MODULES=117"
set "TOOLCHAIN=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
set "LEAN_EXE=!TOOLCHAIN!\bin\lean.exe"
set "CACHE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
if defined ZETA_FASTCORE_CACHE_ROOT set "CACHE_ROOT=!ZETA_FASTCORE_CACHE_ROOT!"
if defined ZETA_FASTCORE_LEAN_EXE set "LEAN_EXE=!ZETA_FASTCORE_LEAN_EXE!"
set "MATHLIB_ROOT=!CACHE_ROOT!\.lake\packages\mathlib\.lake\build\lib\lean"
set "FROZEN_ROOT=%USERPROFILE%\lean-native\zetahyperbolic_paper_frozen_lean433_v1"
if defined ZETA_PAPER_FROZEN_ROOT set "FROZEN_ROOT=!ZETA_PAPER_FROZEN_ROOT!"
set "OUT=!FROZEN_ROOT!\build\lib\lean"
set "COUNTER_FILE=!FROZEN_ROOT!\build_counter.txt"
set "LOCAL_LOG=%CD%\build\logs"
set "LEAN_NUM_THREADS=16"
set "LEAN_JOBS=16"
set "FORCE_ALL=0"
if /I "%~1"=="full" set "FORCE_ALL=1"
set /a GEN_COUNTER=0
set /a COMPILED=0
set /a SKIPPED=0
set /a LEGACY_IMPORTED=0
set "BUILD_FROM=NONE"

echo PACKAGE=!PACKAGE!
echo GOAL=!GOAL!
echo MODULES=!MODULES!
echo RUNNER=!RUNNER!
echo BUILD_MODE=FROZEN_DEPENDENCY_INCREMENTAL
echo BUILD_LAUNCH=DIRECT_PINNED_LEAN_EXE
echo THREADS=16
echo LAKE=NOT_USED
echo NETWORK=NOT_USED
echo PYTHON=NOT_USED
echo POWERSHELL=NOT_USED
echo WSL=NOT_USED
if not exist "!LEAN_EXE!" (echo ERROR=PINNED_LEAN_433_NOT_FOUND&goto :FAIL)
if not exist "!MATHLIB_ROOT!\Mathlib.olean" (echo ERROR=PREBUILT_MATHLIB_CACHE_MISSING&goto :FAIL)
if not exist "!MATHLIB_ROOT!\Mathlib\NumberTheory\LSeries\RiemannZeta.olean" (echo ERROR=RIEMANN_ZETA_OLEAN_MISSING&goto :FAIL)
if not exist "BUILD_ORDER_FROZEN.txt" (echo ERROR=BUILD_PLAN_MISSING&goto :FAIL)
if not exist "MAIN_CHAIN_PRINCIPAL_THEOREMS_V3.lean" (echo ERROR=ENDPOINT_SOURCE_MISSING&goto :FAIL)
if not exist "!FROZEN_ROOT!" mkdir "!FROZEN_ROOT!"
if not exist "!OUT!" mkdir "!OUT!"
if not exist "!LOCAL_LOG!" mkdir "!LOCAL_LOG!"

rem Serialize builds sharing this persistent cache. mkdir is atomic on Windows.
rem Never overwrite a cache another Lean process may be writing concurrently.
set "BUILD_LOCK=!FROZEN_ROOT!\active_build.lockdir"
2>nul mkdir "!BUILD_LOCK!"
if errorlevel 1 (
  echo ERROR=CACHE_BUILD_ALREADY_RUNNING_OR_STALE_LOCK
  echo CACHE_BUILD_LOCK=!BUILD_LOCK!
  echo HINT=Do not run two instances. If no build is running, remove the stale lock directory manually.
  goto :FAIL
)
set "LOCK_OWNED=YES"
echo FROZEN_CACHE_LOCK=ACQUIRED

rem Native Lean + existing cached Mathlib; neither Lake nor a network is needed.
set "LEAN_PATH=!OUT!;!TOOLCHAIN!\lib\lean"
if exist "!CACHE_ROOT!\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;!CACHE_ROOT!\.lake\build\lib\lean"
set /a CACHE_OLEAN_ROOTS=0
for /D %%D in ("!CACHE_ROOT!\.lake\packages\*") do (
  if exist "%%~fD\.lake\build\lib\lean" (
    set "LEAN_PATH=!LEAN_PATH!;%%~fD\.lake\build\lib\lean"
    set /a CACHE_OLEAN_ROOTS+=1 >nul
  )
)
if !CACHE_OLEAN_ROOTS! LSS 1 (echo ERROR=LEAN_PATH_HAS_NO_CACHED_PACKAGES&goto :FAIL)
echo CACHE_ROOT=!CACHE_ROOT!
echo CACHE_OLEAN_ROOTS=!CACHE_OLEAN_ROOTS!
echo MATHLIB_CACHE=READY
echo FROZEN_ROOT=!FROZEN_ROOT!
echo NATIVE_LEAN_PATH=READY
"!LEAN_EXE!" --version
if errorlevel 1 (echo ERROR=LEAN_VERSION_FAILED&goto :FAIL)

rem Each successful module has its own pinned environment, exact source,
rem durable generation, and direct-import generation receipts.
rem A dependency change cannot leave a stale dependent certified, even after
rem an interrupted build or across different extracted ZIP directories.
for %%F in ("!MATHLIB_ROOT!\Mathlib.olean") do (
  set "MATHLIB_DATE=%%~tF"
  set "MATHLIB_SIZE=%%~zF"
)
for %%F in ("!LEAN_EXE!") do (
  set "EXE_DATE=%%~tF"
  set "EXE_SIZE=%%~zF"
)
set "ENV_SIGNATURE=!LEAN_EXE!#!EXE_DATE!#!EXE_SIZE!#!CACHE_ROOT!#!MATHLIB_DATE!#!MATHLIB_SIZE!#J16"
set "LEGACY_SIGNATURE=!LEAN_EXE! !CACHE_ROOT! !MATHLIB_DATE!"
if exist "!COUNTER_FILE!" set /p "GEN_COUNTER=" < "!COUNTER_FILE!"
rem Recover monotone counter if a previous run lost its counter file.
for /F "usebackq tokens=1-4 delims=;" %%I in ("BUILD_ORDER_FROZEN.txt") do (
  if exist "!OUT!\%%K.generation" (
    set "FOUND_GEN=0"
    set /p "FOUND_GEN=" < "!OUT!\%%K.generation"
    if !FOUND_GEN! GTR !GEN_COUNTER! set /a GEN_COUNTER=FOUND_GEN >nul
  )
)
if /I "%~1"=="full" echo FORCE_FULL=YES
if /I not "%~1"=="full" echo FORCE_FULL=NO

rem One-time migration of ONLY modules 1-9 verified by the user's v0.3.2 log.
rem A legacy .olean is accepted only with a matching original environment,
rem matching exact source stamp, and identical compiled direct dependencies.
set "LEGACY_LIB="
if exist "%USERPROFILE%\Downloads\ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_v0_3_2_FASTCORE\build\fastcore-cache-signature.txt" (
  set "LEGACY_DIR=%USERPROFILE%\Downloads\ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_v0_3_2_FASTCORE\build"
  set /p "CANDIDATE_SIGNATURE=" < "!LEGACY_DIR!\fastcore-cache-signature.txt"
  if /I "!CANDIDATE_SIGNATURE!"=="!LEGACY_SIGNATURE!" set "LEGACY_LIB=!LEGACY_DIR!\lib\lean"
)
if defined LEGACY_LIB (echo LEGACY_VERIFIED_SOURCE=V0_3_2) else (echo LEGACY_VERIFIED_SOURCE=NOT_AVAILABLE)

rem First pass registers every module location for dependency lookup.
for /F "usebackq tokens=1-4 delims=;" %%I in ("BUILD_ORDER_FROZEN.txt") do (
  set "TARGET_REL_%%I=%%K"
)

rem Each step computes cache validity from its OWN source and direct imports.
rem Unlike the previous runner, changing module 10 does not dirty modules 11-12
rem or other independent branches; only true transitive dependents rebuild.
for /F "usebackq tokens=1-4 delims=;" %%I in ("BUILD_ORDER_FROZEN.txt") do (
  set "SRC=%%J"
  set "TARGET=!OUT!\%%K"
  set "SOURCE_STAMP=!TARGET!.source"
  set "ENV_STAMP=!TARGET!.environment"
  set "GEN_STAMP=!TARGET!.generation"
  set "LOG=!LOCAL_LOG!\%%I.log"
  set "DEPS=%%L"
  if not exist "!SRC!" (echo ERROR=SOURCE_MISSING !SRC!&goto :FAIL)
  for %%Q in ("!TARGET!") do if not exist "%%~dpQ" mkdir "%%~dpQ"
  set "NEED_BUILD=0"
  set "MIGRATED=0"
  if "!FORCE_ALL!"=="1" set "NEED_BUILD=1"
  if not exist "!TARGET!" set "NEED_BUILD=1"
  if exist "!TARGET!" for %%Z in ("!TARGET!") do if %%~zZ LEQ 0 set "NEED_BUILD=1"
  if not exist "!SOURCE_STAMP!" set "NEED_BUILD=1"
  if not exist "!ENV_STAMP!" set "NEED_BUILD=1"
  if not exist "!GEN_STAMP!" set "NEED_BUILD=1"
  if exist "!SOURCE_STAMP!" (
    fc /B "!SRC!" "!SOURCE_STAMP!" >nul 2>&1
    if errorlevel 1 set "NEED_BUILD=1"
  )
  if exist "!ENV_STAMP!" (
    set /p "OLD_ENV=" < "!ENV_STAMP!"
    if not "!OLD_ENV!"=="!ENV_SIGNATURE!" set "NEED_BUILD=1"
  )
  if not "!DEPS!"=="-" (
    for %%D in (!DEPS!) do (
      set "PARENT=!OUT!\!TARGET_REL_%%D!"
      if not exist "!PARENT!" (echo ERROR=DEPENDENCY_OLEAN_MISSING_%%D&goto :FAIL)
      if not exist "!PARENT!.generation" (echo ERROR=UNCERTIFIED_DEPENDENCY_%%D&goto :FAIL)
      if not exist "!TARGET!.dep.%%D" set "NEED_BUILD=1"
      if exist "!TARGET!.dep.%%D" (
        set /p "OLD_DEP_GEN=" < "!TARGET!.dep.%%D"
        set /p "NEW_DEP_GEN=" < "!PARENT!.generation"
        if not "!OLD_DEP_GEN!"=="!NEW_DEP_GEN!" set "NEED_BUILD=1"
      )
    )
  )

  rem Bootstrap the already-PASS first nine modules without rerunning them.
  rem Never bootstrap a module if any of its compiled parents differ from old.
  if "!NEED_BUILD!"=="1" if "!FORCE_ALL!"=="0" if %%I LEQ 9 if defined LEGACY_LIB (
    set "LEGACY_TARGET=!LEGACY_LIB!\%%K"
    set "CAN_MIGRATE=0"
    if exist "!LEGACY_TARGET!" if exist "!LEGACY_TARGET!.source" if not exist "!GEN_STAMP!" (
      fc /B "!SRC!" "!LEGACY_TARGET!.source" >nul 2>&1
      if not errorlevel 1 set "CAN_MIGRATE=1"
    )
    if "!CAN_MIGRATE!"=="1" if not "!DEPS!"=="-" (
      for %%D in (!DEPS!) do (
        set "PARENT=!OUT!\!TARGET_REL_%%D!"
        set "OLD_PARENT=!LEGACY_LIB!\!TARGET_REL_%%D!"
        if not exist "!OLD_PARENT!" set "CAN_MIGRATE=0"
        if "!CAN_MIGRATE!"=="1" (
          fc /B "!PARENT!" "!OLD_PARENT!" >nul 2>&1
          if errorlevel 1 set "CAN_MIGRATE=0"
        )
      )
    )
    if "!CAN_MIGRATE!"=="1" (
      call :COPY_RETRY "!LEGACY_TARGET!" "!TARGET!"
      if errorlevel 1 (echo ERROR=LEGACY_OLEAN_COPY_FAILED !SRC!&goto :FAIL)
      if not exist "!TARGET!" (echo ERROR=LEGACY_OLEAN_MISSING !SRC!&goto :FAIL)
      for %%Z in ("!TARGET!") do if %%~zZ LEQ 0 (echo ERROR=LEGACY_OLEAN_EMPTY !SRC!&goto :FAIL)
      call :COPY_RETRY "!LEGACY_TARGET!.source" "!SOURCE_STAMP!"
      if errorlevel 1 (echo ERROR=LEGACY_STAMP_COPY_FAILED !SRC!&goto :FAIL)
      fc /B "!SRC!" "!SOURCE_STAMP!" >nul 2>&1
      if errorlevel 1 (echo ERROR=LEGACY_SOURCE_MISMATCH !SRC!&goto :FAIL)
      > "!ENV_STAMP!" echo(!ENV_SIGNATURE!
      if not "!DEPS!"=="-" (
        for %%D in (!DEPS!) do (
          set "PARENT=!OUT!\!TARGET_REL_%%D!"
          set /p "PARENT_GEN=" < "!PARENT!.generation"
          > "!TARGET!.dep.%%D" echo(!PARENT_GEN!
        )
      )
      set /a GEN_COUNTER+=1 >nul
      call :WRITE_RECEIPT "!COUNTER_FILE!" "!GEN_COUNTER!"
      if errorlevel 1 (echo ERROR=LEGACY_COUNTER_WRITE_FAILED !SRC!&goto :FAIL)
      call :WRITE_RECEIPT "!GEN_STAMP!" "!GEN_COUNTER!"
      if errorlevel 1 (echo ERROR=LEGACY_CERTIFICATE_WRITE_FAILED !SRC!&goto :FAIL)
      set /a LEGACY_IMPORTED+=1 >nul
      set "MIGRATED=1"
      echo FROZEN_IMPORT=%%I/!MODULES! !SRC!
      set "NEED_BUILD=0"
    )
  )

  if "!NEED_BUILD!"=="0" (
    if "!MIGRATED!"=="0" (
      echo FROZEN_SKIP=%%I/!MODULES! !SRC!
      set /a SKIPPED+=1 >nul
    )
  ) else (
    if "!BUILD_FROM!"=="NONE" set "BUILD_FROM=%%I"
    echo CHECK=%%I/!MODULES! !SRC!
    rem Invalidate certification BEFORE recompiling. Keep the old .olean
    rem untouched until a new, nonempty .olean has been produced in staging.
    if exist "!GEN_STAMP!" del /Q "!GEN_STAMP!" >nul 2>&1
    if exist "!GEN_STAMP!" (echo ERROR=CANNOT_INVALIDATE_GENERATION !SRC!&goto :FAIL)
    set "STAGE_OLEAN=!TARGET!.pending.olean"
    if exist "!STAGE_OLEAN!" del /Q "!STAGE_OLEAN!" >nul 2>&1
    if exist "!STAGE_OLEAN!" (echo ERROR=STAGING_FILE_LOCKED !SRC!&goto :FAIL)

    rem The compiler MUST return zero AND produce a nonempty .olean.
    rem Direct writes to a shared final path caused the v0.3.4 false PASS.
    "!LEAN_EXE!" -j !LEAN_JOBS! -o "!STAGE_OLEAN!" "!SRC!" > "!LOG!" 2>&1
    set "LEAN_RC=!errorlevel!"
    if not "!LEAN_RC!"=="0" (
      echo ERROR=LEAN_COMPILE_FAILED
      echo LEAN_EXIT_CODE=!LEAN_RC!
      echo FIRST_FAILED_SOURCE=!SRC!
      echo ERROR_LOG=!LOG!
      type "!LOG!"
      goto :FAIL
    )
    if not exist "!STAGE_OLEAN!" (
      echo ERROR=LEAN_EXIT_ZERO_BUT_OLEAN_MISSING
      echo FIRST_FAILED_SOURCE=!SRC!
      echo ERROR_LOG=!LOG!
      type "!LOG!"
      goto :FAIL
    )
    for %%Z in ("!STAGE_OLEAN!") do if %%~zZ LEQ 0 (
      echo ERROR=LEAN_EXIT_ZERO_BUT_OLEAN_EMPTY
      echo FIRST_FAILED_SOURCE=!SRC!
      goto :FAIL
    )
    call :MOVE_RETRY "!STAGE_OLEAN!" "!TARGET!"
    if errorlevel 1 (echo ERROR=LEAN_OLEAN_PUBLISH_LOCKED !SRC!&goto :FAIL)
    if not exist "!TARGET!" (echo ERROR=PUBLISHED_OLEAN_MISSING !SRC!&goto :FAIL)
    for %%Z in ("!TARGET!") do if %%~zZ LEQ 0 (echo ERROR=PUBLISHED_OLEAN_EMPTY !SRC!&goto :FAIL)

    rem The generation receipt is committed LAST. If any receipt is
    rem missing or locked, this module is not counted as verified.
    call :COPY_RETRY "!SRC!" "!SOURCE_STAMP!"
    if errorlevel 1 (echo ERROR=SOURCE_STAMP_COPY_FAILED !SRC!&goto :FAIL)
    fc /B "!SRC!" "!SOURCE_STAMP!" >nul 2>&1
    if errorlevel 1 (echo ERROR=SOURCE_STAMP_CONTENT_MISMATCH !SRC!&goto :FAIL)
    call :WRITE_RECEIPT "!ENV_STAMP!" "!ENV_SIGNATURE!"
    if errorlevel 1 (echo ERROR=ENVIRONMENT_STAMP_WRITE_FAILED !SRC!&goto :FAIL)
    if not "!DEPS!"=="-" (
      for %%D in (!DEPS!) do (
        set "PARENT=!OUT!\!TARGET_REL_%%D!"
        if not exist "!PARENT!.generation" (echo ERROR=DEPENDENCY_GENERATION_MISSING_%%D&goto :FAIL)
        set "PARENT_GEN="
        set /p "PARENT_GEN=" < "!PARENT!.generation"
        call :WRITE_RECEIPT "!TARGET!.dep.%%D" "!PARENT_GEN!"
        if errorlevel 1 (echo ERROR=DEPENDENCY_RECEIPT_WRITE_FAILED_%%D&goto :FAIL)
      )
    )
    set /a GEN_COUNTER+=1 >nul
    rem Reserve the generation number before committing its certificate.
    call :WRITE_RECEIPT "!COUNTER_FILE!" "!GEN_COUNTER!"
    if errorlevel 1 (echo ERROR=GENERATION_COUNTER_WRITE_FAILED !SRC!&goto :FAIL)
    call :WRITE_RECEIPT "!GEN_STAMP!" "!GEN_COUNTER!"
    if errorlevel 1 (echo ERROR=GENERATION_CERTIFICATE_WRITE_FAILED !SRC!&goto :FAIL)
    set "RECORDED_GEN="
    set /p "RECORDED_GEN=" < "!GEN_STAMP!"
    if not "!RECORDED_GEN!"=="!GEN_COUNTER!" (
      echo ERROR=GENERATION_CERTIFICATE_MISMATCH !SRC!
      goto :FAIL
    )
    if not exist "!TARGET!" (echo ERROR=OLEAN_DISAPPEARED_AFTER_PUBLISH !SRC!&goto :FAIL)
    for %%Z in ("!TARGET!") do if %%~zZ LEQ 0 (echo ERROR=OLEAN_EMPTY_AFTER_PUBLISH !SRC!&goto :FAIL)
    set /a COMPILED+=1 >nul
    echo CHECK_PASS=%%I/!MODULES! !SRC!
  )
)

echo ========================================================
echo MAIN_CHAIN_PRINCIPAL_THEOREMS_V3=TYPECHECKED_BY_USER_COMPILER
set /a FROZEN_PASS=SKIPPED+LEGACY_IMPORTED >nul
echo FROZEN_PASS=!FROZEN_PASS!
echo FROZEN_LEGACY_IMPORTED=!LEGACY_IMPORTED!
echo UNCHANGED_SKIPPED=!SKIPPED!
echo BUILD_FROM=!BUILD_FROM!
echo NEW_COMPILED=!COMPILED!
echo MODULES=!MODULES!
echo ENTIRE_PAPER=NOT_YET_FORMALIZED
echo THEOREM_3_4_PRINTED=REQUIRES_CORRECTION
echo CORE_ALGEBRA_TARGET=95_PERCENT
echo CORE_ALGEBRA_TARGET_CLAIM=AWAITING_EXACT_19_OF_20_AUDIT
echo LEAN_BUILD=PASS
echo ========================================================
if defined LOCK_OWNED rd "!BUILD_LOCK!" >nul 2>&1
popd
exit /b 0

:FAIL
echo BUILD_FROM=!BUILD_FROM!
set /a FROZEN_PASS=SKIPPED+LEGACY_IMPORTED >nul
echo FROZEN_PASS=!FROZEN_PASS!
echo FROZEN_LEGACY_IMPORTED=!LEGACY_IMPORTED!
echo NEW_COMPILED=!COMPILED!
echo LEAN_BUILD=FAIL
if defined LOCK_OWNED rd "!BUILD_LOCK!" >nul 2>&1
popd
exit /b 1

rem Atomic same-volume publication with bounded retries for transient Windows locks.
:MOVE_RETRY
set "MOVE_SOURCE=%~1"
set "MOVE_DEST=%~2"
for /L %%R in (1,1,5) do (
  move /Y "!MOVE_SOURCE!" "!MOVE_DEST!" >nul 2>&1
  if not errorlevel 1 if exist "!MOVE_DEST!" if not exist "!MOVE_SOURCE!" exit /b 0
  if %%R LSS 5 (
    echo RETRY=FILE_LOCK_MOVE_ATTEMPT_%%R
    timeout /t 1 /nobreak >nul 2>&1
  )
)
exit /b 1

:COPY_RETRY
set "COPY_SOURCE=%~1"
set "COPY_DEST=%~2"
for /L %%R in (1,1,5) do (
  copy /Y /B "!COPY_SOURCE!" "!COPY_DEST!" >nul 2>&1
  if not errorlevel 1 if exist "!COPY_DEST!" exit /b 0
  if %%R LSS 5 (
    echo RETRY=FILE_LOCK_COPY_ATTEMPT_%%R
    timeout /t 1 /nobreak >nul 2>&1
  )
)
exit /b 1

:WRITE_RECEIPT
set "RECEIPT_TARGET=%~1"
set "RECEIPT_VALUE=%~2"
set "RECEIPT_PENDING=%~1.pending"
rem A stale pending receipt must NEVER be mistaken for a successful new write.
if exist "!RECEIPT_PENDING!" del /Q "!RECEIPT_PENDING!" >nul 2>&1
if exist "!RECEIPT_PENDING!" exit /b 1
> "!RECEIPT_PENDING!" echo(!RECEIPT_VALUE!
if not exist "!RECEIPT_PENDING!" exit /b 1
set "PENDING_READ_BACK="
set /p "PENDING_READ_BACK=" < "!RECEIPT_PENDING!"
if not "!PENDING_READ_BACK!"=="!RECEIPT_VALUE!" exit /b 1
call :MOVE_RETRY "!RECEIPT_PENDING!" "!RECEIPT_TARGET!"
if errorlevel 1 exit /b 1
if not exist "!RECEIPT_TARGET!" exit /b 1
set "COMMITTED_READ_BACK="
set /p "COMMITTED_READ_BACK=" < "!RECEIPT_TARGET!"
if not "!COMMITTED_READ_BACK!"=="!RECEIPT_VALUE!" exit /b 1
exit /b 0
