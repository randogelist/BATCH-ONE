# v0.3.3 FASTCORE FIX1 — user compiler log repair

Your Lean 4.33.0 compiler passed modules 1–9 of 38, then failed at module 10:

```
Unknown identifier ManuscriptChain.BasisInvariance.theorem_2_4_constructed_for_manuscript
```

**Cause:** That declaration is defined in `Theorem_2_5_Lagrange_Pole_Diagonalization.lean`,
which comes *after* the chronological Theorem 2.4 wrapper and cannot yet be imported.

**Fix:** The wrapper at `PaperOrder/Theorem_2_4_Canonical_Basis_Invariance.lean`
now uses `theorem_2_4_constructed_canonical_basis_invariance`, which was
already proved by the imported Theorem 2.4 implementation. It explicitly
retains the nonzero-determinant hypothesis that the paper itself states.
Theorem 2.5 later supplies the needed nonzero determinant proof.

This is a source-level repair **without local Lean compilation**. The only
compilation authority is the user's Windows Lean 4.33.0 compiler. Runner is
still accelerated/cached, directly invoking the pinned native Lean binary.

There is exactly **one** `run.cmd` in the archive.
