# Section 4A: exact Lean extension from frozen 47/47

User Windows Lean 4.33.0 compiler checkpoint: `MAIN_CHAIN_PAPER_ORDER_SECTION3` **47/47 PASS**.
Existing Lean sources are unchanged; new files are modules 48–53.

- 48: actual finite rational-denominator exclusion using an integer polynomial, normalized spectral factorization, and an explicit evaluation budget.
- 49: uniform real measure and irrationality theorem from the explicitly stated LocalComparison/Decay/IndexBudget conditions.
- 50: nonzero-integer resultant product barrier, without pretending the concrete polynomial resultant identity is already constructed.
- 51: finite Horner polynomial unit-disc bounds and nonarchimedean zero-free disk under explicit ultrametric norm laws. Concrete p-adic instance remains to be constructed.
- 52: exact rational decay/exponent margins of Theorem 4.4 (not the missing analytic spectral bound).
- 53: chronological entry point `MAIN_CHAIN_PAPER_ORDER_SECTION4A`.

**NOT CLAIMED:** complete paper Theorems 4.1–4.4, actual height bound, or final irrationality measure, since the concrete uniform estimates and certain interfaces remain separate.

Native Windows Lean 4.33.0, 16 threads, persistent previously certified `.olean` files. Exactly one `run.cmd`.
No local Lean compilation was run during creation; only the user's compiler is authoritative.
