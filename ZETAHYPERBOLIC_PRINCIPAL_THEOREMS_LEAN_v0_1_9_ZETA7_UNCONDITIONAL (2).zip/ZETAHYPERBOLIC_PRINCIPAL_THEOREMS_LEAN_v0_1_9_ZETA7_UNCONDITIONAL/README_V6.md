# V6 single-run package

One ZIP, one `run.cmd`. Native Lean 4.33.0 and Mathlib pinned to user's
existing cache. The persistent frozen cache reuses the user-verified 97
modules. Compile only the five new Lean modules and affected dependents.

Expected initial new check: `CHECK=98/102`. If a source changes or a
dependency becomes invalidated the runner automatically rebuilds the
affected module. No local Lean compilation has been performed.

See `MATHEMATICAL_GATE_AUDIT_V6.md` for exact mathematical scope.
