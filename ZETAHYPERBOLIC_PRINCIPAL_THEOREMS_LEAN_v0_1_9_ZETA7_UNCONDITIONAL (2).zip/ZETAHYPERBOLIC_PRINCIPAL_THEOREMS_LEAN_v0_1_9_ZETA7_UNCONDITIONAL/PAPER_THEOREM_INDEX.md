# Full manuscript theorem index — chronological

This register distinguishes **the existence of code** from a proof of the **exact
printed statement**. All entries retain their PDF numbering. New Lean source
was NOT compiled here; only old user-supplied archived checks are available.

| PDF | Item | Status | Exact remaining issue |
|---|---|---|---|
| 2.1 | Definition: Order-s rational moment functional (p. 3) | DEFINITIONS_PRESENT | Concrete tau and mu generator values and genuine Hankel pencil defined. |
| 2.2 | Lemma: Pullback identity (p. 4) | NEW_NORMAL_FORM_PROOF_SOURCE_ONLY | Monomial, pole and finite normal-form pullback; awaiting Windows compiler. |
| 2.3 | Lemma: Reflection and difference identities for tau (p. 5) | GENERATOR_PROOFS_FROM_CHECKED_UPSTREAM | Reflection on monomials and poles, and difference identity on poles. |
| 2.4 | Theorem: Canonical basis invariance (p. 6) | CORE_CHECKED_UPSTREAM | Exact change of basis, determinant scalar, primitive normalization. |
| 2.5 | Theorem: Lagrange pole diagonalization (p. 6) | CORE_CHECKED_UPSTREAM_NEW_WRAPPER_SOURCE_ONLY | Vandermonde slope, Lagrange evaluations and exact degree. |
| 3.1 | Theorem: Universal hyperbolicity and zero-free disk (p. 7) | UNCONDITIONAL_UPSTREAM_VERIFIED_NEW_WRAPPER_SOURCE_ONLY | General odd-weight Gram positivity, root realness and disk. |
| 3.2 | Proposition: Continuous hyperbolic pencil for all real s > 1 (p. 8) | PARTIAL_ABSTRACT_SPECTRAL_LEMMA | Printed continuous weight differs by pi/2 at odd integer indices. |
| 3.3 | Theorem: Total positivity, leading sign, and universal signature (p. 8) | PARTIAL_LEADING_COEFFICIENT | Full strict total positivity and signature not yet checked. |
| 3.4 | Theorem: Root interlacing and Dodgson condensation for principal minors (p. 9) | FALSE_AS_PRINTED_COUNTEREXAMPLE | First principal minor can be constant, so inverse-zero root statements fail. |
| 3.5 | Corollary: Stieltjes J-fraction from interlacing roots (p. 10) | NEEDS_CORRECTION | Continued fraction normalization and possible cyclicity gap. |
| 3.6 | Corollary: Stieltjes reciprocal-root power sums (p. 11) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 3.7 | Theorem: Turanian non-negativity and Newton log-concavity (p. 11) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 3.8 | Theorem: Christoffel-Darboux pole representation and Jacobi derivative identity (p. 12) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 3.9 | Theorem: Hyperbolicity for Hurwitz and Dirichlet Hankel determinants (p. 13) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 3.10 | Remark: Non-classicality of the Hankel family (p. 14) | REMARK_REQUIRES_PRECISE_DEFINITION | Non-classicality needs corrected hypothesis. |
| 4.1 | Theorem: Spectral irrationality measure criterion (p. 14) | ABSTRACT_CONDITIONAL_TRANSFER_CHECKED_UPSTREAM | Paper exponents need specific spectral/arithmetic data. |
| 4.2 | Proposition: Transfer criterion for algebraic approximations (p. 15) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.3 | Proposition: Ultrametric zero-free disk over Qp (p. 15) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.4 | Theorem: Sharpened spectral bound and effective irrationality measure for zeta(5) (p. 16) | PARTIAL_WITNESS_CONDITIONAL | Decay/normalization witness is explicit; quantitative spectral growth remains unproved. |
| 4.5 | Theorem: Irrationality and effective measure for b*zeta(5)+a*zeta(3) (p. 18) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.6 | Theorem: Two-sided determinant bounds and coefficient heights (p. 19) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.7 | Theorem: Macroscopic exponential root collapse and root separation (p. 21) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.8 | Proposition: Rational root exclusion and degree bounds for cluster factors (p. 21) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.9 | Remark: Spectral bounds and variational conjecture (p. 22) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.10 | Remark: Lee-Yang phase transition at zeta(5) (p. 22) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 4.11 | Conjecture: Conjecture about limiting spectral growth constant (p. 22) | CONJECTURE_NOT_THEOREM | Manuscript labels it a conjecture. |
| 5.1 | Theorem: Two-variable Beukers measure for zeta(7) (p. 22) | PARTIAL_DEFINITIONS | Two-variable integral evaluation not fully formalized. |
| 5.2 | Theorem: Dual hyperbolicity and Krein-space decomposition (p. 23) | PARTIAL_CONDITIONAL_FINITE_CERTIFICATE | Positive/negative cone existence and tails not constructed. |
| 5.3 | Proposition: Two-variable Beukers measure and dual pencil for beta(4) (p. 24) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 5.4 | Theorem: Cancellation of higher zeta values on even pole pairs (p. 25) | FINITE_POLE_IDENTITY_PROVED_SOURCE_ONLY | Pole-pair cancellation only; full tau identities rely on Section2. |
| 5.5 | Remark: Restriction to simple-pole case (p. 25) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 5.6 | Theorem: Weight-seven prime-sum evaluation and pole-ordered refinement (p. 26) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 5.7 | Theorem: Simultaneous double-pole Hankel determinant for 1,zeta(5),zeta(6) (p. 28) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.1 | Theorem: Divided-difference p-adic valuation law and intrinsic p^-6 barrier (p. 29) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.2 | Theorem: Simultaneous weight-(6,7) Beukers functional (p. 31) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.3 | Theorem: Unconditional q-adic non-vanishing and positive-cone approximations (p. 32) | PARTIAL_CONDITIONAL_POSITIVE_BASIS | Finite certificate and q-adic non-vanishing not established. |
| 6.4 | Theorem: Character-Vandermonde sign cancellation and beta(4) hyperbolicity (p. 33) | PARTIAL_BETA_INTERFACE | Positive kernel not constructed. |
| 6.5 | Theorem: Unconditional q-adic nonvanishing for beta(4) (p. 34) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.6 | Theorem: Generalized multi-weight positive-definite pencil (p. 35) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.7 | Theorem: Universal multi-weight two-variable Beukers Krein decomposition (p. 37) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.8 | Corollary: Unconditional three-term linear independence cone (p. 38) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.9 | Theorem: Triple-pole and multi-weight Hankel determinants (p. 38) | PARTIAL_FINITE_HERMITE_REPAIR | No q-adic endpoint proved. |
| 6.10 | Theorem: Universal potential-gap identity and vanishing quadratic derivative growth (p. 39) | PARTIAL_WITH_INVALID_PRINTED_INFERENCE | Missing upper decay-rate bound; existing lower rate bound is insufficient for the >581 ratio. |
| 6.11 | Theorem: Distribution growth law and 2-adic polynomial-quotient obstruction (p. 40) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.12 | Theorem: Sign-flip restoration of positive definiteness and q-adic non-vanishing (p. 42) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.13 | Theorem: Central-factorial secant differential identity and Laplace mode annihilation (p. 43) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.14 | Theorem: Even-pole scaling via cosh and positive-definite Zeta-Beta pencils (p. 45) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.15 | Theorem: Arithmetic transcendence and strictly positive one-variable measure (p. 46) | PENDING_EXACT_PAPER_PROOF | No complete theorem proof in the assembled source graph. |
| 6.16 | Theorem: Generalized multi-weight Zeta-Beta positive-definite pencil (p. 47) | PARTIAL_COMPACTNESS_LEMMA | Weight ratio and endpoints not verified. |
| 6.17 | Theorem: Universal two-variable Beukers Zeta-Beta pencil (p. 48) | PARTIAL_FINITE_INDEX_REPAIR | q-adic determinant valuation still missing. |
| 6.18 | Theorem: Principal-minor 2-adic integrality and dyadic height bounds (p. 49) | PARTIAL_FINITE_QUOTIENT_REPAIR | 2-adic measure still missing. |
