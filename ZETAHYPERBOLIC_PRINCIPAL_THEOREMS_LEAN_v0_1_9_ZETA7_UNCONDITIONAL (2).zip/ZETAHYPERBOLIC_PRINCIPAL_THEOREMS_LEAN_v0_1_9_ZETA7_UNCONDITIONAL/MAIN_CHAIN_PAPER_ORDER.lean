import PaperOrder.Definition_2_1_Order_s_Rational_Moment_Functional
import PaperOrder.Lemma_2_2_Pullback_Identity
import PaperOrder.Lemma_2_3_Reflection_And_Difference_Identities
import PaperOrder.Theorem_2_4_Canonical_Basis_Invariance
import PaperOrder.Theorem_2_5_Lagrange_Pole_Diagonalization
import PaperOrder.Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import PaperOrder.Proposition_3_2_Continuous_Hyperbolic_Pencil
import PaperOrder.Theorem_3_3_Total_Positivity_Leading_Sign_And_Signature
import PaperOrder.Theorem_3_4_Principal_Minor_Repair_Frontier

/-!
# Master chain in the PDF's EXACT chronological order.

This entrypoint includes all checked and source-only theorem-specific Lean
modules through the first 3.4 repair frontier. Its final theorem is the
unconditional general odd-weight spectral result (3.1), not a specialised
zeta(5) endpoint. Theorem 3.2 is only proved as a generic spectral transfer,
3.3 only as the leading-coefficient component, and the false printed 3.4 has
a checked obstruction. See PAPER_THEOREM_INDEX.csv for the rest of the PDF.
There is NO fabricated proof or extra conditional axiom for unfinished claims.
-/

namespace PaperOrder

/-- The general manuscript theorem reached after the actual Section 2 chain. -/
theorem MAIN_CHAIN_PAPER_ORDER (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  Section3.theorem_3_1_universal_hyperbolicity p hp

end PaperOrder

#print axioms PaperOrder.MAIN_CHAIN_PAPER_ORDER
#print axioms PaperOrder.Section2.lemma_2_2_normal_form
#print axioms PaperOrder.Section2.lemma_2_3_reflection_monomial
#print axioms PaperOrder.Section2.theorem_2_5_pencil_and_degree
#print axioms PaperOrder.Section3.proposition_3_2_abstract_roots_real
#print axioms PaperOrder.Section3.theorem_3_3_algebraic_leading_coefficient
#print axioms PaperOrder.Section3.theorem_3_4_first_principal_minor_obstruction
