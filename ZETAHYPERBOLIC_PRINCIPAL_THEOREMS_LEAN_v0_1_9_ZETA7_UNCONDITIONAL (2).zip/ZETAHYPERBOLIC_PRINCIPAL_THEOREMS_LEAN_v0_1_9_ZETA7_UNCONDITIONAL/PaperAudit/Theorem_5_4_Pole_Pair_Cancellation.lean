import Definition_2_1_Order_s_Rational_Moment_Functional
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Tactic.Ring

/-!
The exact elementary simple-pole component of manuscript Theorem 5.4.
This does NOT formalize the full auxiliary functional tau on rational functions;
it formalizes its defining pole values and the cancellation on +/-j.
-/

namespace PaperAudit
open ManuscriptChain.Real

/-- Harmonic increments at every weight and every nonnegative index. -/
theorem harmonic_succ_sub (s n : ℕ) :
    harmonic s (n + 1) - harmonic s n =
      1 / (((n + 1 : ℕ) : ℚ) ^ s) := by
  simp [harmonic, Finset.sum_range_succ, add_comm, add_left_comm, add_assoc]

/-- Formula (2.4) at a positive pole x=j, with j=n+1. -/
def tauPositivePole (s n : ℕ) (X : ℚ) : ℚ := harmonic s (n + 1) - X

/-- Formula (2.4) at the negative pole x=-j, with j=n+1. -/
def tauNegativePole (s n : ℕ) (X : ℚ) : ℚ := harmonic s n - X

/-- Theorem 5.4, identity (5.5), for the exact defining pole evaluations. -/
theorem even_pole_pair_cancellation (s n : ℕ) (X : ℚ) :
    tauPositivePole s n X - tauNegativePole s n X =
      1 / (((n + 1 : ℕ) : ℚ) ^ s) := by
  change (harmonic s (n + 1) - X) - (harmonic s n - X) = _
  rw [show (harmonic s (n + 1) - X) - (harmonic s n - X) =
      harmonic s (n + 1) - harmonic s n by ring]
  exact harmonic_succ_sub s n

end PaperAudit

#print axioms PaperAudit.even_pole_pair_cancellation
