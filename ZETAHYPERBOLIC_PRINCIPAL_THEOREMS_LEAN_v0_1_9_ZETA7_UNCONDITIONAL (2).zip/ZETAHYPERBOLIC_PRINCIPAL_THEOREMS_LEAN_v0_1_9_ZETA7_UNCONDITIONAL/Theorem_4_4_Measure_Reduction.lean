import Equation_4_3_Paper_Witness
import Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5

/-!
# Theorem 4.4: exact frontier for exponent 25687

The paper's ARITHMETIC witness alone proves irrationality. A quantitative
irrationality MEASURE additionally uses the paper's uniform relative spectral
bound ‖B_K‖ <= exp(11.411 K). The source formalizes the transfer and the
constructed eigenfactorization, but the quantitative bound itself is NOT
proved. Hence this is a TWO-input reduction, deliberately NOT mislabelled
as a one-witness theorem.

If the spectral bound is proved unconditionally in a future module, this
becomes a one-witness implication immediately by passing the proved value.
-/

noncomputable section
namespace PaperWitnessOnly
open ManuscriptChain
open ManuscriptChain.MainChain

/-- The exact PDF exponent follows *from the witness and the separate
spectral estimate*. `spectrum` is the mathematical gap that MUST be
eliminated to make this endpoint witness-only. -/
theorem MEASURE_25687_OF_WITNESS_AND_SPECTRAL
    (w : PaperWitness)
    (spectrum : MainChain.MainSpectralData (normalization w).onset) :
    ∀ (a : ℤ) (b : ℕ), 0 < b →
      MainChain.indexDenominatorThreshold (normalization w).onset ≤ b →
      1 / (b : ℝ) ^ 25687 <
        |MainChain.zeta5 - (a : ℝ) / (b : ℝ)| := by
  exact RealTransfer.conditional_measure
    (MainChain.main_localComparison (normalization w) spectrum)
    (decay_of_witness w)
    (MainChain.main_indexBudget (normalization w))

end PaperWitnessOnly

#print axioms PaperWitnessOnly.MEASURE_25687_OF_WITNESS_AND_SPECTRAL
