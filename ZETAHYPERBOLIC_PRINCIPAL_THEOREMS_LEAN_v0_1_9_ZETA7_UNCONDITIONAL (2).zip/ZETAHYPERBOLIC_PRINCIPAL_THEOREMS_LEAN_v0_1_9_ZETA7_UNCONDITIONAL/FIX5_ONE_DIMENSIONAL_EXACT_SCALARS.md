# FIX5 — Rational one-dimensional dual moment witness (module 113/115)

The user compiler has certified modules 1–112, and compilation fails in the
one-dimensional rational witness module 113. The supplied log excerpt only
shows the final axiom printouts, not the first underlying error, so this is
a targeted proof-tactic repair rather than an assertion of compiler success.

Changes confined to `PaperOrder/Principal_Theorem_5_2_OneDimensional_Rational_Witness.lean`:

* Evaluate the 2×2 finite rational dual moment sums independently of the
  `Fin 1` determinant reduction.
* Prove the exact constant/slope pairs `(-38,37)` and `(0,1)` for the rows
  `1-6x` and `1`, respectively.
* Reduce `Matrix.det` of a 1×1 matrix with `Matrix.det_fin_one`, then
  rewrite using these scalar lemmas. No new axioms or sorry placeholders.

No changes to already-compiler-verified modules 1–112. Build is run on the
user's Windows Lean 4.33 installation; this archive is not locally compiled.

**Scope**: The result `ζ(7) < 38/37` remains an explicit analytic premise
for the negative witness. Do not infer the paper's full infinite Krein cone
or irrationality from the finite scalar identity.
