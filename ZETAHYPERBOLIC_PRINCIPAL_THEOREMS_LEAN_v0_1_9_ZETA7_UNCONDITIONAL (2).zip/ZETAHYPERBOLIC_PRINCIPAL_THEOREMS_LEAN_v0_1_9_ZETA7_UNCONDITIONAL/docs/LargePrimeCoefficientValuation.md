# A large-prime coefficient valuation for the full Hankel determinant

This note proves an exact local arithmetic statement for the manuscript's actual one-variable rational pencil. It is a mathematical derivation, independently audited and checked against exact rational computations; it is **not a Lean theorem**. It supplies a lower bound for the primitive leading coefficient. It does not prove normalized decay or its failure.

## Statement

Let `k,m,N,K` be positive integers, put

\[
s=2k+1,\quad h=K-N,\quad
D_N(t)=\prod_{j=1}^N(t+j^2),\quad
T(t)=\prod_{a=N+1}^K(t+a^2),\quad F(t)=D_N(t)^{2m-1}.
\]

Use exactly the order-`s` functional of Definition 2.1:

\[
\mu_X(t^e)=\frac{(-1)^e B_{2e+2}}{(2k)!}
 \prod_{j=1}^{2k-1}(2e+2+j),
\qquad
\mu_X((t+a^2)^{-1})=
 a^{s-1}(X-H_a^{(s)})+\frac1{2a}-\frac1{s-1}.
\]

Let

\[
G_s(X)_{ij}=\mu_X\left(\frac{F(t)t^{i+j}}{T(t)}\right),
\qquad \Delta_s(X)=\det G_s(X),\qquad 0\le i,j<h.
\]

Suppose `p` is prime and

\[
3N<K,\qquad \frac{2K}{3}<p\le K-N,\qquad
p>2k,\qquad s>2m. \tag{1}
\]

Set

\[
E=K+(2m-2)N-2.
\]

Assume the polynomial moments `μ(t^e)` are `p`-integral for `0≤e≤E`. The following explicit sufficient condition discharges this assumption:

\[
E+1<k(p-1). \tag{2}
\]

Then the coefficient of degree `p−N−1` has the exact valuation

\[
\boxed{\quad
v_p\big([X^{p-N-1}]\Delta_s\big)
=2(2m-1)N-s(K-p)-1.
\quad} \tag{3}
\]

The leading coefficient satisfies

\[
v_p(\operatorname{lc}\Delta_s)=2(2m-1)N+s-1. \tag{4}
\]

Consequently, if `P_s` is the primitive integer polynomial obtained by any positive rational rescaling of `Δ_s`,

\[
\boxed{\quad
v_p(\operatorname{lc}P_s)\ge s(K-p+1).
\quad} \tag{5}
\]

Equation (5) is a lower bound, not an equality: some other coefficient may have a valuation smaller than the coefficient in (3).

## Why condition (2) makes the polynomial part integral

Write `n=2e+2`. Since `p>2k`, the factorial `(2k)!` is a `p`-adic unit. The von Staudt–Clausen denominator theorem says that `B_n` is `p`-integral unless `p−1` divides `n`, and in the latter case its valuation is exactly `−1`.

In that latter case put `n=j(p−1)`. Condition (2) gives `n<2k(p−1)`, hence `1≤j≤2k−1`. The factor `n+j=jp` occurs in `∏_{r=1}^{2k−1}(n+r)`, canceling the only possible Bernoulli denominator. Thus all the required polynomial moments are integral.

This invocation of von Staudt–Clausen is an established mathematical ingredient of this on-paper proof; the package does not presently contain a Lean proof of this arithmetic step.

## An integer interpolation basis removes residue denominators

For each tail pole put

\[
v_a=-a^2,\qquad L_a(t)=\frac{T(t)}{t+a^2}\in\mathbb Z[t].
\]

These `h` polynomials form a rational basis of degree less than `h`. Let `C` be their coefficient matrix with rows `C_{a,i}=[t^i]L_a`, and set

\[
G'_s=C G_s C^{\mathsf T}.
\]

For `a≠b`,

\[
\frac{F L_aL_b}{T}
=\frac{FT}{(t+a^2)(t+b^2)}\in\mathbb Z[t].
\]

For `a=b`, monic division gives

\[
\frac{F L_a^2}{T}
=Q_{aa}(t)+\frac{c_a}{t+a^2},
\qquad
c_a=F(v_a)T'(v_a),\quad Q_{aa}\in\mathbb Z[t].
\]

The off-diagonal polynomial above and every `Q_aa` have degree at most `E`. Thus

\[
G'_s(X)=\operatorname{diag}(d_a)X+B,
\qquad d_a=c_a a^{s-1}, \tag{6}
\]

where

\[
B_{ab}=\mu(Q_{ab})\quad(a\ne b),
\]

\[
B_{aa}=\mu(Q_{aa})+
 c_a\left(-a^{s-1}H_a^{(s)}+\frac1{2a}-\frac1{s-1}\right).
\]

Every polynomial contribution is integral. In particular every off-diagonal entry of `B` is integral. No residue denominator has been discarded or presumed integral.

## Collision counts and diagonal valuations

For a nonzero square residue class modulo `p`, let `l_K` count its representatives in `{1,…,K}`, let `l_N` count its representatives in `{1,…,N}`, and put `l=l_K−l_N` for its tail representatives.

Conditions (1) imply `K<3p/2` and `N<p/2`. Therefore `l_K≤3` and `l_N≤1`. For two distinct positive tail indices with equal square modulo `p`, exactly one of their sum and difference is divisible by `p`, and that factor has valuation one. Their ranges exclude a nonzero multiple of `p²`. The exceptional index `a=p` is the only index divisible by `p`, and its square collides with no other tail square.

It follows that, for `a≠p`,

\[
\alpha_a:=v_p(c_a)
=(2m-1)l_N+(l-1)
=(2m-2)l_N+l_K-1\le 2m. \tag{7}
\]

Also `α_p=0`. Split the indices into

\[
\mathcal L=\{N+1,\ldots,p-1\},\qquad
\mathcal H=\{p,\ldots,K\}.
\]

For `a∈L`, the harmonic sum and all pole correction terms are integral. Hence `B_aa` is integral and

\[
v_p(d_a)=\alpha_a.
\]

For `a>p`, the harmonic sum has the exact decomposition

\[
H_a^{(s)}=p^{-s}+u_a,\qquad u_a\in\mathbb Z_p.
\]

Here `a` is a unit, so

\[
v_p(d_a)=\alpha_a,\qquad
v_p(B_{aa})=\alpha_a-s<0. \tag{8}
\]

The negative term cannot cancel against the integral polynomial contribution or the remaining integral pole terms.

At `a=p`, the cancellation between the harmonic term and `1/(2p)` is explicit:

\[
-p^{s-1}H_p^{(s)}+\frac1{2p}-\frac1{s-1}
=-\frac1{2p}-p^{s-1}u_p-\frac1{s-1}.
\]

Since `p>2k≥2`, its valuation is exactly `−1`. Thus

\[
v_p(d_p)=s-1,\qquad v_p(B_{pp})=-1. \tag{9}
\]

Define `β_a=v_p(B_aa)` for high indices. Equations (8)–(9) give the useful uniform identity

\[
v_p(d_a)-\beta_a=s\qquad(a\in\mathcal H). \tag{10}
\]

## Principal minors and the unique coefficient minimum

For any index subset `J`, the determinant expansion gives

\[
v_p(\det B_{J,J})\ge
\sum_{a\in J\cap\mathcal H}\beta_a. \tag{11}
\]

Indeed, the only entries with negative valuation are the high diagonal entries. Each permutation can use any given such entry at most once; omitting a negative entry only raises this lower bound. All other entries are integral. This proof includes all off-diagonal contributions.

For `J=H`, equality holds in (11): the identity permutation has valuation `∑_H β_a`, whereas every other permutation omits at least one negative diagonal entry and therefore has strictly larger valuation. There is a unique lowest-valuation product.

Because the `X` coefficient in (6) is diagonal,

\[
[X^\ell]\det G'_s(X)=
\sum_{\substack{I\subseteq\{N+1,\ldots,K\}\\|I|=\ell}}
\left(\prod_{a\in I}d_a\right)\det B_{I^c,I^c}.
\]

Choose `ℓ=|L|=p−N−1`. The term `I=L` has exact valuation

\[
V=\sum_{a\in\mathcal L}\alpha_a+
  \sum_{a>p}(\alpha_a-s)-1
 =\sum_a\alpha_a-s(K-p)-1. \tag{12}
\]

Any other `I` replaces `q≥1` low indices by `q` high indices. Apply (11) and (10). Relative to (12), each added high derivative contributes a gain `s`, while removing a low derivative can save at most `α_a≤2m`. Thus the valuation of every other term is at least

\[
V+q(s-2m)>V.
\]

This proves the exact coefficient valuation in the transformed basis. It does not assume the low principal submatrix is nonsingular and does not assume its determinant is a unit.

## Returning to the monomial basis

The evaluation matrix of the `L_a` basis at the tail nodes is diagonal with entries `T'(v_a)`. Comparing it to the Vandermonde evaluation matrix gives

\[
2v_p(\det C)=\sum_a v_p(T'(v_a)).
\]

Since `det G'_s=(det C)^2 Δ_s`, subtracting this from (12) leaves

\[
v_p([X^\ell]\Delta_s)
=(2m-1)\sum_a v_p(D_N(v_a))-s(K-p)-1.
\]

Every `j≤N` has exactly two tail representatives of its square class: `p−j` and `p+j`. Both are in the tail because `p>N+N` and `p+N≤K`. The potential representative `2p−j` exceeds `K` because `2p−N>K`. Each of the two factors contributes valuation one. Therefore

\[
\sum_a v_p(D_N(v_a))=2N,
\]

proving (3).

The leading coefficient follows directly from (6):

\[
\operatorname{lc}\Delta_s
=\frac{\prod_a c_a a^{s-1}}{(\det C)^2}.
\]

Equivalently, cancellation of the Vandermonde factors gives the exact integer factorization

\[
\operatorname{lc}\Delta_s
=(-1)^{h(h-1)/2}\prod_{a=N+1}^K F(-a^2)a^{s-1}.
\]

Only `a=p` is divisible by `p`, proving (4).

Finally, if `v_min` is the minimum valuation of the nonzero coefficients of `Δ_s`, primitive integer normalization has scale valuation `−v_min`. Since `v_min` is at most the value in (3), subtracting (3) from (4) proves (5).

## Consequence over a fixed prime interval

Fix `k,m` with `s=2k+1>2m`, and let `N/K→α` with `0≤α<1/3`. Put

\[
y_0=\max\left(\frac23,\frac{1+(2m-2)\alpha}{k}\right).
\]

If `y_0<1−α`, every fixed interval `y_0<u<v<1−α` eventually satisfies all hypotheses for primes `uK<p≤vK`. Since the primitive leading coefficient is a nonzero integer, other primes cannot contribute negative valuations. Thus (5) and the prime number theorem yield

\[
\liminf_{K\to\infty}\frac{\log|\operatorname{lc}P_s|}{K^2}
\ge s\int_u^v(1-y)\,dy.
\]

Letting the interval approach the endpoints gives

\[
\boxed{\quad
\liminf\frac{\log|\operatorname{lc}P_s|}{K^2}
\ge \frac{s}{2}\left((1-y_0)^2-\alpha^2\right).
\quad} \tag{13}
\]

This use of the prime number theorem is also on paper, not formalized in Lean.

For the fixed kernel parameters `m=3`, `N/K→1/10`, every `k≥3` has `y_0=2/3`. Equation (13) becomes

\[
\liminf\frac{\log|\operatorname{lc}P_s|}{K^2}
\ge \frac{91s}{1800}.
\]

At weight seven this is `637/1800≈0.353889`.

## What this establishes about the proposed rank shortcut

The unique term `p^{-s}` in each harmonic sum does not make the whole singular matrix rank one: it is carried by many distinct tail evaluation vectors. After the integer interpolation change of basis, high poles have distinct negative diagonal directions. Their contribution survives in a full determinant coefficient with an exact valuation.

Consequently, a claim that the higher-weight arithmetic cost is automatically only `exp(O(K log K))` cannot follow from a bounded-rank interpretation of that harmonic term. The lower bound above is quadratic in the prime sum and linear in the weight.

This does not compare the complete primitive normalizers at two weights and does not decide normalized decay. For the same kernel, the exact unnormalized leading-coefficient ratio is

\[
\frac{|\operatorname{lc}\Delta_s|}{|\operatorname{lc}\Delta_5|}
=\prod_{a=N+1}^K a^{s-5},
\]

whose logarithm is `O_s(K log K)`. A full normalization comparison would therefore require controlling the primitive leading coefficients, including their upper bounds, rather than only their unnormalized leading terms.

## Exact rational checks

A separate verification script, excluded from the distributed package, uses only Python integers and `fractions.Fraction`. It constructs the original monomial-basis rational pencil from polynomial division and the defining moments, evaluates its determinant at `h+1` integer points, and recovers all coefficients by exact interpolation. It does not use the claimed valuation formula to construct the determinant. The full rational coefficients are saved in `validation/arithmetic/large_prime_coefficient_checks.json`, and a plain-text result log is saved alongside it. The script itself is not distributed.

| `(K,N,m,k,p)` | Selected coefficient valuation | Predicted | Primitive leading valuation | Lower bound |
|---|---:|---:|---:|---:|
| `(8,1,1,2,7)` | −4 | −4 | 12 | 10 |
| `(10,1,2,2,7)` | −10 | −10 | 28 | 20 |
| `(10,1,2,3,7)` | −16 | −16 | 36 | 28 |
| `(14,1,2,3,11)` | −16 | −16 | 36 | 28 |
| `(14,2,2,3,11)` | −10 | −10 | 38 | 28 |

These finite checks are secondary evidence. The coefficient expansion and unique valuation minimum above are the proof for the stated general parameters.
