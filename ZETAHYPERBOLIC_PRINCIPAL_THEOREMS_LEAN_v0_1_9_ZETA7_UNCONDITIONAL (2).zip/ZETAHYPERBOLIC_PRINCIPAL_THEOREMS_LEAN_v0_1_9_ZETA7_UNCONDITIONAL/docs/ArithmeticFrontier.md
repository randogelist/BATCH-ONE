# Arithmetic progress and a fixed-geometry obstruction

This note separates Lean-checked identities from classical arguments. It
does not assert irrationality of a new odd zeta value. The classical results
below concern the actual determinant polynomials and their primitive integer
normalizations, rather than an arbitrary choice of denominator multiplier.

## 1. An exact, canonical rate comparison (Lean checked)

For admissible p=(k,m,N,K), write s=2k+1, h=K-N, xi=zeta(s), and let P_p
be the positive primitive integer normalization of Delta_p. Define

    Lambda_p = |leadingCoeff(P_p)|,
    R_p = det G_p(xi) / |det M_p|.

The new module `Theorem_4_1_Leading_Coefficient_Gap.lean` proves

    Lambda_p >= 1,     R_p > 0,
    P_p(xi) = Lambda_p * R_p.

The identity itself holds without the admissibility premise; positivity
uses admissibility. For an admissible, fixed-weight family with K unbounded
on every tail, Lean also proves the implication

    eventually Lambda_p <= exp(A*K^2),
    eventually R_p <= exp(-B*K^2),
    A < B
      ==> normalized quadratic decay with rate B-A
      ==> Irrational(zeta(2k+1)).

The two eventual bounds remain explicit hypotheses. No quantitative
spectral estimate is needed by this direct irrationality endpoint.

## 2. Changing the weight (exact identity checked; asymptotics on paper)

At fixed m,N,K, the new module `Theorem_2_5_Weight_Change.lean` proves

    det M_(k+d) = det M_k * product_(a=N+1)^K a^(2d)

for nonnegative integer d, together with a division-free comparison for
any two nonnegative weight indices. The identity holds even in dimension
zero and requires no admissibility hypothesis. It also holds for the
leading coefficient of the actual rational determinant polynomial.

Combining it with the classical comparison proved in
`FixedWeightDeterminantComparison.md` gives, for fixed k,m>=1,

    log(R_k/R_2) = O_(k,m)(K log(K+1)).                 (2.1)

Indeed, the extra logarithm is exactly
`-2*(k-2)*sum_(a=N+1)^K log a`, whose absolute value is at most
`2*|k-2|*K*log(K+1)`. Thus the leading quadratic rate of R_k is
independent of each fixed odd weight. This statement permits a liminf or
limsup and does not assume that a limiting rate exists. It is not uniform
when k grows with K.

This leaves a particularly concrete arithmetic task: control the integer
Lambda_p. A weight comparison for the raw determinant does not control it.

## 3. Two new local arithmetic facts (on paper)

`PolynomialMomentDenominatorRank.md` proves that the first monomial moment
with a p-denominator, for p>2k, has index e=k(p-1)-1. Under its stated
threshold condition, the denominator rank of the polynomial-quotient
matrix is exactly

    max(0, K+(2m-2)N-k(p-1)).

This supplies an actual rank saving in a denominator upper bound. Raising
k decreases this contribution. Other pole contributions must still be
included; this rank is not the denominator rank of the full pencil.

`LargePrimeCoefficientValuation.md` treats a different contribution. If

    N < K/3,       2K/3 < p <= K-N,
    p > 2k,        s=2k+1 > 2m,
    k(p-1) >= K+(2m-2)N,

then the polynomial part is p-integral and a specific coefficient satisfies

    v_p([X^(p-N-1)] Delta_p)
      = 2(2m-1)N - s(K-p) - 1.

Together with the exact leading coefficient this implies the unavoidable
primitive divisibility

    v_p(Lambda_p) >= s(K-p+1).                       (3.1)

The integer Lagrange change of basis and its determinant are included in
that proof. Thus (3.1) accounts for common content; it is not merely an
estimate for a possibly wasteful entrywise denominator clearing.

## 4. Fixed geometry cannot work for all sufficiently high odd weights

Here is a classical consequence of (2.1) and (3.1). Fix m>=1 and
alpha in (0,1/3). Let K tend to infinity along any integer sequence, with
N/K tending to alpha. For all sufficiently large fixed k, the primitive
values P_(k,m,N,K)(zeta(2k+1)) grow at a positive quadratic exponential
rate. In particular, this one fixed geometry cannot prove irrationality
at every odd weight through normalized small values.

The statement concerns fixed k followed by K tending to infinity. It does
not concern a joint limit k=k(K), nor families where m or the limiting
ratio N/K are chosen differently for different k.

### 4.1 Arithmetic lower rate

Choose k so that s>2m and

    2k/3 > 1+(2m-2)alpha.

For all sufficiently large K, every prime in `(2K/3, K-N]` satisfies
the conditions of (3.1). Since Lambda is a positive integer, valuations
at all other primes are nonnegative. Consequently

    log Lambda >= s * sum_(2K/3<p<=K-N) (K-p+1) log p.

The prime number theorem and partial summation give

    liminf K^(-2) log Lambda
      >= s * integral_(2/3)^(1-alpha) (1-x) dx
      = s * (1/18-alpha^2/2).                       (4.1)

The positive constant c_alpha=1/18-alpha^2/2 is independent of k.
For the previously displayed geometry N=3(n+1), K=30(n+1), it equals
91/1800. This is a lower bound, not an exact arithmetic growth rate.

### 4.2 A finite analytic lower rate independent of the fixed weight

There is a finite constant C_(alpha,m) such that

    liminf K^(-2) log R_2 >= -C_(alpha,m).           (4.2)

Here is an elementary proof, included so that finiteness is not an
unproved asymptotic assumption. Let t=2m-1 and h=K-N. The Gram kernel is

    W(y) = D_N(y^2)^(2m) / D_K(y^2),
    D_j(u) = product_(a=1)^j (u+a^2).

Andreief's identity expresses the positive Gram determinant as

    det G_2 = (1/h!) integral V(y_1^2,...,y_h^2)^2
                      * product_i W(y_i) w_2(y_i) dy_1...dy_h.

Restrict the integral to the box `i <= y_i <= i+1/4`, i=1,...,h.
Since N>=1, every y_i lies between 1 and K. On this box,

    W(y_i) >= (N!)^(4m) / (2K^2)^K,
    w_2(y_i) >= c * exp(-2*pi*K)

for an absolute c>0, using just the n=1 term of the density. Moreover,
for i<j,

    y_j^2-y_i^2 >= (3/4)*(j-i)^2.

Therefore

    log V^2 >= h(h-1)*log(3/4)
                 + 4*sum_(d=1)^(h-1) (h-d)log d
             >= 2h^2 log h - C_0 h^2.

The final bound follows directly from Stirling's estimate, or from
`sum_(d=1)^(h-1)(h-d)log d = sum_(j=1)^(h-1)log(j!)` and integral bounds.
Because N/K tends to alpha>0 and h/K tends to 1-alpha>0, these estimates,
the box volume 4^(-h), and the factor 1/h! give

    log det G_2 >= 2tNh log K - C_1 K^2.             (4.3)

For completeness, the exact derivative determinant is

    det M_k = (-1)^(h(h-1)/2)
                * product_(a=N+1)^K D_N(-a^2)^t a^(2k).

This follows from the checked Vandermonde factorization and
`product_a T'(-a^2)=(-1)^(h(h-1)/2)*(det V)^2`, where
`T(u)=product_(a=N+1)^K(u+a^2)`. At k=2 it implies

    |det M_2| <= K^(2tNh+4h).

Subtracting its logarithm from (4.3) proves (4.2), after absorbing
4h log K into a constant times K^2. No sharp value of C is claimed.
Equation (2.1) then gives the same lower bound in (4.2) for every fixed k,
with the same C in the limiting inequality.

### 4.3 Combine the two bounds

The exact identity in section 1 now yields

    liminf K^(-2) log P_(k,m,N,K)(zeta(2k+1))
      >= (2k+1)c_alpha - C_(alpha,m).                (4.4)

The right side is positive for every sufficiently large fixed k. Thus
primitive values eventually exceed exp(c*K^2) for some c>0 at those
weights. Positive integer rescalings of the primitive polynomial only
increase these values, so alternative scalar normalizations cannot remove
this obstruction for the same determinant family.

This argument supplies no threshold for zeta(5) or zeta(7). It does not
exclude a family with weight-dependent m or alpha, alpha>=1/3, or a
different construction. It is not a disproof of odd-zeta irrationality.

## 5. A separate scalar shortcut is also excluded

`ScalarFamilyObstruction.md` proves, for h=1, N=K-1, m=1 and every fixed
k>=2,

    liminf K^(-1) log P_(k,1,K-1,K)(zeta(2k+1))
      >= (2k+1)/2 - log 4 > 0.

It computes the rational root, its reduced denominator, and the positive
analytic approximation error. Thus simply shrinking the matrix to one
dimension does not supply a decay certificate at these weights. That
result does not apply to k=1 or to every family of small dimensions.

## 6. What the results leave open

The general spectral theorem and the conditional irrationality implication
remain valid. We have not supplied the missing strict upper-rate gap.
The new arithmetic estimates constrain the choice of family: a uniform
argument for all odd weights must leave the fixed-m, fixed-alpha<1/3
regime at sufficiently high weights, or use another construction.

Only sections 1 and the exact identities in section 2 are newly checked
in Lean. The local prime arguments, scalar obstruction, and section 4 are
classical proofs, independently reviewed, with explicit external classical
inputs (von Staudt-Clausen and the prime number theorem). Exact-rational
sample checks support the local formulas but do not replace their proofs.

The standard arithmetic inputs are recorded in NIST's DLMF:
[von Staudt-Clausen](https://dlmf.nist.gov/24.10#i) and
[prime number theorem](https://dlmf.nist.gov/27.2#E3).
No claim in this note uses the beta-specific growth law printed in
Theorem 6.11 of the source PDF as a theorem about odd zeta values.
