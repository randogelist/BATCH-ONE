# v0.3.5 — FROZEN FASTCORE FIX2

Your compiler log confirmed `CHECK_PASS=10/38` and then showed Windows locking on module 12, followed by an absent `Zetahyperbolic/LagrangeBasis.olean` at module 13. `CHECK_PASS=12` was a false success report by the prior runner, **not** a proof verification.

This patch changes only runner/infrastructure; the 38 Lean sources and dependency plan are unchanged.

- Persistent cache remains `%USERPROFILE%\lean-native\zetahyperbolic_paper_frozen_lean433_v1`; successful 1–10 are reused if receipts match.
- One build per persistent cache, guarded by `active_build.lockdir`.
- Compilation creates a `.pending.olean` instead of writing over a frozen output.
- Success requires Lean exit code 0 **and** a present nonempty `.olean`.
- Publishing and stamp copying get bounded retries on Windows sharing violations.
- Source/environment/parent-generation receipts are written before the final generation certificate; `CHECK_PASS` prints only after that certificate and `.olean` are checked.
- A missing `.olean` automatically invalidates any stale prior success receipt, so module 12 must be recompiled. Actual changed dependents rebuild according to the dependency graph.
- No Lean was compiled while packaging. Your Windows Lean 4.33.0 is the sole verifier.

If `ERROR=CACHE_BUILD_ALREADY_RUNNING_OR_STALE_LOCK`, make sure no other copy of `run.cmd` is running. If it is a stale lock from a terminated process, manually remove `%USERPROFILE%\lean-native\zetahyperbolic_paper_frozen_lean433_v1\active_build.lockdir` before rerunning.
