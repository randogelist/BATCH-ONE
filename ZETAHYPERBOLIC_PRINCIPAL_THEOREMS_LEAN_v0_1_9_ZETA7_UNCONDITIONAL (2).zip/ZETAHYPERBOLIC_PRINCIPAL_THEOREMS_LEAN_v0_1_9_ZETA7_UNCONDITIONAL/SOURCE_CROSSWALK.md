# Source packages and admissible reuse

| Candidate source | What it supplies | Why it does **not** close the full manuscript |
|---|---|---|
| `Zetahyperbolic-general-assembled-lean433 (2).zip` | The checked source-only algebraic + analytic general odd-weight pencil and positive Gram; main proof graph | Does not provide printed 4.4 quantitative rates, 5.2 signed cones, or all §6 extensions |
| `Zetahyperbolic-general-assembled-lean433 (3).zip` | Earlier analytic assembly and proof logs | Superseded by revision (2), same frontier |
| `MAIN_CHAIN_LEAN_ONLY (4).zip` | Theorem-named chronological import shape | Many theorem-named files are interfaces, not paper-complete proofs |
| `ODD_ZETA_3X3_MERGED_v0_3_0.zip` | Finite eta/zeta readout and 3×3 rational matrices | No equality to the manuscript's determinant and no denominator-weighted vanishing certificate |
| `IMPACTG_3X3_LEAN_v0_9_2*.zip` | Euler/binomial rational row identities and finite transfer | Does not provide manuscript normalization estimates |
| `GP7_UNIFIED_LEAN_BASE*.zip` | Finite dyadic and spectral algebra | No signed two-variable tail bound or infinite irrationality certificate |
| `CHEBYSHEV_MASTERTIER_LEAN_v0_1_56*.zip` | Exact ζ(7) polynomial/grid finite identities | No uniform denominator/decay proof for arbitrary index |
| `ZETA3_ELEMENTARY_ANCHOR_SERIES*.zip` and `ZETA3_EULER_BINOMIAL_ROW_MASS*.zip` | ζ(3) rational series identities and limit infrastructure | Separate constructions; not a value-decay proof for ζ(5) pencil |
| `ZETA3_R_HALF_UNCONDITIONAL_MAHLER*.zip` | Auxiliary ζ(3) Mahler/geometry lemmas | No identification with ζ(5) Hankel determinant |
| `ZETA5_NATIVE_WITNESS_SEARCH*.zip` | Concrete finite witness experiments | Finite certificates do not imply `∀ sufficiently large K` estimates |
| `zeta5-spectral-lean (1).zip` | Related Fauzan weight-five architecture, plus repaired cases | Its included separate imported branch retains a PNT axiom / related unresolved input; not same H30 construction |
| `RH_FIVE_INDUCTION_LEAN*.zip` | RH/xi five-induction interfaces | Does not imply Hankel arithmetic rates or odd-zeta irrationality |
| Other BKQR/pi GP materials | Residue decompositions, finite transforms | Rationality-preserving normalization and determinant compatibility not established |

No cross-branch theorem is imported in `MAIN_CHAIN_STRICT` merely because its filename names an endpoint. The correct future bridge must prove its value equality with the **actual** paper-defined rational moment functional and give the exact nonvanishing/normalization bound without assuming the target.
