import MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V5
import PaperOrder.Corollary_3_6_Rectangular_Atomic_Quadratic_SOS
import PaperOrder.Theorem_5_2_Dual_Gram_Nullspace_Iff
import PaperOrder.Theorem_5_2_Two_By_Two_Dual_Discriminant_SOS
import PaperOrder.Theorem_6_10_Two_By_Two_Integer_Hadamard

/-!
# Core algebra V6 — substantive theorem-level continuation

The user's native Lean 4.33.0 compiler established 97/97 for V5. Those
97 sources are frozen unchanged. V6 adds nonnegative and strict real
atomic Hankel quadratic forms in all finite sizes, the exact rational
dual Gram zero-kernel equivalence and positivity-iff-independence,
a sum-of-squares generalized-eigenvalue discriminant for 2x2 pencils,
and exact two-sided 2x2 integer Gram size bounds. The full 19/20 core
algebra audit is NOT inferred from the module count.
-/

noncomputable section
namespace PaperOrder.CoreAlgebra

/-- Combined unconditional V6 algebraic endpoint, supplementing V5. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V6
    {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ)
    (a b d u v w : ℝ) (hu : 0 < u)
    (hM : 0 < u * w - v ^ 2) :
    ((∀ t : Fin h → ℚ, t ≠ 0 → 0 < dualSlopeQuadraticForm c t) ↔
      dualCoefficientRowsSeparate c) ∧
    0 ≤ dualTwoByTwoDiscriminant a b d u v w := by
  exact ⟨dualSlopeQuadraticForm_pos_iff_rowsSeparate c,
    dualTwoByTwo_discriminant_nonneg a b d u v w hu hM⟩

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V6
