# v0.3.4 FROZEN FASTCORE (persistent, dependency-aware)

This replaces the v0.3.3 runner's **global DIRTY flag**. The Lean mathematical sources
(including the source-only v0.3.3 fix for Theorem 2.4) are unchanged.

- One ZIP, exactly one root `run.cmd`; pinned Lean 4.33.0, direct executable,
  existing Mathlib cache, `-j 16`; no Lake/network/Python/PowerShell/WSL on Windows.
- `BUILD_ORDER_FROZEN.txt` contains the exact direct-import graph for 38 Lean modules.
- Stable verified state outside Downloads/extracted ZIPs:
  `%USERPROFILE%\lean-native\zetahyperbolic_paper_frozen_lean433_v1`.
- An `.olean` is reusable only if it is accompanied by its exact source-copy,
  matching pinned environment, a compiled generation and a receipt matching
  the **current generation of every direct imported local `.olean`**.
- Once the user compiles a module, subsequent packages skip the unchanged
  module, even if an unrelated earlier indexed module was repaired.
- If a build is interrupted after changing a parent, children become invalid
  on the next run, even if their source text did not change.
- First-time migration is limited to the user's independently reported
  `CHECK_PASS=1/38` through `CHECK_PASS=9/38` from v0.3.2; migration requires
  the legacy build's cache signature, per-source stamp, original `.olean`, and
  identical compiled parents. Otherwise the affected module is compiled.
- `run.cmd full` forces compilation of the whole dependency closure; normal
  `run.cmd` does not.

The ZIP includes no certified build products, and no local Lean compilation
was performed to assemble it. Other manuscript theorem sources are retained
as source material, **not** implied to have been proved by this build.

To run from Windows CMD:

```bat
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_v0_3_4_FROZEN_FASTCORE.zip" && call "ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_v0_3_4_FROZEN_FASTCORE\run.cmd"
```

Optional environment overrides: `ZETA_FASTCORE_CACHE_ROOT`, `ZETA_FASTCORE_LEAN_EXE`,
`ZETA_PAPER_FROZEN_ROOT`. Changing Lean/Mathlib invalidates per-module environment
receipts; simply extracting a new ZIP does not.
