# FIX14: polynomial constant scalar square

Compiler frontier: 73 frozen modules, first failure module 74,
`PaperOrder/Theorem_3_7_All_Degree_Turan_Leading_Scalar.lean`.

The scalar-invariance proof requires `C (c^2) = (C c)^2`.
This is a ring-homomorphism fact, not an identity which `ring` can
infer automatically while treating `C` as an opaque function.

Fix: rewrite using `map_pow` before the final `ring` invocation.
All Lean sources other than module 74 are unchanged.
No local Lean compilation was performed; user Windows Lean 4.33.0
is the only compilation authority. Frozen cache is preserved.
