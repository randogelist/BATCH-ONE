import MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V2
import PaperOrder.Theorem_5_2_Selected_Monomial_Monicity
import PaperOrder.Theorem_5_2_Dual_Row_Separation_PosDef
import PaperOrder.Theorem_3_3_Normalized_Pole_Quadratic_Signature

/-!
# Chronological core-algebra continuation V3

The verified 59 module checkpoint and all previous unverified sources are
untouched. The new theorem combines two concrete full-dimension algebraic
claims, rather than merely reporting that the imported files typecheck:
monicity on every injectively selected monomial subspace and the true
Vandermonde pole-congruence quadratic form.

The 95% theorem-level target remains a SEPARATE audit obligation; no
completion percentage is claimed by importing this endpoint.
-/

noncomputable section
open scoped BigOperators
namespace PaperOrder.CoreAlgebra
open ManuscriptChain.Real ManuscriptChain.PoleDiagonalization

/-- Full selected-monomial dual determinant and genuine pole-coordinate
quadratic form, both without an analytic or witness hypothesis. -/
theorem MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V3
    (p : ManuscriptChain.Real.Parameters) :
    (∀ (h K s : ℕ) (f : Fin h → Fin (K + 1)),
        Function.Injective f →
          (dualDelta s (dualSelectedMonomialCoefficients f)).natDegree = h) ∧
    (∀ v : Fin p.h → ℚ,
      normalizedPoleSlopeQuadraticForm p v =
        ∑ a : Fin p.h, poleWeight p a * (v a)^2) := by
  constructor
  · intro h K s f hf
    exact dualSelectedMonomialDelta_degree s f hf
  · intro v
    exact normalizedPoleSlopeQuadraticForm_eq_diagonal p v

end PaperOrder.CoreAlgebra

#print axioms PaperOrder.CoreAlgebra.MAIN_CHAIN_CORE_ALGEBRA_95_REASONED_BASE_V3
