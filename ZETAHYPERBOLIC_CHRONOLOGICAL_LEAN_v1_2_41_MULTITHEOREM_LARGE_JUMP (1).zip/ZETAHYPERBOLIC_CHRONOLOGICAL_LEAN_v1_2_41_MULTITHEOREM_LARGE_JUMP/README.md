# ZETAHYPERBOLIC v1.2.29 — Theorem 5.2 exact degree correction

Native Windows Lean 4.33.0; one `run.cmd`. The 128 previously passing
modules are eligible for hash-and-environment verified reuse. No Lean
compilation was performed in preparation of this package.

The new source changes only `ProofAdvances/Theorem_5_2_RealRoots.lean`,
replacing a `simpa` that did not collapse the finite sum by a direct
three-step `calc`: degree of product = sum of individual degrees =
finite sum of ones = n. Both dependent modules are cache-invalidated.

Run the single included `run.cmd` to verify the corrected Lean proof.
The runner enforces rejection of `sorryAx`. This remains a partial
manuscript formalization (`FULL_PAPER=NOT_PROVED`).

# ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_6_COR35_TACTIC_FIX1

**One ZIP, one `run.cmd`, no local Lean compilation.** Native Windows Lean
4.33.0 FASTCORE, prebuilt Mathlib `.olean`, no Lake/network/Python/PowerShell/WSL.

## One copyable Windows CMD command

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_6_COR35_TACTIC_FIX1.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_6_COR35_TACTIC_FIX1\run.cmd"
```

## New mathematics in strict PDF order

- `ProofAdvances/Proposition_3_2.lean`: genuine real-exponent pole-weight
  scaling (positive, nonzero, matching original odd weight), Vandermonde slope,
  symmetry, determinant product and nondegeneracy, and universal spectral
  factorization conditional on a *supplied positive-definite base matrix*.
  **The paper's explicit integral base for real s is not yet verified.**
- `ProofAdvances/Theorem_3_3.lean`: actual odd-zeta Gram determinant strictly
  positive (from existing unconditional construction), leading coefficient
  equal to a fully specified pole product, and invariance of positive and
  negative diagonal-weight index sets across real exponents; weight-five
  parity arithmetic identity. **Non-principal strict total positivity, exact
  alternating inertia counts, and Carleman determinacy remain open.**
- `PAPER_CHRONOLOGICAL_CHAIN.lean`: exposes those two additions alongside the
  existing proved Section-2/3 and single-Witness Section-4 results. Later
  paper-entry metadata modules are kept byte-identical to avoid rebuilding
  all their import descendants merely to change a `#check` wrapper.

## Frozen PASS behavior

- Old 112 sources: **111 remain byte-identical**, exactly one aggregator is
  modified. Two substantive proof files are new (114 source targets total).
- Old modules are reused **only if they previously passed your compiler**;
  this package does not invent PASS certificates for modules you have not run.
- `FASTCORE_CACHE_MANIFEST.txt`: every module has its SHA256 source hash,
  import-closure SHA256, and eligibility for verified v1.2.2 cache migration.
  Runtime verifies source hashes against this manifest; changes to a module
  or any of its transitive local imports change its import-closure key.
- Successful `.olean` files are preserved in `%USERPROFILE%\LeanRuns\ZETAHYPERBOLIC_CHRONOLOGICAL_FASTCORE_433\CAS`, partitioned by Lean
  binary, toolchain version, Mathlib fingerprint and dependency search paths.
  Cache integrity checks the stored `.olean` against a recorded SHA256.
- The native runner may migrate previously compiled and provenance-checked
  `.olean` modules from the v1.2.2 persistent cache or a successful v1.2.2
  Downloads directory. No recompilation of a valid frozen module.
- After any failure it resumes from the first non-cached or invalidated
  module, keeping passed prefixes for future runs.

## Honest verification status

Static import graph, source hashes, manifest, and ZIP file integrity were
checked here. **NO local Lean compiler invoked.** Successful compilation
remains to be reported from your Windows `run.cmd` output.

The complete paper remains open; a successful build is not proof of its
unformalized integral, total-positivity, Diophantine, or later chapters.

## v1.2.4 compiler-log repair

Fixed only the declaration-doc-comment / `#check` parse boundary in `Paper/Lemma_2_2.lean`. Previous PASS cache is retained. Details: `FIX_1_LOG.md`.


## v1.2.5 source verification and resume

Before any module is compiled the runner prints `LEMMA22_SOURCE=FIX2_CONFIRMED`
when the exact repaired source is present. If this line is absent, investigate whether
an older package is being executed. See `FIX_2_LOG.md`.
The runner can reuse PASS modules from partially completed v1.2.4/v1.2.3 runs if
compiler, Mathlib, source, and import-closure identity match; failures are never
cached as PASS.


## v1.2.6 Corollary 3.5 fix

The redundant tactic after `field_simp` was deleted from
`Paper/Corollary_3_5.lean`. The source is identified at the start of `run.cmd`
by `COROLLARY35_SOURCE=FIX1_CONFIRMED`; the previous `LEMMA22_SOURCE=FIX2_CONFIRMED`
check remains. The frozen successful proofs in your cache are reused when
source and dependency fingerprints match. This update was not compiled locally.

## v1.2.7 chronological advance

New source-only Section 3 proofs are in ProofAdvances/Theorem_3_4.lean,
ProofAdvances/Corollary_3_6.lean, and ProofAdvances/Theorem_3_7.lean.
See SEC3_INCREMENT.md for exact mathematical scope. The existing witness
and frozen modules have not been rewritten. No local Lean compilation.

## v1.2.8 final wrapper repair

The final chronological wrapper now uses explicit `Matrix.transpose` in `CHRONOLOGICAL_FINITE_ATOMIC_GRAM`. See `FIX_4_LOG.md`. No other `.lean` source was modified; all 116 passing modules are eligible for CAS reuse. Run your Windows `run.cmd`; no compilation was performed while packaging.

## v1.2.9 verified baseline / new unverified mathematical increment

The previously reported Lean 4.33.0 baseline is **117/117 PASS**. The three
new mathematical modules and updated main entry point in this ZIP have **not**
been locally compiled. See `SEC3_CD_INCREMENT.md` for exact theorem scope.

Windows CMD:

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_9_CD_SPECTRUM.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_9_CD_SPECTRUM\run.cmd"
```

## v1.2.10 actualGamma equality repair

Previous **user-compiled** checkpoint: `118/120`; only the actual-derivative
factorization and its downstream entrypoint need rechecking. See `FIX_5_LOG.md`.

Extract `ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_10_CD_ACTUAL_GAMMA_FIX1.zip`
into Downloads and run the included `run.cmd`. Your Windows CMD can use:

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_10_CD_ACTUAL_GAMMA_FIX1.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_LEAN_v1_2_10_CD_ACTUAL_GAMMA_FIX1\run.cmd"
```

The startup must print `CD_ACTUAL_SOURCE=GAMMA_FIX1_CONFIRMED`.


## v1.2.11 FIX2 update

`ProofAdvances/Theorem_3_8_Actual.lean` now uses a direct definitional
`change` instead of a `simpa`/higher-order function rewrite. The runner prints
`RUN_REVISION=V1211_CD_DEFINITIONAL_GOAL_FIX2` and
`CD_ACTUAL_SOURCE=DEFINITIONAL_GOAL_FIX2_CONFIRMED`. See `FIX_6_LOG.md`.

Previous verified PASS modules are frozen and reused by cache keys.
The complete paper is NOT yet proved. No local Lean compilation performed.

## v1.2.12 - Theorem 3.8 affine Jacobi continuation

User-compiled predecessor: v1.2.11 `120/120 BUILD=PASS`. This archive adds
`ProofAdvances/Theorem_3_8_Jacobi.lean` and updates only the final
`PAPER_CHRONOLOGICAL_CHAIN.lean` import / endpoint. The formal polynomial,
real derivative and log derivative are unconditional for positive-det matrices.
The actual odd-zeta endpoint uses the already proved Gram positivity. The
Laplace-tau differentiation-under-integral (PDF (3.8)) remains open.
Read `SEC3_JACOBI_INCREMENT.md` for scope. No local Lean compilation.

## v1.2.13 Jacobi trace correction

Source-level replacement of the failed v1.2.12 Jacobi module.
The final chronological wrapper is unchanged, but must be recompiled
because its import closure changed. All other 119 previously passed
modules remain available for verified cached reuse. No local Lean
compilation was performed.

## v1.2.14 Theorem 3.9 extension

One new independent generic shifted-square pole pencil proof module and one
updated chronological entrypoint. The v1.2.13 Jacobi module remains a
compiler candidate, not an already verified PASS. Base 120/120 is frozen.
No local Lean compilation performed. See `SEC3_HURWITZ_INCREMENT.md`.


## v1.2.15 -- arithmetic architecture advance

This branch adds three actual Lean proof files for the precise finite
Jacobi expansion, Fekete numerator positivity and signed-character
cancellation, and rational two-variable moment symmetry. It also adds
three wrapper theorems to `PAPER_CHRONOLOGICAL_CHAIN.lean`. The latest
compiler-verified base remains 120/120, while v1.2.13--15 additions await
the user's compiler. Exactly one `run.cmd` is present. No axiom, sorry,
local Lean compilation, Lake, network fetch, or Python on the user's PC.


## v1.2.16 additions: finite Gram and actual dual derivative

The corrected Corollary 3.6 is strengthened to a full-dimensional
finite-atomic Hankel `PosSemidef` theorem, a Vandermonde determinant-square
identity, full-order strict determinant positivity and positive definiteness
when all atoms are pairwise distinct. Theorem 5.2 gains an exact bridge
from the *actual rational coefficient matrix* to the positive-definite
X-derivative (conditional only on the basis being full row rank).

The previous 127 sources are preserved unchanged except for the chronological
spine. The runner contains 129 targets and one `run.cmd`. Unproved
Laplace integral identities, further Krein-space cones and odd-zeta arithmetic
are not asserted as consequences of these finite theorems.

**Static source only**. No Lean compilation performed by the authoring system.


## v1.2.18 FIX3

See FIX_9_LOG.md for the corrected Jacobi proof. No local Lean build has been run. Frozen modules are retained.


## v1.2.19 correction
See `FIX_10_LOG.md` for the changed Jacobi proof. The new module is not compiler-verified; do not freeze it until the native Lean check succeeds.

## v1.2.20 FIX5
Typed polynomial coefficient ring for Jacobi determinant and eval bridge; replaced manual derivative coefficient proof with pinned Mathlib theorem. Native Lean compilation remains pending.

## v1.2.21 FIX6
The failed Jacobi matrix-evaluation proof now separates diagonal/off-diagonal entries and normalizes real multiplication. No local Lean compilation; check on native Windows Lean 4.33.0.

## v1.2.22 PositiveSlope isUnit FIX1
Explicitly apply the matrix-isUnit equivalence before projecting `.mpr`; preserves the 123 previously successful checks. Windows compiler has the final authority.

## v1.2.24 dual moment FIX1
Avoid broad simplification of the two-variable rational dual polynomial at X=0. Incremental Lean 4.33 compilation is reserved for the native Windows runner.

## v1.2.25 verified-source boundary
The dual-entry zero-evaluation proof explicitly unfolds the outer pencil and uses `simp only` for polynomial evaluation. Only native Windows Lean 4.33.0 can verify the newly changed proof.

## v1.2.26 checkpoint
The single change fixes the unqualified `Matrix.isUnit_iff_isUnit_det.mpr` in Corollary 3.6 FullGram. All prior PASS modules are retained in the source; FASTCORE reuses validated `.olean` files. Compile only the failed module and any invalidated downstream modules.

## v1.2.27 proof and runner revision
This package prints `RUN_REVISION=V1227_COR36_EXPLICIT_MATRIX_FIX2` and verifies the SHA-256 of `Corollary_3_6_FullGram.lean` before compilation. A log still printing the failing `Matrix.isUnit_iff_isUnit_det.mpr` is from a previous source.

## v1.2.28 — positive-slope dual spectral closure
New theorem candidates: `ProofAdvances/Theorem_5_2_RealRoots.lean` and `ProofAdvances/Theorem_5_2_ActualRoots.lean`. Adds complete finite-dimensional degree/real-rootedness for the paper's rational Beukers dual determinant under its intrinsic full-row-rank condition. No local Lean compilation performed.

## v1.2.31
Fixes the remaining Theorem 5.2 actual rational dual roots source-level errors from v1.2.30. Checks must pass on native Windows Lean; no unverified theorem is represented as proved.

## v1.2.32
Compiler-directed fix of `Theorem_5_2_ActualRoots.lean`: define a named Matrix term to eliminate `Function.map` elaboration; preserve previously compiler-passed modules. Requires native compiler verification.

## v1.2.33
Uses fully qualified `Matrix.map` in the actual rational dual spectral proof; includes a distinctive compiler marker. No status change until user compiler confirms PASS.

## v1.2.34 — Principal theorem endpoint

New standalone `PAPER_PRINCIPAL_THEOREM.lean`: unconditional whole-odd-weight
spectral theorem and exact disks, plus the 25687 ζ(5) exponent conditional only
on the already-declared quantified Witness. Theorem 4.5 is an unproved target.
The certificate is not finite-checkable under the current Witness interface.
Build remains proof-checking only; full paper not proved.

## v1.2.35 — extended principal proof endpoint

New `PAPER_PRINCIPAL_THEOREM_EXTENDED.lean` adds the unconditional actual finite rational dual spectral theorem, explicit linear factorization, and faithful a=0/scale-only rational irrationality conclusions from the existing Witness. The unproved general ζ(3)+ζ(5) claim and analytic infinite-dimensional conditions are not asserted. All 132 user-verified modules frozen; test only new source. See `PRINCIPAL_EXTENDED_STATUS.md`.

## v1.2.36 new proof frontier
See `V1236_DIRECT_THEOREMS.md` for the two unconditional all-dimensional Turan theorem targets and strict limitations.

## v1.2.37 proof repair
See `FIX24_LOG.md` for the two normalization fixes.

## v1.2.38 New principal strictness/equality theorem
See `V1238_STRICT_TURAN_ROLLE.md`.

## v1.2.39 Direct p-adic Proposition 4.3 (Q_p scope)
See `V1239_PADIC_THEOREM.md`.


## v1.2.41: larger-jump five-module proof batch
See `V1241_LARGE_JUMP_THEOREMS.md`. Existing 137 certified sources are frozen. **New proofs and p-adic module are not yet compiler verified.**
