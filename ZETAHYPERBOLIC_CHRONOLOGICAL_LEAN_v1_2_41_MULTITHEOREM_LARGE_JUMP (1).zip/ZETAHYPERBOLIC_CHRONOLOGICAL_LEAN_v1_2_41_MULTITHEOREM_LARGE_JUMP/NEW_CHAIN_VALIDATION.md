# Compilation status / acceptance criterion

User-requested verification mode: **compiler runs exclusively on user's Windows Lean 4.33.0. No assistant local Lean build has been run.**

Preserved sources: archived Lean 4.33 theorem modules; original validation details in `VALIDATION.md`.

New files requiring user's compilation:

- `PAPER_02_03_UNCONDITIONAL.lean`
- `PAPER_04_WITNESS.lean`
- `PAPER_05_06_VERIFIED_SCOPE.lean`
- `PAPER_MAIN_CHAIN.lean`

`run.cmd` uses native `lean.exe` (not Lake) to compile all 64 files in topologically sorted order, including the four new entrypoints. `.olean` files are created locally on the user machine. The only Windows batch file is `run.cmd`.

Success criteria from `run.cmd`: `BUILD=PASS`; `#print axioms` on the new final theorem reports only standard logical axioms; no `sorryAx`. It still reports `WITNESS_EXISTENCE=NOT_PROVED`. A syntactically successful build does not certify the entire manuscript.

Do not convert Witness into a global `axiom` to make compilation succeed, and do not claim a witness has been proved unless its two exact fields are actually constructed.
