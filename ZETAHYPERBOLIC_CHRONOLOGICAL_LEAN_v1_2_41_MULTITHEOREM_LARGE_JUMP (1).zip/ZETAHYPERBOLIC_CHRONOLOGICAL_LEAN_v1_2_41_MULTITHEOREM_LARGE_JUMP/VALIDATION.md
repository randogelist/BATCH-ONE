# Validation of the general theorem and arithmetic frontier

## Current validation

- Native Linux Lean **4.33.0**, with `-E hasSorry`.
- **59 proof modules covered**: 55 unchanged modules match the exact SHA256
  hashes and compiled objects from the preceding combined validation;
  all four new or changed modules were compiled again against that baseline.
- The four are `Theorem_2_5_Weight_Change`,
  `Theorem_4_1_Leading_Coefficient_Gap`, `Zetahyperbolic`, and
  `CHECK_AXIOMS`. Every new compilation passed with zero warnings.
- `lakefile.lean` was checked with the bundled Lake shared library loaded.
- **231 axiom reports PASS** across the current proof graph, using only
  `propext`, `Classical.choice`, and `Quot.sound`, or no axioms.
- All **60 Lean source hashes**, including `lakefile.lean`, are recorded.
- Source/import guard: **PASS**. No admitted proofs or custom axioms occur
  in the active source graph.
- Default general import reaches **38 local modules** and excludes the
  optional zeta(5) application, optional repairs, and external wrapper.

This is incremental validation with a hash-verified baseline, not a claim
that all 59 modules were freshly rebuilt in this revision. The preceding
combined checks are preserved under `validation/combined/`, and the full
analytic build under `validation/assembled/`.

The unchanged baseline contains **43 pre-existing style warnings** in four
modules: Foundations (5), CoreLinearAlgebra (1), LagrangeBasis (3), and
Section2Checked (34). Those warnings are retained in their original logs.
The new and changed modules are warning-free; a globally warning-free
project is not claimed.

## Preserved parallel revision

The intervening revision's four arithmetic modules and all its validation
records are retained. `MAIN_CHAIN_ARITHMETIC` supplies the generic and
linear-family criteria in `GeneralArithmetic`; `MAIN_CHAIN_IRRATIONALITY`
supplies the arbitrary-K and all-odd-weight criteria in `GeneralIrrationality`.
The combined root proves that their canonical primitive polynomials agree.
The two criteria use different index conventions, documented in
`IRRATIONALITY_FRONTIER.md`; both still require normalized decay.

## New checked statements

`Theorem_2_5_Weight_Change.lean` proves exact rational derivative-determinant
and leading-coefficient comparisons between weights at fixed geometry.
No admissibility hypothesis or asymptotic bound is used by those identities.

`Theorem_4_1_Leading_Coefficient_Gap.lean` proves the exact factorization
of the positive primitive value into its integer leading-coefficient size
and the Gram/derivative determinant ratio. It proves that a strict gap
between their eventual exponential upper bounds yields normalized decay
and irrationality. The estimates remain explicit hypotheses.

The following checked modules from the preceding revision are preserved:

`Theorem_2_4_Primitive_Normalization_Minimality.lean` proves that every
positive integral rescaling is a positive integer multiple of the positive
primitive normalization. It proves the resulting scale and value bounds.

`Theorem_4_1_Direct_Irrationality_From_Decay.lean` proves the direct generic
integer-polynomial denominator squeeze.

`MAIN_CHAIN_IRRATIONALITY.lean` constructs actual primitive determinant
polynomials, proves their degree and positivity, and connects eventual
normalized quadratic decay to irrationality of the actual odd zeta value.
It proves the all-odd-weight implication, an explicit admissible unbounded
family, and transfer from arbitrary positive integral rescalings.

`ZETA5_DIRECT_IRRATIONALITY.lean` supplies positivity internally and derives
irrationality from either the combined normalized value bound or the two
separate multiplier and archimedean estimates. No quantitative spectral
input occurs in these new direct endpoints.

The normalized decay estimates themselves remain unproved. The pre-existing
general spectral theorem retains zero open analytic inputs and requires
only structural parameter admissibility.

## Classical comparison note

`docs/FixedWeightDeterminantComparison.md` contains a separate classical
derivation of the fixed-weight log-determinant comparison
`log(det G_k / det G_2) = O_(k,m)(K log K)` and a local-denominator diagnostic.
It received an independent mathematical review. **Neither new comparison
nor local valuation diagnostic is claimed to have been formalized in Lean.**
The document asserts no arithmetic rate or unconditional irrationality.

The new notes `docs/PolynomialMomentDenominatorRank.md`,
`docs/LargePrimeCoefficientValuation.md`, and
`docs/ScalarFamilyObstruction.md` provide classical arithmetic proofs.
`docs/ArithmeticFrontier.md` combines these with a finite analytic lower
bound to exclude fixed m and fixed limiting N/K in (0,1/3) at all
sufficiently high fixed odd weights. The local valuation and obstruction
arguments received separate mathematical audits. They have **not** been
formalized in Lean; source scans and compiler checks do not certify them.
The local computations were also checked on exact rational examples.
No global decay upper estimate or new irrationality assertion follows.

## Reproducibility and limits

- Lean: `leanprover/lean4:v4.33.0`.
- Mathlib: `db584cd6d46c92f209a44c0f1c829460d327499d`.
- Dependency pins: `lake-manifest.json`.
- Dependency order: `MODULES_CHECKED.txt`.
- Current extension logs, source hashes, axiom audit, import boundary, and
  validation summary: `validation/arithmetic_frontier/`.
- Previous merged arithmetic checks: `validation/combined/`.
- Previous complete analytic build and hashes: `validation/assembled/`.
- `validation/arithmetic/` preserves the intervening complete arithmetic build.
- `validation/irrationality/` preserves the direct-bridge checks before merging.
- Earlier directories record historical revisions and their earlier inputs.

Local compiler checks used the existing pinned dependency caches without
network. No Windows execution, remote CI, or end-to-end Lake build is
claimed. The Lake configuration itself was checked.

The source-only ZIP excludes executable scripts, binaries, compiled objects,
symlinks, and nested archives. Every member is UTF-8 text with regular-file
permissions. `SHA256SUMS.txt` covers every member except itself.


## v1.2.18 static validation

Patch scope: only Jacobi module. Source hashes updated. Jacobi + transitive importers get new CAS closure keys; other modules retain previous keys. No local compiler run.
