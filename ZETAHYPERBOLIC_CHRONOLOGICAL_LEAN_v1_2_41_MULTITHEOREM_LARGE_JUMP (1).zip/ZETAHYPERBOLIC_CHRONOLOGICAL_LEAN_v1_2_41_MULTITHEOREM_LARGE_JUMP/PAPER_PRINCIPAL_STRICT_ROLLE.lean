import PAPER_PRINCIPAL_THEOREMS_DIRECT
import ProofAdvances.Theorem_3_7_StrictRolle

/-!
# Stronger direct principal Theorem 3.7 endpoint

All admissible actual odd-zeta determinants and all full-row-rank finite
rational dual Beukers determinants of positive dimension satisfy strict
first Turan positivity at every real non-root. In addition, the exact
zero locus of the Turan expression is classified by multiple polynomial
roots. Root Rolle separation is formalized for both families.

Does not claim principal-minor interlacing, an infinite Krein theorem,
or an unconditional odd-zeta irrationality theorem.
-/

noncomputable section

namespace ZetaHyperbolicPaper.PrincipalStrictRolle

open PaperAdvances.Theorem3_7_AllDegrees
open PaperAdvances.Theorem3_7_StrictRolle

def OddZetaStrictAndEquality : Prop :=
  ∀ (p : ManuscriptChain.Real.Parameters)
      (hp : ManuscriptChain.Real.Admissible p) (x : ℝ),
    ((ManuscriptChain.Real.realPolynomial
      (ManuscriptChain.Real.delta p)).eval x ≠ 0 →
      0 < turan (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.delta p)) x) ∧
    (turan (ManuscriptChain.Real.realPolynomial
      (ManuscriptChain.Real.delta p)) x = 0 ↔
      (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.delta p)).eval x = 0 ∧
      (Polynomial.derivative (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.delta p))).eval x = 0)

def DualStrictAndEquality : Prop :=
  ∀ (h K s : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
    Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul →
      0 < h → ∀ x : ℝ,
    ((ManuscriptChain.Real.realPolynomial
      (ManuscriptChain.Real.dualDelta s c)).eval x ≠ 0 →
      0 < turan (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.dualDelta s c)) x) ∧
    (turan (ManuscriptChain.Real.realPolynomial
      (ManuscriptChain.Real.dualDelta s c)) x = 0 ↔
      (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.dualDelta s c)).eval x = 0 ∧
      (Polynomial.derivative (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.dualDelta s c))).eval x = 0)

/-- A simultaneously strict and equality-classified theorem endpoint,
proved without the Section 4 arithmetic Witness. -/
theorem PRINCIPAL_STRICT_TURAN_WITH_EQUALITY_UNCONDITIONAL :
    OddZetaStrictAndEquality ∧ DualStrictAndEquality := by
  constructor
  · intro p hp x
    exact ⟨THEOREM_3_7_ACTUAL_TURAN_STRICT p hp x,
      THEOREM_3_7_ACTUAL_TURAN_EQUALITY p hp x⟩
  · intro h K s c hc hh x
    exact ⟨THEOREM_5_2_ACTUAL_DUAL_TURAN_STRICT s c hc hh x,
      THEOREM_5_2_ACTUAL_DUAL_TURAN_EQUALITY s c hc hh x⟩

end ZetaHyperbolicPaper.PrincipalStrictRolle

#print axioms ZetaHyperbolicPaper.PrincipalStrictRolle.PRINCIPAL_STRICT_TURAN_WITH_EQUALITY_UNCONDITIONAL
