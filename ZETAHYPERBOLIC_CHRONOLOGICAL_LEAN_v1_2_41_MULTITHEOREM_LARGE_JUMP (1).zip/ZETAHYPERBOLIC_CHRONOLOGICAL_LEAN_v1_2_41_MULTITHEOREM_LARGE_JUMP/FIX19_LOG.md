# Fix 19: Theorem 5.2(1) exact degree, Lean v1.2.29

Input checkpoint: BUILD=FAIL, 128/131 checks passed; first failure
`ProofAdvances/Theorem_5_2_RealRoots.lean:131:2` with `hprod`
remaining a degree=sum equation, not degree=n.

Patch: replace the final `simpa` by an explicit finite-sum computation
using `Finset.sum_const`, `Finset.card_fin`, `Nat.nsmul_eq_mul`, and
`Polynomial.natDegree_X_add_C`; no theorem statement changed.

Only `ProofAdvances/Theorem_5_2_RealRoots.lean` source changed.
`Theorem_5_2_ActualRoots` and `PAPER_CHRONOLOGICAL_CHAIN` are dependency
invalidated. The 128 other source files are unchanged.

New source SHA256: E4F1AC80A4F1644A509B890B6A48D2FC47A902105E808F11362A91985308BB83
New manifest SHA256: 4526B1E4CE3A82448B9C5570E7DB38B5AC8D9C40E05E71689E52F17F14BC7741

Lean compiler status of this patch: untested locally; user's compiler authoritative.
