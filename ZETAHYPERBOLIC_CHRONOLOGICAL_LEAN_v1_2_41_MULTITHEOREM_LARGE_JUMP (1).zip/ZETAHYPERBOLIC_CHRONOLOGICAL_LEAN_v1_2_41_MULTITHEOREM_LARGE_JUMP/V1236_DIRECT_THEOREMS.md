# v1.2.36 — Direct principal theorem proofs

**New genuinely mathematical results.**

* Theorem 3.7: arbitrary finite size, pointwise first-derivative
  Turan/Laguerre inequality for the **actual rational odd-zeta Hankel
  determinant**, with no additional hypothesis once admissibility is given.
* Theorem 5.2 finite algebra: the same globally quantified inequality for
  the **actual rational dual Beukers determinant** with full row-rank
  coefficient basis, independent of Section-4 Witness.
* A universal exact product recurrence proves both at once:
  T(LP)(x) = L(x)^2 T(P)(x) + L'(x)^2 P(x)^2.
  The proof is an induction over finite products of real affine factors.
* New scoped principal endpoint combines both unconditional branches
  with the pre-existing Witness-conditional Section-4 endpoint.

This does NOT prove arbitrary higher-order Turan inequalities, the
Beukers integral, the full Krein decomposition, printed irrationality
of a zeta(3)+b zeta(5), witness existence, or the entire 52-page paper.
`FULL_PAPER=NOT_PROVED` stays explicit.

**Compile/freeze policy:** the first 133 manifest entries and ALL
previous Lean sources are preserved byte-for-byte. Only two new
modules are appended and marked `NO` for cached-old eligibility.
No local Lean compilation was performed. User's native Windows
Lean 4.33.0 compiler is authoritative.
