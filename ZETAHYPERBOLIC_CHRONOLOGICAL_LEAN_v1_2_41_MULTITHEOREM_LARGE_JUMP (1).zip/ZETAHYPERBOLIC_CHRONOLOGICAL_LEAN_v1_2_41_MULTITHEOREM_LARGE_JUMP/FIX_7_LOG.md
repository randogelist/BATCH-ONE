# v1.2.13 Jacobi correction, source-only

User reported `BUILD=FAIL` at the v1.2.12 Jacobi module, with
`LEAN_CHECKS=119/121`, `FROZEN_PASS=119`, and `sorryAx` reported by
`#print axioms` for all four attempted Jacobi proof endpoints.
The error excerpt was truncated, so it cannot establish which specific
Lean elaboration goals failed. v1.2.13 replaces the fragile proof chain
rather than claiming to know a single root-cause from incomplete logs.

Revised proof strategy:
1. Import the pinned Mathlib theorem `Matrix.derivative_det_one_add_X_smul`.
2. Relate the polynomial `det (I + X A)` to `det (I + t A)` via ring-hom evaluation.
3. Use `Polynomial.hasDerivAt` for the real derivative at zero.
4. Factor actual real matrices, `G+tH = G*(I+t G⁻¹H)`, using `Matrix.mul_nonsing_inv`.
5. Derive determinant and logarithmic determinant derivatives by `HasDerivAt.const_mul` and `.log`.
6. Transport the result to the already compiled actual odd-zeta Christoffel-Darboux trace.

Unchanged previous source files: 120. The Jacobi source is replaced.
Only the Jacobi source and final chronological wrapper import closure
will require new compilation when the prior frozen cache validates.
The final wrapper source bytes remain unchanged.

The exact Laplace-scaled infinite-integral derivative identity in PDF
Theorem 3.8(2) is NOT asserted by this proof.

**This source was not compiled locally; Windows native Lean 4.33 verifies it.**
