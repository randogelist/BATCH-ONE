# v1.2.25 — Theorem 5.1 dual moment zero-evaluation FIX2

Only the previously failing `ProofAdvances/Theorem_5_1_DualSymmetric.lean` was modified. At X=0, evaluate the affine dual polynomial by unfolding only the `Real.dualEntry` definition and applying explicit polynomial evaluation rewrite rules; the nested rational sums remain unchanged. No theorem statement, input witness, or existing validated proof module changed.

A log repeating `Theorem_5_1_DualSymmetric.lean:50:67` with the old elaborated finite-sum goal can originate from v1.2.23: this source's repaired theorem body is on different lines. The new runner explicitly prints the V1225 revision marker and checks the exact SHA-256 of the new source before starting Lean.

Lean compilation: not performed locally. Previously passed objects must be reused only when their source, dependencies and Lean/Mathlib environment match.
