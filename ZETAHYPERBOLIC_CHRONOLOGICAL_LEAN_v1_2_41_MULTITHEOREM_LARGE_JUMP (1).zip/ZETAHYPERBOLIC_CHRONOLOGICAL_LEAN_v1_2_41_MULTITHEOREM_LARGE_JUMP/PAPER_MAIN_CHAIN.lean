import PAPER_02_03_UNCONDITIONAL
import PAPER_04_WITNESS
import PAPER_05_06_VERIFIED_SCOPE

/-!
# Auditable manuscript-ordered MAIN_CHAIN

Sections 2 and 3 are unconditional. The Section-4 target has a SINGLE
`Witness` argument and is proved from the actual primitive determinant.
Theorem 5.1 and some Chapter-5/6 finite structures are present, but the
52-page paper as printed contains claims requiring correction and extensive
unformalized results; those are NOT asserted by this theorem.

A successful compilation verifies this exact result and its imports, NOT the
existence of Witness. `#print axioms` should show at most standard Lean
logical axioms (propext, Classical.choice, Quot.sound), not `sorryAx`.
-/

noncomputable section

namespace ZetaHyperbolicPaper

/-- Exact final scope: general odd-weight spectral theorem, plus the paper's
    ζ(5) exponent-25687 effective measure and irrationality from ONE
    witness object. No other caller hypothesis is present. -/
def MainStatement (w : Witness) : Prop :=
  (∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      ManuscriptChain.General.GeneralStatement p) ∧
  ManuscriptChain.RealTransfer.RationalMeasure
    (riemannZeta 5).re 25687
    (ManuscriptChain.MainChain.indexDenominatorThreshold (w.start + 1)) ∧
  Irrational (riemannZeta 5).re

/-- FINAL MAIN_CHAIN: the sole conditional argument is the witness. -/
theorem PAPER_MAIN_CHAIN (w : Witness) : MainStatement w := by
  refine ⟨?_, WITNESS_IMPLIES_EFFECTIVE_MEASURE w,
    WITNESS_IMPLIES_IRRATIONAL_ZETA5 w⟩
  intro p hp
  exact CHAPTER_3_SPECTRAL p hp

end ZetaHyperbolicPaper

#check ZetaHyperbolicPaper.Witness
#check ZetaHyperbolicPaper.PAPER_MAIN_CHAIN
#print axioms ZetaHyperbolicPaper.PAPER_MAIN_CHAIN
