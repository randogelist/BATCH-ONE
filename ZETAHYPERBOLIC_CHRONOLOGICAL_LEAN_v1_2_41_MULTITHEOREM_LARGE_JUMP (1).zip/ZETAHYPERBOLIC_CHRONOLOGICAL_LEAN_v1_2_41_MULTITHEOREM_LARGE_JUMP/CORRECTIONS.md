# Mandatory manuscript corrections (2026-10-24 audit)

## Corollary 3.5 – equation (3.6), page 10: FALSE AS PRINTED

Let `G=LLᵀ>0`, `M=Mᵀ`, `δ=X-ξ` and `A=L⁻¹ M L⁻ᵀ`.
The correct Jacobi–Cholesky identity is

    Δ_{h-1}(X)/Δ_h(X)
     = (L_{hh})^{-2} ⟨e_h, (I+δ A)^{-1} e_h⟩,

for X with Δ_h(X)≠0. (Here h is 1-based; `L_{hh}>0`.)
Any Lanczos J-fraction must retain the Gram factor `(L_{hh})^{-2}` and
tridiagonalize `I+δ A`, not `A+δ I`. Accordingly, denominators
are `1+δ a_j` and squared off-diagonals are `δ² b_j²`, with the
appropriate reversed ordering. Strict positivity of all Lanczos off-diagonals
requires a cyclicity proof and is not automatic from symmetry.

Counterexample (one-dimensional abstract pencil):
G=1/2, M=-1, ξ=X=0. Actual Δ_0/Δ_1 = 2. Printed formula has
T=M/G=-2 and gives 1/T=-1/2. Both satisfy G>0 and M≠0.
The paper's actual `(s,N,K,m)=(3,1,2,1)` also has
`G(X)=29/2-12X`, with derivative `M=-12` and `G(ζ(3))>0`,
so the two sides of (3.6) at X=ζ(3) have opposite signs.

## Corollary 3.6 – page 11: TWO FALSE CLAUSES

For fixed K, h=K-N, and `u_j=(r_j-q0)^(-2)>0`, define
`S_{2r}=Σ_{j=1}^h u_j^r` and `d_min=min_j |r_j-q0|`.
Then the CORRECT finite-power-sum estimate is

    h^(-1/(2r)) d_min <= S_{2r}^(-1/(2r)) <= d_min  (r>=1).

The printed version puts `1 <= S_{2r}^(-1/(2r))/d_min`,
contradicting `S_{2r} >= max_j u_j^r`; for h>1 the upper bound
above is strict.

The sequence `S_{2r}` is a Stieltjes moment sequence supported on AT MOST
h atoms. Hence all moment Hankel determinants are NONNEGATIVE, but
those of order >h are ZERO. Even smaller Hankel determinants can vanish
when squared root distances coincide. Replace 'strictly positive Hankel
determinants' by 'nonnegative Hankel determinants; strictly positive only
through the number of distinct support points'.

## Theorem 5.2(3) – page 24: PROOF GAP

A vector orthogonal to the finite negative-mode family `{ψ^-_{m,ν}:m<=M}`
is not orthogonal to the infinitely many omitted negative modes `m>M`.
Equation (5.4) cannot be truncated to `m<=M` merely by choosing the vector
inside a finite-dimensional W; the omitted tail may alter the sign.
An actual uniform tail estimate plus rational-polynomial approximation
is needed. The pre-existing replacement Lean module exposes
`WeightSevenTailBound` explicitly; it does not prove the printed existence.
The proof's single m=0 rank-one term also cannot by itself give `I_h` for h>1.

## Consequence

Claims 3.5, 3.6 cannot be kernel-proved with their literal types.
The corrected 3.5 and 3.6 should replace the manuscript statements before
full formalization. They do not invalidate the separate general odd-weight
spectral Theorem 3.1, which has an independent Lean proof.
