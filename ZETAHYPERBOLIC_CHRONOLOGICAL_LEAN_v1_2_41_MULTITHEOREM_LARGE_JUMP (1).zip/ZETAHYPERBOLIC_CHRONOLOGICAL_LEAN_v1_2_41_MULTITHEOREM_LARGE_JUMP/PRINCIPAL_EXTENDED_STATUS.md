# Principal theorem extension v1.2.35 – actual finite dual spectral bridge

## Previously verified compiler checkpoint
v1.2.34: BUILD=PASS, LEAN_CHECKS=132/132, FROZEN_PASS=131, NEW_COMPILED=1. All 132 proof-checking modules are preserved byte-for-byte. The new module is NOT yet compiler-verified; the user's native Windows Lean 4.33.0 runner is the only compilation authority.

## New mathematical content
- Section 5.2(1) is assembled at the *actual rational dual moment determinant*: full degree h, all complex roots real, explicit positive-slope linear factorization, under the finitely stated row-rank assumption. The other half of Theorem 5.2 (Beukers analytic integral and infinite Krein decomposition) is NOT proved.
- The sole previously identified `ZetaHyperbolicPaper.Witness` proves all nonzero rational-affine transforms of ζ(5) irrational, and the a=0 case of printed Theorem 4.5 for positive integer b. This does **not** prove irrationality of aζ(3)+bζ(5) for a≠0.
- Exact rescaled effective inequality for integer q>0 is `q/(q*d)^25687 < |q*ζ(5) - a/d|`, when q*d passes the witnessed cutoff. This does **not** give the printed coefficient-one inequality for arbitrary linear combinations.
- New named merged theorem `PRINCIPAL_WITH_FINITE_DUAL_FROM_WITNESS` imports the verified spectral Section 3 and conditional Section 4 endpoint and the finite Section 5.2 algebra.

No sorry or custom axioms. No claim of finite witness, unconditional ζ(5) irrationality, full Theorem 4.5, or proof of entire 52-page paper.
