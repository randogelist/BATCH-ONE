# V1.2.16 proof increment

This version adds two source modules, preserving all previously passing Lean
sources with byte-for-byte identical text.

1. Corrected Corollary 3.6: an arbitrary finite atomic moment Hankel matrix
   is positive semidefinite; in the square case with h distinct atoms its
   determinant is det(V)^2 > 0 and its full Gram is positive definite.
2. Theorem 5.2: the X coefficient of the actual rational two-variable
   Beukers pencil equals C Cᵀ; when C has independent rows it is positive
   definite and has strictly positive determinant.

The statements are unconditional finite algebra except for ordinary domain
conditions of distinctness and full row rank. They have no dependence on the
odd-zeta `Witness` and do not resolve the paper's integral identities.

Checkpoint before this package: native Lean v1.2.11 `120/120 PASS`.
New 129-module package status: UNCOMPILED.
