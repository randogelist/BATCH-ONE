# Section 3 chronological increment — v1.2.7

No Lean compiler was invoked in preparing this archive. The mathematical
identities below were independently checked by elementary symbolic algebra;
**Lean kernel checking of the NEW sources awaits the user's 4.33.0 compiler**.

* Theorem 3.4: `ProofAdvances/Theorem_3_4.lean` proves the symmetric 3x3
  Dodgson determinant relation and the sign law when the 2x2 leading minor
  vanishes. Full size-r condensation and interlacing are NOT asserted.
* Corollary 3.5: previously fixed scalar normalization remains unchanged;
  first successful compiler verification not yet reported for that file.
* Corollary 3.6: `ProofAdvances/Corollary_3_6.lean` proves the general finite
  Hankel=Vandermonde-Gram identity for h atoms and n polynomial moments;
  and shows that a two-atom Hankel has positive semidefinite order-2
  determinant but zero order-3 determinant. The paper's strictly-positive
  all-orders claim cannot be certified as written.
* Theorem 3.7: `ProofAdvances/Theorem_3_7.lean` proves both Turan inequalities
  for arbitrary real-rooted cubics, plus a 3-eigenvalue variance identity
  and the 3-mode Taylor derivative inequality. Arbitrary degree remains open.

No user-supplied Witness fields have been added or modified.
The frozen/pass modules from v1.2.5/v1.2.6 were not modified.
`PAPER_CHRONOLOGICAL_CHAIN.lean` has new theorem aliases for 3.4/3.6/3.7.

The `FASTCORE_CACHE_MANIFEST.txt` has 117 targets. Original 113 unchanged
cache keys retained verbatim, with only the final main chain key regenerated.
