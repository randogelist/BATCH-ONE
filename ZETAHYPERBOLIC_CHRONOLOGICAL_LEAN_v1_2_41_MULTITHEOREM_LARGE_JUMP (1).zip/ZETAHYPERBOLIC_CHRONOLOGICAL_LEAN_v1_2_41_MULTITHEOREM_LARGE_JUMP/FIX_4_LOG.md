# v1.2.8 — Final chronological wrapper dimension fix

**User-reported compiler run of v1.2.7**: `FROZEN_PASS=113`, `REUSED_OLEAN=113`, `NEW_COMPILED=3`, `LEAN_CHECKS=116/117` followed by a matrix multiplication instance synthesis failure in `PAPER_CHRONOLOGICAL_CHAIN.lean` near line 54.

## Repair

The previous main-chain theorem stated `V * Vᵀ` using the scoped postfix transpose notation without opening `Matrix` in that file. The right-hand factor was elaborated as a second `(Fin n) × (Fin h)` matrix, preventing `HMul` instance synthesis. The right-hand side now writes `Matrix.transpose (V)` explicitly, forcing matrix dimensions `(Fin h) × (Fin n)`.

The source theorem in `ProofAdvances/Corollary_3_6.lean` was already successfully compiled by the user's Lean, and its statement remains unchanged. No mathematics or existing proof has been altered.

## Compilation and caching

- Previous 116 module source hashes and dependency cache keys are **unchanged**.
- Only `PAPER_CHRONOLOGICAL_CHAIN.lean` has a new key.
- Native Windows FASTCORE 4.33.0, 16 threads, 1 `run.cmd` and frozen CAS reuse remain unchanged.
- A new `CHAIN117_SOURCE=MATRIX_TRANSPOSE_FIX_CONFIRMED` check in `run.cmd` validates the new file before running.
- The runner seeds from the v1.2.7 source directory when available, and resumes its persistent CAS cache.
- **Not Lean-compiled here**: this is a source repair submitted for the user's compiler.
