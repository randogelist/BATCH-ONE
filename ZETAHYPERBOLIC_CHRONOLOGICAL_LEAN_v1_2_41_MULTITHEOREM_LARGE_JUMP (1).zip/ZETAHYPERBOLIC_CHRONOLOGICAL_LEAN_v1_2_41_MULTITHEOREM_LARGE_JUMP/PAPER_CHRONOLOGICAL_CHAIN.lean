import Paper.Theorem_6_18
import PAPER_MAIN_CHAIN
import ProofAdvances.Theorem_3_3
import ProofAdvances.Theorem_3_7
import ProofAdvances.Theorem_3_8_Actual
import ProofAdvances.Theorem_3_8_Jacobi
import ProofAdvances.Theorem_3_9_ShiftedPole
import ProofAdvances.Theorem_3_8_ExactTaylor
import ProofAdvances.Theorem_3_9_CharacterPositive
import ProofAdvances.Theorem_3_9_PositiveSlope
import ProofAdvances.Theorem_5_1_DualSymmetric
import ProofAdvances.Theorem_5_2_DualDerivative
import ProofAdvances.Corollary_3_6_FullGram
import ProofAdvances.Theorem_5_2_ActualDual
import ProofAdvances.Theorem_5_2_RealRoots
import ProofAdvances.Theorem_5_2_ActualRoots

/-!
# Full PDF-ordered import spine

Imports every numbered entry in the paper's order, starting from Definition 2.1
and finishing with Theorem 6.18. Only the two theorems below are claimed by this
file. The chronological import graph does not prove the open entries merely by
importing their modules. Printed Corollaries 3.5/3.6 have corrected local lemmas.
-/
noncomputable section
namespace PaperChronology

/-- The truly unconditional whole-odd-weight spectral chain. -/
theorem CHRONOLOGICAL_UNCONDITIONAL_SPECTRAL
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ZetaHyperbolicPaper.CHAPTER_3_SPECTRAL p hp

/-- The paper's Section-4 effective measure, conditional on the SAME
single explicit Witness used in v1.1.0. Other later mathematical statements
are NOT asserted by this theorem. -/
theorem CHRONOLOGICAL_WITNESS_ENDPOINT
    (w : ZetaHyperbolicPaper.Witness) :
    ZetaHyperbolicPaper.MainStatement w :=
  ZetaHyperbolicPaper.PAPER_MAIN_CHAIN w

/-- New Section 3.2 finite real-exponent pole theorem (no analytic input). -/
theorem CHRONOLOGICAL_REAL_S_SLOPE_NONSINGULAR
    (p : ManuscriptChain.Real.Parameters) (s : ℝ) :
    (PaperAdvances.Proposition3_2.slope p s).det ≠ 0 :=
  PaperAdvances.Proposition3_2.slope_det_ne_zero p s

/-- New Section 3.3 consequence for the actual odd-weight Gram matrix. -/
theorem CHRONOLOGICAL_ACTUAL_GRAM_DET_POSITIVE
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    0 < (ManuscriptChain.Real.gram p (ManuscriptChain.Real.zeta p.weight)).det :=
  PaperAdvances.Theorem3_3.actual_gram_det_pos p hp

/-- The genuine size-three Dodgson identity from Theorem 3.4. -/
theorem CHRONOLOGICAL_DODGSON_3X3 (a b c d e f : ℝ) :
    a * (a*d*f + 2*b*c*e - a*e^2 - d*c^2 - f*b^2) =
      (a*d - b^2) * (a*f - c^2) - (a*e - b*c)^2 :=
  PaperAdvances.Theorem3_4.symmetric_3x3_dodgson a b c d e f

/-- The corrected finite-atomic Hankel Gram factorization of Corollary 3.6. -/
theorem CHRONOLOGICAL_FINITE_ATOMIC_GRAM {h : ℕ} (u : Fin h → ℝ) (n : ℕ) :
    PaperAdvances.Corollary3_6.finiteHankel u n =
      PaperAdvances.Corollary3_6.finiteVandermonde u n *
        Matrix.transpose (PaperAdvances.Corollary3_6.finiteVandermonde u n) :=
  PaperAdvances.Corollary3_6.finite_hankel_gram u n

/-- Corollary 3.6 corrected: every finite-atomic Hankel truncation is
    positive semidefinite, unconditionally. -/
theorem CHRONOLOGICAL_FINITE_ATOMIC_POSSEMIDEF {h : ℕ}
    (u : Fin h → ℝ) (n : ℕ) :
    (PaperAdvances.Corollary3_6.finiteHankel u n).PosSemidef :=
  PaperAdvances.Corollary3_6_FullGram.finite_hankel_posSemidef u n

/-- The complete h-by-h atomic Hankel determinant is strictly positive
    exactly when the h real nodes are distinct. -/
theorem CHRONOLOGICAL_FINITE_ATOMIC_FULL_DET_POS {h : ℕ}
    (u : Fin h → ℝ) (hu : Function.Injective u) :
    0 < (PaperAdvances.Corollary3_6.finiteHankel u h).det :=
  PaperAdvances.Corollary3_6_FullGram.finite_hankel_full_det_pos u hu

/-- Complete first-degree-3 Turan inequality, part of Theorem 3.7. -/
theorem CHRONOLOGICAL_CUBIC_TURAN_FIRST (x a b c : ℝ) :
    0 ≤ ((x-b)*(x-c) + (x-a)*(x-c) + (x-a)*(x-b))^2
      - ((x-a)*(x-b)*(x-c)) * (2*((x-a)+(x-b)+(x-c))) :=
  PaperAdvances.Theorem3_7.cubic_first_turan_nonnegative x a b c

/-- Theorem 3.3: the complete real-s slope determinant sign reduction. -/
theorem CHRONOLOGICAL_SLOPE_DET_SIGN
    (p : ManuscriptChain.Real.Parameters) (s : ℝ) :
    0 < (PaperAdvances.Proposition3_2.slope p s).det ↔
      0 < ∏ a : Fin p.h, PaperAdvances.Proposition3_2.gamma p s a :=
  PaperAdvances.Theorem3_3_Sign.slope_det_pos_iff p s

/-- Theorem 3.8(1): actual Hankel relative spectrum equals the pole-kernel
spectrum, as complete characteristic polynomials. -/
theorem CHRONOLOGICAL_ACTUAL_CD_CHARPOLY
    (p : ManuscriptChain.Real.Parameters) :
    ((PaperAdvances.Theorem3_8_Actual.actualGram p)⁻¹ *
      ManuscriptChain.Real.derivativeMatrix p).charpoly =
      (PaperAdvances.Theorem3_8_Kernel.poleOperator
        (PaperAdvances.Theorem3_8_Actual.actualGram p)
        (PaperAdvances.Theorem3_8_Actual.actualV p)
        (PaperAdvances.Theorem3_8_Actual.actualGamma p)).charpoly :=
  PaperAdvances.Theorem3_8_Actual.actual_relative_charpoly_eq_pole p

/-- The matching finite trace identity, the algebraic side of Jacobi. -/
theorem CHRONOLOGICAL_ACTUAL_CD_TRACE
    (p : ManuscriptChain.Real.Parameters) :
    ((PaperAdvances.Theorem3_8_Actual.actualGram p)⁻¹ *
      ManuscriptChain.Real.derivativeMatrix p).trace =
      (PaperAdvances.Theorem3_8_Kernel.poleOperator
        (PaperAdvances.Theorem3_8_Actual.actualGram p)
        (PaperAdvances.Theorem3_8_Actual.actualV p)
        (PaperAdvances.Theorem3_8_Actual.actualGamma p)).trace :=
  PaperAdvances.Theorem3_8_Actual.actual_relative_trace_eq_pole p

/-- Theorem 3.8(2), finite-affine part: actual odd-zeta pencil's
logarithmic derivative equals the verified pole-kernel trace. -/
theorem CHRONOLOGICAL_ACTUAL_AFFINE_JACOBI
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    HasDerivAt
      (fun t : ℝ => Real.log
        ((PaperAdvances.Theorem3_8_Actual.actualGram p +
          t • ManuscriptChain.Real.derivativeMatrix p).det))
      (PaperAdvances.Theorem3_8_Kernel.poleOperator
        (PaperAdvances.Theorem3_8_Actual.actualGram p)
        (PaperAdvances.Theorem3_8_Actual.actualV p)
        (PaperAdvances.Theorem3_8_Actual.actualGamma p)).trace 0 :=
  PaperAdvances.Theorem3_8_Jacobi.actual_affine_log_jacobi p hp

/-- Theorem 3.9 — exact full-size nonsingularity for shifted-square poles.
    The positivity of a *specific analytic* Gram matrix remains separate. -/
theorem CHRONOLOGICAL_HURWITZ_SHIFTED_SLOPE_NONSINGULAR
    {n : ℕ} (N : ℕ) (theta s : ℝ) (htheta : 0 < theta)
    (residue : Fin n → ℝ) (hres : ∀ a, residue a ≠ 0) :
    (PaperAdvances.Theorem3_9_ShiftedPole.poleM
      (PaperAdvances.Theorem3_9_ShiftedPole.shiftedSquareNode (n := n) N theta)
      (PaperAdvances.Theorem3_9_ShiftedPole.shiftedGamma N theta s residue)).det ≠ 0 :=
  PaperAdvances.Theorem3_9_ShiftedPole.hurwitz_slope_nonsingular
    N theta s htheta residue hres

/-- Theorem 3.9 — real-rootedness for any positive definite shifted base. -/
theorem CHRONOLOGICAL_HURWITZ_SHIFTED_ROOTS_REAL
    {n : ℕ} (N : ℕ) (theta s center : ℝ) (htheta : 0 < theta)
    (residue : Fin n → ℝ) (hres : ∀ a, residue a ≠ 0)
    (G : Matrix (Fin n) (Fin n) ℝ) (hG : G.IsSymm) (hpos : G.PosDef)
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (PaperAdvances.Theorem3_9_ShiftedPole.polePencil
        (PaperAdvances.Theorem3_9_ShiftedPole.shiftedSquareNode (n := n) N theta)
        (PaperAdvances.Theorem3_9_ShiftedPole.shiftedGamma N theta s residue)
        center G hG).detPolynomial = 0) :
    z.im = 0 :=
  PaperAdvances.Theorem3_9_ShiftedPole.hurwitz_complex_roots_real
    N theta s center htheta residue hres G hG hpos z hz

/-- Theorem 3.8: the determinant has an exact quadratic remainder
    for every finite real matrix, not just a formal derivative statement. -/
theorem CHRONOLOGICAL_CD_EXACT_TAYLOR {n : ℕ}
    (A : Matrix (Fin n) (Fin n) ℝ) (t : ℝ) :
    (1 + t • A).det =
      1 + A.trace * t +
      ((PaperAdvances.Theorem3_8_Jacobi.unitDetPoly A).divX.divX).eval t * t ^ 2 :=
  PaperAdvances.Theorem3_8_ExactTaylor.unit_det_exact_second_order A t

/-- Theorem 3.9: positive Fekete numerators for all five real
    characters of conductors 3, 4, 5, and 8 on the unit interval. -/
theorem CHRONOLOGICAL_FEKETE_POSITIVE
    (z : ℝ) (hz : 0 < z) (h1 : z < 1) :
    0 < PaperAdvances.Theorem3_9_CharacterPositive.f3 z ∧
    0 < PaperAdvances.Theorem3_9_CharacterPositive.f4 z ∧
    0 < PaperAdvances.Theorem3_9_CharacterPositive.f5 z ∧
    0 < PaperAdvances.Theorem3_9_CharacterPositive.f8pos z ∧
    0 < PaperAdvances.Theorem3_9_CharacterPositive.f8neg z :=
  PaperAdvances.Theorem3_9_CharacterPositive.all_fekete_numerators_pos z hz h1

/-- Theorem 5.1: rational divided-difference moments are symmetric,
    independent of the unproved two-dimensional integration bridge. -/
theorem CHRONOLOGICAL_DUAL_RATIONAL_SYMMETRY (s r t : ℕ) :
    ManuscriptChain.Real.dualConstant s r t =
      ManuscriptChain.Real.dualConstant s t r :=
  PaperAdvances.Theorem5_1_DualSymmetric.dual_constant_symmetric s r t

/-- Theorem 3.9 / 6.4: complete positive-definite pole slope once the
    signed residues have strictly positive weights. -/
theorem CHRONOLOGICAL_POLE_SLOPE_POSITIVE {n : ℕ}
    (nodes gamma : Fin n → ℝ)
    (hn : Function.Injective nodes) (hgamma : ∀ a, 0 < gamma a) :
    (PaperAdvances.Theorem3_9_ShiftedPole.poleM nodes gamma).PosDef :=
  PaperAdvances.Theorem3_9_PositiveSlope.poleM_posDef nodes gamma hn hgamma

/-- Theorem 5.2: coefficient-row injectivity implies a positive definite
    dual X-derivative, for every matrix size and polynomial degree. -/
theorem CHRONOLOGICAL_DUAL_DERIVATIVE_POSDEF {h K : ℕ}
    (C : Matrix (Fin h) (Fin (K + 1)) ℝ)
    (hC : Function.Injective C.vecMul) :
    (PaperAdvances.Theorem5_2_DualDerivative.dualSlope C).PosDef :=
  PaperAdvances.Theorem5_2_DualDerivative.dualSlope_posDef C hC

/-- Theorem 5.2(1): for the actual rational coefficient matrix of
    the two-variable Beukers pencil, full row rank implies positive
    definiteness of the X-derivative. -/
theorem CHRONOLOGICAL_ACTUAL_DUAL_SLOPE_POSDEF {h K : ℕ}
    (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul) :
    (PaperAdvances.Theorem5_2_ActualDual.actualSlope s c).PosDef :=
  PaperAdvances.Theorem5_2_ActualDual.actualSlope_posDef s c hc

/-- In particular the coefficient determinant is strictly positive. -/
theorem CHRONOLOGICAL_ACTUAL_DUAL_SLOPE_DET_POS {h K : ℕ}
    (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul) :
    0 < (PaperAdvances.Theorem5_2_ActualDual.actualSlope s c).det :=
  PaperAdvances.Theorem5_2_ActualDual.actualSlope_det_pos s c hc

/-- Theorem 5.2(1): exact degree of the actual rational two-variable
    Beukers determinant under the manuscript's linear independence of
    coefficient rows. Neither its center matrix nor its value need be
    positive, and no new analytic witness is introduced. -/
theorem CHRONOLOGICAL_DUAL_ACTUAL_EXACT_DEGREE {h K : ℕ}
    (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul) :
    (ManuscriptChain.Real.realPolynomial
      (ManuscriptChain.Real.dualDelta s c)).natDegree = h :=
  PaperAdvances.Theorem5_2_ActualRoots.actualDualDelta_natDegree s c hc

/-- Theorem 5.2(1): every complex root of the actual dual rational
    Beukers determinant is real, even with an indefinite constant matrix. -/
theorem CHRONOLOGICAL_DUAL_ACTUAL_ROOTS_REAL {h K : ℕ}
    (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective
      (PaperAdvances.Theorem5_2_DualDerivative.coefficientMatrix c).vecMul)
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (ManuscriptChain.Real.realPolynomial
        (ManuscriptChain.Real.dualDelta s c)) = 0) :
    z.im = 0 :=
  PaperAdvances.Theorem5_2_ActualRoots.actualDualDelta_complex_roots_real
    s c hc z hz

end PaperChronology

#print axioms PaperChronology.CHRONOLOGICAL_UNCONDITIONAL_SPECTRAL
#print axioms PaperChronology.CHRONOLOGICAL_WITNESS_ENDPOINT

#print axioms PaperChronology.CHRONOLOGICAL_REAL_S_SLOPE_NONSINGULAR
#print axioms PaperChronology.CHRONOLOGICAL_ACTUAL_GRAM_DET_POSITIVE

#print axioms PaperChronology.CHRONOLOGICAL_DODGSON_3X3
#print axioms PaperChronology.CHRONOLOGICAL_FINITE_ATOMIC_GRAM
#print axioms PaperChronology.CHRONOLOGICAL_CUBIC_TURAN_FIRST

#print axioms PaperChronology.CHRONOLOGICAL_SLOPE_DET_SIGN
#print axioms PaperChronology.CHRONOLOGICAL_ACTUAL_CD_CHARPOLY
#print axioms PaperChronology.CHRONOLOGICAL_ACTUAL_CD_TRACE

#print axioms PaperChronology.CHRONOLOGICAL_ACTUAL_AFFINE_JACOBI

#print axioms PaperChronology.CHRONOLOGICAL_HURWITZ_SHIFTED_SLOPE_NONSINGULAR
#print axioms PaperChronology.CHRONOLOGICAL_HURWITZ_SHIFTED_ROOTS_REAL

#print axioms PaperChronology.CHRONOLOGICAL_CD_EXACT_TAYLOR
#print axioms PaperChronology.CHRONOLOGICAL_FEKETE_POSITIVE
#print axioms PaperChronology.CHRONOLOGICAL_DUAL_RATIONAL_SYMMETRY

#print axioms PaperChronology.CHRONOLOGICAL_POLE_SLOPE_POSITIVE

#print axioms PaperChronology.CHRONOLOGICAL_DUAL_DERIVATIVE_POSDEF

#print axioms PaperChronology.CHRONOLOGICAL_FINITE_ATOMIC_POSSEMIDEF
#print axioms PaperChronology.CHRONOLOGICAL_FINITE_ATOMIC_FULL_DET_POS
#print axioms PaperChronology.CHRONOLOGICAL_ACTUAL_DUAL_SLOPE_POSDEF
#print axioms PaperChronology.CHRONOLOGICAL_ACTUAL_DUAL_SLOPE_DET_POS

#print axioms PaperChronology.CHRONOLOGICAL_DUAL_ACTUAL_EXACT_DEGREE
#print axioms PaperChronology.CHRONOLOGICAL_DUAL_ACTUAL_ROOTS_REAL
