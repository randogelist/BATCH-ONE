# v1.2.26 — Corollary 3.6 full-Gram matrix IsUnit repair

Only `ProofAdvances/Corollary_3_6_FullGram.lean` was modified.

The previous expression `Matrix.isUnit_iff_isUnit_det.mpr hdet` was parsed as a lookup for the non-existent declaration `Matrix.isUnit_iff_isUnit_det.mpr`. We now apply the iff to the concrete matrix first, producing `hmatrix : IsUnit (finiteVandermonde u h)`, and supply this to `Matrix.vecMul_injective_iff_isUnit`. This is the same calling convention already verified in Theorem 3.9 PositiveSlope.

Source and import-spine CAS keys were invalidated; all other successful modules retain their existing keys.

No Lean compilation performed here; native Windows Lean 4.33.0 remains the only compiler authority. The source is submitted for compiler verification and the project remains `FULL_PAPER=NOT_PROVED`.
