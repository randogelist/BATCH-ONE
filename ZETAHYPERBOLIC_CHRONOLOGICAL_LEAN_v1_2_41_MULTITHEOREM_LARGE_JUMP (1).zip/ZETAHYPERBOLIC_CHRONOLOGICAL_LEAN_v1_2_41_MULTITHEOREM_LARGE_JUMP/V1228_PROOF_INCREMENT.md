# v1.2.28 — dual spectral algebra (Theorem 5.2(1))

User-confirmed compiler checkpoint for v1.2.27:
`BUILD=PASS`, `LEAN_CHECKS=129/129`, `FROZEN_PASS=120`, `NEW_COMPILED=9`.
The new branch creates and verifies a *source-level* proof proposal for the
nonpositive-center, positive-derivative spectral theorem. It proves, if
accepted by native Lean, that a symmetric affine determinant with positive
slope factors into real linear factors, has exact degree equal to its size,
and has no nonreal zeros. The proof uses matrix square roots, inverse
congruence, and the real Hermitian spectral theorem already employed in
Theorem 3.1. The second new module specializes this to the ACTUAL rational
Beukers dual matrix and its determinant, using the previously passed
`dualEntry` symmetric and slope `C*Cᵀ` lemmas.

The full analytic Beukers integral and infinite Krein-space cone assertions
remain open and are not made hypotheses of the dual spectral lemma.
No `sorry`, `admit`, `axiom` or opaque constants are introduced.

This new package has NOT been compiled locally. The user's pinned native
Windows Lean 4.33.0 compiler is the only proof acceptance authority.
The previously confirmed 129 modules remain unchanged except for the
chronological main chain (whose dependency closure must be rechecked).
