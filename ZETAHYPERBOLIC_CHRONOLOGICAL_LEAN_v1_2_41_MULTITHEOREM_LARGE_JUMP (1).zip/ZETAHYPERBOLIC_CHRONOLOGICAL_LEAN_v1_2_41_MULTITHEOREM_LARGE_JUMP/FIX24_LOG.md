# v1.2.37 — Turan evaluation and closed-goal tactic patch

Source-level fix of `ProofAdvances/Theorem_3_7_AllDegrees.lean`, targeting:

1. The `turan_mul_linear` proof leaves `(Polynomial.eval x (2 : ℝ[X]))` unreduced. Switch the evaluation normalization to `simp [...] <;> ring`, where `simp` handles the polynomial numeral and `ring` finishes the normalized real-ring identity.
2. The `turan_mul_affine` proof already closes after `simp only`; replace an unconditional, trailing `ring` with the guarded `<;> ring` to eliminate `No goals to be solved`.

All 133 old modules are byte-identical. The two new module closure fingerprints are updated, with no claim of compiler PASS until the user's pinned Windows Lean 4.33.0 accepts the package. No axioms, `sorry`, or witness were introduced. `FULL_PAPER=NOT_PROVED` is retained.
