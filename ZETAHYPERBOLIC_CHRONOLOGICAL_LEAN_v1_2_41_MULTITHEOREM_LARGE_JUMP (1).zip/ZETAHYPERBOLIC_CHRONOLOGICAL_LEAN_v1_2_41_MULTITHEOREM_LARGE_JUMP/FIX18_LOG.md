# v1.2.27 — explicit matrix IFF source repair

The reported compiler error `Matrix.isUnit_iff_isUnit_det.mpr` at
`Corollary_3_6_FullGram.lean:81:7` identifies the v1.2.25 source, not the
v1.2.26 source (which already changed the expression). To make a fresh
run unambiguous, v1.2.27 also modifies the proof's binder names and logs
a new revision marker before compilation. The proof follows the already
compiler-PASS `Theorem_3_9_PositiveSlope.poleM_posDef` exact calling pattern:
`(Matrix.isUnit_iff_isUnit_det A).2 hdet`, then
`Matrix.vecMul_injective_iff_isUnit.2 hVunit`.

User checkpoint: 126 of 129 modules passed; keep verified frozen modules.
This release changes only the failing `ProofAdvances/Corollary_3_6_FullGram.lean`
and its downstream import-closure metadata. It does not add axioms, sorry,
or a new witness. It is uncompiled locally per user's policy.
