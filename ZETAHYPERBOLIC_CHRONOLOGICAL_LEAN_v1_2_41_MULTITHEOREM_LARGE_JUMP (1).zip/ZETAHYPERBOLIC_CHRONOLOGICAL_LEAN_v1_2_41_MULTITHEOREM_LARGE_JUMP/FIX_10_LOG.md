# v1.2.19 — Jacobi coefficient identity fix4

Source-level change (UNCOMPILED): `ProofAdvances/Theorem_3_8_Jacobi.lean`.

- The polynomial derivative at zero is proved from Mathlib's already established identity `Matrix.coeff_det_one_add_X_smul_one`, and the polynomial coefficient/derivative equations, instead of attempting a direct elaboration of `Matrix.derivative_det_one_add_X_smul`.
- The determinant evaluation identity uses an explicit `RingHom.map_det` equality.
- Additional `#print axioms` checks expose the identities imported by subsequent modules.
- This ZIP contains no executable Lean compilation done by the assistant. Only Windows native Lean 4.33.0 on the user's machine determines success.
- No previous passing Lean file is modified. Frozen hashes retained; invalidation isolated to the Jacobi source and two dependents.

Actual source SHA256: `C63E344A7507866F97278E2C27164D3DF04297EB6767B525A7E0F5E2B55337E4`.
Manifest SHA256: `9BBDFE75EB1B7E35A28D40CA5C14F4822EB66075DEB868F3A240D6F4EBFFEA73`.

Prior user compiler status: 119/129 PASS. This is **not** proof of the entire PDF; unconditional statements and the one witness interface retain their prior scope.
