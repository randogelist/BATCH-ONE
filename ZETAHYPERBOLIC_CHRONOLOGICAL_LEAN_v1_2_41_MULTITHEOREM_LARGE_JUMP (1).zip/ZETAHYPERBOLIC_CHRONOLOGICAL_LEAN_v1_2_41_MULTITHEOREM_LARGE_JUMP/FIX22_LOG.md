# v1.2.32 — actual roots proof, Matrix-head elaboration fix3

Native Windows Lean 4.33.0 returned `BUILD=FAIL`, `LEAN_CHECKS=129/131`
and only `ProofAdvances/Theorem_5_2_ActualRoots.lean` failed. The
`(fun i j => ... : Matrix _ _ ℚ[X]).map` is not recognized by the Lean
field elaborator because Matrix is definitionally a function. This
revision defines `actualDualPolynomialMatrix` as a genuine named Matrix
constant, and uses `(actualDualPolynomialMatrix s c).map ...` plus
`RingHom.map_det` with the same matrix. This change is definitional:
actualDualPolynomialMatrix is the actual dualEntry matrix, hence
mathematically the original rational dualDelta matrix.

Unchanged verified modules remain frozen. Only this failed source and
its chronological consumer have cache-dependency keys invalidated.
No Lean compilation was performed locally. User compiler is the sole
authority. `FULL_PAPER=NOT_PROVED` remains unchanged.
