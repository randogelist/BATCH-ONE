# Lemma 2.2 declaration fix 2 (2026-10-24)

The user returned the same `Paper\Lemma_2_2.lean:27:71` compiler failure after the v1.2.4 release.
The position matches v1.2.3's 71-character `/-\*` documentation-comment line, whereas
v1.2.4's line 27 has 70 characters. That suggests an older extracted package or log may
have been used. The precise cause on the user machine cannot be confirmed from the excerpt.

**This release removes both `#check` commands** adjacent to the offending boundary and
replaces the referenced simple-pole identity with an actual theorem
`PaperChronology.pullback_pole` using the previously proved
`Zetahyperbolic.pullback_identity_pole` (no new hypothesis).
The inherited monomial theorem and harmonic successor theorem are unchanged.

`run.cmd` displays `LEMMA22_SOURCE=FIX2_CONFIRMED` only after verifying the actual
package `Paper\Lemma_2_2.lean` against `74D53073952EA52F9D231563381AD585DB9C2CA0D417FE3DAA5CF90712E9DF71`.
It exits before compilation if the file is stale or does not match.

A corrected direct-seeding comparison now compares full runtime fingerprints to old
`_native_build/FASTCORE_ENV.txt`, and additionally checks source, matching import
closure, prior `CHECK_PASS`, and artifact existence. Successful modules can be seeded
from a partial v1.2.4 (or v1.2.3) build rather than relying on the persistent CAS alone.
A cache miss always compiles with the user's own compiler.

No Lean compilation was performed locally.
