# v1.2.22 — Proposition 3.9 positive-slope FIX1

Native Windows Lean 4.33 log: 123/129 checks passed; failed module `ProofAdvances/Theorem_3_9_PositiveSlope.lean` at 39:10: `Unknown constant Matrix.isUnit_iff_isUnit_det.mpr`. Failure caused `sorryAx` reports for two downstream declarations, not a new mathematical assumption.

Repair: change the projection from the unapplied theorem name to the explicit iff `(Matrix.isUnit_iff_isUnit_det (poleV nodes)).mpr hdet`. This has type `IsUnit (poleV nodes)` from the already obtained `hdet : IsUnit (poleV nodes).det`.

Only the previously failing Lean source changed; the chronologically ordered root module's transitive hash is invalidated without editing its source. The other 128 source files are byte-identical to v1.2.21. Frozen-cache reuse is preserved. This is static packaging only, not local Lean compilation.
