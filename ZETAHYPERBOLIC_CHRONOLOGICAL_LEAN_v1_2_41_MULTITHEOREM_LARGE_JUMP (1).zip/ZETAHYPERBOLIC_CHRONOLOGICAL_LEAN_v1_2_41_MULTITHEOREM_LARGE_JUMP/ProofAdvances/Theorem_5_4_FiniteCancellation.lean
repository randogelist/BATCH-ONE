import ProofAdvances.Lemma_2_3_FullNormalForm
import Paper.Theorem_5_4
import Mathlib.Tactic

/-!
# Theorem 5.4 finite-weight pole-pair cancellation

Linear combination of arbitrarily many adjacent-pole differences
cancels all occurrences of the parameter X, with exact rational
harmonic increments. This is a finite structural consequence, not
an assertion of the remaining transcendental evaluations in 5.4.
-/

noncomputable section
open scoped BigOperators
namespace PaperAdvances.Theorem5_4_FiniteCancellation

/-- Arbitrary finite weighted cancellation of the affine parameter,
for every natural weight and any rational coefficient vector. -/
theorem FINITE_POLE_PAIR_CANCELLATION
    (s : ℕ) (J : Finset ℕ) (c : ℕ → ℚ) (X : ℚ) :
    (∑ n ∈ J, c n *
      ((ManuscriptChain.Real.harmonic s (n + 1) - X) -
       (ManuscriptChain.Real.harmonic s n - X))) =
    ∑ n ∈ J, c n / (((n + 1 : ℕ) : ℚ) ^ s) := by
  apply Finset.sum_congr rfl
  intro n hn
  rw [PaperChronology.even_pole_pair_cancellation s n X]
  simp only [div_eq_mul_inv, one_mul]

/-- The same identity simultaneously for weights three, five, seven. -/
theorem FINITE_POLE_PAIR_WEIGHTS_3_5_7
    (J : Finset ℕ) (c : ℕ → ℚ) (X : ℚ) :
    ((∑ n ∈ J, c n *
        ((ManuscriptChain.Real.harmonic 3 (n + 1) - X) -
         (ManuscriptChain.Real.harmonic 3 n - X))) =
       ∑ n ∈ J, c n / (((n + 1 : ℕ) : ℚ) ^ 3)) ∧
    ((∑ n ∈ J, c n *
        ((ManuscriptChain.Real.harmonic 5 (n + 1) - X) -
         (ManuscriptChain.Real.harmonic 5 n - X))) =
       ∑ n ∈ J, c n / (((n + 1 : ℕ) : ℚ) ^ 5)) ∧
    ((∑ n ∈ J, c n *
        ((ManuscriptChain.Real.harmonic 7 (n + 1) - X) -
         (ManuscriptChain.Real.harmonic 7 n - X))) =
       ∑ n ∈ J, c n / (((n + 1 : ℕ) : ℚ) ^ 7)) := by
  exact ⟨FINITE_POLE_PAIR_CANCELLATION 3 J c X,
    FINITE_POLE_PAIR_CANCELLATION 5 J c X,
    FINITE_POLE_PAIR_CANCELLATION 7 J c X⟩

end PaperAdvances.Theorem5_4_FiniteCancellation

#print axioms PaperAdvances.Theorem5_4_FiniteCancellation.FINITE_POLE_PAIR_CANCELLATION
