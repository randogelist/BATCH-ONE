import Paper.Lemma_2_2
import Mathlib.Tactic

/-!
# Lemma 2.2: full finite normal-form pullback

Unlike a check of two generator classes alone, the statement here
quantifies over arbitrary polynomial numerators and arbitrarily many
simple-pole residues. This is the entire partial-fraction normal form
represented by `RatMomentElem`, not a claimed equality of actual
`RatFunc` objects under substitution (that separate semantic encoding
remains an extension).

No quantitative arithmetic hypothesis or sorry is used.
-/

noncomputable section
open Polynomial
open scoped BigOperators
namespace PaperAdvances.Lemma2_2_FullNormalForm

/-- Generator-prescribed pullback value on an arbitrary decomposed
rational moment element, with polynomial part and finitely supported
pole residues. This is the tau-side of manuscript (2.5). -/
def tauPulledbackNormalForm (k : ℕ) (R : Zetahyperbolic.RatMomentElem) : ℚ[X] :=
  (∑ e ∈ Finset.range (R.polyPart.natDegree + 1),
    C (R.polyPart.coeff e *
      ((-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1)))) +
  ∑ j ∈ Finset.Icc 1 R.maxPole,
    C (R.poleRes j) *
      (C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        C ((j : ℚ) ^ (2 * k) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
            Zetahyperbolic.tauPolePoly k (-(j : ℤ))))

/-- Lemma 2.2 (2.5) for EVERY finite rational partial-fraction
normal form, rather than one basis element at a time. -/
theorem FULL_PULLBACK_ALL_NORMAL_FORMS
    (k : ℕ) (hk : 1 ≤ k) (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k R = tauPulledbackNormalForm k R := by
  unfold Zetahyperbolic.muFunctionalPoly tauPulledbackNormalForm
  apply congrArg₂ (fun u v : ℚ[X] => u + v)
  · apply Finset.sum_congr rfl
    intro e he
    exact congrArg (fun y : ℚ => C (R.polyPart.coeff e * y))
      (Zetahyperbolic.pullback_identity_monomial k e hk)
  · apply Finset.sum_congr rfl
    intro j hj
    exact congrArg (fun Y : ℚ[X] => C (R.poleRes j) * Y)
      (Zetahyperbolic.pullback_identity_pole k j hk
        (Finset.mem_Icc.mp hj).1)

/-- The entire finite decomposition is covered uniformly at odd
weights 3, 5 and 7. -/
theorem PULLBACK_ODD_WEIGHTS_3_5_7
    (R : Zetahyperbolic.RatMomentElem) :
    (Zetahyperbolic.muFunctionalPoly 1 R = tauPulledbackNormalForm 1 R) ∧
    (Zetahyperbolic.muFunctionalPoly 2 R = tauPulledbackNormalForm 2 R) ∧
    (Zetahyperbolic.muFunctionalPoly 3 R = tauPulledbackNormalForm 3 R) := by
  exact ⟨FULL_PULLBACK_ALL_NORMAL_FORMS 1 (by omega) R,
    FULL_PULLBACK_ALL_NORMAL_FORMS 2 (by omega) R,
    FULL_PULLBACK_ALL_NORMAL_FORMS 3 (by omega) R⟩

end PaperAdvances.Lemma2_2_FullNormalForm

#print axioms PaperAdvances.Lemma2_2_FullNormalForm.FULL_PULLBACK_ALL_NORMAL_FORMS
#print axioms PaperAdvances.Lemma2_2_FullNormalForm.PULLBACK_ODD_WEIGHTS_3_5_7
