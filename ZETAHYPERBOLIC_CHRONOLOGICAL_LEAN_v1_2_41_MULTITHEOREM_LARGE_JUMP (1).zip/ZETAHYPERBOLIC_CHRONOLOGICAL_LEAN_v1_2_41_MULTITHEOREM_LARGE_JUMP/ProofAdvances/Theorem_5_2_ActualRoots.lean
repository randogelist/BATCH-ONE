import ProofAdvances.Theorem_5_2_RealRoots
import ProofAdvances.Theorem_5_2_ActualDual
import ProofAdvances.Theorem_5_1_DualSymmetric
import Mathlib.Tactic

/-!
# Theorem 5.2(1) -- full actual rational Beukers dual spectral polynomial

Identifies the real polynomial obtained from the *actual* rational dual
moment determinant with a symmetric positive-slope pencil.  Theorem
5.2(1)'s degree and real-rootedness then follow, in every finite size,
from coefficient-row injectivity (i.e. linear independence of the chosen
polynomial basis).  No positive-definite hypothesis on the Beukers moment
matrix, and no zeta(5) or irrationality witness, is required.

The analytic integral-moment identification and the infinite Krein-space
construction of Theorem 5.2(2)/(3) remain separate mathematical work.
-/

noncomputable section
open Matrix Polynomial
namespace PaperAdvances.Theorem5_2_ActualRoots

open ManuscriptChain
open ManuscriptChain.Spectral
open PaperAdvances.Theorem5_1_DualSymmetric
open PaperAdvances.Theorem5_2_ActualDual
open PaperAdvances.Theorem5_2_RealRoots
open PaperAdvances.Theorem5_2_DualDerivative

/-- Actual center matrix of the rational dual moment polynomial. -/
def actualBase {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℝ :=
  fun i j => Real.evalQ (Real.dualEntry s c i j) (Real.zeta s)

/-- The actual base is symmetric, even if indefinite. -/
theorem actualBase_isSymm {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    (actualBase s c).IsSymm := by
  ext i j
  change Real.evalQ (Real.dualEntry s c j i) (Real.zeta s) =
    Real.evalQ (Real.dualEntry s c i j) (Real.zeta s)
  exact congrArg (fun q : ℚ[X] => Real.evalQ q (Real.zeta s))
    (dual_entry_symmetric s c j i)

/-- Symmetry of the true X-derivative holds before requiring full row rank. -/
theorem actualSlope_isSymm {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    (actualSlope s c).IsSymm := by
  ext i j
  change ((Real.dualEntry s c j i).coeff 1 : ℝ) =
    ((Real.dualEntry s c i j).coeff 1 : ℝ)
  rw [dual_entry_symmetric s c j i]

/-- The manuscript's dual rational polynomial, as a real symmetric pencil. -/
def actualPencil {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    SymmetricAffinePencil h where
  center := Real.zeta s
  base := actualBase s c
  direction := actualSlope s c
  base_symmetric := actualBase_isSymm s c
  direction_symmetric := actualSlope_isSymm s c

/-- Evaluation of each actual rational dual-pencil entry is affine.
Using real evaluation at zero avoids ambiguous coercions from ℚ[X]. -/
theorem dualEntry_eval_affine {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ)
    (i j : Fin h) (x : ℝ) :
    Real.evalQ (Real.dualEntry s c i j) x =
      Real.evalQ (Real.dualEntry s c i j) (0 : ℝ) +
        x * ((Real.dualEntry s c i j).coeff 1 : ℝ) := by
  let a : ℚ :=
    ∑ r, ∑ t, c i r * c j t * Real.dualConstant s r.val t.val
  let b : ℚ := ∑ r, c i r * c j r
  have hp : Real.dualEntry s c i j = C a + C b * X := rfl
  have hval (y : ℝ) :
      Real.evalQ (Real.dualEntry s c i j) y = (a : ℝ) + (b : ℝ) * y := by
    rw [hp]
    simp [Real.evalQ, Real.realPolynomial]
  have hcoeff : (Real.dualEntry s c i j).coeff 1 = b := by
    simpa only [b] using dual_entry_linear_coefficient s c i j
  rw [hval x, hval 0, hcoeff]
  ring

/-- The actual matrix at X equals evaluation of the paper's entries. -/
theorem actualPencil_matrixAt {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) (x : ℝ) :
    (actualPencil s c).matrixAt x =
      (fun i j => Real.evalQ (Real.dualEntry s c i j) x) := by
  ext i j
  change Real.evalQ (Real.dualEntry s c i j) (Real.zeta s) +
    (x - Real.zeta s) * ((Real.dualEntry s c i j).coeff 1 : ℝ) =
      Real.evalQ (Real.dualEntry s c i j) x
  rw [dualEntry_eval_affine s c i j x,
    dualEntry_eval_affine s c i j (Real.zeta s)]
  ring

/-- Matrix-typed form of the actual rational dual-moment pencil.
Keeping the matrix as a named definition prevents the dot-notation elaborator
from seeing only the definitionally equal function type. -/
def actualDualPolynomialMatrix {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℚ[X] :=
  fun i j => Real.dualEntry s c i j

/-- The entire actual polynomial matrix equals the transported ℚ[X] pencil.
This is the same proof pattern as the previously verified theorem
`ManuscriptChain.Real.manuscriptPencil_polynomialMatrix`. -/
theorem actualPencil_polynomialMatrix {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    (actualPencil s c).polynomialMatrix =
      Matrix.map (actualDualPolynomialMatrix s c)
        (Polynomial.mapRingHom (Rat.castHom ℝ)) := by
  apply Matrix.ext
  intro i j
  apply Polynomial.funext
  intro x
  change ((actualPencil s c).polynomialMatrix i j).eval x =
    Real.evalQ (Real.dualEntry s c i j) x
  calc
    ((actualPencil s c).polynomialMatrix i j).eval x =
        ((actualPencil s c).matrixAt x) i j := by
          simp [SymmetricAffinePencil.polynomialMatrix,
            SymmetricAffinePencil.matrixAt] <;> ring
    _ = Real.evalQ (Real.dualEntry s c i j) x :=
          congrArg (fun M : Matrix (Fin h) (Fin h) ℝ => M i j)
            (actualPencil_matrixAt s c x)

/-- Polynomial determinant commutes with coefficient transport ℚ→ℝ.
Unlike the previous failed scalar-det rewrite, this directly applies
`RingHom.map_det` to the known polynomial matrix. -/
theorem actualPencil_detPolynomial {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) :
    (actualPencil s c).detPolynomial =
      Real.realPolynomial (Real.dualDelta s c) := by
  unfold SymmetricAffinePencil.detPolynomial
  rw [actualPencil_polynomialMatrix]
  exact ((Polynomial.mapRingHom (Rat.castHom ℝ)).map_det
    (actualDualPolynomialMatrix s c)).symm

/-- Pointwise determinant transport follows from polynomial equality. -/
theorem actualPencil_det_eval {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) (x : ℝ) :
    (actualPencil s c).detPolynomial.eval x =
      Real.evalQ (Real.dualDelta s c) x := by
  rw [actualPencil_detPolynomial]
  rfl

/-- Full exact degree of the actual rational Beukers dual determinant. -/
theorem actualDualDelta_natDegree {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective (coefficientMatrix c).vecMul) :
    (Real.realPolynomial (Real.dualDelta s c)).natDegree = h := by
  rw [← actualPencil_detPolynomial]
  exact positive_slope_exact_degree (actualPencil s c)
    (actualSlope_posDef s c hc)

/-- Real-rootedness of the actual rational dual determinant, with no
    positive-definiteness assumption on its constant matrix. -/
theorem actualDualDelta_complex_roots_real {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ)
    (hc : Function.Injective (coefficientMatrix c).vecMul)
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (Real.realPolynomial (Real.dualDelta s c)) = 0) :
    z.im = 0 := by
  rw [← actualPencil_detPolynomial] at hz
  exact positive_slope_complex_roots_real (actualPencil s c)
    (actualSlope_posDef s c hc) z hz

end PaperAdvances.Theorem5_2_ActualRoots

#print axioms PaperAdvances.Theorem5_2_ActualRoots.actualPencil_detPolynomial
#print axioms PaperAdvances.Theorem5_2_ActualRoots.actualDualDelta_natDegree
#print axioms PaperAdvances.Theorem5_2_ActualRoots.actualDualDelta_complex_roots_real
