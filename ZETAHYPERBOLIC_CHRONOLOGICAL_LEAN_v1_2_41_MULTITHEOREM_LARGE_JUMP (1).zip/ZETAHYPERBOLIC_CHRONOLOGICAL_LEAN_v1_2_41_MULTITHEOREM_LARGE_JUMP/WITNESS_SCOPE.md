# The single Witness: exact, inspectable mathematical contract

The exact field definitions are in `PAPER_04_WITNESS.lean`.

Set `K_n=30n`, `N_n=3n`, `h_n=27n`, with `Q_n(X)` the **primitive integer normalization of the paper's actual Hankel determinant** at weight five. Let `ξ=ζ(5)`. The positive definite Gram matrix and all spectral factors are already constructed in Lean.

`Witness.start` is an eventual-validity onset. The witness consists of exactly:

**W1: normalized evaluation bound.** For every `n >= start + 1`,

    |Q_n(ξ)| <= exp[-(1/2500)*(30n)^2].

Nonvanishing `Q_n(ξ) != 0`, polynomial integrality, primitive normalization, and degree `27n` are already theorems; they are not witness fields.

**W2: printed spectral-factor bound.** For every `n >= start + 1` and every root factor `β_{n,i}` of the original matrix pencil,

    |β_{n,i}| <= exp[(11411/1000)*(30n)].

The factorization is already produced by Lean from the proved positive Gram realization, so `Witness` does not postulate root existence or factorization.

### Mathematical origin of W1/W2

The paper (§4) asserts W1 via normalized `Q_n=m_{K,M} F_K` using multiplier and archimedean rates, and W2 via the Legendre–Stirling potential estimate. The archive *does not* have native proofs of these printed quantitative estimates. They must be separately supplied as one `Witness` argument to close the effective measure. This is strictly stronger than merely giving a polynomial or checking a finite numerical instance.

The underlying original file `Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5.lean` contains proved generic implications from multiplier/archimedean estimates, but those estimates themselves remain separate mathematical obligations. The present package merges their required consequences into W1, not the other way around.

### Formal consequences

`PAPER_04_WITNESS.lean` defines:

    witnessDecay w
    witnessSpectralData w
    WITNESS_IMPLIES_EFFECTIVE_MEASURE w
    WITNESS_IMPLIES_IRRATIONAL_ZETA5 w

The first two compile the native interfaces using **only** W1/W2 and proved module lemmas. The measure uses both W1 and W2. The irrationality theorem uses W1 alone, because ordinary rational denominator clearing suffices for a direct contradiction.

### Does this make the entire PDF single-Witness conditional?

**No.** Theorem 5.1's double integral, §5.2's infinite Krein tail / subspaces, §5.6's valuations, and many §6 statements are independent theorems; W1/W2 does not imply them. Nor can the incorrect printed Corollaries 3.5/3.6 be validated. No additional hypotheses are added to the advertised **PAPER_MAIN_CHAIN** theorem, but its claim is deliberately narrower than the whole paper.
