# Manuscript theorem coverage – strict statement audit

Meaning: `PROVED` = available in copied Lean 4.33 sources with matching scope;
`PARTIAL` = finite/model/conditional replacement only;
`FALSE` = literal printed claim mathematically fails;
`NOT CERTIFIED` = not proved by the selected source packages.
The listed source files may contain additional useful conditional theorems;
that is not equivalent to proving the complete printed statement.

| Manuscript | Status | Evidence / missing obligation |
|---|---|---|
| Definition 2.1 | PROVED (finite algebra) | Rational moments and pole functional in Definition_2_1... |
| Lemma 2.2–2.3 | PARTIAL | Pullback/reflection/difference not all in imported source chain |
| Theorem 2.4 | PROVED (core) | Canonical primitive basis invariance; actual determinant normalization |
| Theorem 2.5 | PROVED (key algebra) | Exact slope Vandermonde, derivative invertible; separate Lagrange polynomials not completely reproduced |
| Theorem 3.1 | PROVED | Actual positive moment realization, Riemann-zeta center, spectral roots, exact zero-free radius |
| Proposition 3.2 | NOT CERTIFIED | Continuous real-weight family not assembled in Lean |
| Theorem 3.3 | NOT CERTIFIED | Full strict total positivity, signs, universal signature |
| Theorem 3.4 | NOT CERTIFIED | Full interlacing and Dodgson chain |
| Corollary 3.5 | FALSE as printed | Missing normalization and incorrect parameter in (3.6) |
| Corollary 3.6 | FALSE as printed | Reversed finite sum bound and impossible all-order strict positivity |
| Theorem 3.7 | NOT CERTIFIED | Printed strict coefficient/nonzero claims need proof |
| Theorem 3.8–3.9 | NOT CERTIFIED | CD kernel, Hurwitz/Dirichlet full extensions |
| Theorem 4.1 | PROVED (general criterion) | Integer-polynomial/spectral transfer with quantitative premises; correct logical scope |
| Proposition 4.2–4.3 | NOT CERTIFIED | Algebraic approximation/p-adic disk under paper definitions |
| Theorem 4.4 | PARTIAL | Spectral norm 11.411, exact normalizer & 0.0004 decay NOT discharged; measure 25687 not proved |
| Theorem 4.5 | NOT CERTIFIED | Combined ζ(5),ζ(3) measure needs p-adic normalizer and spectral estimates |
| Theorem 4.6–4.7 | NOT CERTIFIED | Two-sided asymptotics, root macroscopic collapse |
| Proposition 4.8 | NOT CERTIFIED | Derived quantitative exclusions depend on 4.4 |
| Theorem 5.1 | PARTIAL | Finite rational dual moments/pencil defined; two-variable integral identity omitted |
| Theorem 5.2 | PARTIAL | Positive/negative certificate implications; unproved infinite tails and cone existence |
| Proposition 5.3 | NOT CERTIFIED | Full β(4) dual integral |
| Theorem 5.4 | NOT CERTIFIED | Cancellation on even pole pairs under manuscript functional |
| Theorem 5.6 | NOT CERTIFIED | Exact prime-sum integrals and p-adic weight enhancement |
| Theorem 5.7 | PARTIAL | Triple/double-pole finite Hermite algebra, not full valuation result |
| Theorem 6.1–6.2 | NOT CERTIFIED | Local p-adic valuations, coupled Mellin system |
| Theorem 6.3 | PARTIAL | Tail and positive-basis existence left as premises |
| Theorem 6.4 | PARTIAL | Beta auxiliary models; PDF identities not all consistent/realized |
| Theorem 6.5–6.9 | NOT CERTIFIED | Full q-adic/multi-weight conclusions not in active no-gap core |
| Theorem 6.10 | PARTIAL | Exact finite determinant identity; not entire potential-gap theorem |
| Theorem 6.11–6.18 | NOT CERTIFIED | Further q-adic/β multiweight claims and uniform bounds |
| Conjecture 4.11 | OPEN CONJECTURE | Not an unconditional theorem in PDF |

## Strongest unconditional statement

`ZetaPaperNoGaps.ALL_ODD_WEIGHT_SPECTRAL_NO_PREMISES` supplies a
hypothesis-free spectral statement with arbitrary natural-number indices.
The more general `ZetaPaperNoGaps.ODD_WEIGHT_SPECTRAL` applies to every
*admissible* odd weight `s=2k+1` and any `m,N,K` satisfying `k,m,N>=1, K>N`.
It proves exact determinant degree and real-rootedness around `ζ(s)`,
with an exact positive zero-free radius. **It does not prove irrationality.**

## Missing inputs for irrationality inside THIS paper

For direct irrationality of odd zeta, the copied project constructs the
primitive integer polynomial `P_{k,n}` and proves positive evaluation.
The substantive missing fact is a family-dependent bound

    0 < P_{k,n}(ζ(2k+1)) <= exp(-c K_n^2), c>0, K_n ->∞,

or explicit integer normalizers and upper bounds that imply it.
For the paper's **effective exponent 25687**, additionally certify the
paper's norm exponent `||G^(-1/2) M G^(-1/2)|| <= exp(11.411 K)` and the
chosen parameter schedule at the declared constant.

An unrelated proof of `Irrational ζ(5)` does NOT imply that stronger measure.

**v1.2.14 / Theorem 3.9**: new finite pole-spectrum theorem candidate;
full manuscript claim still partial pending shifted analytic gram realization.
