import Paper.Conjecture_4_11
import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7

/-!
# Theorem 5.1 — Two-variable Beukers measure for zeta(7)
PDF: the exact numbered assertion from the supplied 52-page manuscript.
STATUS: PARTIAL
REMAINING / EVIDENCE: Finite rational dual coefficient identities exist; double-integral identity is not proved.

Only the explicit `theorem` declarations below constitute kernel proof objects.
An imported `#check` is a pointer to a previously proved lemma or conditional
interface; it does NOT claim this entire printed result is formalized.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology

/-- Exact finite diagonal coefficient in the rational dual pencil (not
itself an integral identity). -/
theorem rational_diagonal_moment (r : ℕ) :
    ManuscriptChain.Real.dualConstant 7 r r =
      -ManuscriptChain.Real.harmonic 7 r := by
  simp [ManuscriptChain.Real.dualConstant]

/-- Exact finite off-diagonal coefficient in the rational dual pencil. -/
theorem rational_off_diagonal_moment (r t : ℕ) (hrt : r ≠ t) :
    ManuscriptChain.Real.dualConstant 7 r t =
      (ManuscriptChain.Real.harmonic 6 r - ManuscriptChain.Real.harmonic 6 t) /
        ((6 : ℚ) * ((r : ℚ) - (t : ℚ))) := by
  simp [ManuscriptChain.Real.dualConstant, hrt]

end PaperChronology
