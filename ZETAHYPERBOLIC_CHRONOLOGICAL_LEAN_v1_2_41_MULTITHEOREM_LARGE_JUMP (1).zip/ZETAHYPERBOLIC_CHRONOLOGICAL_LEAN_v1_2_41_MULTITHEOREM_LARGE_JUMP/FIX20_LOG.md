# v1.2.30 Theorem 5.2 actual determinant fix

Compiler checkpoint: 129/131 passed; failure in ProofAdvances/Theorem_5_2_ActualRoots.lean (lines 71, 72, 78, 105).

- Replaced the ambiguous rational `Polynomial.eval 0` -> real coercion with `Real.evalQ` at `(0 : ℝ)`.
- Proved the **polynomial-matrix** bridge first, following the already-compiled Section 3.1 `manuscriptPencil_polynomialMatrix` pattern.
- Used `RingHom.map_det` on this explicit polynomial matrix instead of brittle scalar determinant rewrites.
- Kept the full degree and complex-root statements unchanged; their proofs reuse the passed `Theorem_5_2_RealRoots` factorization.
- Prior passed source files are byte-identical; only the failing Lean source changed; the main chain is dependency-invalidated.
- No Lean compilation performed locally. User's Lean 4.33.0 compiler is the sole verifier.

Source SHA-256: `E8B53B81E181F2ED6A2655C062FF9550A8F7286AE5780E8E3738996A3EA05025`.
Manifest SHA-256: `06B43C4F2CBA76D7D24D8CC863E5B4E7DC3A1C6B003487FD137DE52A84658570`.
