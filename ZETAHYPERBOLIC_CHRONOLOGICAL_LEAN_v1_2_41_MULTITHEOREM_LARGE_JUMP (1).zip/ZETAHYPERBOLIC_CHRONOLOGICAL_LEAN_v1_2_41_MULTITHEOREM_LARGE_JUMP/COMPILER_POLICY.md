# Frozen verified module policy

- A module may be labeled `FROZEN_PASS` only if an `.olean` created by a successful prior Lean invocation is present, the source matches its pre-recorded SHA256, the module's full local import-closure key is unchanged, the toolchain/dependency environment matches, and the cache `.olean` content SHA256 matches the pass marker.
- A failed module never acquires a pass marker.
- Changed imports invalidate importing descendants (even if their source text is unchanged).
- Reuse is independent across source-package versions; changing only the PDF ledger or README does not invalidate Lean proofs.
- The legacy cache is eligible only for modules with exactly identical source and transitive local imports; v1.2.2 compatibility is checked against its environment/snapshot/positive pass marker.
- Cache reuse is provenance verification, NOT re-running Lean.
- Missing or unverifiable prior success triggers compilation on the user's machine rather than an unjustified SKIP.
- No local Lean compilation performed while preparing this ZIP.

## v1.2.5 partial-PASS seeding

The optional prior-download seed folder now defaults to v1.2.4 (falling back to v1.2.3).
The runner accepts module reuse only with matching runtime fingerprint, matching
source bytes, identical closure manifest record, and previously logged CHECK_PASS.
Otherwise it compiles the module on the user's machine.

## Corollary 3.5 incremental repair (v1.2.6)

`Paper/Corollary_3_5.lean` is the only Lean file changed from v1.2.5.
Only its import descendants receive new cache-closure hashes; the other
PASS `.olean` modules are eligible for reuse without executing the compiler.
No local compiler was run for this release.

### v1.2.7 policy

The 114 old targets retain their exact source SHA256 and (except the changed
final import spine) their previous cache closure keys. The new targets are
three proof-advance modules for Section 3. An old PASS can be skipped only
when its source SHA, dependency closure key and Lean/Mathlib identity match.
The runner does not assume a PASS from the presence of a `.lean` file.

## v1.2.8 cache preservation

The 116 previously passed module manifest entries are byte-for-byte preserved. Only the final chronological wrapper source hash and CAS key changed. Cached `.olean` artifacts are reused on a source+transitive-dependency+environment match, never solely based on a PASS claim.

## v1.2.9 freeze-on-PASS
117 existing PASS modules are cache-eligible (unchanged source and import closure).
Three new proof sources are compiled fresh; updated paper entrypoint is fresh.
No new module gets a manufactured PASS certificate. Exactly one run.cmd.


## v1.2.10 PASS-preservation

No previously passed source was edited. Only the failed actual-CD module was
edited. The chronologic main chain was left unchanged but has an invalidated
import closure; both are marked NO in the manifest and must compile anew.

## v1.2.12 incremental extension

120/120 user-verified v1.2.11 baseline; one new Lean proof module and one
invalidated chronological wrapper; 119 unchanged source modules. Cache
identities for the 119 untouched modules remain literally unchanged.

## v1.2.13

Source-only correction; cache hashes for the 119 predecessors remain
byte-for-byte unchanged. The new candidate `Jacobi.lean` is NOT passed
until the user's compiler reports CHECK_PASS and no sorryAx.

## v1.2.14 frozen baseline

The 119 unchanged modules preceding the unverified Jacobi candidate retain
their exact source and dependency closure hashes. The new shifted-pole module
and changed chronological wrapper compile only when they lack a verified CAS
cache. No unverified module is declared PASS by this package.
