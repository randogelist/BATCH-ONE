# v0.3.14 — Finite Hankel determinant and Krein bridges

New independent Lean proof modules (source only, native compiler verification pending):

1. `S03_Theorem_3_3_MomentDeterminantBridge`: exact identification of the finite atomic Hankel moment matrix with its Vandermonde–diagonal–Vandermonde-transpose Gram matrix, and consequent determinant/positivity statements for arbitrary dimensions.
2. `S03_Corollary_3_6_FiniteAnnihilator`: uniform polynomial annihilator for finite support, exact moment functional on monomials, and vanishing of all polynomial multiples. Explains finite Hankel rank limitations without false strict-positivity claims.
3. `S05_Theorem_5_2_FiniteKreinSplit`: exact weighted finite signed-square splitting and cone inequalities in arbitrary dimensions.

No changes to previously frozen Lean source modules. No Lean build run locally. One run.cmd; persistent FASTCORE cache and no-network direct native Lean 4.33 retained. The PDF's infinite analytic and uniform arithmetic steps remain separate frontiers, with only the preexisting Witness as the conditional input to its downstream endpoint.
