# v0.3.20 — Theorem 3.3 strict atomic energy repair

Source: `PaperProofs/S03_Theorem_3_3_AtomicMomentEnergy.lean`.

Compiler log for v0.3.19: type mismatch at line 133 in
`Finset.single_le_sum` while proving strict positivity of the
weighted atomic Hankel quadratic form.

Replaced the comparison proof by `Finset.sum_pos'`, with:
- all summands nonnegative by `mul_nonneg`,
- a strictly positive detected summand by `mul_pos` and `sq_pos_of_ne_zero`,
- explicit membership `Finset.mem_univ a`.

Only that Lean proof source is changed; previously passed Lean files are
unchanged. The same source-level definitions and theorem statements remain.
Existing import-dependent source stamps are invalidated by the normal
FASTCORE source/dependency fingerprint mechanism.

Lean has NOT been compiled locally. The user's native Lean 4.33.0 compiler
is the sole verification authority.
