import Zetahyperbolic.Section2Checked
import Definition_2_1_Order_s_Rational_Moment_Functional

/-!
# Definition 2.1: Order-s rational moment functional
PDF pp. 3–4. Status: formalized.
Prior checked basis / current support: Zetahyperbolic.Section2Checked; Definition_2_1_Order_s_Rational_Moment_Functional.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S02_Definition_2_1

open ManuscriptChain
/-- The order-s rational functional's target value is the genuine Mathlib zeta at integer s>1. -/
theorem center_is_riemann_zeta_re (s : ℕ) (hs : 1 < s) :
    ManuscriptChain.Real.zeta s = (riemannZeta s).re :=
  ManuscriptChain.Real.zeta_eq_riemannZeta_re hs

/-- The coefficients underlying Definition 2.1 have an exact rational action. -/
theorem harmonic_step (s j : ℕ) :
    Zetahyperbolic.harmonicWeight s (j + 1) =
      Zetahyperbolic.harmonicWeight s j +
      (((j + 1 : ℕ) : ℚ) ^ s)⁻¹ :=
  Zetahyperbolic.harmonicWeight_succ s j

end PaperChronology.S02_Definition_2_1
