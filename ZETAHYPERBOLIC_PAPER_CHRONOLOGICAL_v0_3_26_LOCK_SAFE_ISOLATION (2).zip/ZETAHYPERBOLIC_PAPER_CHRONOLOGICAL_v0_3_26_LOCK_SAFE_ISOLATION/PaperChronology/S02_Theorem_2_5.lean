import PaperChronology.S02_Theorem_2_4
import PaperOrder.Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Theorem 2.5: Lagrange pole diagonalization
PDF pp. 6–7. Status: formalized.
Prior checked basis / current support: Zetahyperbolic.lagrange_pole_diagonalization.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S02_Theorem_2_5

open Polynomial
/-- The exact theorem, imported from the original functional's development. -/
theorem pole_diagonalization (p : Zetahyperbolic.HankelParams)
    (k : ℕ) (hk : 1 ≤ k) :
    Zetahyperbolic.M_deriv p k =
      Zetahyperbolic.V_pole p *
        Matrix.diagonal (Zetahyperbolic.gammaWeight p k) *
        (Zetahyperbolic.V_pole p).transpose ∧
    (∀ a b : Fin p.h, a ≠ b →
      (Zetahyperbolic.G_lagrange p k a b).natDegree = 0) ∧
    (∀ a : Fin p.h, ∃ c : ℚ,
      Zetahyperbolic.G_lagrange p k a a =
        C (Zetahyperbolic.gammaWeight p k a) *
        (X - C (Zetahyperbolic.harmonicWeight (2 * k + 1)
           (Zetahyperbolic.poleNat p a))) + C c) :=
  Zetahyperbolic.lagrange_pole_diagonalization p k hk

/-- The nonzero-determinant premise of the preceding theorem has now been
proved by the actual Lagrange-pole determinant factorization. This is the
first chronological point at which the hypothesis-free manuscript version
of Theorem 2.4 is available. -/
theorem canonical_basis_invariance_unconditional
    (p : ManuscriptChain.Real.Parameters)
    (A B : Matrix (Fin p.h) (Fin p.h) ℚ)
    (hA : Matrix.det A ≠ 0) (hB : Matrix.det B ≠ 0) :
    let n₀ := ManuscriptChain.BasisInvariance.primitiveNormalization
      (ManuscriptChain.Real.delta p)
      (ManuscriptChain.PoleDiagonalization.delta_ne_zero p)
    let nAB := ManuscriptChain.BasisInvariance.primitiveNormalization
      (Matrix.det (ManuscriptChain.BasisInvariance.changeBasisPencil
        (ManuscriptChain.Real.pencil p) A B))
      ((ManuscriptChain.BasisInvariance.det_changeBasisPencil_ne_zero_iff
        (ManuscriptChain.Real.pencil p) A B hA hB).mpr
        (ManuscriptChain.PoleDiagonalization.delta_ne_zero p))
    nAB.polynomial = n₀.polynomial ∨ nAB.polynomial = -n₀.polynomial :=
  ManuscriptChain.BasisInvariance.theorem_2_4_constructed_for_manuscript
    p A B hA hB

-- The corrected native finite-pencil endpoint, with an explicit proof term.
#check PaperOrder.Section2.theorem_2_5_lagrange_evaluation
#check PaperOrder.Section2.theorem_2_5_pencil_and_degree
#check PaperOrder.Section2.theorem_2_5_nonzero

end PaperChronology.S02_Theorem_2_5
