import PaperChronology.S06_Theorem_6_9
import Zetahyperbolic.Theorem_6_10_Finite_Determinant_Identity

/-!
# Theorem 6.10: Universal potential gap and quadratic derivative growth
PDF pp. 39–40. Status: partial.
Prior checked basis / current support: exact finite determinant coefficient identity proved; limits not proved.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S06_Theorem_6_10

open Polynomial
/-- Exact finite determinant coefficient identity, independent of asymptotic potential theory. -/
theorem finite_top_coefficient {n : ℕ}
    (A M : Matrix (Fin n) (Fin n) ℝ) (xi scale : ℝ) :
    (Zetahyperbolic.Theorem6_10.normalizedDet A M xi scale).coeff n =
      scale * M.det :=
  Zetahyperbolic.Theorem6_10.normalizedDet_coeff A M xi scale

-- Open: convergence of both logarithmic potentials and numerical energy inequality.

end PaperChronology.S06_Theorem_6_10
