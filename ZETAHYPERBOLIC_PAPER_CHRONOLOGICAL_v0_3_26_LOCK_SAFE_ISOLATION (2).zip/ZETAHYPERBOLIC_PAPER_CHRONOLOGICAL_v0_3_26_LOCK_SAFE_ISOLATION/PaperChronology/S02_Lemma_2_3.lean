import PaperChronology.S02_Lemma_2_2

/-!
# Lemma 2.3: Reflection and difference identities for tau_X
PDF pp. 5. Status: formalized.
Prior checked basis / current support: Zetahyperbolic.tau_reflection_monomial / tau_reflection_pole / tau_difference_pole.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S02_Lemma_2_3

open Polynomial
/-- Reflection on the polynomial basis. -/
theorem reflect_monomial (k d : ℕ) (hk : 1 ≤ k) :
    (-1 : ℚ) ^ d * (∑ i ∈ Finset.range (d + 1),
      (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i) =
      -Zetahyperbolic.tauMonomial k d :=
  Zetahyperbolic.tau_reflection_monomial k d hk

/-- Reflection on simple integer poles. -/
theorem reflect_pole (k : ℕ) (r : ℤ) :
    -Zetahyperbolic.tauPolePoly k (-1 - r) =
      -Zetahyperbolic.tauPolePoly k r :=
  Zetahyperbolic.tau_reflection_pole k r

/-- Difference on the poles r /= 0,1. -/
theorem difference_pole (k : ℕ) (r : ℤ) (hr0 : r ≠ 0) (hr1 : r ≠ 1) :
    Zetahyperbolic.tauPolePoly k (r - 1) -
      Zetahyperbolic.tauPolePoly k r =
        C (-((r : ℚ) ^ (2 * k + 1))⁻¹) :=
  Zetahyperbolic.tau_difference_pole k r hr0 hr1

end PaperChronology.S02_Lemma_2_3
