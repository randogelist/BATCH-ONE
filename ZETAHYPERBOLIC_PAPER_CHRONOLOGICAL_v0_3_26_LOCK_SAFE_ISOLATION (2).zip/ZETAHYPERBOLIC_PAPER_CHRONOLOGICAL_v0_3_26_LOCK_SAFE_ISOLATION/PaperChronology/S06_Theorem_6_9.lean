import PaperChronology.S06_Corollary_6_8
import Zetahyperbolic.Theorem_6_9_Triple_Pole_Hermite_Repair

/-!
# Theorem 6.9: Triple-pole and multi-weight Hankel determinants
PDF pp. 38–39. Status: partial.
Prior checked basis / current support: corrected finite triple-pole Hermite identities proved; full q-adic bound pending.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S06_Theorem_6_9

#check Zetahyperbolic.TriplePoleRepair.poleFunctional_eq_jetFunctional
#check Zetahyperbolic.TriplePoleRepair.localBlock_det
#check Zetahyperbolic.TriplePoleRepair.hermite_congruence
#check Zetahyperbolic.TriplePoleRepair.momentMatrix_det_ne_zero
-- Open: identify the repaired 3-jet coefficients of the original rational kernel.

end PaperChronology.S06_Theorem_6_9
