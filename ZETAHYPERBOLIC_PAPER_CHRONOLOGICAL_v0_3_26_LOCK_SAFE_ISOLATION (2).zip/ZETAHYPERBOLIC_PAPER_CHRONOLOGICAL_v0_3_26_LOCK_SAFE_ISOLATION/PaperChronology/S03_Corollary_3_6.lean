import PaperChronology.S03_Corollary_3_5

/-!
# Corollary 3.6: Stieltjes reciprocal-root power sums
PDF pp. 11. Status: correction-required.
Prior checked basis / current support: finite atom Hankel determinants vanish beyond support size.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S03_Corollary_3_6

/-- Finite-support moments disprove strict positivity of Hankel minors of all sizes. -/
theorem one_atom_rank_obstruction (u : ℝ) :
    (u ^ 0) * (u ^ 2) - (u ^ 1) * (u ^ 1) = 0 :=
  PaperSection3Corrections.one_atom_hankel_minor_zero u

-- Open: corrected finite-support rank, power sums, and limit bounds.

end PaperChronology.S03_Corollary_3_6
