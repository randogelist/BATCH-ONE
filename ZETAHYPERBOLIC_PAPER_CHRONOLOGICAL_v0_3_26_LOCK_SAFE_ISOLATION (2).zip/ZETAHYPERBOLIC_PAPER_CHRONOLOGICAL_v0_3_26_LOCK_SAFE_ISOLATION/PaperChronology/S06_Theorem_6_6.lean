import PaperChronology.S06_Theorem_6_5

/-!
# Theorem 6.6: Generalized multi-weight positive-definite pencil
PDF pp. 36–37. Status: open.
Prior checked basis / current support: pointwise positive mixed kernel not proved.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S06_Theorem_6_6

-- Open: simultaneous multi-weight, one-variable positive-definite pencil.

end PaperChronology.S06_Theorem_6_6
