import PaperChronology.S03_Theorem_3_9
import MAIN_CHAIN

/-!
# Theorem 4.1: Spectral irrationality measure criterion
PDF pp. 14–15. Status: partial.
Prior checked basis / current support: generic integer polynomial transfer proved; matching exponential rates are separate.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S04_Theorem_4_1

open ManuscriptChain
/-- The exact generic Diophantine-transfer interface, proved independently of zeta(5). -/
theorem integer_transfer
    {Q : ℕ → Polynomial ℤ} {xi : ℝ} {radius budget : ℕ → ℝ}
    {start exponent threshold : ℕ}
    (comparison : RealTransfer.LocalComparison Q xi radius start)
    (decay : RealTransfer.Decay Q xi budget start)
    (index : RealTransfer.IndexBudget Q radius budget start exponent threshold) :
    RealTransfer.RationalMeasure xi exponent threshold ∧ Irrational xi :=
  ManuscriptChain.GENERAL_DIOPHANTINE_TRANSFER comparison decay index

-- Open: theorem 4.1's uniform c-selection derived solely from its stated rate bounds.

end PaperChronology.S04_Theorem_4_1
