import PaperChronology.S03_Proposition_3_2
import MAIN_CHAIN_NO_OPEN_INPUTS
import Mathlib.Tactic

/-!
# Theorem 3.3: total positivity, leading coefficient sign, universal signature
PDF pp. 8-9. Status: PARTIAL.

The true Hankel moment positivity and pole weight nonvanishing are already
proved in the imported source. This module advances part (2) with the exact
integer exponent congruence for K = 30n, N = 3n, h = 27n, 2m = 6.
The positive mixed minors, full leading coefficient sign transfer, and
Sylvester inertia/counting theorem remain open. No premise is introduced
as an axiom or silently imported as a witness.
-/

noncomputable section
namespace PaperChronology.S03_Theorem_3_3

/-- Twice the sign exponent of the leading coefficient, before reduction
modulo 2: h(h-1) + 2*(2m-1)*N*h for h=27n, N=3n, 2m=6. -/
theorem leading_sign_exponent_twice (n : ℤ) :
    (27 * n) * (27 * n - 1) + 2 * 5 * (3 * n) * (27 * n) =
      1539 * n ^ 2 - 27 * n := by
  ring

/-- Exact decomposition of the doubled sign exponent in terms of the
paper's expected exponent n(n-1)/2. -/
theorem doubled_exponent_decomposition (n : ℤ) :
    1539 * n ^ 2 - 27 * n =
      (n ^ 2 - n) + 2 * (756 * n ^ 2 + 13 * n * (n - 1)) := by
  ring

/-- Product of consecutive integers is even, including negative n.
The witnesses avoid rewriting inside integer-division subterms. -/
theorem consecutive_integer_product_even (n : ℤ) :
    ∃ t : ℤ, n * (n - 1) = 2 * t := by
  have hrange : n % 2 = 0 ∨ n % 2 = 1 := by omega
  rcases hrange with h0 | h1
  · refine ⟨(n / 2) * (n - 1), ?_⟩
    have hn : n = 2 * (n / 2) := by omega
    calc
      n * (n - 1) = (2 * (n / 2)) * (n - 1) :=
        congrArg (fun x : ℤ => x * (n - 1)) hn
      _ = 2 * ((n / 2) * (n - 1)) := by ring
  · refine ⟨n * ((n - 1) / 2), ?_⟩
    have hn : n - 1 = 2 * ((n - 1) / 2) := by omega
    calc
      n * (n - 1) = n * (2 * ((n - 1) / 2)) :=
        congrArg (fun x : ℤ => n * x) hn
      _ = 2 * (n * ((n - 1) / 2)) := by ring

/-- The exponent parity needed for the weight-five leading sign.
This does not assert the determinant sign without the pole-weight sign lemma. -/
theorem leading_sign_parity (n : ℤ) :
    ((1539 * n ^ 2 - 27 * n) / 2) % 2 =
      ((n ^ 2 - n) / 2) % 2 := by
  obtain ⟨t, ht⟩ := consecutive_integer_product_even n
  have ht' : n ^ 2 - n = 2 * t := by
    calc
      n ^ 2 - n = n * (n - 1) := by ring
      _ = 2 * t := ht
  have heq :
      1539 * n ^ 2 - 27 * n =
        (n ^ 2 - n) + 4 * (378 * n ^ 2 + 13 * t) := by
    calc
      1539 * n ^ 2 - 27 * n =
          (n ^ 2 - n) + 4 * (378 * n ^ 2 + 13 * t) +
            26 * (n ^ 2 - n - 2 * t) := by ring
      _ = (n ^ 2 - n) + 4 * (378 * n ^ 2 + 13 * t) := by
        simp only [ht', sub_self, mul_zero, add_zero]
  rw [heq]
  omega

#print axioms leading_sign_exponent_twice
#print axioms doubled_exponent_decomposition
#print axioms consecutive_integer_product_even
#print axioms leading_sign_parity

-- Previously established source dependencies (NOT claimed as full proof):
#check ManuscriptChain.GRAM_POSITIVE
#check Zetahyperbolic.gammaWeight_ne_zero

end PaperChronology.S03_Theorem_3_3
