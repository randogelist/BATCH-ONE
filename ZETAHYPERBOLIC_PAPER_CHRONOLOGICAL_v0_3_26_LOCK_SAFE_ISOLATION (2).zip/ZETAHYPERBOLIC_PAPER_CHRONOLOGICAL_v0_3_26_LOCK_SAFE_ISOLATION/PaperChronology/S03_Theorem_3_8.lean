import PaperChronology.S03_Theorem_3_7
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Theorem 3.8: Christoffel-Darboux pole representation / Jacobi derivative
PDF pp. 12–13. Status: partial.
Prior checked basis / current support: Vandermonde factorization proved; orthogonal kernel theorem pending.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S03_Theorem_3_8

#check ManuscriptChain.PoleDiagonalization.pole_slope_diagonal
#check ManuscriptChain.PoleDiagonalization.poleDiagonalPencil_eq
-- Open: the Christoffel-Darboux kernel spectrum and Jacobi derivative law.

end PaperChronology.S03_Theorem_3_8
