import PaperChronology.S04_Proposition_4_2
import PaperProofs.S04_Proposition_4_3_PadicDisk

/-!
# Proposition 4.3: p-adic zero-free disk (actual Cp, not ZMod)

The full paper statement is now supported by the unconditional universal
integer-polynomial Lipschitz theorem, with p-adic-integer center and arbitrary
p-adic complex test point. No extra analytic hypothesis is introduced.
-/

noncomputable section
namespace PaperChronology.S04_Proposition_4_3

variable (p : ℕ) [Fact (Nat.Prime p)]

/-- The complete ultrametric local-constancy and root-exclusion conclusion. -/
theorem paper_padic_zero_free_disk
    (Q : Polynomial ℤ) (xi alpha : ℂ_[p])
    (hxi : ‖xi‖ ≤ 1)
    (hQ : PaperProofs.S04_Proposition_4_3_PadicDisk.evalIntegral p Q xi ≠ 0)
    (halpha : ‖alpha - xi‖ <
      ‖PaperProofs.S04_Proposition_4_3_PadicDisk.evalIntegral p Q xi‖) :
    ‖PaperProofs.S04_Proposition_4_3_PadicDisk.evalIntegral p Q alpha‖ =
      ‖PaperProofs.S04_Proposition_4_3_PadicDisk.evalIntegral p Q xi‖ ∧
    PaperProofs.S04_Proposition_4_3_PadicDisk.evalIntegral p Q alpha ≠ 0 :=
  PaperProofs.S04_Proposition_4_3_PadicDisk.ultrametric_zero_free_disk
    p Q xi alpha hxi hQ halpha

end PaperChronology.S04_Proposition_4_3

#print axioms PaperChronology.S04_Proposition_4_3.paper_padic_zero_free_disk
