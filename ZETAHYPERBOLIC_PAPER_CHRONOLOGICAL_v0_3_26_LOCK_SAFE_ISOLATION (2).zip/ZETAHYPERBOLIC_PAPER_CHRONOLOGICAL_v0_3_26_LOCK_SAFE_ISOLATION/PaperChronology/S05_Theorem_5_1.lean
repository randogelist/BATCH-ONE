import PaperChronology.S04_Conjecture_4_11
import PAPER_FINITE_MOMENTS

/-!
# Theorem 5.1: Two-variable Beukers measure for zeta(7)
PDF pp. 22–23. Status: partial.
Prior checked basis / current support: finite rational diagonal/offdiagonal moments constructed; analytic integral pending.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S05_Theorem_5_1

/-- Finite diagonal rational constant of the genuine two-variable dual pencil. -/
theorem diagonal (r : ℕ) :
    ManuscriptChain.Real.dualConstant 7 r r =
      -ManuscriptChain.Real.harmonic 7 r :=
  PaperFiniteMoments.dual_diagonal r

/-- Rational off-diagonal divided difference, independent of the zeta parameter. -/
theorem off_diagonal (r t : ℕ) (hrt : r ≠ t) :
    ManuscriptChain.Real.dualConstant 7 r t =
      (ManuscriptChain.Real.harmonic 6 r - ManuscriptChain.Real.harmonic 6 t) /
        (6 * ((r : ℚ) - (t : ℚ))) :=
  PaperFiniteMoments.dual_offdiagonal r t hrt

-- Open: identify these moments with the stated strictly positive double integral.

end PaperChronology.S05_Theorem_5_1
