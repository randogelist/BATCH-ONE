import PaperChronology.S02_Definition_2_1

/-!
# Lemma 2.2: Pullback identity
PDF pp. 4. Status: formalized.
Prior checked basis / current support: Zetahyperbolic.pullback_identity_monomial / pullback_identity_pole.
Status `partial` or `open` does not claim to prove the paper item.
No open mathematical statement is promoted to an axiom.
-/

noncomputable section
namespace PaperChronology.S02_Lemma_2_2

open Polynomial
/-- Pullback on all monomials; see Section2Checked. -/
theorem monomial (k e : ℕ) (hk : 1 ≤ k) :
    Zetahyperbolic.muMonomial k e =
      (-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1) :=
  Zetahyperbolic.pullback_identity_monomial k e hk

/-- Pullback on the simple poles; linearity and partial fractions cover the stated domain. -/
theorem pole (k j : ℕ) (hk : 1 ≤ k) (hj : 1 ≤ j) :
    Zetahyperbolic.muPolePoly k j =
      C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        C ((j : ℚ) ^ (2 * k) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
           Zetahyperbolic.tauPolePoly k (-(j : ℤ))) :=
  Zetahyperbolic.pullback_identity_pole k j hk hj

end PaperChronology.S02_Lemma_2_2
