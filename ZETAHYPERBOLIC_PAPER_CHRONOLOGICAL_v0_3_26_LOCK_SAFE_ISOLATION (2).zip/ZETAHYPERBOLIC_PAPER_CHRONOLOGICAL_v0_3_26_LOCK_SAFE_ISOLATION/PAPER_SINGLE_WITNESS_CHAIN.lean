import PAPER_WITNESS_GRAM
import ZETA5_APPLICATION

/-!
# Paper main implication: exactly one *explicit* witness predicate

The witness contains the eventual primitive-multiplier, determinant and
spectral-growth estimates from the paper. It contains no Gram assumption:
Gram positivity and nonvanishing are theorems imported from the unconditional
spectral chain. Existence of the witness is NOT asserted.

This endpoint is not a proof of every later manuscript theorem.
-/

noncomputable section
namespace PaperSingleWitness

open ManuscriptChain

/-- Sole conditional input for the paper's quantitative Section 4 endpoint.
    Three joint *eventual* estimates, uniform in the actual family K=30n. -/
def Witness : Prop :=
  ∃ start : ℕ,
    MainChain.MultiplierUpper (MainChain.primitiveMainNormalization start) ∧
    MainChain.ArchimedeanUpper (start + 1) ∧
    (∀ n (hn : start + 1 ≤ n)
        (i : Fin ((Real.mainParameters n).h)),
      |(MainChain.mainRootFactorization (start + 1)
          (main_gram_positive start) n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * MainChain.mainK n))

/-- The witness implies decay for the internally constructed primitive polynomials. -/
theorem NORMALIZED_QUADRATIC_DECAY (witness : Witness) :
    ∃ start : ℕ,
      RealTransfer.Decay
        (MainChain.primitiveMainNormalization start).Q
        (Real.zeta 5) MainChain.decayBudget (start + 1) := by
  obtain ⟨start, multiplier, archimedean, _spectral⟩ := witness
  refine ⟨start, ?_⟩
  exact MainChain.main_decay
    (MainChain.primitiveMainNormalization start)
    (MainChain.baseValuePositive_of_gram
      (start + 1) (main_gram_positive start))
    multiplier archimedean

/-- All odd weights: original paper's universal pencil, no quantitative input. -/
theorem THEOREM_3_1_ALL_ODD_WEIGHTS :
    ∀ p : Real.Parameters, Real.Admissible p → General.GeneralStatement p := by
  intro p hp
  exact ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- Irrationality conditional precisely on `Witness`. -/
theorem THEOREM_4_4_IRRATIONALITY (witness : Witness) :
    Irrational (riemannZeta 5).re := by
  obtain ⟨start, multiplier, archimedean, spectral⟩ := witness
  exact ManuscriptChain.ZETA5_APPLICATION_PRIMITIVE_FROM_GRAM
    start (main_gram_positive start) multiplier archimedean spectral

/-- The printed exponent 25687 conditional precisely on `Witness`. -/
theorem THEOREM_4_4_MEASURE (witness : Witness) :
    ∃ b₀ : ℕ,
      ∀ (a : ℤ) (b : ℕ), 0 < b → b₀ ≤ b →
        1 / (b : ℝ) ^ 25687 <
          |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| := by
  obtain ⟨start, multiplier, archimedean, spectral⟩ := witness
  refine ⟨MainChain.indexDenominatorThreshold (start + 1), ?_⟩
  exact ManuscriptChain.ZETA5_APPLICATION_MEASURE_PRIMITIVE_FROM_GRAM
    start (main_gram_positive start) multiplier archimedean spectral

/-- Chronological assembly: unconditional §§2–3 plus conditional §4.4. -/
theorem PAPER_MAIN_CHAIN (witness : Witness) :
    (∀ p : Real.Parameters, Real.Admissible p → General.GeneralStatement p) ∧
    Irrational (riemannZeta 5).re ∧
    (∃ b₀ : ℕ,
      ∀ (a : ℤ) (b : ℕ), 0 < b → b₀ ≤ b →
        1 / (b : ℝ) ^ 25687 <
          |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)|) := by
  exact ⟨THEOREM_3_1_ALL_ODD_WEIGHTS,
    THEOREM_4_4_IRRATIONALITY witness,
    THEOREM_4_4_MEASURE witness⟩

end PaperSingleWitness

#print axioms PaperSingleWitness.NORMALIZED_QUADRATIC_DECAY
#print axioms PaperSingleWitness.THEOREM_3_1_ALL_ODD_WEIGHTS
#print axioms PaperSingleWitness.THEOREM_4_4_IRRATIONALITY
#print axioms PaperSingleWitness.THEOREM_4_4_MEASURE
#print axioms PaperSingleWitness.PAPER_MAIN_CHAIN
#print PaperSingleWitness.Witness
#print PaperSingleWitness.PAPER_MAIN_CHAIN
