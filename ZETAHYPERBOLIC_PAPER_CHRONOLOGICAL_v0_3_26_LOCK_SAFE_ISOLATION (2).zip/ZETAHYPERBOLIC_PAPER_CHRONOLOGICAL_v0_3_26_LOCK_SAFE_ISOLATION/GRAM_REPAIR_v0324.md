# Theorem 3.3 arbitrary-order Gram determinant repair

- Added a theorem module with the exact four `PaperChronology.Theorem3_3.ArbitraryGram` names.
- Generic determinant and zero-weight statements explicitly assume `[CommRing R]`.
- The positive determinant statement uses `ℝ`, as ordering does not follow from a generic ring.
- Each proof is a direct specialization of the **existing** `Zetahyperbolic.CoreLinearAlgebra` unconditional lemmas.
- No previously passed Lean sources were edited; only the single new module is inserted into the chronological build order.
- The error log cited a file not present in the latest available ZIP. This provides a standalone, theorem-name-compatible bridge; it does not silently patch a different unprovided source tree.
- **No local Lean compilation was performed.** Native Windows Lean 4.33.0 remains authoritative.
