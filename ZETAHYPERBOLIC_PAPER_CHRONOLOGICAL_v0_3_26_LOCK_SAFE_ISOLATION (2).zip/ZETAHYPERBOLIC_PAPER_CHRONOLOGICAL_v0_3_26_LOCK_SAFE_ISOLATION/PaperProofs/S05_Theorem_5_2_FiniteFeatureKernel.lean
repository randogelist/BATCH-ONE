import Mathlib.Tactic

/-!
# Theorem 5.2: arbitrary finite feature kernels and signed Gram energies

The two-variable Beukers/Krein matrix admits finite signed feature
factorizations. Here the algebraic Hilbert-space step is proved for
ARBITRARY numbers of modes, atoms and vector coefficients, without an
assumption of a positive kernel. This theorem is independent of analytic
integrability, polynomial density or infinite-dimensional cone existence.

Each positive feature family has a nonnegative quadratic form; subtracting
two such families gives an exact signed kernel-energy identity.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel

variable {n kp kn : ℕ}

/-- A general finite feature kernel with possibly signed feature weights. -/
def featureKernel (w : Fin kp → ℝ) (f : Fin kp → Fin n → ℝ)
    (i j : Fin n) : ℝ :=
  ∑ r : Fin kp, w r * (f r i * f r j)

/-- Symmetry holds even if the feature weights are signed. -/
theorem featureKernel_symmetric
    (w : Fin kp → ℝ) (f : Fin kp → Fin n → ℝ) (i j : Fin n) :
    featureKernel w f i j = featureKernel w f j i := by
  unfold featureKernel
  apply Finset.sum_congr rfl
  intro r _
  ring

/-- The elementary square-of-a-sum formula in every finite dimension. -/
private theorem pair_sum_square (u : Fin n → ℝ) :
    (∑ i : Fin n, ∑ j : Fin n, u i * u j) =
      (∑ i : Fin n, u i) ^ 2 := by
  classical
  calc
    (∑ i : Fin n, ∑ j : Fin n, u i * u j) =
        ∑ i : Fin n, u i * (∑ j : Fin n, u j) := by
          simp only [Finset.mul_sum]
    _ = (∑ i : Fin n, u i) * (∑ j : Fin n, u j) := by
          rw [Finset.sum_mul]
    _ = (∑ i : Fin n, u i) ^ 2 := by ring

/-- Exact feature-map quadratic form = weighted sum of feature squares. -/
theorem featureKernel_energy
    (w : Fin kp → ℝ) (f : Fin kp → Fin n → ℝ)
    (v : Fin n → ℝ) :
    (∑ i : Fin n, ∑ j : Fin n,
        v i * featureKernel w f i j * v j) =
      ∑ r : Fin kp, w r * (∑ i : Fin n, v i * f r i) ^ 2 := by
  classical
  unfold featureKernel
  calc
    (∑ i : Fin n, ∑ j : Fin n,
        v i * (∑ r : Fin kp, w r * (f r i * f r j)) * v j) =
      ∑ i : Fin n, ∑ j : Fin n, ∑ r : Fin kp,
        w r * ((v i * f r i) * (v j * f r j)) := by
          apply Finset.sum_congr rfl
          intro i _
          apply Finset.sum_congr rfl
          intro j _
          rw [Finset.mul_sum, Finset.sum_mul]
          apply Finset.sum_congr rfl
          intro r _
          ring
    _ = ∑ r : Fin kp, ∑ i : Fin n, ∑ j : Fin n,
        w r * ((v i * f r i) * (v j * f r j)) := by
          calc
            (∑ i : Fin n, ∑ j : Fin n, ∑ r : Fin kp,
                w r * ((v i * f r i) * (v j * f r j))) =
              ∑ i : Fin n, ∑ r : Fin kp, ∑ j : Fin n,
                w r * ((v i * f r i) * (v j * f r j)) := by
                  apply Finset.sum_congr rfl
                  intro i _
                  exact Finset.sum_comm
            _ = ∑ r : Fin kp, ∑ i : Fin n, ∑ j : Fin n,
                w r * ((v i * f r i) * (v j * f r j)) := by
                  exact Finset.sum_comm
    _ = ∑ r : Fin kp,
        w r * (∑ i : Fin n, v i * f r i) ^ 2 := by
          apply Finset.sum_congr rfl
          intro r _
          calc
            (∑ i : Fin n, ∑ j : Fin n,
                w r * ((v i * f r i) * (v j * f r j))) =
              w r * (∑ i : Fin n, ∑ j : Fin n,
                (v i * f r i) * (v j * f r j)) := by
                  simp only [Finset.mul_sum]
            _ = w r * (∑ i : Fin n, v i * f r i) ^ 2 := by
                  rw [pair_sum_square]

/-- The exact abstract finite positive-cone certificate. -/
theorem featureKernel_energy_nonnegative
    (w : Fin kp → ℝ) (f : Fin kp → Fin n → ℝ)
    (hw : ∀ r, 0 ≤ w r) (v : Fin n → ℝ) :
    0 ≤ ∑ i : Fin n, ∑ j : Fin n,
      v i * featureKernel w f i j * v j := by
  rw [featureKernel_energy]
  exact Finset.sum_nonneg (fun r _ =>
    mul_nonneg (hw r) (sq_nonneg _))

/-- Difference of two finite feature kernels = difference of their
nonnegative (for nonnegative weights) feature energies. -/
theorem signed_featureKernel_energy
    (wp : Fin kp → ℝ) (fp : Fin kp → Fin n → ℝ)
    (wn : Fin kn → ℝ) (fn : Fin kn → Fin n → ℝ)
    (v : Fin n → ℝ) :
    (∑ i : Fin n, ∑ j : Fin n,
      v i * (featureKernel wp fp i j - featureKernel wn fn i j) * v j) =
      (∑ r : Fin kp, wp r * (∑ i : Fin n, v i * fp r i) ^ 2) -
      (∑ r : Fin kn, wn r * (∑ i : Fin n, v i * fn r i) ^ 2) := by
  calc
    (∑ i : Fin n, ∑ j : Fin n,
      v i * (featureKernel wp fp i j - featureKernel wn fn i j) * v j) =
      (∑ i : Fin n, ∑ j : Fin n, v i * featureKernel wp fp i j * v j) -
      (∑ i : Fin n, ∑ j : Fin n, v i * featureKernel wn fn i j * v j) := by
        simp only [mul_sub, sub_mul, Finset.sum_sub_distrib]
    _ = (∑ r : Fin kp, wp r * (∑ i : Fin n, v i * fp r i) ^ 2) -
        (∑ r : Fin kn, wn r * (∑ i : Fin n, v i * fn r i) ^ 2) := by
          rw [featureKernel_energy, featureKernel_energy]

end PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel

#print axioms PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel.featureKernel_symmetric
#print axioms PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel.featureKernel_energy
#print axioms PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel.featureKernel_energy_nonnegative
#print axioms PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel.signed_featureKernel_energy
