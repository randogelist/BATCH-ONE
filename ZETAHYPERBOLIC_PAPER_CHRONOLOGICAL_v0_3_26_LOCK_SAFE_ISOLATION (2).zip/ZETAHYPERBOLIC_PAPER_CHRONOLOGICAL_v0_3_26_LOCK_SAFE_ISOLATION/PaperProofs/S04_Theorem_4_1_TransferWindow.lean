import Theorem_4_1_Spectral_Irrationality_Measure_Criterion
import Mathlib.Tactic

/-!
# Theorem 4.1: corrected quantitative index-selection window

The proof requires λ/ε < c < μ/ρ, hence λ/c < ε and ρ*c < μ.
The latter pair are the inequalities actually used in the quadratic
exponent and root-perturbation estimates. The printed proof contains
an ambiguous multiplication/division in this step; the Lean statements
resolve it algebraically. These are unconditional real inequalities,
not an asserted uniform estimate for the manuscript polynomials.
-/

namespace PaperProofs.S04_Theorem_4_1_TransferWindow

/-- An exponent μ strictly greater than λρ/ε gives a nonempty
admissible interval for the index-selection scaling c. -/
theorem scaling_window_exists
    (lambda rho eps mu : ℝ) (heps : 0 < eps) (hrho : 0 < rho)
    (hbound : lambda * rho / eps < mu) :
    ∃ c : ℝ, lambda / eps < c ∧ c < mu / rho := by
  have hwindow : lambda / eps < mu / rho := by
    apply (div_lt_div_iff₀ heps hrho).2
    exact (div_lt_iff₀ heps).1 hbound
  refine ⟨(lambda / eps + mu / rho) / 2, ?_, ?_⟩ <;> linarith

/-- Correct direction for the negative quadratic exponent:
K ≈ c log b requires λ/c < ε, not λ*c < ε. -/
theorem decay_direction
    (lambda eps c : ℝ) (hlambda : 0 ≤ lambda)
    (heps : 0 < eps) (hc : lambda / eps < c) :
    lambda / c < eps := by
  have hnonneg : 0 ≤ lambda / eps := div_nonneg hlambda heps.le
  have hcpos : 0 < c := lt_of_le_of_lt hnonneg hc
  have hnum : lambda < c * eps := (div_lt_iff₀ heps).1 hc
  apply (div_lt_iff₀ hcpos).2
  simpa only [mul_comm] using hnum

/-- Correct direction for the root-perturbation exponent. -/
theorem perturbation_direction
    (rho mu c : ℝ) (hrho : 0 < rho) (hc : c < mu / rho) :
    rho * c < mu := by
  have h := (lt_div_iff₀ hrho).1 hc
  simpa only [mul_comm] using h

/-- Exact positive margin: ε − λ/c = 1/5627500 at the paper's c=2251. -/
theorem printed_decay_margin_exact :
    (1 / 2500 : ℚ) - (9 / 10 : ℚ) / 2251 = 1 / 5627500 := by
  norm_num

/-- Exact positive perturbation margin μ − ρc = 839/1000. -/
theorem printed_perturbation_margin_exact :
    (25687 : ℚ) - (11411 / 1000 : ℚ) * 2251 = 839 / 1000 := by
  norm_num

/-- Both strict inequalities for the concrete manuscript parameters. -/
theorem printed_window_valid :
    ((9 / 10 : ℚ) / (1 / 2500) < 2251) ∧
    ((11411 / 1000 : ℚ) * 2251 < 25687) := by
  norm_num

end PaperProofs.S04_Theorem_4_1_TransferWindow

#print axioms PaperProofs.S04_Theorem_4_1_TransferWindow.scaling_window_exists
#print axioms PaperProofs.S04_Theorem_4_1_TransferWindow.decay_direction
#print axioms PaperProofs.S04_Theorem_4_1_TransferWindow.perturbation_direction
#print axioms PaperProofs.S04_Theorem_4_1_TransferWindow.printed_decay_margin_exact
#print axioms PaperProofs.S04_Theorem_4_1_TransferWindow.printed_perturbation_margin_exact
