import Mathlib.Tactic

/-!
# Theorem 6.1(3): exact nondegenerate 2 × 2 local pole block

The local leading principal matrix in the paper has entries
  [[0, 1/6], [1/6, -1]]
and determinant -1/36. The identity holds in every field where 6 is
invertible. This algebraic certificate isolates the noncancellation
mechanism; it is not itself an assertion about the full valuation bound.
-/

namespace PaperProofs.S06_Theorem_6_1_LocalObstruction

/-- Field-level exact local determinant identity. -/
theorem local_block_det (F : Type*) [Field F] :
    (0 : F) * (-1) - (1 / 6) * (1 / 6) = -(6 : F)⁻¹ ^ 2 := by
  simp only [zero_mul, zero_sub, one_div]
  ring

/-- The local block is invertible if the residue characteristic is
coprime to 6, irrespective of other global determinant factors. -/
theorem local_block_det_ne_zero
    (F : Type*) [Field F] (h6 : (6 : F) ≠ 0) :
    (0 : F) * (-1) - (1 / 6) * (1 / 6) ≠ 0 := by
  rw [local_block_det]
  have hInv : (6 : F)⁻¹ ≠ 0 := inv_ne_zero h6
  have hPow : ((6 : F)⁻¹) ^ 2 ≠ 0 := pow_ne_zero 2 hInv
  exact neg_ne_zero.mpr hPow

/-- Explicit rational value printed in the manuscript. -/
theorem local_block_det_rational :
    (0 : ℚ) * (-1) - (1 / 6) * (1 / 6) = -1 / 36 := by
  norm_num

end PaperProofs.S06_Theorem_6_1_LocalObstruction

#print axioms PaperProofs.S06_Theorem_6_1_LocalObstruction.local_block_det
#print axioms PaperProofs.S06_Theorem_6_1_LocalObstruction.local_block_det_ne_zero
#print axioms PaperProofs.S06_Theorem_6_1_LocalObstruction.local_block_det_rational
