import PaperChronology.S03_Theorem_3_4
import Mathlib.Tactic

/-!
# Theorem 3.4: 1 × 1 → 2 × 2 principal-minor spectral interlacing

This proves the entire 2 × 2 symmetric base case of Cauchy interlacing
by explicit eigenvalue formulas. The general h × h principal-minor theorem
still requires a separate arbitrary-dimensional argument.
-/

noncomputable section
namespace PaperProofs.S03_Theorem_3_4_TwoByTwoInterlacing

/-- Smaller real eigenvalue of [[a,b],[b,c]]. -/
def eigenLow (a b c : ℝ) : ℝ :=
  (a + c - Real.sqrt ((a - c) ^ 2 + 4 * b ^ 2)) / 2

/-- Larger real eigenvalue of [[a,b],[b,c]]. -/
def eigenHigh (a b c : ℝ) : ℝ :=
  (a + c + Real.sqrt ((a - c) ^ 2 + 4 * b ^ 2)) / 2

/-- Both expressions are roots of the characteristic polynomial. -/
theorem eigenvalues_are_roots (a b c : ℝ) :
    (eigenLow a b c - a) * (eigenLow a b c - c) - b ^ 2 = 0 ∧
    (eigenHigh a b c - a) * (eigenHigh a b c - c) - b ^ 2 = 0 := by
  have hrad : 0 ≤ (a - c) ^ 2 + 4 * b ^ 2 := by positivity
  have hsqrt :
      (Real.sqrt ((a - c) ^ 2 + 4 * b ^ 2)) ^ 2 =
        (a - c) ^ 2 + 4 * b ^ 2 := Real.sq_sqrt hrad
  constructor
  · unfold eigenLow
    nlinarith
  · unfold eigenHigh
    nlinarith

/-- Cauchy interlacing in dimension two: each diagonal entry of a real
symmetric 2 × 2 matrix lies between its two eigenvalues. -/
theorem principal_one_by_one_interlaces (a b c : ℝ) :
    eigenLow a b c ≤ a ∧ a ≤ eigenHigh a b c ∧
    eigenLow a b c ≤ c ∧ c ≤ eigenHigh a b c := by
  have hrad : 0 ≤ (a - c) ^ 2 + 4 * b ^ 2 := by positivity
  have hsqrt :
      (Real.sqrt ((a - c) ^ 2 + 4 * b ^ 2)) ^ 2 =
        (a - c) ^ 2 + 4 * b ^ 2 := Real.sq_sqrt hrad
  have hsqrt_nonneg :
      0 ≤ Real.sqrt ((a - c) ^ 2 + 4 * b ^ 2) := Real.sqrt_nonneg _
  unfold eigenLow eigenHigh
  constructor
  · nlinarith [sq_nonneg b]
  constructor
  · nlinarith [sq_nonneg b]
  constructor
  · nlinarith [sq_nonneg b]
  · nlinarith [sq_nonneg b]

/-- The 2 × 2 spectral interval is never inverted. -/
theorem eigenLow_le_eigenHigh (a b c : ℝ) :
    eigenLow a b c ≤ eigenHigh a b c := by
  unfold eigenLow eigenHigh
  have h := Real.sqrt_nonneg ((a - c) ^ 2 + 4 * b ^ 2)
  linarith

end PaperProofs.S03_Theorem_3_4_TwoByTwoInterlacing

#print axioms PaperProofs.S03_Theorem_3_4_TwoByTwoInterlacing.eigenvalues_are_roots
#print axioms PaperProofs.S03_Theorem_3_4_TwoByTwoInterlacing.principal_one_by_one_interlaces
#print axioms PaperProofs.S03_Theorem_3_4_TwoByTwoInterlacing.eigenLow_le_eigenHigh
