import PaperChronology.S03_Theorem_3_1
import PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram
import PaperProofs.S03_Theorem_3_3_RootSideTransfer
import PaperProofs.S03_Theorem_3_7_ThreeRootNewton
import PaperProofs.S04_Theorem_4_1_TransferWindow
import PaperProofs.S05_Theorem_5_2_DualDeterminant
import PaperProofs.S05_Theorem_5_4_EvenPole
import PaperProofs.S05_Theorem_5_6_OuterPieces
import PaperProofs.S06_Theorem_6_1_DividedDifference
import PaperProofs.S06_Theorem_6_1_LocalObstruction

/-!
# Genuine unconditional core of the chronological Zetahyperbolic manuscript

This structure gathers mathematical propositions with actual Lean proof terms,
not placeholders or `#check` declarations. Its construction does NOT use
`PaperSingleWitness.Witness`, and does not import the optional §4 endpoint.

The complete paper still has further theorems that are NOT included here.
-/

noncomputable section
namespace PaperProofs.FOUNDATIONAL_CERTIFICATE

/-- One explicit, checkable bundle of what the unconditional formal
base actually proves. `FullRowRank` remains a LOCAL condition on an arbitrary
coefficient matrix, as in the paper's Theorem 5.2, not a global extra axiom. -/
structure UnconditionalPaperCore : Prop where
  oddSpectral :
    ∀ p : ManuscriptChain.Real.Parameters,
      ManuscriptChain.Real.Admissible p →
      ManuscriptChain.General.GeneralStatement p
  finiteGramDet :
    ∀ (n : ℕ) (nodes weights : Fin n → ℝ),
      (PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram.finiteAtomGram
        nodes weights).det =
        ((PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram.atomVandermonde
          nodes).det) ^ 2 * ∏ i, weights i
  transferWindow :
    ∀ (lambda rho eps mu : ℝ),
      0 < eps → 0 < rho → lambda * rho / eps < mu →
        ∃ c : ℝ, lambda / eps < c ∧ c < mu / rho
  dualGramDet :
    ∀ (h K : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
      PaperProofs.S05_Theorem_5_2_DualEnergy.FullRowRank c →
      0 < (PaperProofs.S05_Theorem_5_2_DualEnergy.realCoefficientGram c).det
  evenPoleCancellation :
    ∀ (k j : ℕ), 1 ≤ j →
      Zetahyperbolic.tauPolePoly k (j : ℤ) -
        Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
        Polynomial.C (((j : ℚ) ^ (2*k+1))⁻¹)
  threeRootNewton :
    ∀ a b c : ℝ, 3 * (a*b + a*c + b*c) ≤ (a+b+c)^2
  localPoleBlock :
    (0 : ℚ) * (-1) - (1 / 6) * (1 / 6) = -1 / 36

/-- Compiler-checkable unconditional mathematical bundle with no `Witness`.
The root-location, rational area, and denominator bridges are additionally
available through imported or separately compiled proof modules. -/
theorem PAPER_UNCONDITIONAL_FOUNDATIONS : UnconditionalPaperCore := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro p hp
    exact ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp
  · intro n nodes weights
    exact PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram.finiteAtomGram_det nodes weights
  · intro lambda rho eps mu heps hrho hbound
    exact PaperProofs.S04_Theorem_4_1_TransferWindow.scaling_window_exists
      lambda rho eps mu heps hrho hbound
  · intro h K c hc
    exact PaperProofs.S05_Theorem_5_2_DualDeterminant.real_dual_slope_det_positive c hc
  · intro k j hj
    exact PaperProofs.S05_Theorem_5_4_EvenPole.tau_even_pole_pair k j hj
  · intro a b c
    exact PaperProofs.S03_Theorem_3_7_ThreeRootNewton.three_root_newton a b c
  · exact PaperProofs.S06_Theorem_6_1_LocalObstruction.local_block_det_rational

end PaperProofs.FOUNDATIONAL_CERTIFICATE

#print axioms PaperProofs.FOUNDATIONAL_CERTIFICATE.PAPER_UNCONDITIONAL_FOUNDATIONS
#print PaperProofs.FOUNDATIONAL_CERTIFICATE.UnconditionalPaperCore
