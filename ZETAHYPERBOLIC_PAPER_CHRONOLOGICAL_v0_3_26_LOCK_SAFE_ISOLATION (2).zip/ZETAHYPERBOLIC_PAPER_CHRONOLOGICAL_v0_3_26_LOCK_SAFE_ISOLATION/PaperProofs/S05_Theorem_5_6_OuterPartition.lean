import PaperProofs.S05_Theorem_5_6_OuterPieces
import Mathlib.Tactic

/-!
# Theorem 5.6: exact partition endpoints for the outer piecewise integrand

All endpoints in the paper's table are in strict increasing order.
Together with the existing arithmetic sums this certifies the finite
partition bookkeeping. The analytic identification of the floor/min/max
integrand with each piece remains an independent proof obligation.
-/

namespace PaperProofs.S05_Theorem_5_6_OuterPartition

/-- Adjacent endpoints of all 11 rational intervals are strictly ordered. -/
theorem eleven_intervals_ordered :
    ((1 / 3 : ℚ) < 43 / 120) ∧
    ((43 / 120 : ℚ) < 29 / 80) ∧
    ((29 / 80 : ℚ) < 37 / 100) ∧
    ((37 / 100 : ℚ) < 37 / 80) ∧
    ((37 / 80 : ℚ) < 29 / 60) ∧
    ((29 / 60 : ℚ) < 1 / 2) ∧
    ((1 / 2 : ℚ) < 43 / 80) ∧
    ((43 / 80 : ℚ) < 37 / 60) ∧
    ((37 / 60 : ℚ) < 37 / 40) ∧
    ((37 / 40 : ℚ) < 1) ∧
    ((1 : ℚ) < 37 / 20) := by
  norm_num

/-- The tabulated affine-piece arithmetic is exact. -/
theorem outer_piece_total_exact :
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (1/3) (43/120) (51/8) (-5) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (43/120) (29/80) (513/40) (-23) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (29/80) (37/100) (571/40) (-27) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (37/100) (37/80) (497/40) (-22) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (37/80) (29/60) (41/10) (-4) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (29/60) (1/2) (53/20) (-1) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (1/2) (43/80) (7/2) 1 +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (43/80) (37/60) (121/10) (-15) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (37/60) (37/40) (41/4) (-12) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      (37/40) 1 1 (-2) +
    PaperProofs.S05_Theorem_5_6_OuterPieces.affineArea
      1 (37/20) (37/20) (-1) =
      (453803 : ℚ) / 288000 := by
  exact PaperProofs.S05_Theorem_5_6_OuterPieces.all_eleven_areas

end PaperProofs.S05_Theorem_5_6_OuterPartition

#print axioms PaperProofs.S05_Theorem_5_6_OuterPartition.eleven_intervals_ordered
#print axioms PaperProofs.S05_Theorem_5_6_OuterPartition.outer_piece_total_exact
