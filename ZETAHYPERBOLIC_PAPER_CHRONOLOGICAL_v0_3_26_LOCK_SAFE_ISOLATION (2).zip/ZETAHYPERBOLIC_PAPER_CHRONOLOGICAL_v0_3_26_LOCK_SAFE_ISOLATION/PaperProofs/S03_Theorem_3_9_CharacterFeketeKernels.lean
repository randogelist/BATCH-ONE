import Mathlib.Tactic

/-!
# Theorems 3.9 and 6.4 — explicit character Fekete factors

The five real primitive Dirichlet character numerators used in the paper
are *exactly* the listed products. They are positive throughout z ∈ (0,1),
and division by the periodic-series denominator 1-z^q preserves strict
positivity. This proves the finite algebraic positivity of the kernels,
not the analytic identification of the L-value pencil.
-/

noncomputable section
namespace PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels

/-- Numerators of the real character geometric generating series. -/
def numerator_m3 (z : ℝ) := z - z ^ 2
def numerator_m4 (z : ℝ) := z - z ^ 3
def numerator_p5 (z : ℝ) := z - z ^ 2 - z ^ 3 + z ^ 4
def numerator_p8 (z : ℝ) := z - z ^ 3 - z ^ 5 + z ^ 7
def numerator_m8 (z : ℝ) := z + z ^ 3 - z ^ 5 - z ^ 7

/-- Fekete factorization for the real character modulo 3. -/
theorem numerator_m3_factor (z : ℝ) :
    numerator_m3 z = z * (1 - z) := by
  dsimp [numerator_m3]
  ring

/-- Fekete factorization for the real character modulo 4. -/
theorem numerator_m4_factor (z : ℝ) :
    numerator_m4 z = z * (1 - z ^ 2) := by
  dsimp [numerator_m4]
  ring

/-- Fekete factorization for the real character modulo 5. -/
theorem numerator_p5_factor (z : ℝ) :
    numerator_p5 z = z * (1 - z) ^ 2 * (1 + z) := by
  dsimp [numerator_p5]
  ring

/-- Fekete factorization for the real character of conductor 8, sign +. -/
theorem numerator_p8_factor (z : ℝ) :
    numerator_p8 z = z * (1 - z ^ 2) * (1 - z ^ 4) := by
  dsimp [numerator_p8]
  ring

/-- Fekete factorization for the real character of conductor 8, sign -. -/
theorem numerator_m8_factor (z : ℝ) :
    numerator_m8 z = z * (1 + z ^ 2) * (1 - z ^ 4) := by
  dsimp [numerator_m8]
  ring

/-- For 0 ≤ z < 1, every positive natural power of z is below 1. -/
theorem pow_lt_one_between
    (z : ℝ) (hz : 0 ≤ z) (h1 : z < 1)
    (n : ℕ) (hn : 0 < n) : z ^ n < 1 := by
  have hle : ∀ k : ℕ, z ^ k ≤ 1 := by
    intro k
    induction k with
    | zero => simp
    | succ k ih =>
      rw [pow_succ]
      calc
        z ^ k * z ≤ 1 * z := mul_le_mul_of_nonneg_right ih hz
        _ = z := one_mul z
        _ ≤ 1 := le_of_lt h1
  cases n with
  | zero => omega
  | succ k =>
    rw [pow_succ]
    calc
      z ^ k * z ≤ 1 * z := mul_le_mul_of_nonneg_right (hle k) hz
      _ = z := one_mul z
      _ < 1 := h1

/-- All five numerator polynomials are positive on the unit interval. -/
theorem numerator_m3_pos
    (z : ℝ) (hz : 0 < z) (h1 : z < 1) : 0 < numerator_m3 z := by
  rw [numerator_m3_factor]
  exact mul_pos hz (sub_pos.mpr h1)

theorem numerator_m4_pos
    (z : ℝ) (hz : 0 < z) (h1 : z < 1) : 0 < numerator_m4 z := by
  rw [numerator_m4_factor]
  exact mul_pos hz (sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 2 (by norm_num)))

theorem numerator_p5_pos
    (z : ℝ) (hz : 0 < z) (h1 : z < 1) : 0 < numerator_p5 z := by
  rw [numerator_p5_factor]
  have hm : 0 < 1 - z := sub_pos.mpr h1
  have hp : 0 < 1 + z := by linarith
  exact mul_pos (mul_pos hz (pow_pos hm 2)) hp

theorem numerator_p8_pos
    (z : ℝ) (hz : 0 < z) (h1 : z < 1) : 0 < numerator_p8 z := by
  rw [numerator_p8_factor]
  have h2 : 0 < 1 - z ^ 2 := sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 2 (by norm_num))
  have h4 : 0 < 1 - z ^ 4 := sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 4 (by norm_num))
  exact mul_pos (mul_pos hz h2) h4

theorem numerator_m8_pos
    (z : ℝ) (hz : 0 < z) (h1 : z < 1) : 0 < numerator_m8 z := by
  rw [numerator_m8_factor]
  have hp : 0 < 1 + z ^ 2 := by nlinarith [sq_nonneg z]
  have h4 : 0 < 1 - z ^ 4 := sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 4 (by norm_num))
  exact mul_pos (mul_pos hz hp) h4

/-- Exact periodic-series rational kernels. -/
def kernel_m3 (z : ℝ) := numerator_m3 z / (1 - z ^ 3)
def kernel_m4 (z : ℝ) := numerator_m4 z / (1 - z ^ 4)
def kernel_p5 (z : ℝ) := numerator_p5 z / (1 - z ^ 5)
def kernel_p8 (z : ℝ) := numerator_p8 z / (1 - z ^ 8)
def kernel_m8 (z : ℝ) := numerator_m8 z / (1 - z ^ 8)

/-- Strict positivity, uniformly for all five primitive real characters
of conductors 3, 4, 5, and 8. -/
theorem character_kernels_pos
    (z : ℝ) (hz : 0 < z) (h1 : z < 1) :
    0 < kernel_m3 z ∧ 0 < kernel_m4 z ∧ 0 < kernel_p5 z ∧
      0 < kernel_p8 z ∧ 0 < kernel_m8 z := by
  have hden3 : 0 < 1 - z ^ 3 := sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 3 (by norm_num))
  have hden4 : 0 < 1 - z ^ 4 := sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 4 (by norm_num))
  have hden5 : 0 < 1 - z ^ 5 := sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 5 (by norm_num))
  have hden8 : 0 < 1 - z ^ 8 := sub_pos.mpr
    (pow_lt_one_between z (le_of_lt hz) h1 8 (by norm_num))
  exact ⟨div_pos (numerator_m3_pos z hz h1) hden3,
    div_pos (numerator_m4_pos z hz h1) hden4,
    div_pos (numerator_p5_pos z hz h1) hden5,
    div_pos (numerator_p8_pos z hz h1) hden8,
    div_pos (numerator_m8_pos z hz h1) hden8⟩

end PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels

#print axioms PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels.numerator_m3_factor
#print axioms PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels.numerator_m4_factor
#print axioms PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels.numerator_p5_factor
#print axioms PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels.numerator_p8_factor
#print axioms PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels.numerator_m8_factor
#print axioms PaperProofs.S03_Theorem_3_9_CharacterFeketeKernels.character_kernels_pos
