import Zetahyperbolic.CoreLinearAlgebra
import Mathlib.Tactic

/-!
# Theorem 3.3: arbitrary-dimensional finite atomic Hankel determinants

Exact congruence determinant factorization for any number of atoms.
This provides the general finite-atomic Gram determinant bridge behind
strict positivity, rather than a dimension-specific expansion.
No integral measure or unproved analytic input is used.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram

variable {n : ℕ}

/-- The row `i` contains all i-th powers of the distinct interpolation nodes. -/
def atomVandermonde (nodes : Fin n → ℝ) :
    Matrix (Fin n) (Fin n) ℝ :=
  fun i j => nodes j ^ (i : ℕ)

/-- The finite atomic Gram/Hankel matrix, expressed by its exact
Vandermonde-diagonal-Vandermonde-transpose factorization. -/
def finiteAtomGram (nodes weights : Fin n → ℝ) :
    Matrix (Fin n) (Fin n) ℝ :=
  atomVandermonde nodes * Matrix.diagonal weights *
    (atomVandermonde nodes).transpose

/-- Exact finite determinant identity in every dimension. -/
theorem finiteAtomGram_det (nodes weights : Fin n → ℝ) :
    (finiteAtomGram nodes weights).det =
      ((atomVandermonde nodes).det) ^ 2 * ∏ i, weights i := by
  unfold finiteAtomGram
  exact Zetahyperbolic.det_conjugated_diagonal (atomVandermonde nodes) weights

/-- The Gram determinant is strictly positive under algebraically
checkable nondegeneracy of the Vandermonde and positive masses. -/
theorem finiteAtomGram_det_pos
    (nodes weights : Fin n → ℝ)
    (hV : (atomVandermonde nodes).det ≠ 0)
    (hw : ∀ i, 0 < weights i) :
    0 < (finiteAtomGram nodes weights).det := by
  rw [finiteAtomGram_det]
  have hV2 : 0 < ((atomVandermonde nodes).det) ^ 2 :=
    sq_pos_of_ne_zero hV
  have hwprod : 0 < ∏ i, weights i :=
    Finset.prod_pos (fun i _ => hw i)
  exact mul_pos hV2 hwprod

/-- Nonvanishing is independent of the signs of the atom masses as long
as none vanishes; positivity is a stronger additional assertion. -/
theorem finiteAtomGram_det_ne_zero
    (nodes weights : Fin n → ℝ)
    (hV : IsUnit (atomVandermonde nodes).det)
    (hw : ∀ i, weights i ≠ 0) :
    (finiteAtomGram nodes weights).det ≠ 0 := by
  unfold finiteAtomGram
  exact Zetahyperbolic.det_conjugated_diagonal_ne_zero
    (atomVandermonde nodes) weights hV hw

end PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram

#print axioms PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram.finiteAtomGram_det
#print axioms PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram.finiteAtomGram_det_pos
#print axioms PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram.finiteAtomGram_det_ne_zero
