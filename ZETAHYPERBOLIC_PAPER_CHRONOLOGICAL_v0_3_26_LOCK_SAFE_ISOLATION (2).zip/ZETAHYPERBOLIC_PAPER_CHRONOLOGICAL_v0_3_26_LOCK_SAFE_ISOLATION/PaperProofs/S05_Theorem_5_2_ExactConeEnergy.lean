import PaperProofs.S05_Theorem_5_2_ExactFifthKernel
import Mathlib.Tactic

/-!
# Theorem 5.2: finite Krein cone energies with the exact fifth-power features

Each truncation in the reconstructed Beukers kernel has three positive
and three negative square features, with coefficients 1,5,10.
For arbitrary finite evaluation nodes and coefficients these two
energies are separately nonnegative. This identifies the precise finite
pre-Hilbert signatures of the kernel in Theorem 5.2(2) without asserting
infinite-dimensional cone exhaustion or constructive rational bases.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S05_Theorem_5_2_ExactConeEnergy

open PaperProofs.S05_Theorem_5_2_ExactFifthKernel

variable {n : ℕ}

def positiveEnergy (M : ℕ) (nodes v : Fin n → ℝ) : ℝ :=
  ∑ m in Finset.range M,
    (∑ i : Fin n, v i * plus0 m (nodes i)) ^ 2 +
    5 * (∑ i : Fin n, v i * plus1 m (nodes i)) ^ 2 +
    10 * (∑ i : Fin n, v i * plus2 m (nodes i)) ^ 2

def negativeEnergy (M : ℕ) (nodes v : Fin n → ℝ) : ℝ :=
  ∑ m in Finset.range M,
    (∑ i : Fin n, v i * minus0 m (nodes i)) ^ 2 +
    5 * (∑ i : Fin n, v i * minus1 m (nodes i)) ^ 2 +
    10 * (∑ i : Fin n, v i * minus2 m (nodes i)) ^ 2

/-- Exact positive-square certificate in all finite sizes M and n. -/
theorem positiveEnergy_nonnegative
    (M : ℕ) (nodes v : Fin n → ℝ) :
    0 ≤ positiveEnergy M nodes v := by
  unfold positiveEnergy
  apply Finset.sum_nonneg
  intro m _
  have h0 : 0 ≤ (∑ i : Fin n, v i * plus0 m (nodes i)) ^ 2 := sq_nonneg _
  have h1 : 0 ≤ 5 * (∑ i : Fin n, v i * plus1 m (nodes i)) ^ 2 :=
    mul_nonneg (by norm_num) (sq_nonneg _)
  have h2 : 0 ≤ 10 * (∑ i : Fin n, v i * plus2 m (nodes i)) ^ 2 :=
    mul_nonneg (by norm_num) (sq_nonneg _)
  linarith

/-- Exact negative-square certificate in all finite sizes M and n. -/
theorem negativeEnergy_nonnegative
    (M : ℕ) (nodes v : Fin n → ℝ) :
    0 ≤ negativeEnergy M nodes v := by
  unfold negativeEnergy
  apply Finset.sum_nonneg
  intro m _
  have h0 : 0 ≤ (∑ i : Fin n, v i * minus0 m (nodes i)) ^ 2 := sq_nonneg _
  have h1 : 0 ≤ 5 * (∑ i : Fin n, v i * minus1 m (nodes i)) ^ 2 :=
    mul_nonneg (by norm_num) (sq_nonneg _)
  have h2 : 0 ≤ 10 * (∑ i : Fin n, v i * minus2 m (nodes i)) ^ 2 :=
    mul_nonneg (by norm_num) (sq_nonneg _)
  linarith

/-- The finite signed form never exceeds its positive cone energy. -/
theorem signedEnergy_le_positive
    (M : ℕ) (nodes v : Fin n → ℝ) :
    positiveEnergy M nodes v - negativeEnergy M nodes v ≤
      positiveEnergy M nodes v := by
  have h := negativeEnergy_nonnegative M nodes v
  linarith

/-- The finite signed form is bounded below by the negative cone energy. -/
theorem signedEnergy_ge_negative
    (M : ℕ) (nodes v : Fin n → ℝ) :
    -negativeEnergy M nodes v ≤
      positiveEnergy M nodes v - negativeEnergy M nodes v := by
  have h := positiveEnergy_nonnegative M nodes v
  linarith

end PaperProofs.S05_Theorem_5_2_ExactConeEnergy

#print axioms PaperProofs.S05_Theorem_5_2_ExactConeEnergy.positiveEnergy_nonnegative
#print axioms PaperProofs.S05_Theorem_5_2_ExactConeEnergy.negativeEnergy_nonnegative
#print axioms PaperProofs.S05_Theorem_5_2_ExactConeEnergy.signedEnergy_le_positive
#print axioms PaperProofs.S05_Theorem_5_2_ExactConeEnergy.signedEnergy_ge_negative
