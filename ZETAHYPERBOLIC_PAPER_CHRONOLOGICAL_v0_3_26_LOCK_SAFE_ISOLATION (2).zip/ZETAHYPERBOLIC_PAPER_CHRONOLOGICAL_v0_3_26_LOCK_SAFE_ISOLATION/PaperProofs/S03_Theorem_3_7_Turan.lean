import PaperChronology.S03_Theorem_3_7
import Mathlib.Tactic

/-! Theorem 3.7, real-rooted quadratic case of the Laguerre/Turan
inequality. General arbitrary-degree and strictness case remains open. -/
namespace PaperProofs.S03_Theorem_3_7_Turan

/-- `(P')² - P P'' = (x-r)²+(x-s)²` for P=(x-r)(x-s). -/
theorem quadratic_turan_identity (x r s : ℝ) :
    (2*x-r-s)^2 - 2*((x-r)*(x-s)) = (x-r)^2 + (x-s)^2 := by
  ring

theorem quadratic_turan_nonnegative (x r s : ℝ) :
    0 ≤ (2*x-r-s)^2 - 2*((x-r)*(x-s)) := by
  rw [quadratic_turan_identity]
  positivity

end PaperProofs.S03_Theorem_3_7_Turan
#print axioms PaperProofs.S03_Theorem_3_7_Turan.quadratic_turan_nonnegative
