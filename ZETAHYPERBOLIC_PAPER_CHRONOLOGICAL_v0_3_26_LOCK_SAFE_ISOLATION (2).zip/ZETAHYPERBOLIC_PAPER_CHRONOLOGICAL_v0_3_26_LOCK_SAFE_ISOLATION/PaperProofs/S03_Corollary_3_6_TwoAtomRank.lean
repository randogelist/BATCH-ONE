import PaperChronology.S03_Corollary_3_6
import PaperProofs.S03_Theorem_3_3_TwoAtomMinors
import Mathlib.Tactic

/-!
# Corollary 3.6, corrected finite-rank moment theorem

A positive two-atom moment functional has strictly positive adjacent
2 × 2 minors if its nodes differ, but all 3 × 3 Hankel determinants vanish.
The latter statement holds at EVERY shifted index r, not only at r = 0.
This repairs the impossible assertion of strict positivity at all orders.
-/

namespace PaperProofs.S03_Corollary_3_6_TwoAtomRank

open PaperProofs.S03_Theorem_3_3_TwoAtomMinors

/-- The 3 × 3 Hankel determinant is identically zero for two atoms.
Its explicit expansion is valid at every moment shift `r`. -/
theorem shifted_three_by_three_vanishes
    (w₀ w₁ u v : ℝ) (r : ℕ) :
    moment w₀ w₁ u v r *
        (moment w₀ w₁ u v (r + 2) * moment w₀ w₁ u v (r + 4) -
          moment w₀ w₁ u v (r + 3) ^ 2) -
      moment w₀ w₁ u v (r + 1) *
        (moment w₀ w₁ u v (r + 1) * moment w₀ w₁ u v (r + 4) -
          moment w₀ w₁ u v (r + 2) * moment w₀ w₁ u v (r + 3)) +
      moment w₀ w₁ u v (r + 2) *
        (moment w₀ w₁ u v (r + 1) * moment w₀ w₁ u v (r + 3) -
          moment w₀ w₁ u v (r + 2) ^ 2) = 0 := by
  simp only [moment, pow_add, pow_one]
  ring

end PaperProofs.S03_Corollary_3_6_TwoAtomRank

#print axioms PaperProofs.S03_Corollary_3_6_TwoAtomRank.shifted_three_by_three_vanishes
