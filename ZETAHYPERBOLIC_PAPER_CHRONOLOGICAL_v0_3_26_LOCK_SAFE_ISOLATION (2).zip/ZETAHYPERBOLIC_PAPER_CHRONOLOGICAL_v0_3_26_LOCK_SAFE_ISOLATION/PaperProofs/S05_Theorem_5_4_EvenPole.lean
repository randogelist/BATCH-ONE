import Zetahyperbolic.Section2Checked
import Mathlib.Tactic

/-! Theorem 5.4 in full on the exact simple-pole domain of Definition 2.1:
`τ_X((x-j)^(-1) - (x+j)^(-1)) = j^(-(2k+1))`.
This is the paper's stated case; no higher-order poles are introduced. -/
namespace PaperProofs.S05_Theorem_5_4_EvenPole

open Polynomial

/-- The two opposite pole indices correspond to harmonic indices j and j-1. -/
theorem opposite_pole_indices (j : ℕ) (hj : 1 ≤ j) :
    Zetahyperbolic.dIndex (j : ℤ) = j ∧
    Zetahyperbolic.dIndex (-(j : ℤ)) = j-1 := by
  constructor
  · simp [Zetahyperbolic.dIndex]
  · have hneg : ¬ (0 : ℤ) ≤ -(j : ℤ) := by omega
    unfold Zetahyperbolic.dIndex
    rw [if_neg hneg]
    have hcast : -(-(j : ℤ)) - 1 = ((j - 1 : ℕ) : ℤ) := by omega
    rw [hcast]
    simp

/-- The exact tau-polynomial of an x-even integer pole pair is CONSTANT,
so all dependence on the formal zeta variable X cancels. -/
theorem tau_even_pole_pair (k j : ℕ) (hj : 1 ≤ j) :
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
        C (((j : ℚ) ^ (2*k+1))⁻¹) := by
  obtain ⟨hdpos, hdneg⟩ := opposite_pole_indices j hj
  have hpred : j-1+1=j := by omega
  have hrec := Zetahyperbolic.harmonicWeight_succ (2*k+1) (j-1)
  rw [hpred] at hrec
  unfold Zetahyperbolic.tauPolePoly
  rw [hdpos, hdneg]
  calc
    (C (Zetahyperbolic.harmonicWeight (2*k+1) j) - X) -
      (C (Zetahyperbolic.harmonicWeight (2*k+1) (j-1)) - X) =
        C (Zetahyperbolic.harmonicWeight (2*k+1) j -
          Zetahyperbolic.harmonicWeight (2*k+1) (j-1)) := by
      rw [Polynomial.C_sub]
      ring
    _ = C (((j : ℚ) ^ (2*k+1))⁻¹) := by
      rw [hrec]
      congr 1
      ring

end PaperProofs.S05_Theorem_5_4_EvenPole
#print axioms PaperProofs.S05_Theorem_5_4_EvenPole.tau_even_pole_pair
