import PaperProofs.S03_Theorem_3_3_TwoAtomMinors
import Mathlib.Tactic

/-!
# Theorem 3.3: three-atom Hankel determinant (genuine 3 × 3 case)

This is an exact positive-minor calculation for three real atoms. It is
unconditional polynomial algebra. The continuous-measure arbitrary-order
strict total positivity claim is not asserted here.
-/

namespace PaperProofs.S03_Theorem_3_3_ThreeAtomMoment

/-- Three weighted atoms, with a free moment index. -/
def moment3 (a b c u v w : ℝ) (r : ℕ) : ℝ :=
  a * u ^ r + b * v ^ r + c * w ^ r

/-- The first nontrivial Hankel determinant for three atoms is a sum of
three squared pairwise Vandermonde factors. -/
theorem two_by_two_factor
    (a b c u v w : ℝ) :
    moment3 a b c u v w 0 * moment3 a b c u v w 2 -
      (moment3 a b c u v w 1) ^ 2 =
      a * b * (v - u) ^ 2 + a * c * (w - u) ^ 2 +
        b * c * (w - v) ^ 2 := by
  dsimp [moment3]
  ring

/-- All three atoms are needed for a nonzero 3 × 3 Hankel determinant.
The factorization is exact, not asymptotic. -/
theorem three_by_three_factor
    (a b c u v w : ℝ) :
    moment3 a b c u v w 0 *
        (moment3 a b c u v w 2 * moment3 a b c u v w 4 -
          (moment3 a b c u v w 3) ^ 2) -
      moment3 a b c u v w 1 *
        (moment3 a b c u v w 1 * moment3 a b c u v w 4 -
          moment3 a b c u v w 2 * moment3 a b c u v w 3) +
      moment3 a b c u v w 2 *
        (moment3 a b c u v w 1 * moment3 a b c u v w 3 -
          (moment3 a b c u v w 2) ^ 2) =
      a * b * c * (v - u) ^ 2 * (w - u) ^ 2 * (w - v) ^ 2 := by
  dsimp [moment3]
  ring

/-- Strict 2 × 2 positivity needs only two distinct atoms with positive
masses, and a third atom with nonnegative mass. -/
theorem two_by_two_strict
    (a b c u v w : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 ≤ c)
    (huv : u ≠ v) :
    0 < moment3 a b c u v w 0 * moment3 a b c u v w 2 -
      (moment3 a b c u v w 1) ^ 2 := by
  rw [two_by_two_factor]
  have hgap : 0 < (v - u) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huv.symm)
  have hfirst : 0 < a * b * (v - u) ^ 2 := by positivity
  have hsecond : 0 ≤ a * c * (w - u) ^ 2 := by positivity
  have hthird : 0 ≤ b * c * (w - v) ^ 2 := by positivity
  linarith

/-- Strict 3 × 3 positivity for positive masses and pairwise distinct
nodes. This is an explicit third-order case of Theorem 3.3. -/
theorem three_by_three_strict
    (a b c u v w : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
    0 < moment3 a b c u v w 0 *
        (moment3 a b c u v w 2 * moment3 a b c u v w 4 -
          (moment3 a b c u v w 3) ^ 2) -
      moment3 a b c u v w 1 *
        (moment3 a b c u v w 1 * moment3 a b c u v w 4 -
          moment3 a b c u v w 2 * moment3 a b c u v w 3) +
      moment3 a b c u v w 2 *
        (moment3 a b c u v w 1 * moment3 a b c u v w 3 -
          (moment3 a b c u v w 2) ^ 2) := by
  rw [three_by_three_factor]
  have h₁ : 0 < (v - u) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huv.symm)
  have h₂ : 0 < (w - u) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huw.symm)
  have h₃ : 0 < (w - v) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr hvw.symm)
  positivity

end PaperProofs.S03_Theorem_3_3_ThreeAtomMoment

#print axioms PaperProofs.S03_Theorem_3_3_ThreeAtomMoment.two_by_two_factor
#print axioms PaperProofs.S03_Theorem_3_3_ThreeAtomMoment.three_by_three_factor
#print axioms PaperProofs.S03_Theorem_3_3_ThreeAtomMoment.two_by_two_strict
#print axioms PaperProofs.S03_Theorem_3_3_ThreeAtomMoment.three_by_three_strict
