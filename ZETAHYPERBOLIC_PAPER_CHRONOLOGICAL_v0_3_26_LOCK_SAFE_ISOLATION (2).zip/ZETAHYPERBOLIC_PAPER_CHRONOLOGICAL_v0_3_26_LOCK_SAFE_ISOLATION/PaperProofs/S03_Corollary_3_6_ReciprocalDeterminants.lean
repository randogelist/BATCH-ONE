import PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant
import PaperProofs.S03_Corollary_3_6_ReciprocalRoots
import Mathlib.Tactic

/-!
# Corollary 3.6 — corrected reciprocal-root Hankel determinants

The finite reciprocal-root power sums are moments of the concrete atoms
u_a = (r_a-q)⁻². Their n-by-n Hankel determinant is exactly the square
of the Vandermonde determinant. Every shifted principal section has the
corresponding extra product of u_a^k; no false positivity is asserted
beyond finite-support rank or when reciprocal distances coincide.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants

open PaperProofs.S03_Theorem_3_3_AtomicMomentEnergy
open PaperProofs.S03_Theorem_3_3_ArbitraryFiniteGram
open PaperProofs.S03_Theorem_3_3_MomentDeterminantBridge
open PaperProofs.S03_Theorem_3_3_ShiftedMomentDeterminant
open PaperProofs.S03_Corollary_3_6_ReciprocalRoots

variable {n : ℕ}

/-- Square reciprocal-root moment matrix. -/
def reciprocalHankel (roots : Fin n → ℝ) (q : ℝ) :
    Matrix (Fin n) (Fin n) ℝ :=
  fun i j => evenReciprocalMoment roots q ((i : ℕ) + (j : ℕ))

/-- This is literally the finite atomic Hankel matrix with unit masses. -/
theorem reciprocalHankel_eq_atomic
    (roots : Fin n → ℝ) (q : ℝ) :
    reciprocalHankel roots q =
      atomicHankel (reciprocalNodes roots q) (fun _ => 1) n := by
  classical
  ext i j
  simp [reciprocalHankel, atomicHankel, evenReciprocalMoment, atomicMoment]

/-- All-dimensional exact determinant formula, including zero determinant
when two reciprocal squared distances are identical. -/
theorem reciprocalHankel_det
    (roots : Fin n → ℝ) (q : ℝ) :
    (reciprocalHankel roots q).det =
      ((atomVandermonde (reciprocalNodes roots q)).det) ^ 2 := by
  rw [reciprocalHankel_eq_atomic]
  rw [atomicHankel_det]
  simp

/-- Strict n-by-n determinant positivity is equivalent to the finite
Vandermonde certificate; distinct roots alone do not suffice. -/
theorem reciprocalHankel_det_pos
    (roots : Fin n → ℝ) (q : ℝ)
    (hV : (atomVandermonde (reciprocalNodes roots q)).det ≠ 0) :
    0 < (reciprocalHankel roots q).det := by
  rw [reciprocalHankel_det]
  exact sq_pos_of_ne_zero hV

/-- Exact shifted reciprocal-root Hankel matrix. -/
def shiftedReciprocalHankel
    (roots : Fin n → ℝ) (q : ℝ) (shift : ℕ) :
    Matrix (Fin n) (Fin n) ℝ :=
  fun i j => evenReciprocalMoment roots q (shift + ((i : ℕ) + (j : ℕ)))

theorem shiftedReciprocalHankel_eq_atomic
    (roots : Fin n → ℝ) (q : ℝ) (shift : ℕ) :
    shiftedReciprocalHankel roots q shift =
      shiftedAtomicHankel (reciprocalNodes roots q) (fun _ => 1) shift := by
  classical
  ext i j
  simp [shiftedReciprocalHankel, shiftedAtomicHankel,
    evenReciprocalMoment, atomicMoment]

/-- The exact determinant of EVERY shifted n-by-n reciprocal-root moment
section, with the correct finite rank and positivity conditions. -/
theorem shiftedReciprocalHankel_det
    (roots : Fin n → ℝ) (q : ℝ) (shift : ℕ) :
    (shiftedReciprocalHankel roots q shift).det =
      ((atomVandermonde (reciprocalNodes roots q)).det) ^ 2 *
        (∏ a : Fin n, reciprocalNodes roots q a ^ shift) := by
  rw [shiftedReciprocalHankel_eq_atomic]
  rw [shiftedAtomicHankel_det]
  simp only [one_mul]

/-- Reciprocal-root moment sections have positive determinants whenever
the squared reciprocal distances are Vandermonde-distinct and q avoids
all spectral roots. -/
theorem shiftedReciprocalHankel_det_pos
    (roots : Fin n → ℝ) (q : ℝ) (shift : ℕ)
    (hq : ∀ a, roots a ≠ q)
    (hV : (atomVandermonde (reciprocalNodes roots q)).det ≠ 0) :
    0 < (shiftedReciprocalHankel roots q shift).det := by
  rw [shiftedReciprocalHankel_det]
  have hprod : 0 < ∏ a : Fin n, reciprocalNodes roots q a ^ shift := by
    apply Finset.prod_pos
    intro a _
    exact pow_pos (reciprocalNodes_pos roots q hq a) shift
  exact mul_pos (sq_pos_of_ne_zero hV) hprod

end PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants

#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants.reciprocalHankel_eq_atomic
#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants.reciprocalHankel_det
#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants.reciprocalHankel_det_pos
#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants.shiftedReciprocalHankel_det
#print axioms PaperProofs.S03_Corollary_3_6_ReciprocalDeterminants.shiftedReciprocalHankel_det_pos
