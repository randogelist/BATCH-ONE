import PaperProofs.S05_Theorem_5_2_TruncatedKernel
import PaperProofs.S05_Theorem_5_2_FiniteFeatureKernel
import Mathlib.Tactic

/-!
# Theorem 5.2: exact finite-dimensional signed Krein kernel identity

This moves the fifth-power geometric kernel decomposition from a
pointwise equality to the quadratic form on an arbitrary finite set
of evaluation points, with arbitrary real coefficients. The identity
requires no assumptions on convergence or linear independence.
-/

noncomputable section
open scoped BigOperators
namespace PaperProofs.S05_Theorem_5_2_ExactKreinQuadratic

open PaperProofs.S05_Theorem_5_2_TruncatedKernel

variable {n : ℕ}

/-- Direct finite kernel energy for the weight-seven Beukers modes. -/
def finiteKernelEnergy (M : ℕ) (nodes v : Fin n → ℝ) : ℝ :=
  ∑ i : Fin n, ∑ j : Fin n,
    v i * truncatedKernel M (nodes i) (nodes j) * v j

/-- A signed positive-minus-negative finite Krein energy. -/
def finiteSignedEnergy (M : ℕ) (nodes v : Fin n → ℝ) : ℝ :=
  ∑ i : Fin n, ∑ j : Fin n,
    v i * (truncatedPositive M (nodes i) (nodes j) -
      truncatedNegative M (nodes i) (nodes j)) * v j

/-- Universal finite quadratic extension of the exact mode decomposition. -/
theorem signedEnergy_eq_twice_kernel
    (M : ℕ) (nodes v : Fin n → ℝ) :
    finiteSignedEnergy M nodes v = 2 * finiteKernelEnergy M nodes v := by
  unfold finiteSignedEnergy finiteKernelEnergy
  calc
    (∑ i : Fin n, ∑ j : Fin n,
       v i * (truncatedPositive M (nodes i) (nodes j) -
         truncatedNegative M (nodes i) (nodes j)) * v j) =
      ∑ i : Fin n, ∑ j : Fin n,
        2 * (v i * truncatedKernel M (nodes i) (nodes j) * v j) := by
          apply Finset.sum_congr rfl
          intro i _
          apply Finset.sum_congr rfl
          intro j _
          rw [truncated_difference]
          ring
    _ = 2 * (∑ i : Fin n, ∑ j : Fin n,
      v i * truncatedKernel M (nodes i) (nodes j) * v j) := by
        simp only [Finset.mul_sum]

end PaperProofs.S05_Theorem_5_2_ExactKreinQuadratic

#print axioms PaperProofs.S05_Theorem_5_2_ExactKreinQuadratic.signedEnergy_eq_twice_kernel
