import PaperChronology.S03_Theorem_3_4
import Mathlib.Tactic

/-! Theorem 3.4. Exact Dodgson condensation for the symmetric 3x3
principal-minor pencil, without any spectral hypotheses. This is the
r=3 case; the full arbitrary-r theorem remains a separate frontier. -/
namespace PaperProofs.S03_Theorem_3_4_Dodgson

/-- Jacobi-Dodgson for the symmetric 3x3 pencil with entries
`[[a,b,c],[b,d,e],[c,e,f]]`. -/
theorem symmetric_three_by_three_condensation
    (a b c d e f : ℝ) :
    (a*d*f + 2*b*c*e - a*e^2 - d*c^2 - f*b^2) * a =
      (a*d-b^2)*(a*f-c^2) - (a*e-b*c)^2 := by
  ring

/-- The sign-alternation conclusion at a zero of the leading 2x2 minor. -/
theorem condensation_sign_at_minor_root
    (a b c d e f : ℝ) (hminor : a*d-b^2=0) :
    (a*d*f + 2*b*c*e - a*e^2 - d*c^2 - f*b^2)*a ≤ 0 := by
  rw [symmetric_three_by_three_condensation, hminor]
  nlinarith [sq_nonneg (a*e-b*c)]

end PaperProofs.S03_Theorem_3_4_Dodgson
#print axioms PaperProofs.S03_Theorem_3_4_Dodgson.symmetric_three_by_three_condensation
#print axioms PaperProofs.S03_Theorem_3_4_Dodgson.condensation_sign_at_minor_root
