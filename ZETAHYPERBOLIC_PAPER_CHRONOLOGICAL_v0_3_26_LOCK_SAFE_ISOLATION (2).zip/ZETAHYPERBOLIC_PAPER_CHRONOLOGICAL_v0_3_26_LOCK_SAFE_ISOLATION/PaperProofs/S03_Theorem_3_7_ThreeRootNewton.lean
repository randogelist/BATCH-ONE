import PaperProofs.S03_Theorem_3_7_Turan
import Mathlib.Tactic

/-!
# Theorem 3.7: exact Newton inequality for the three-root factor

For Φ(Y) = (1+aY)(1+bY)(1+cY), the first normalized
Newton inequality is e₁²/9 ≥ e₂/3. It follows from a positive
sum of squared differences, with equality iff a=b=c.
This does not yet assert the full arbitrary-degree Newton hierarchy.
-/

namespace PaperProofs.S03_Theorem_3_7_ThreeRootNewton

/-- The normalized three-root Newton gap is half the pairwise energy. -/
theorem three_root_gap_identity (a b c : ℝ) :
    (a + b + c) ^ 2 - 3 * (a*b + a*c + b*c) =
      ((a-b)^2 + (a-c)^2 + (b-c)^2) / 2 := by
  ring

/-- A genuine Newton inequality for three arbitrary real spectral values. -/
theorem three_root_newton (a b c : ℝ) :
    3 * (a*b + a*c + b*c) ≤ (a + b + c) ^ 2 := by
  have h := three_root_gap_identity a b c
  nlinarith [sq_nonneg (a-b), sq_nonneg (a-c), sq_nonneg (b-c)]

/-- Strict Newton inequality as soon as two spectral values differ. -/
theorem three_root_newton_strict (a b c : ℝ) (hab : a ≠ b) :
    3 * (a*b + a*c + b*c) < (a + b + c) ^ 2 := by
  have heq := three_root_gap_identity a b c
  have hgap : 0 < (a - b) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr hab)
  have hac : 0 ≤ (a - c) ^ 2 := sq_nonneg _
  have hbc : 0 ≤ (b - c) ^ 2 := sq_nonneg _
  linarith

end PaperProofs.S03_Theorem_3_7_ThreeRootNewton

#print axioms PaperProofs.S03_Theorem_3_7_ThreeRootNewton.three_root_gap_identity
#print axioms PaperProofs.S03_Theorem_3_7_ThreeRootNewton.three_root_newton
#print axioms PaperProofs.S03_Theorem_3_7_ThreeRootNewton.three_root_newton_strict
