# Paper theorem checklist (chronological)

**Target manuscript:** 52-page *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values*.

The status describes exact mathematical proof coverage; a successfully compiled module containing a `#check` is **not** a theorem proof. All the following entries have separately numbered Lean source files, compiled in exactly this order.

| Item | Paper title | PDF pages | Status | Existing support / next obstruction |
|---|---|---:|---|---|
| `S02_Definition_2_1` | Order-s rational moment functional | 3–4 | **formalized** | Zetahyperbolic.Section2Checked; Definition_2_1_Order_s_Rational_Moment_Functional |
| `S02_Lemma_2_2` | Pullback identity | 4 | **formalized** | Zetahyperbolic.pullback_identity_monomial / pullback_identity_pole |
| `S02_Lemma_2_3` | Reflection and difference identities for tau_X | 5 | **formalized** | Zetahyperbolic.tau_reflection_monomial / tau_reflection_pole / tau_difference_pole |
| `S02_Theorem_2_4` | Canonical basis invariance | 6 | **formalized** | BasisInvariance.primitive_normalization theorem |
| `S02_Theorem_2_5` | Lagrange pole diagonalization | 6–7 | **formalized** | Zetahyperbolic.lagrange_pole_diagonalization |
| `S03_Theorem_3_1` | Universal hyperbolicity and zero-free disk | 7–8 | **formalized** | ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL |
| `S03_Proposition_3_2` | Continuous hyperbolic pencil for all real s > 1 | 8 | **correction-required** | correct continuous weight prefactor; no complete analytic equality |
| `S03_Theorem_3_3` | Total positivity, leading sign, universal signature | 8–9 | **partial** | positive Gram and gamma nonvanishing; leading-sign exponent parity (compiler confirmation pending); new proved-by-source two-atom mixed-minor factorization and adjacent strict minor; continuous minors and inertia remain open |
| `S03_Theorem_3_4` | Root interlacing and Dodgson condensation | 9–10 | **open** | new 1×1→2×2 base-case interlacing; general principal-minor interlacing remains open |
| `S03_Corollary_3_5` | Stieltjes J-fraction from interlacing roots | 10–11 | **correction-required** | printed one-pole unit-slope denominator inconsistent |
| `S03_Corollary_3_6` | Stieltjes reciprocal-root power sums | 11 | **correction-required** | finite atom determinants vanish beyond support size; added all-shifts 3×3 rank-defect identity for 2 atoms |
| `S03_Theorem_3_7` | Turanian non-negativity and Newton log-concavity | 11–12 | **partial** | real-root theorem available; coefficient/strictness assertion unfinished |
| `S03_Theorem_3_8` | Christoffel-Darboux pole representation / Jacobi derivative | 12–13 | **partial** | Vandermonde factorization proved; orthogonal kernel theorem pending |
| `S03_Theorem_3_9` | Hyperbolicity for Hurwitz and Dirichlet determinants | 13–14 | **partial** | five explicit Fekete factor inequalities proved |
| `S04_Theorem_4_1` | Spectral irrationality measure criterion | 14–15 | **partial** | generic integer polynomial transfer proved; matching exponential rates are separate |
| `S04_Proposition_4_2` | Transfer criterion for algebraic approximations | 15 | **open** | resultant/Mahler bound not formalized |
| `S04_Proposition_4_3` | Ultrametric zero-free disk over Qp | 15 | **compiler-pending full closure** | Genuine `ℂ_[p]` disk: `PaperProofs.S04_Proposition_4_3_PadicDisk.ultrametric_zero_free_disk` (not the older ZMod residue surrogate) |
| `S04_Theorem_4_4` | Sharpened spectral bound and effective measure for zeta(5) | 16–18 | **witness-conditional** | PaperSingleWitness.Witness contains all eventual quantitative estimates |
| `S04_Theorem_4_5` | Irrationality and measure for b*zeta(5)+a*zeta(3) | 18–19 | **open** | mixed-weight primitive normalization and prime valuations pending |
| `S04_Theorem_4_6` | Two-sided determinant bounds and coefficient heights | 19–21 | **partial** | finite relative-determinant identity; asymptotic bounds pending |
| `S04_Theorem_4_7` | Macroscopic exponential root collapse and separation | 21 | **open** | root clustering density and constants not formalized |
| `S04_Proposition_4_8` | Rational root exclusion and cluster factor degrees | 21–22 | **open** | requires published quantitative estimates and additional bounds |
| `S04_Conjecture_4_11` | Limit of spectral exponent and variational supremum | 22 | **conjecture** | no proof expected: conjecture is distinct from theorem |
| `S05_Theorem_5_1` | Two-variable Beukers measure for zeta(7) | 22–23 | **partial** | finite rational diagonal/offdiagonal moments constructed; analytic integral pending |
| `S05_Theorem_5_2` | Dual hyperbolicity and Krein-space decomposition | 23–24 | **partial** | finite signed truncation and tail comparison proved; existence open |
| `S05_Proposition_5_3` | Two-variable Beukers measure for beta(4) | 24–25 | **open** | beta moment identities and analytic bridge pending |
| `S05_Theorem_5_4` | Cancellation of higher zeta values on even pole pairs | 25 | **compiler-pending full closure** | Exact `tauPolePoly` statement for all k,j >= 1, using `PaperProofs.S05_Theorem_5_4_EvenPole.tau_even_pole_pair` |
| `S05_Theorem_5_6` | Weight-seven prime-sum integral and inner refinement | 26–27 | **open** | 11-piece integral and local p-adic weight lemma pending |
| `S05_Theorem_5_7` | Double-pole Hankel determinant for 1,zeta(5),zeta(6) | 28–29 | **open** | q-adic valuation and prime minors pending |
| `S06_Theorem_6_1` | Divided-difference p-adic valuation law | 29–31 | **open** | finite rational divided differences ready; exact valuations pending |
| `S06_Theorem_6_2` | Simultaneous weights (6,7) Beukers functional | 31–32 | **open** | joint algebraic kernel and denominator control pending |
| `S06_Theorem_6_3` | q-adic nonvanishing / positive-cone polynomial bases | 32–33 | **partial** | tail certificate implication proved; existence and q-adic nonvanishing pending |
| `S06_Theorem_6_4` | Character-Vandermonde sign cancellation for beta(4) | 33–35 | **correction-required** | conditional beta mass identities only; printed analytic realization unresolved |
| `S06_Theorem_6_5` | q-adic non-vanishing for Delta_K(0) | 35–36 | **open** | local arithmetic nonvanishing unfinished |
| `S06_Theorem_6_6` | Generalized multi-weight positive-definite pencil | 36–37 | **open** | pointwise positive mixed kernel not proved |
| `S06_Theorem_6_7` | Universal multi-weight two-variable Krein decomposition | 37–38 | **open** | general signed Hilbert expansion not proved |
| `S06_Corollary_6_8` | Three-term linear independence cone for 1,zeta(3),zeta(5) | 38 | **correction-required** | does not follow from zeta(5) decay alone |
| `S06_Theorem_6_9` | Triple-pole and multi-weight Hankel determinants | 38–39 | **partial** | corrected finite triple-pole Hermite identities proved; full q-adic bound pending |
| `S06_Theorem_6_10` | Universal potential gap and quadratic derivative growth | 39–40 | **partial** | exact finite determinant coefficient identity proved; limits not proved |
| `S06_Theorem_6_11` | Distribution growth law and 2-adic polynomial obstruction | 40–42 | **open** | uniform p-adic distribution estimates pending |
| `S06_Theorem_6_12` | Full-dimension sign flip and q-adic nonvanishing | 42–43 | **open** | joint realization and q-adic estimates pending |
| `S06_Theorem_6_13` | Central-factorial secant differential identity | 43–45 | **open** | differential and Laplace identities pending |
| `S06_Theorem_6_14` | Even-pole scaling and coupled positive-definite pencils | 45–46 | **open** | even-pole moment bridge pending |
| `S06_Theorem_6_15` | Arithmetic transcendence and rank-one pencils | 46–47 | **open** | full transcendence and rank-one proof pending |
| `S06_Theorem_6_16` | Generalized multi-weight Zeta-Beta positive pencil | 47–48 | **partial** | compact ratio comparison proved with endpoint hypotheses |
| `S06_Theorem_6_17` | Universal two-variable Zeta-Beta pencil and Krein signature | 48–49 | **partial** | parity index arithmetic lemmas; full signature pending |
| `S06_Theorem_6_18` | 2-adic integrality law and dyadic height bounds | 49–50 | **partial** | finite boundary degree/quotient zero proved; valuation pending |

## Status definitions

- **formalized**: the named mathematical item is present in imported Lean with a proven wrapper (paper-level scope as documented).
- **compiler-pending full closure**: full mathematical statement has a proof term but the changed chronological wrapper and/or new dependency requires the user’s native Lean 4.33 compiler and clean `#print axioms` audit.
- **partial**: only explicitly described finite or structural component is formalized; paper statement remains open.
- **witness-conditional**: all remaining assumptions of this endpoint are in `PaperSingleWitness.Witness`, NOT proved by this package.
- **correction-required**: printed claim or proof contains a mathematical defect; corrected target needed before completing the theorem.
- **open**: no full proof imported; no new axiom or assumed theorem introduced.
- **conjecture**: remains the author’s conjecture and is not implicitly assumed.

## Global proof boundary

`PaperChronology.THEOREM_3_1_ALL_ODD_WEIGHTS` is unconditional (under elementary admissibility).
`PaperChronology.SECTION_4_4_FROM_WITNESS` takes exactly `PaperSingleWitness.Witness`.
A full all-theorem conclusion with only this witness is **not** present and is not claimed.
The PDF contains independent §5–§6 obligations unrelated to that one quantitative witness.

## Explicit mathematical corrections preserved

1. Proposition 3.2 has a pi/2 prefactor mismatch relative to its claimed odd-integer specialization.
2. Corollary 3.5 omits normalization and uses an incorrect affine denominator.
3. Corollary 3.6 asserts strict positivity past the finite-support rank bound, which is false.
4. Earlier audited §§5–6 repairs are retained; proof files labeled partial do not claim the uncorrected printed statement.

## Build contract

Run only `run.cmd` under Windows native Lean 4.33.0 with pinned Mathlib sources and compiled caches.
There is deliberately no local Lean build or Lean execution in the preparation of this ZIP.
Provide the generated `PAPER_CHRONOLOGY_BUILD.log` after your first run for compiler-directed revision.

## v0.3.12 added proof-sized mathematical obligations (uncompiled)

- §3.3: `ThreeAtomMoment, ArbitraryFiniteGram, RootSideTransfer`. Not the complete paper theorem where an analytic bridge remains.
- §3.7: `ThreeRootNewton`. Not the complete paper theorem where an analytic bridge remains.
- §4.1: `TransferWindow + exact exponent margin`. Not the complete paper theorem where an analytic bridge remains.
- §5.2: `DualDeterminant`. Not the complete paper theorem where an analytic bridge remains.
- §5.4: `EvenPole decoupled from optional witness`. Not the complete paper theorem where an analytic bridge remains.
- §5.6: `OuterPieces + OuterPartition independent`. Not the complete paper theorem where an analytic bridge remains.
- §6.1: `DividedDifference + LocalObstruction independent`. Not the complete paper theorem where an analytic bridge remains.
- §6.10: `finite 2×3 GramDet independent`. Not the complete paper theorem where an analytic bridge remains.

`PAPER_UNCONDITIONAL_FOUNDATIONS` is a genuine bundled Lean theorem, with no Witness.
