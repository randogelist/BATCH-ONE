import Zetahyperbolic.CoreLinearAlgebra

/-!
# Manuscript Theorem 3.3 — arbitrary-order Gram determinant repair

This module makes the algebraic structure over a `CommRing` EXPLICIT.
In particular, Lean can infer the `OfNat R 0`, determinant, multiplication,
and diagonal matrix instances, rather than leaving bare `R` uninstantiated.

The determinant factorization and its zero-mass consequence are generic
commutative-ring results. Strict positivity is specialized to `ℝ` and
requires a nonsingular evaluation matrix and positive atom weights.

These are unconditional finite-dimensional identities, NOT a proof of
positive total minors for the continuous infinite moment measure.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_3.ArbitraryGram

variable {n : ℕ}

/-- A square weighted Gram matrix in arbitrary finite dimension. -/
def weightedGram {R : Type*} [CommRing R]
    (V : Matrix (Fin n) (Fin n) R) (w : Fin n → R) :
    Matrix (Fin n) (Fin n) R :=
  V * Matrix.diagonal w * V.transpose

/-- Full arbitrary-order determinant identity. Explicit commutative-ring
instances repair the missing `CommRing R` in the failing generic source. -/
theorem weightedGram_det {R : Type*} [CommRing R]
    (V : Matrix (Fin n) (Fin n) R) (w : Fin n → R) :
    (weightedGram V w).det = (V.det) ^ 2 * ∏ i, w i := by
  exact Zetahyperbolic.det_conjugated_diagonal V w

/-- A vanishing atom mass forces the whole square Gram determinant to vanish. -/
theorem weightedGram_det_zero_of_weight_zero
    {R : Type*} [CommRing R]
    (V : Matrix (Fin n) (Fin n) R) (w : Fin n → R)
    (i : Fin n) (hi : w i = 0) :
    (weightedGram V w).det = 0 := by
  exact Zetahyperbolic.det_conjugated_diagonal_eq_zero_of_weight_zero V w i hi

/-- Algebraic nonsingularity: for an invertible evaluation matrix and
nonvanishing atom masses, the weighted Gram determinant is nonzero. -/
theorem weightedGram_det_ne_zero
    {R : Type*} [CommRing R] [Nontrivial R] [NoZeroDivisors R]
    (V : Matrix (Fin n) (Fin n) R) (w : Fin n → R)
    (hV : IsUnit V.det) (hw : ∀ i, w i ≠ 0) :
    (weightedGram V w).det ≠ 0 := by
  exact Zetahyperbolic.det_conjugated_diagonal_ne_zero V w hV hw

/-- A strictly positive determinant over the reals. Positivity does NOT
follow from `CommRing`; this theorem supplies the stronger ordered field. -/
theorem weightedGram_det_pos
    (V : Matrix (Fin n) (Fin n) ℝ) (w : Fin n → ℝ)
    (hV : V.det ≠ 0) (hw : ∀ i, 0 < w i) :
    0 < (weightedGram V w).det := by
  rw [weightedGram_det]
  have hsq : 0 < (V.det) ^ 2 := sq_pos_of_ne_zero hV
  have hprod : 0 < ∏ i, w i := Finset.prod_pos (fun i _ => hw i)
  exact mul_pos hsq hprod

end PaperChronology.Theorem3_3.ArbitraryGram

#print axioms PaperChronology.Theorem3_3.ArbitraryGram.weightedGram_det
#print axioms PaperChronology.Theorem3_3.ArbitraryGram.weightedGram_det_zero_of_weight_zero
#print axioms PaperChronology.Theorem3_3.ArbitraryGram.weightedGram_det_ne_zero
#print axioms PaperChronology.Theorem3_3.ArbitraryGram.weightedGram_det_pos
