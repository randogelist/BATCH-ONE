import Lake
open Lake DSL

package zetahyperbolic where
  -- The audited build order is listed in MODULES_CHECKED.txt.

require mathlib from git
  "https://github.com/leanprover-community/mathlib4" @ "db584cd6d46c92f209a44c0f1c829460d327499d"

@[default_target]
lean_lib Zetahyperbolic where
  -- Register all local namespaces, including theorem-named top-level files.
  roots := #[
    `Zetahyperbolic,
    `Zeta5Merge,
    `Definition_2_1_Order_s_Rational_Moment_Functional,
    `Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7,
    `Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil,
    `Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7,
    `Theorem_2_4_Canonical_Basis_Invariance,
    `Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk,
    `Theorem_2_5_Lagrange_Pole_Diagonalization,
    `Theorem_4_1_Spectral_Irrationality_Measure_Criterion,
    `Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5,
    `Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4,
    `Theorem_3_1_General_Odd_Weight_Endpoint,
    `Theorem_3_1_Positive_Moment_Realization,
    `MAIN_CHAIN,
    `ZETA5_APPLICATION,
    `APPLICATIONS,
    `AUDITED_REPAIRS,
    `Theorem_3_1_Hyperbolic_Weight,
    `Theorem_3_1_Hyperbolic_Moments,
    `Theorem_3_1_Concrete_Moment_Realization,
    `Theorem_3_1_Rational_Integral_Bridge,
    `ANALYTIC_FRONTIER,
    `Theorem_3_1_Zeta_Tail,
    `Theorem_3_1_Coth_Partial_Fractions,
    `Theorem_3_1_Pole_Scaling,
    `Theorem_3_1_Bose_Tail_Integral,
    `Theorem_3_1_Pole_Integral_Identity,
    `MAIN_CHAIN_ASSEMBLED,
    `Theorem_4_1_General_Odd_Zeta_Application,
    `Theorem_4_1_Integer_Polynomial_Irrationality,
    `Theorem_4_1_Linear_Odd_Zeta_Family,
    `MAIN_CHAIN_ARITHMETIC,
    `CHECK_AXIOMS,
    `PAPER_SECTION3_CORRECTIONS,
    `PAPER_FINITE_MOMENTS,
    `MAIN_CHAIN_NO_OPEN_INPUTS
  ]
  -- Explicit endpoints only: unfinished manuscript files are not globbed.
  -- Lake recursively builds their imports within the registered roots.
  globs := #[.one `Zetahyperbolic, .one `MAIN_CHAIN,
             .one `APPLICATIONS, .one `AUDITED_REPAIRS, .one `ANALYTIC_FRONTIER,
             .one `MAIN_CHAIN_ASSEMBLED, .one `MAIN_CHAIN_ARITHMETIC, .one `CHECK_AXIOMS,
             .one `PAPER_SECTION3_CORRECTIONS, .one `PAPER_FINITE_MOMENTS,
             .one `MAIN_CHAIN_NO_OPEN_INPUTS]

-- Source-only distribution: use lake build with the pinned dependencies available.

-- Optional, audited single-witness terminal chain.
lean_lib PaperSingleWitnessChain where
  roots := #[`PAPER_SINGLE_WITNESS_CHAIN]


-- Numbered paper chronology: every module remains an individually buildable target.
lean_lib PaperChronology where
  roots := #[
    `PaperChronology.S02_Definition_2_1,
    `PaperChronology.S02_Lemma_2_2,
    `PaperChronology.S02_Lemma_2_3,
    `PaperChronology.S02_Theorem_2_4,
    `PaperChronology.S02_Theorem_2_5,
    `PaperChronology.S03_Theorem_3_1,
    `PaperChronology.S03_Proposition_3_2,
    `PaperChronology.S03_Theorem_3_3,
    `PaperChronology.S03_Theorem_3_4,
    `PaperChronology.S03_Corollary_3_5,
    `PaperChronology.S03_Corollary_3_6,
    `PaperChronology.S03_Theorem_3_7,
    `PaperChronology.S03_Theorem_3_8,
    `PaperChronology.S03_Theorem_3_9,
    `PaperChronology.S04_Theorem_4_1,
    `PaperChronology.S04_Proposition_4_2,
    `PaperChronology.S04_Proposition_4_3,
    `PaperChronology.S04_Theorem_4_4,
    `PaperChronology.S04_Theorem_4_5,
    `PaperChronology.S04_Theorem_4_6,
    `PaperChronology.S04_Theorem_4_7,
    `PaperChronology.S04_Proposition_4_8,
    `PaperChronology.S04_Conjecture_4_11,
    `PaperChronology.S05_Theorem_5_1,
    `PaperChronology.S05_Theorem_5_2,
    `PaperChronology.S05_Proposition_5_3,
    `PaperChronology.S05_Theorem_5_4,
    `PaperChronology.S05_Theorem_5_6,
    `PaperChronology.S05_Theorem_5_7,
    `PaperChronology.S06_Theorem_6_1,
    `PaperChronology.S06_Theorem_6_2,
    `PaperChronology.S06_Theorem_6_3,
    `PaperChronology.S06_Theorem_6_4,
    `PaperChronology.S06_Theorem_6_5,
    `PaperChronology.S06_Theorem_6_6,
    `PaperChronology.S06_Theorem_6_7,
    `PaperChronology.S06_Corollary_6_8,
    `PaperChronology.S06_Theorem_6_9,
    `PaperChronology.S06_Theorem_6_10,
    `PaperChronology.S06_Theorem_6_11,
    `PaperChronology.S06_Theorem_6_12,
    `PaperChronology.S06_Theorem_6_13,
    `PaperChronology.S06_Theorem_6_14,
    `PaperChronology.S06_Theorem_6_15,
    `PaperChronology.S06_Theorem_6_16,
    `PaperChronology.S06_Theorem_6_17,
    `PaperChronology.S06_Theorem_6_18,
    `PaperChronology
  ]
