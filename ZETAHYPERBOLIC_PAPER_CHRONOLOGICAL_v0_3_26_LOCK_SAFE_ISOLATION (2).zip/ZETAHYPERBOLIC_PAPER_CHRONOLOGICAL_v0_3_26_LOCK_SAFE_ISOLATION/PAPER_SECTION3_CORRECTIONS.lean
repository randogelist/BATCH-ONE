import Mathlib.Tactic

/-!
# Paper §3: mathematically corrected finite identities

These are proofs of exact algebraic facts, NOT a proof of the manuscript's
uncorrected Corollaries 3.5 and 3.6. In particular the printed J-fraction
has incorrect scaling already at h = 1, and a finite-atom Stieltjes moment
measure never has positive Hankel determinants beyond its support size.

The corrected continuous density for Proposition 3.2 has prefactor
  2 * (2*pi)^(s-1) / Gamma(s).
The PDF instead prints (2*pi)^s / (2*Gamma(s)), a factor pi/2 at odd s.
-/

namespace PaperSection3Corrections

/-- Compare the printed and the actual odd-weight density prefactors
    at s = 2*k+1. The multiplier is pi/2. -/
theorem printed_prefactor_scale (k : ℕ) :
    (2 * Real.pi) ^ (2 * k + 1) / (2 * (Nat.factorial (2 * k) : ℝ)) =
    (Real.pi / 2) *
      (2 * (2 * Real.pi) ^ (2 * k) / (Nat.factorial (2 * k) : ℝ)) := by
  rw [pow_succ]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

/-- The corrected continuous coefficient specializes to the discrete one. -/
theorem corrected_prefactor_at_odd_weights (k : ℕ) :
    2 * (2 * Real.pi) ^ ((2 * k + 1) - 1) /
      (Nat.factorial (2 * k) : ℝ) =
    2 * (2 * Real.pi) ^ (2 * k) /
      (Nat.factorial (2 * k) : ℝ) := by
  have h : 2 * k + 1 - 1 = 2 * k := by omega
  rw [h]

/-- The one-pole example N=1,K=2,m=1,k=1 has formal moment value
    mu_X((t+1)/(t+4)) = 1/4 - 3*(4X - 19/4). -/
def onePolePencil (X : ℚ) : ℚ :=
  1 / 4 - 3 * (4 * X - 19 / 4)

theorem one_pole_affine (X : ℚ) :
    onePolePencil X = 29 / 2 - 12 * X := by
  unfold onePolePencil
  ring

/-- A unit-slope J-fraction denominator cannot be the correct
    denominator for this actual one-pole rational moment pencil. -/
theorem no_unit_slope_fraction_denominator (a xi : ℝ) :
    ¬ (∀ X : ℝ, 29 / 2 - 12 * X = a + (X - xi)) := by
  intro h
  have hzero := h 0
  have hone := h 1
  norm_num at hzero hone
  linarith

/-- The correct one-dimensional normalized pencil is 1+(X-xi)*beta,
    where beta=M/G(xi); the unnormalized prefactor G(xi) matters. -/
theorem correct_one_pole_factorization
    (g m xi X : ℝ) (hg : g ≠ 0) :
    g + (X - xi) * m = g * (1 + (X - xi) * (m / g)) := by
  field_simp [hg] <;> ring

/-- One-atom moment data (M0,M1,M2)=(1,u,u^2) has zero
    2x2 Hankel determinant. This refutes strict positivity of *all*
    Hankel minors for finite-support moment sequences. -/
theorem one_atom_hankel_minor_zero (u : ℝ) :
    (u ^ 0) * (u ^ 2) - (u ^ 1) * (u ^ 1) = 0 := by
  ring

end PaperSection3Corrections

#print axioms PaperSection3Corrections.printed_prefactor_scale
#print axioms PaperSection3Corrections.corrected_prefactor_at_odd_weights
#print axioms PaperSection3Corrections.one_pole_affine
#print axioms PaperSection3Corrections.no_unit_slope_fraction_denominator
#print axioms PaperSection3Corrections.correct_one_pole_factorization
#print axioms PaperSection3Corrections.one_atom_hankel_minor_zero
