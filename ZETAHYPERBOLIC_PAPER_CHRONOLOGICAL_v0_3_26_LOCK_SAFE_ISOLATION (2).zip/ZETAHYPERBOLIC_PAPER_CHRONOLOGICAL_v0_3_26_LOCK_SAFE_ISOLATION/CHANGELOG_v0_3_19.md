# v0.3.19: full finite moment shifts and real-character factors

## New all-dimensional proofs (compiler pending)

- `S03_Theorem_3_3_ShiftedMomentDeterminant.lean`: for all n and shift k,
  `det(M_{k+i+j}) = det(V)^2 * prod_a(w_a*x_a^k)` for finite atoms,
  plus strict positivity and the exact quadratic sum-of-squares identity.
- `S03_Corollary_3_6_ReciprocalDeterminants.lean`: all-dimensional
  reciprocal-root Hankel determinant and its shifted variants, with
  explicit nondegeneracy (distinct squared reciprocal distances).
- `S03_Theorem_3_9_CharacterFeketeKernels.lean`: exact five Fekete
  factorizations and pointwise strict positivity of all five rational
  Dirichlet-character kernels on the open unit interval.

## Trust and scope

- All mathematical statements above are unconditional finite algebra.
- No `sorry`, `admit`, custom `axiom`, or postulated witness is introduced.
- They do **not** prove the manuscript's continuous-measure total positivity,
  full L-function integration identities, or quantitative irrationality estimates.
- Existing proof files remain byte-identical to v0.3.18.
- Lean has NOT been run in the assistant environment. The user's native Lean
  4.33.0 compiler remains the only verification authority.
- Existing persistent PASS_ONCE cache and single-writer `run.cmd recover`
  mode are retained. Exactly one `run.cmd` in the archive.

The latest user-provided PASS with 134 frozen modules belongs to the
separate `PAPER_CHRONOLOGICAL_NATIVE_LEAN` package family. It is not silently
transferred into the ZETAHYPERBOLIC cache or counted as a pass of this ZIP.
