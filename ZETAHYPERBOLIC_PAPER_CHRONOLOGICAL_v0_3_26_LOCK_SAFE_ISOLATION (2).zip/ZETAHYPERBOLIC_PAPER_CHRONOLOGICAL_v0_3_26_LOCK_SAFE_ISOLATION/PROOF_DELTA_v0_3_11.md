# v0.3.11 substantive proof delta

| Paper result | New theorem | Status |
|---|---|---|
| Theorem 3.8, finite pole kernel | `poleKernel_transpose`, `poleKernel_symmetric` | unconditional algebra, analytic CD identification open |
| Theorem 5.2(1), finite dual slope | `entry_slope`, `slope_eq_coeff_gram`, `slope_transpose_eq`, `slope_diagonal_nonnegative` | unconditional finite algebra, complete dual hyperbolicity and Krein decomposition open |
| Theorem 4.4 | `PAPER_SINGLE_WITNESS_CHAIN` unchanged from v0.3.10 | witness-dependent; awaits user compiler result |

No `sorry`/`admit`/custom axioms are introduced. No local Lean compilation was performed.

| Theorem 5.2(1), real Gram energy | `realCoefficientGram_energy`, `realCoefficientGram_nonnegative` | sum-of-squares identity and positive semidefiniteness, full rank separately required for strict positivity |

| Theorem 5.2(1), strict real slope positivity | `realCoefficientGram_posDef` | full row rank supplied as the paper’s explicit polynomial independence assumption (not the Diophantine Witness) |
