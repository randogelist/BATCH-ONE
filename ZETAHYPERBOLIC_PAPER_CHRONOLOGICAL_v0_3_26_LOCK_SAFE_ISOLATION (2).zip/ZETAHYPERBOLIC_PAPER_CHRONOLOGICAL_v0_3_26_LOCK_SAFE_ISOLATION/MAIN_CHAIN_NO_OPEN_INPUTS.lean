import MAIN_CHAIN_ASSEMBLED
import PAPER_SECTION3_CORRECTIONS
import PAPER_FINITE_MOMENTS

/-!
# Unconditional native odd-weight spectral endpoints

This module supplies *all mathematical inputs* to the §2-§3.1 pencil
architecture. The admissibility conditions below are elementary numerical
conditions on parameters, not open mathematical hypotheses.

This does NOT establish §4.4's irrationality-measure exponent, §4.5's
mixed irrationality, nor all §5-§6 claims. Unsupported manuscript statements
are corrected or excluded, never admitted.
-/

namespace PaperNoOpenInputs

open ManuscriptChain

/-- Actual manuscript Theorem 3.1, all admissible positive odd weights. -/
theorem THEOREM_3_1 (p : Real.Parameters) (hp : Real.Admissible p) :
    General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- Exact positive root-free radius (including boundary attainment). -/
theorem THEOREM_3_1_EXACT_RADIUS (p : Real.Parameters)
    (hp : Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (Real.zeta p.weight : ℂ)‖ < radius →
        ¬ General.ComplexRoot p z) ∧
      (∃ z : ℂ, General.ComplexRoot p z ∧
        ‖z - (Real.zeta p.weight : ℂ)‖ = radius) :=
  ManuscriptChain.EXACT_ZERO_FREE_DISK p hp

/-- A no-input instance for ζ(3), k=1,m=1,N=1,K=2. -/
def zeta3Case : Real.Parameters := ⟨1, 1, 1, 2⟩

private theorem zeta3Case_ok : Real.Admissible zeta3Case := by
  exact ⟨by decide, by decide, by decide, by decide⟩

theorem ZETA3_SPECTRAL : General.GeneralStatement zeta3Case :=
  THEOREM_3_1 zeta3Case zeta3Case_ok

/-- A no-input instance at the paper's weight-five parameter ratio. -/
def zeta5Case : Real.Parameters := ⟨2, 3, 3, 30⟩

private theorem zeta5Case_ok : Real.Admissible zeta5Case := by
  exact ⟨by decide, by decide, by decide, by decide⟩

theorem ZETA5_SPECTRAL : General.GeneralStatement zeta5Case :=
  THEOREM_3_1 zeta5Case zeta5Case_ok

/-- A no-input instance at the paper's weight-seven parameter ratio. -/
def zeta7Case : Real.Parameters := ⟨3, 4, 3, 40⟩

private theorem zeta7Case_ok : Real.Admissible zeta7Case := by
  exact ⟨by decide, by decide, by decide, by decide⟩

theorem ZETA7_SPECTRAL : General.GeneralStatement zeta7Case :=
  THEOREM_3_1 zeta7Case zeta7Case_ok

end PaperNoOpenInputs

#print axioms PaperNoOpenInputs.THEOREM_3_1
#print axioms PaperNoOpenInputs.THEOREM_3_1_EXACT_RADIUS
#print axioms PaperNoOpenInputs.ZETA3_SPECTRAL
#print axioms PaperNoOpenInputs.ZETA5_SPECTRAL
#print axioms PaperNoOpenInputs.ZETA7_SPECTRAL
