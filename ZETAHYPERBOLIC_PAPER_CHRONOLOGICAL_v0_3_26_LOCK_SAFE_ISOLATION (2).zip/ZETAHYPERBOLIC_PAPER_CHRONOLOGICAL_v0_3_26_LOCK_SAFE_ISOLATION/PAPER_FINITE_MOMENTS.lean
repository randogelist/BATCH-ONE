import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Mathlib.Tactic

/-!
# Paper §5, algebraic moment identities

The following are exact rational moment identities. They DO NOT pretend
that the positive two-variable integral or the unbounded signed Krein
remainder was discharged here. The full analytic §5 identities remain
outside the unconditional theorem graph.
-/

namespace PaperFiniteMoments

open ManuscriptChain

/-- Diagonal coefficient of the dual pencil: the zeta term has slope 1. -/
theorem dual_diagonal (r : ℕ) :
    Real.dualConstant 7 r r = -Real.harmonic 7 r := by
  simp [Real.dualConstant]

/-- Off-diagonal divided difference is rational and has no zeta term. -/
theorem dual_offdiagonal (r t : ℕ) (h : r ≠ t) :
    Real.dualConstant 7 r t =
      (Real.harmonic 6 r - Real.harmonic 6 t) /
        (6 * ((r : ℚ) - (t : ℚ))) := by
  simp [Real.dualConstant, h]

/-- The finite harmonic increment supplies the simple even-pole
    cancellation used in Theorem 5.4. -/
theorem odd_harmonic_increment (k j : ℕ) :
    Real.harmonic (2*k+1) (j+1) - Real.harmonic (2*k+1) j =
      1 / (((j+1 : ℕ) : ℚ) ^ (2*k+1)) := by
  simp [Real.harmonic, Finset.sum_range_succ]

end PaperFiniteMoments

#print axioms PaperFiniteMoments.dual_diagonal
#print axioms PaperFiniteMoments.dual_offdiagonal
#print axioms PaperFiniteMoments.odd_harmonic_increment
