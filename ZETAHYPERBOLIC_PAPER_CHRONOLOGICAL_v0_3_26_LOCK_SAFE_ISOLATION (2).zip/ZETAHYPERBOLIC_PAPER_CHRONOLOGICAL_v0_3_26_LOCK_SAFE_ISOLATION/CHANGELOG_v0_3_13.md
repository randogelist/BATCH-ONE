# v0.3.13 — Arbitrary atomic moment energy and reciprocal-root correction

Source-only Lean proof extension; no local compilation.

- New `S03_Theorem_3_3_AtomicMomentEnergy`: full finite-dimensional Hankel quadratic energy identity for any number of real support nodes, arbitrary nonnegative masses, arbitrary Hankel truncation size, plus a detection-based strict positivity criterion and symmetry.
- New `S03_Corollary_3_6_ReciprocalRoots`: exact reciprocal squared-distance atoms and positive-semidefinite power-sum Hankel forms of every order, avoiding the manuscript's incorrect strict positivity beyond finite support rank.
- No edits to previously passed Lean modules. 2 new modules inserted chronologically in dependency-sorted FASTCORE run order.
- The one Witness endpoint remains separate and conditional; no new custom axiom, sorry, admit, or unproved parameter declaration.
- A valid native Lean 4.33.0 build and axiom audit can be provided only by the user's compiler.
