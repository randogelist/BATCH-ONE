import PaperNative.SECTION_02_03
import Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5

/-!
# The paper's one explicit unproved input: Witness

This is a SINGLE named object (not a new assumption declaration and
not an assertion that it exists). It packages three independent, substantive
uniform inequalities at the actual K=30n, N=3n, m=3, k=2 primitive Hankel
family. It assumes *none* of the final irrationality or measure statements.

- p-adic/prime integrality: the primitive multiplier has the required rate;
- archimedean/energy: the scaled determinant has the required quadratic rate;
- real spectral separation: the constructed spectrum satisfies rho=11.411.

All other construction, positivity, nonvanishing, exact degree, normalization,
index selection, irrationality transfer, and the Mathlib zeta identification
are inherited as proved theorems. Supplying `Witness` is the only additional
open argument to the new Section 4 endpoints. No proof of existence is given.
-/

noncomputable section

namespace PaperNative
open ManuscriptChain

/-- The family's structural admissibility needs no input from the witness. -/
theorem section4_admissible (n : ℕ) (hn : 1 ≤ n) :
    Real.Admissible (Real.mainParameters n) := by
  refine ⟨?_, ?_, ?_, ?_⟩ <;>
    dsimp [Real.mainParameters] <;> omega

/-- All Gram-positivity proof obligations are discharged unconditionally. -/
theorem section4_gram_positive (start : ℕ) :
    ∀ n, start + 1 ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef := by
  intro n hn
  have hnonzero : 1 ≤ n := by omega
  have h := ManuscriptChain.GRAM_POSITIVE
    (Real.mainParameters n) (section4_admissible n hnonzero)
  simpa [ManuscriptChain.General.GramPositive,
    Real.mainParameters, Real.Parameters.weight] using h

/-- The single conditional interface. Quantitative claims are NOT assumed
    true in Lean: a user must later construct an actual value of this type.

    `start` is the finite onset of all three eventual bounds.
    `multiplier` encodes the prime-value arithmetic bound;
    `archimedean` encodes the determinant/energy bound;
    `spectral` encodes the quantitative zero-free disk.
    The root factorization itself is proved from `section4_gram_positive`. -/
structure Witness where
  start : ℕ
  multiplier : MainChain.MultiplierUpper (MainChain.primitiveMainNormalization start)
  archimedean : MainChain.ArchimedeanUpper (start + 1)
  spectral : ∀ n (hn : start + 1 ≤ n) i,
    |(MainChain.mainRootFactorization (start + 1)
      (section4_gram_positive start) n hn).beta i| ≤
      _root_.Real.exp ((Real.rhoPrinted : ℝ) * MainChain.mainK n)

end PaperNative
