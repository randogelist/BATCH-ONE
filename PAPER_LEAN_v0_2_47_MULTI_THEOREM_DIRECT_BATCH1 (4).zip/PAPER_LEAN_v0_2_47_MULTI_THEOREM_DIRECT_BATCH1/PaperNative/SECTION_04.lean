import PaperNative.WITNESS
import MAIN_CHAIN_IRRATIONALITY
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion

/-!
# PDF, Section 4: single Witness -> exact quantitative endpoint

The actual primitive integer polynomials are built by `primitiveMainNormalization`.
The index budget for 25687 is already proved in the source. No fake witness or
paper's final conclusion is inserted into the Witness fields.
-/

noncomputable section

namespace PaperNative
open ManuscriptChain

/-- Theorem 4.4: the stated effective irrationality measure, conditional on
    exactly one explicitly typed `Witness` argument. -/
theorem THEOREM_4_4_EFFECTIVE_MEASURE (w : Witness) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b →
      MainChain.indexDenominatorThreshold (w.start + 1) ≤ b →
      1 / (b : ℝ) ^ 25687 <
        |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| :=
  ManuscriptChain.theorem_4_4_measure_primitive_from_gram
    w.start (section4_gram_positive w.start)
    w.multiplier w.archimedean w.spectral

/-- Theorem 4.4: irrationality of the ACTUAL zeta(5), not a free variable. -/
theorem THEOREM_4_4_IRRATIONAL_ZETA5 (w : Witness) :
    Irrational (riemannZeta 5).re :=
  ManuscriptChain.theorem_4_4_irrationality_primitive_from_gram
    w.start (section4_gram_positive w.start)
    w.multiplier w.archimedean w.spectral

/-- A genuine output of the witness: integer polynomial degree and positivity
    are not conditional assumptions. -/
theorem THEOREM_4_4_PRIMITIVE_FAMILY
    (w : Witness) (n : ℕ) (hn : w.start + 1 ≤ n) :
    ((MainChain.primitiveMainNormalization w.start).Q n).IsPrimitive ∧
    ((MainChain.primitiveMainNormalization w.start).Q n).natDegree = 27 * n := by
  exact ⟨MainChain.primitiveMainNormalization_isPrimitive w.start n,
    MainChain.MainNormalization.natDegree_eq
      (MainChain.primitiveMainNormalization w.start) n hn⟩

end PaperNative
