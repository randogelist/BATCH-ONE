import PaperNative.MAIN_CHAIN

/-!
# Trust-boundary audit for the ACTUAL endpoint, not an abstract theorem

Inspect both `#check` (its explicit remaining Witness argument) and
`#print axioms` (which must not include sorryAx or any custom axiom).
Only the standard Lean logical axioms are admissible here:
propext, Classical.choice, Quot.sound.

A standard-axiom report does NOT construct `Witness`.
-/

#check PaperNative.Witness
#check PaperNative.section4_gram_positive
#check PaperNative.THEOREM_2_4_PRIMITIVE_INTEGER_POLYNOMIAL
#check PaperNative.THEOREM_2_5_EXACT_DEGREE
#check PaperNative.THEOREM_3_1_UNIVERSAL_HYPERBOLICITY
#check PaperNative.THEOREM_3_1_EXACT_ZERO_FREE_DISK
#check PaperNative.THEOREM_4_4_EFFECTIVE_MEASURE
#check PaperNative.THEOREM_4_4_IRRATIONAL_ZETA5
#check PaperNative.THEOREM_4_4_PRIMITIVE_FAMILY
#check PaperNative.THEOREM_5_1_RATIONAL_DIAGONAL
#check PaperNative.MAIN_CHAIN

#print axioms PaperNative.THEOREM_2_5_EXACT_DEGREE
#print axioms PaperNative.THEOREM_3_1_UNIVERSAL_HYPERBOLICITY
#print axioms PaperNative.section4_gram_positive
#print axioms PaperNative.THEOREM_4_4_EFFECTIVE_MEASURE
#print axioms PaperNative.THEOREM_4_4_IRRATIONAL_ZETA5
#print axioms PaperNative.MAIN_CHAIN
