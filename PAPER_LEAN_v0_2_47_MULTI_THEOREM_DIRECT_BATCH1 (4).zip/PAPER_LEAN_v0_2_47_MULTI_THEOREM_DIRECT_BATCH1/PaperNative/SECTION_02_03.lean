import MAIN_CHAIN_ASSEMBLED
import MAIN_CHAIN_IRRATIONALITY
import Theorem_2_4_Canonical_Basis_Invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# PDF, Sections 2--3: exact rational construction and spectral chain

All named results in this file use the manuscript's actual rational moments,
not abstract surrogate polynomial data. All theorems are unconditional apart
from ordinary mathematical parameter admissibility (k,m,N>=1, N<K).

This module does NOT assert the incorrect unnormalized equation (3.6),
incorrect finite-rank moment inequality of Corollary 3.6, or pairwise simple
spectrum: the spectral theorem establishes real roots, not simplicity.
-/

noncomputable section
open Polynomial

namespace PaperNative
open ManuscriptChain

/-- Definition 2.1 and Theorem 2.5: exact degree from the residue pencil. -/
theorem THEOREM_2_5_EXACT_DEGREE (p : Real.Parameters) :
    (Real.delta p).natDegree = p.h :=
  General.delta_degree p

/-- Theorem 2.5: the derivative matrix is nonsingular. -/
theorem THEOREM_2_5_DERIVATIVE_NONSINGULAR (p : Real.Parameters) :
    (Real.derivativeMatrix p).det ≠ 0 :=
  General.derivative_nonsingular p

/-- Section 2: the primitive integer determinant is constructed internally. -/
theorem THEOREM_2_4_PRIMITIVE_INTEGER_POLYNOMIAL (p : Real.Parameters) :
    (GeneralIrrationality.primitivePolynomial p).IsPrimitive :=
  GeneralIrrationality.primitivePolynomial_isPrimitive p

/-- Theorem 3.1: unconditional on the analytic side for all odd weights. -/
theorem THEOREM_3_1_UNIVERSAL_HYPERBOLICITY
    (p : Real.Parameters) (hp : Real.Admissible p) :
    General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- Theorem 3.1: center positivity is established, not assumed. -/
theorem THEOREM_3_1_GRAM_POSITIVE
    (p : Real.Parameters) (hp : Real.Admissible p) :
    (Real.gram p (Real.zeta p.weight)).PosDef :=
  ManuscriptChain.GRAM_POSITIVE p hp

/-- Theorem 3.1: exact positive zero-free radius and boundary root. -/
theorem THEOREM_3_1_EXACT_ZERO_FREE_DISK
    (p : Real.Parameters) (hp : Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (Real.zeta p.weight : ℂ)‖ < radius →
        ¬ General.ComplexRoot p z) ∧
      (∃ z : ℂ, General.ComplexRoot p z ∧
        ‖z - (Real.zeta p.weight : ℂ)‖ = radius) :=
  ManuscriptChain.EXACT_ZERO_FREE_DISK p hp

end PaperNative
