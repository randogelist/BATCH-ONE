import PaperNative.SECTIONS_05_06

/-!
# Rebuilt main chronological spine of the paper

(2.1, 2.4, 2.5) actual rational moments -> primitive determinant and degree
(3.1) analytic realization -> positivity -> real spectrum -> zero-free disk
(4.1) polynomial transfer (reused fully proved source)
(4.4) quantitative Witness -> effective zeta(5) measure and irrationality
(5--6) rational finite bridges compiled separately, NOT confused with a
        proof of every 52-page assertion.

ONLY ADDITIONAL MATHEMATICAL FRONTIER IN THIS ENDPOINT: (w : Witness).
The structural `(p : Parameters)` / `(hp : Admissible p)` refer to the
finite dimensions, not to an unproved analytic claim.
-/

noncomputable section
namespace PaperNative
open ManuscriptChain

/-- The full established spine: universal spectral theorem together with the
    actual zeta(5) effective endpoint. Printed false propositions and
    still-open Sections 5--6 claims are not stated as proved. -/
theorem MAIN_CHAIN (w : Witness) :
    (∀ p : Real.Parameters, Real.Admissible p → General.GeneralStatement p) ∧
    (∀ a : ℤ, ∀ b : ℕ, 0 < b →
      MainChain.indexDenominatorThreshold (w.start + 1) ≤ b →
      1 / (b : ℝ) ^ 25687 <
        |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)|) ∧
    Irrational (riemannZeta 5).re := by
  refine ⟨?_, ?_, ?_⟩
  · intro p hp
    exact THEOREM_3_1_UNIVERSAL_HYPERBOLICITY p hp
  · exact THEOREM_4_4_EFFECTIVE_MEASURE w
  · exact THEOREM_4_4_IRRATIONAL_ZETA5 w

end PaperNative
