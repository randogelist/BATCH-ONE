import PaperNative.SECTION_04
import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil
import Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7
import Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4
import Zetahyperbolic.Theorem_6_9_Triple_Pole_Hermite_Repair
import Zetahyperbolic.Theorem_6_10_Finite_Determinant_Identity
import Zeta5Merge.Theorem6_16
import Zeta5Merge.Theorem6_17
import Zeta5Merge.Theorem6_18

/-!
# PDF, Sections 5--6: formally present portions (not the whole PDF)

Some named source files have much weaker theorems than the PDF's full claims.
In particular, 5.1's integral identity and 5.2's unconditional infinite
Krein cone construction are not established by the source files. This module
keeps their finite/rational implications honestly scoped. Theorem 6.4(1)'s
printed positive differential weight has a sign error and is excluded.

No extra hypothesis beyond `Witness` is imported into the MAIN endpoint;
the theorem below about the finite 5.2 cone deliberately exposes the
finite-certificate assumption in its OWN auxiliary theorem statement.
-/

noncomputable section
namespace PaperNative
open ManuscriptChain

/-- Theorem 5.1's unconditional rational diagonal (not its missing
    two-variable integral identity). -/
theorem THEOREM_5_1_RATIONAL_DIAGONAL (s r : ℕ) :
    Real.dualConstant s r r = - Real.harmonic s r := by
  simp [Real.dualConstant]

/-- Theorem 5.2's finite positive-cone implication with its honest input.
    This auxiliary statement is NOT used to prove the final Section 4 result. -/
theorem THEOREM_5_2_FINITE_CONE
    {h K M : ℕ} (c : Fin h → Fin (K + 1) → ℚ)
    (tail : Extensions.WeightSevenTailBound c M)
    (cert : Extensions.FinitePositiveCertificate c M) :
    Extensions.PositiveQForm (Extensions.weightSevenGram c) :=
  Extensions.weight_seven_positive_from_finite_certificate c tail cert

end PaperNative
