# v0.2.10 -- finite power-sum lemma / Lean elaboration repair

- Compiler report: `PaperChronological/T3_6_Corrected.lean:31:6` failed to apply `Finset.single_le_sum`.
- Repair: explicit nonnegativity proof for all indices of `Finset.univ`; explicit `f` and `s` arguments.
- Changed Lean source: `PaperChronological/T3_6_Corrected.lean` (SHA256 `13357179c9bf5c24a9e2a6122cde09de3af862215bd5bd1e0aa59d6e3e58e2c0` -> `1b9818c6d2b2a688ea6a564f829082a6e7047c1c93590e47ce5edfe5c6f0c657`).
- Unchanged Lean sources: 128.
- No local Lean compilation was performed.
- Build: `run.cmd recover`, with the previous PASS-ONCE cache; no deletion of cached `.olean` files.
- The stronger all-orders strict Stieltjes Hankel positivity is not asserted (false beyond finite support rank).
