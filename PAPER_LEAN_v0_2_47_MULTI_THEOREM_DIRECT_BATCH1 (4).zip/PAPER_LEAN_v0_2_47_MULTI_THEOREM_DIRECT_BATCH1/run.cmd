@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0"
if errorlevel 1 (echo ERROR=CANNOT_ENTER_PACKAGE_DIRECTORY & exit /b 1)

rem PAPER CHRONOLOGICAL: PASS-ONCE / FREEZE / INCREMENTAL
rem Persistent user-side olean cache shared across ZIP versions.
rem Only compile modules whose sources or transitively imported modules changed.
rem Frozen Lean proof sources unchanged. Principal theorem modules additive.
rem Native Windows CMD / Lean 4.33.0 only. No Lake, Python, PowerShell or WSL.

set "LOG=%CD%\CHRONOLOGICAL_LEAN_433_LOG.txt"
set "PACKAGE=PAPER_LEAN_v0_2_47_MULTI_THEOREM_DIRECT_BATCH1"
set "LEAN_HOME=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
set "LEAN_EXE=%LEAN_HOME%\bin\lean.exe"
set "STDLIB=%LEAN_HOME%\lib\lean"
set "BASE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
set "MATHLIB_OLEAN=%BASE_ROOT%\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean"
set "LEAN_NUM_THREADS=16"
set "LEAN_JOBS=16"
set "CACHE_ROOT=%USERPROFILE%\lean-native\paper_chronological_fastcore_433"
set "OUTDIR=%CACHE_ROOT%\lib\lean"
set "STAMP_DIR=%CACHE_ROOT%\source_stamps"
set "CHANGED_DIR=%CACHE_ROOT%\changed_this_run"
set "STAGING_DIR=%CACHE_ROOT%\staging_olean"
set "MODULE_LOGS=%CACHE_ROOT%\module_logs"
set "LOCKDIR=%CACHE_ROOT%\active_run.lock"
set "T5_1_RECHECKED=%CACHE_ROOT%\T5_1_IO_RECOVERY_20261024.PASS"
set "SIG=%CACHE_ROOT%\toolchain.signature"
set "NEW_SIG=%CACHE_ROOT%\toolchain.signature.new"
set "MANIFEST=%CACHE_ROOT%\PASS_HISTORY.csv"
set "LEGACY_ROOT=%USERPROFILE%\Downloads\PAPER_CHRONOLOGICAL_NATIVE_LEAN_v0_2_2_FASTCORE_STARTUP_FIX1"
set "LEGACY_BUILD=%LEGACY_ROOT%\.build"
set "REBUILD_ALL=0"
set "RECOVER_STALE=0"
if /I "%~1"=="recover" set "RECOVER_STALE=1"
set /a BUILT=0
set /a REUSED=0
set /a SEED_OLD=0
if /I "%~1"=="full" set "REBUILD_ALL=1"

>"%LOG%" echo PACKAGE=%PACKAGE%
>>"%LOG%" echo RUNNER=PASS_ONCE_FASTCORE_NATIVE_LEAN_433_LOCK_SAFE_RECOVERY
echo PACKAGE=PAPER_LEAN_v0_2_47_MULTI_THEOREM_DIRECT_BATCH1
>>"%LOG%" echo WORKFLOW=ONLY_CHANGED_SOURCES_AND_DEPENDENTS
>>"%LOG%" echo WIN_LOCK_FIX=ATOMIC_STAGED_OLEAN_PER_MODULE_LOG_RETRY
>>"%LOG%" echo FAILURE_DIAGNOSTICS=EXACT_MODULE_EXIT_CODE_AND_PRIVATE_COMPILER_LOG
>>"%LOG%" echo STALE_LOCK_RECOVERY=EXPLICIT_RECOVER_ARGUMENT_AND_NO_ACTIVE_LEAN_PROCESS
>>"%LOG%" echo T6_10_RESTART=ONE_THREAD_FALLBACK
>>"%LOG%" echo LOCK_AFFECTED_THEOREM_5_1=ONE_TIME_RECHECK
>>"%LOG%" echo PREVIOUSLY_PASSED_SOURCE_FILES=UNCHANGED
>>"%LOG%" echo PRINCIPAL_THEOREM_TRANSITION=NEW_SECTION3_DIRECT_PROOFS
>>"%LOG%" echo PRINCIPAL_STAGE3=ACTUAL_SIGNED_DERIVATIVE_STRICT_TURAN_AND_POLE_KERNEL_DET
>>"%LOG%" echo PRINCIPAL_T3_3_DIAGONAL_SUM_FIX=EXPLICIT_FINSET_COLLAPSE
>>"%LOG%" echo PRINCIPAL_T3_7_PROD_INSERT_FIX=EXPLICIT_ERASE_NONMEMBERSHIP
>>"%LOG%" echo PRINCIPAL_STAGE4=ACTUAL_ZETA_CHARPOLY_EQUIVALENCE_AND_EXACT_BILATERAL_GAP
>>"%LOG%" echo PRINCIPAL_STAGE5=PDF_WIDE_DIRECT_THEOREMS_3_5_3_6_3_9_4_8_5_2_6_1
>>"%LOG%" echo LEAN_TOOLCHAIN=4.33.0
>>"%LOG%" echo LEAN_THREADS=%LEAN_JOBS%
>>"%LOG%" echo SINGLE_QUANTITATIVE_WITNESS=EXPLICIT
>>"%LOG%" echo NO_LEAN_COMPILATION_WAS_PERFORMED_WHILE_PACKAGING=YES
>>"%LOG%" echo CACHE_ROOT=%CACHE_ROOT%

echo RUNNER=PASS_ONCE_FASTCORE_NATIVE_LEAN_433_LOCK_SAFE_RECOVERY
echo PACKAGE=PAPER_LEAN_v0_2_47_MULTI_THEOREM_DIRECT_BATCH1
echo MODE=ONLY_CHANGED_SOURCES_AND_IMPORT_DEPENDENTS
echo CACHE_ROOT=%CACHE_ROOT%

rem v0.2.44: explicit erased-index nonmembership for the strict Turan product.
findstr /L /C:"have ha_not : a " "PaperChronological\Principal_T3_7_StrictActual.lean" >nul
if errorlevel 1 (
  >>"%LOG%" echo ERROR=PRINCIPAL_T3_7_ERASE_PATCH_MISSING
  echo ERROR=PRINCIPAL_T3_7_ERASE_PATCH_MISSING
  goto failed
)
echo PRINCIPAL_T3_7_ERASE_FIX=PRESENT
>>"%LOG%" echo PRINCIPAL_T3_7_ERASE_FIX=PRESENT

rem Stop immediately if the older unpatched v0.2.13 source was extracted instead.
findstr /L /C:"exact (poleIndex_injective p) hab" "PaperChronological\S2_CanonicalPresentation.lean" >nul
if errorlevel 1 (
  >>"%LOG%" echo ERROR=SECTION2_INJECTIVITY_PATCH_MISSING
  echo ERROR=SECTION2_INJECTIVITY_PATCH_MISSING
  goto failed
)
echo SECTION2_INJECTIVITY_FIX=PRESENT
>>"%LOG%" echo SECTION2_INJECTIVITY_FIX=PRESENT

rem Ensure v0.2.22+ Section 2 residue denominator normalization is present.
findstr /L /C:"change ManuscriptChain.Real.residue p d 0 a =" "PaperChronological\S2_IndependentKernelBridge.lean" >nul
if errorlevel 1 (
  >>"%LOG%" echo ERROR=SECTION2_KERNEL_DENOM_NORMALIZATION_PATCH_MISSING
  echo ERROR=SECTION2_KERNEL_DENOM_NORMALIZATION_PATCH_MISSING
  goto failed
)
echo SECTION2_KERNEL_BRIDGE_FIX=PRESENT
>>"%LOG%" echo SECTION2_KERNEL_BRIDGE_FIX=PRESENT

rem Verify the actual v0.2.24+ native setoid fix is present before compilation.
findstr /L /C:"exact sameFinitePoleData_symm R S hRS" "PaperChronological\S2_DirectedUnionMoment.lean" >nul
if errorlevel 1 (
  >>"%LOG%" echo ERROR=SECTION2_SETOID_EQUIVALENCE_PATCH_MISSING
  echo ERROR=SECTION2_SETOID_EQUIVALENCE_PATCH_MISSING
  goto failed
)
echo SECTION2_SETOID_EQUIVALENCE_FIX=PRESENT

rem v0.2.28: verify the two-quotient congruence argument order.
findstr /L /C:"sameFinitePoleData_add r s r' s' hr hs" "PaperChronological\S2_GlobalLinearOperations.lean" >nul
if errorlevel 1 (
  >>"%LOG%" echo ERROR=SECTION2_QUOTIENT_ADDITION_CONGRUENCE_PATCH_MISSING
  echo ERROR=SECTION2_QUOTIENT_ADDITION_CONGRUENCE_PATCH_MISSING
  goto failed
)
echo SECTION2_QUOTIENT_ADD_FIX=PRESENT
>>"%LOG%" echo SECTION2_QUOTIENT_ADD_FIX=PRESENT
>>"%LOG%" echo SECTION2_SETOID_EQUIVALENCE_FIX=PRESENT

if not exist "%LEAN_EXE%" (
  >>"%LOG%" echo ERROR=LEAN_433_BINARY_MISSING
  goto failed
)
if not exist "%MATHLIB_OLEAN%" (
  >>"%LOG%" echo ERROR=PREBUILT_MATHLIB_MISSING
  goto failed
)
if not exist "%STDLIB%\Lean\Elab\Command.olean" (
  >>"%LOG%" echo ERROR=STDLIB_MISSING
  goto failed
)
if not exist "BUILD_GRAPH.txt" (
  >>"%LOG%" echo ERROR=BUILD_GRAPH_MISSING
  goto failed
)
"%LEAN_EXE%" --version >>"%LOG%" 2>&1
if errorlevel 1 goto failed
findstr /C:"4.33.0" "%LOG%" >nul
if errorlevel 1 (
  >>"%LOG%" echo ERROR=WRONG_LEAN_TOOLCHAIN
  goto failed
)

if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
if errorlevel 1 goto failed
rem A directory lock serializes writes to the PASS-ONCE .olean cache.
rem Recover an abandoned lock ONLY after an explicit "recover" argument.
rem An active lean.exe process blocks recovery; see PASS_ONCE_PROTOCOL.md.
2>nul mkdir "%LOCKDIR%"
if errorlevel 1 (
  if "%RECOVER_STALE%"=="1" (
    call :recoverStaleLock
    if errorlevel 1 goto failed
    2>nul mkdir "%LOCKDIR%"
  )
)
if errorlevel 1 (
  >>"%LOG%" echo ERROR=CACHE_ALREADY_IN_USE_OR_STALE_LOCK
  >>"%LOG%" echo RECOVERY_HINT=call run.cmd recover
  echo ERROR=CACHE_ALREADY_IN_USE_OR_STALE_LOCK
  echo RECOVERY_HINT=call run.cmd recover
  echo LOCKDIR=%LOCKDIR%
  goto failed
)
set "HAS_LOCK=1"

rem The cache signature changes only for toolchain/dependency changes,
rem NOT for different ZIP versions or unrelated manuscript source changes.
>"%NEW_SIG%" echo TOOLCHAIN=LEAN_433_PASS_ONCE_V1
>>"%NEW_SIG%" echo LEAN_EXE=%LEAN_EXE%
>>"%NEW_SIG%" echo MATHLIB_ROOT=%BASE_ROOT%
for %%I in ("%LEAN_EXE%") do >>"%NEW_SIG%" echo LEAN_BINARY=%%~zI,%%~tI
for %%I in ("%MATHLIB_OLEAN%") do >>"%NEW_SIG%" echo MATHLIB_OLEAN=%%~zI,%%~tI
for %%I in ("%STDLIB%\Lean\Elab\Command.olean") do >>"%NEW_SIG%" echo LEAN_STD_COMMAND=%%~zI,%%~tI

rem Optional one-time migration of the previous version's successfully built
rem modules. Each old .olean must have a matching old source stamp; copied
rem snapshots are checked against this ZIP before reusing any module.
if not exist "%SIG%" if "%REBUILD_ALL%"=="0" call :migrateLegacy

if exist "%SIG%" (
  fc /B "%SIG%" "%NEW_SIG%" >nul 2>nul
  if errorlevel 1 set "REBUILD_ALL=1"
) else (
  rem An empty cache needs initial compilation; never call it already proved.
  set "REBUILD_ALL=1"
)

if "%REBUILD_ALL%"=="1" (
  echo CACHE_MODE=REBUILD_PROJECT_ONLY
  >>"%LOG%" echo CACHE_MODE=REBUILD_PROJECT_ONLY
  if exist "%OUTDIR%" rmdir /S /Q "%OUTDIR%"
  if exist "%STAMP_DIR%" rmdir /S /Q "%STAMP_DIR%"
) else (
  echo CACHE_MODE=PASS_ONCE_REUSE
  >>"%LOG%" echo CACHE_MODE=PASS_ONCE_REUSE
)
copy /Y "%NEW_SIG%" "%SIG%" >nul
if errorlevel 1 goto failed
del /Q "%NEW_SIG%" >nul 2>nul
if not exist "%OUTDIR%" mkdir "%OUTDIR%"
if not exist "%STAMP_DIR%" mkdir "%STAMP_DIR%"
if not exist "%STAGING_DIR%" mkdir "%STAGING_DIR%"
if not exist "%MODULE_LOGS%" mkdir "%MODULE_LOGS%"
if exist "%CHANGED_DIR%" rmdir /S /Q "%CHANGED_DIR%"
mkdir "%CHANGED_DIR%"
if errorlevel 1 goto failed

rem LEAN_PATH uses cached project oleans, precompiled Lean stdlib and Mathlib.
set "LEAN_PATH=%OUTDIR%;%STDLIB%"
if exist "%BASE_ROOT%\.lake\build\lib\lean" (
  set "LEAN_PATH=!LEAN_PATH!;%BASE_ROOT%\.lake\build\lib\lean"
)
set /a ROOTS=0
for /D %%P in ("%BASE_ROOT%\.lake\packages\*") do (
  if exist "%%~fP\.lake\build\lib\lean" (
    set "LEAN_PATH=!LEAN_PATH!;%%~fP\.lake\build\lib\lean"
    set /a ROOTS+=1 >nul
  )
)
>>"%LOG%" echo PREBUILT_LIBRARY_ROOTS=!ROOTS!
if not exist "%MANIFEST%" (
  >"%MANIFEST%" echo Source,Result,LeanCompiler,DependencyCache
)

rem The package generator topologically verified BUILD_GRAPH.txt, including
rem every project-local `import` edge. A direct-import rebuild propagates ONLY
rem through dependent files; unrelated previously passed modules stay frozen.
for /F "usebackq tokens=1,2,* delims=|" %%A in ("BUILD_GRAPH.txt") do (
  call :compile "%%A" "%%B" "%%C"
  if errorlevel 1 goto buildfailed
)

findstr /I /C:"sorryAx" /C:"native_decide.ax_" "%LOG%" >nul 2>nul
if not errorlevel 1 (
  >>"%LOG%" echo ERROR=UNACCEPTED_AXIOM_APPEARS_IN_NEW_AUDIT
  goto failed
)
>>"%LOG%" echo PROJECT_MODULES_NEW_OR_CHANGED=!BUILT!
>>"%LOG%" echo PROJECT_MODULES_FROZEN_REUSED=!REUSED!
>>"%LOG%" echo LEGACY_MODULES_IMPORTED=!SEED_OLD!
>>"%LOG%" echo CHRONOLOGICAL_BUILD=PASS
>>"%LOG%" echo FULL_PAPER_CLOSED=NO
>>"%LOG%" echo WITNESS_EXISTENCE_PROVED=NO
>>"%LOG%" echo RUN_EXIT_CODE=0

echo PROJECT_MODULES_NEW_OR_CHANGED=!BUILT!
echo PROJECT_MODULES_FROZEN_REUSED=!REUSED!
echo CHRONOLOGICAL_BUILD=PASS
echo AXIOM_AUDIT=CHECK_RUN_LOG
echo LOG=%LOG%
if defined HAS_LOCK call :releaseOwnedLock
popd
exit /b 0


:recoverStaleLock
rem User explicitly requested recovery and is responsible for closing other builds.
rem Refuse when a Lean compiler is currently running (in any project).
if not exist "%LOCKDIR%" exit /b 0
if not exist "%SystemRoot%\System32\tasklist.exe" (
  >>"%LOG%" echo ERROR=TASKLIST_UNAVAILABLE_STALE_LOCK_NOT_REMOVED
  echo ERROR=TASKLIST_UNAVAILABLE_STALE_LOCK_NOT_REMOVED
  exit /b 1
)
set "RECOVERY_LEAN_RUNNING=0"
for /F "tokens=1 delims=," %%P in ('"%SystemRoot%\System32\tasklist.exe" /FI "IMAGENAME eq lean.exe" /FO CSV /NH 2^>nul') do (
  if /I "%%~P"=="lean.exe" set "RECOVERY_LEAN_RUNNING=1"
)
if "%RECOVERY_LEAN_RUNNING%"=="1" (
  >>"%LOG%" echo ERROR=RECOVERY_REFUSED_ACTIVE_LEAN_PROCESS
  echo ERROR=RECOVERY_REFUSED_ACTIVE_LEAN_PROCESS
  exit /b 1
)
rem Never touch source_stamps, cached oleans, or PASS_HISTORY during recovery.
rmdir /S /Q "%LOCKDIR%" >nul 2>nul
if exist "%LOCKDIR%" (
  >>"%LOG%" echo ERROR=STALE_LOCK_CANNOT_BE_REMOVED
  echo ERROR=STALE_LOCK_CANNOT_BE_REMOVED
  exit /b 1
)
>>"%LOG%" echo STALE_LOCK_RECOVERED=YES
 echo STALE_LOCK_RECOVERED=YES
exit /b 0

:releaseOwnedLock
rem Called only by the instance that successfully acquired this lock.
rmdir /S /Q "%LOCKDIR%" >nul 2>nul
if exist "%LOCKDIR%" (
  >>"%LOG%" echo WARNING=OWNED_LOCK_CLEANUP_FAILED
  echo WARNING=OWNED_LOCK_CLEANUP_FAILED
)
exit /b 0


:compile
setlocal EnableDelayedExpansion
set "SRC=%~1"
set "RELOUT=%~2"
set "OUT=%OUTDIR%\%~2"
set "STAMP=%STAMP_DIR%\%~1"
set "DONE=%CHANGED_DIR%\%~2.done"
set "STAGED=%STAGING_DIR%\%~2"
set "LOGBASE=%MODULE_LOGS%\%~2"
set "RECOMPILE=0"
if not exist "!SRC!" (
  >>"%LOG%" echo ERROR=MISSING_SOURCE_!SRC!
  endlocal & exit /b 1
)
if not exist "!OUT!" set "RECOMPILE=1"
if not exist "!STAMP!" set "RECOMPILE=1"
if exist "!OUT!" (
  for %%F in ("!OUT!") do if %%~zF LEQ 0 set "RECOMPILE=1"
)
if "!RECOMPILE!"=="0" (
  fc /B "!SRC!" "!STAMP!" >nul 2>nul
  if errorlevel 1 set "RECOMPILE=1"
)
if "!RECOMPILE!"=="0" if not "%~3"=="" (
  for %%D in (%~3) do (
    if exist "%CHANGED_DIR%\%%~D.done" set "RECOMPILE=1"
  )
)
rem Theorem 5.1's previous run had file-sharing errors and then an importer
rem could not read its module. Treat it as UNCERTIFIED once, not as frozen PASS.
if /I "!SRC!"=="Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7.lean" (
  if not exist "%T5_1_RECHECKED%" set "RECOMPILE=1"
)
if "!RECOMPILE!"=="0" (
  >>"%LOG%" echo FROZEN_REUSE=!SRC!
  endlocal & set /a REUSED+=1 >nul & exit /b 0
)
for %%D in ("!OUT!") do if not exist "%%~dpD" mkdir "%%~dpD"
for %%D in ("!STAMP!") do if not exist "%%~dpD" mkdir "%%~dpD"
for %%D in ("!DONE!") do if not exist "%%~dpD" mkdir "%%~dpD"
for %%D in ("!STAGED!") do if not exist "%%~dpD" mkdir "%%~dpD"
for %%D in ("!LOGBASE!") do if not exist "%%~dpD" mkdir "%%~dpD"
set /a ATTEMPT=0
:compile_attempt
set /a ATTEMPT+=1
set "THREADS=%LEAN_JOBS%"
rem Avoid high parallelism for the specific lock-affected module and importer.
if /I "!SRC!"=="Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7.lean" set "THREADS=1"
if /I "!SRC!"=="PaperChronological\T5_1.lean" set "THREADS=1"
rem T6_10 wrapper was the first unconfirmed module on the user compiler.
rem Begin this wrapper at one thread to avoid silent high-thread failures.
if /I "!SRC!"=="PaperChronological\T6_10.lean" set "THREADS=1"
if !ATTEMPT! GTR 1 set "THREADS=1"
set "ONELOG=!LOGBASE!.attempt!ATTEMPT!.txt"
if exist "!STAGED!" del /Q "!STAGED!" >nul 2>nul
echo COMPILING=!SRC! [threads=!THREADS! attempt=!ATTEMPT!]
>>"%LOG%" echo COMPILING=!SRC! THREADS=!THREADS! ATTEMPT=!ATTEMPT!
rem Each compiler process writes only its private attempt log and staged olean.
rem Source stamp and shared olean are published after successful termination.
"%LEAN_EXE%" -j !THREADS! -o "!STAGED!" "!SRC!" 1>"!ONELOG!" 2>&1
set "RC=!errorlevel!"
if exist "!ONELOG!" type "!ONELOG!" >>"%LOG%"
if not "!RC!"=="0" (
  >>"%LOG%" echo LEAN_EXIT_CODE=!RC! MODULE=!SRC! ATTEMPT=!ATTEMPT!
  rem A syntactic/type/proof error is deterministic: report it immediately.
  set "PROOF_ERROR=0"
  if exist "!ONELOG!" (
    findstr /I /C:"error:" /C:"error(" /C:"unsolved goals" /C:"unknown identifier" "!ONELOG!" >nul 2>nul
    if not errorlevel 1 set "PROOF_ERROR=1"
  )
  if "!PROOF_ERROR!"=="1" (
    >>"%LOG%" echo ERROR=LEAN_PROOF_OR_ELABORATION_FAILURE
    goto module_failed
  )
  rem An error-free nonzero exit is often a native crash, resource failure,
  rem or Windows I/O race. Retry ONLY this uncertified module at one thread.
  >>"%LOG%" echo NONDIAGNOSTIC_LEAN_FAILURE=RETRY_SINGLE_THREAD
  goto transient_retry
)
if not exist "!STAGED!" (
  >>"%LOG%" echo IO_ERROR=OLEAN_NOT_CREATED !SRC!
  goto transient_retry
)
for %%F in ("!STAGED!") do if %%~zF LEQ 0 (
  >>"%LOG%" echo IO_ERROR=OLEAN_ZERO_BYTES !SRC!
  goto transient_retry
)
rem Windows move on same volume commits only fully written staged output.
move /Y "!STAGED!" "!OUT!" >nul 2>nul
if errorlevel 1 (
  >>"%LOG%" echo IO_ERROR=OLEAN_ATOMIC_PROMOTION_LOCKED !SRC!
  goto transient_retry
)
if not exist "!OUT!" (
  >>"%LOG%" echo IO_ERROR=OLEAN_MISSING_AFTER_MOVE !SRC!
  goto transient_retry
)
copy /Y "!SRC!" "!STAMP!" >nul 2>nul
if errorlevel 1 (
  >>"%LOG%" echo IO_ERROR=SOURCE_STAMP_COPY_LOCKED !SRC!
  goto transient_retry
)
>"!DONE!" echo REBUILT_AND_USER_COMPILER_PASS
if not exist "!DONE!" (
  >>"%LOG%" echo IO_ERROR=CHANGED_MARKER_MISSING !SRC!
  goto transient_retry
)
if /I "!SRC!"=="Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7.lean" (
  >"%T5_1_RECHECKED%" echo THIS_MODULE_REBUILT_AND_USER_COMPILER_PASS
)
>>"%MANIFEST%" echo !SRC!,PASS,Lean_433,LOCAL_IMPORTS_VALIDATED
>>"%LOG%" echo NATIVE_PASS=!SRC!
if !ATTEMPT! GTR 1 >>"%LOG%" echo RETRY_RECOVERED=!SRC! ATTEMPTS=!ATTEMPT!
endlocal & set /a BUILT+=1 >nul & exit /b 0
:transient_retry
if !ATTEMPT! GEQ 3 (
  >>"%LOG%" echo ERROR=IO_OR_NONDIAGNOSTIC_RETRY_EXHAUSTED MODULE=!SRC!
  goto module_failed
)
>>"%LOG%" echo IO_RETRY=!SRC! AFTER_ATTEMPT=!ATTEMPT!
rem PING uses only Windows built-ins: works even when CMD input is redirected.
ping -n 3 127.0.0.1 >nul 2>nul
goto compile_attempt

:module_failed
>>"%LOG%" echo FATAL_MODULE=!SRC! EXIT_CODE=!RC! ATTEMPT=!ATTEMPT!
>>"%LOG%" echo FATAL_PRIVATE_COMPILER_LOG=!ONELOG!
echo FATAL_MODULE=!SRC!
echo FATAL_EXIT_CODE=!RC! ATTEMPT=!ATTEMPT!
echo PRIVATE_COMPILER_LOG=!ONELOG!
if exist "!ONELOG!" (
  echo -- BEGIN EXACT LEAN DIAGNOSTIC --
  type "!ONELOG!"
  echo -- END EXACT LEAN DIAGNOSTIC --
) else (
  echo ERROR=NO_PRIVATE_COMPILER_LOG_CREATED
)
endlocal & exit /b 1


:migrateLegacy
if not exist "%LEGACY_BUILD%\fastcore.signature" exit /b 0
if not exist "%LEGACY_BUILD%\lib\lean" exit /b 0
if not exist "%LEGACY_BUILD%\source_stamps" exit /b 0
if not exist "%LEGACY_ROOT%\CHRONOLOGICAL_LEAN_433_LOG.txt" exit /b 0
findstr /C:"PASS=" "%LEGACY_ROOT%\CHRONOLOGICAL_LEAN_433_LOG.txt" >nul
if errorlevel 1 exit /b 0

set "EXPECT_OLD_SIG=%CACHE_ROOT%\legacy_expected.signature"
>"!EXPECT_OLD_SIG!" echo RUNNER=FASTCORE_R2
>>"!EXPECT_OLD_SIG!" echo LEAN_EXE=%LEAN_EXE%
>>"!EXPECT_OLD_SIG!" echo CACHE_ROOT=%BASE_ROOT%
for %%I in ("%LEAN_EXE%") do >>"!EXPECT_OLD_SIG!" echo LEAN_BINARY=%%~zI,%%~tI
for %%I in ("%MATHLIB_OLEAN%") do >>"!EXPECT_OLD_SIG!" echo MATHLIB_OLEAN=%%~zI,%%~tI
fc /B "%LEGACY_BUILD%\fastcore.signature" "!EXPECT_OLD_SIG!" >nul 2>nul
if errorlevel 1 (
  >>"%LOG%" echo LEGACY_CACHE=SIGNATURE_MISMATCH_NOT_IMPORTED
  del /Q "!EXPECT_OLD_SIG!" >nul 2>nul
  exit /b 0
)
del /Q "!EXPECT_OLD_SIG!" >nul 2>nul
if not exist "%OUTDIR%" mkdir "%OUTDIR%"
if not exist "%STAMP_DIR%" mkdir "%STAMP_DIR%"
if not exist "%STAGING_DIR%" mkdir "%STAGING_DIR%"
if not exist "%MODULE_LOGS%" mkdir "%MODULE_LOGS%"
xcopy /E /I /Q /H /Y "%LEGACY_BUILD%\lib\lean\*" "%OUTDIR%\" >nul
if errorlevel 1 exit /b 0
xcopy /E /I /Q /H /Y "%LEGACY_BUILD%\source_stamps\*" "%STAMP_DIR%\" >nul
if errorlevel 1 exit /b 0
rem Now install new, version-independent signature to preserve migrated cache.
copy /Y "%NEW_SIG%" "%SIG%" >nul
if errorlevel 1 exit /b 0
set /a SEED_OLD=1 >nul
>>"%LOG%" echo LEGACY_CACHE=MIGRATED_WITH_SOURCE_BYTE_REVALIDATION
exit /b 0

:buildfailed
>>"%LOG%" echo CHRONOLOGICAL_BUILD=FAIL
rem Print both proof diagnostics and silent exit/IO errors in the console.
findstr /N /I /C:"error:" /C:"FATAL_MODULE=" /C:"LEAN_EXIT_CODE=" /C:"IO_ERROR=" /C:"IO_RETRY_EXHAUSTED=" "%LOG%"
goto failed
:failed
>>"%LOG%" echo RUN_EXIT_CODE=1
echo RUN=FAIL
echo LOG=%LOG%
if defined HAS_LOCK call :releaseOwnedLock
popd
exit /b 1
