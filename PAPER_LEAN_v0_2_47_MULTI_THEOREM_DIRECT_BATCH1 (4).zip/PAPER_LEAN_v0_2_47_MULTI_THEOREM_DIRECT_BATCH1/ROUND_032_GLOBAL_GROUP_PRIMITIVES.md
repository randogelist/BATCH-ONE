# Round 0.2.32 — explicit native additive primitives

Native Windows Lean 4.33.0 diagnostics from v0.2.31:

- `failed to synthesize Zero RationalMomentDomain` during `nsmulRec` / `zsmulRec` elaboration.
- Automatically generated `AddCommGroup` recursion-law fields could not be solved as a consequence.

Correction: install the **already proved** quotient operations as `Zero`,
`Add`, `Neg`, and `Sub` before constructing `AddCommGroup`.
This makes the `nsmulRec`/`zsmulRec` requirements available during elaboration.
The group and module proofs still use the pre-existing algebraic identities,
not a witness, a custom axiom, `sorry`, or an assumption of the result.

This source-level repair is not locally compiled. Only the user's pinned
Windows Lean 4.33.0 compiler is authoritative. Existing passing files are
unchanged; the cache invalidates this file and its transitive dependents.
