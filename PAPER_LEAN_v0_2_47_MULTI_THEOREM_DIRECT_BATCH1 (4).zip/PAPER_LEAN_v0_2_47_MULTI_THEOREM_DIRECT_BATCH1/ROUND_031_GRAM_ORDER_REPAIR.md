# v0.2.11 — Corollary 3.6, finite Gram sum-order repair

User compiler detected a remaining goal in `PaperChronological/T3_6_MomentGram.lean:75`.

The former `simp only [pow_two, Finset.sum_mul, Finset.mul_sum]` rewrote the right-hand square into a double sum with the indices reversed relative to the left-hand side. The mathematical equality is correct, but the elaborated expressions were not syntactically equal.

**Change:** first use `Finset.sum_congr` to fix one atom `a`, then rewrite `pow_two`, `Finset.sum_mul`, `Finset.mul_sum` sequentially with `rw` (not `simp only`). The product expansion now has index order `i` then `j`, matching the goal.

Exactly one Lean source has changed, and the other 128 are byte-for-byte identical. All previously verified compilation artifacts remain in the user's persistent PASS-ONCE cache and are not shipped inside this ZIP. The native Lean 4.33.0 compiler is authoritative: **no local Lean compilation was performed**.

The strongest result in this particular module is a finite-support positive SEMIDEFINITE Hankel moment matrix. The incorrect manuscript all-orders STRICT-positivity statement remains unasserted.
