# Principal theorem Stage 2 — source-only candidate

- Retains the 148 source modules from successful v0.2.40 native Lean run **byte-for-byte**.
- Adds `Principal_T3_7_DerivativeTuran.lean`: universal multiplication identity for the *ordinary* polynomial derivative Turan form; finite-product closure; constructive application to the actual odd-zeta determinant using its proved spectral factorization. This is the first-order T3.7(1) conclusion for all real `x`.
- Adds `Principal_T3_3_WeightedAtomicGram.lean`: finite Vandermonde-based positive determinant for a genuinely defined weighted atomic Hankel moment matrix. It is a special/finite-atomic component of T3.3, not continuous total positivity.
- Adds `PRINCIPAL_STAGE2_CHAIN.lean` and `PRINCIPAL_STAGE2_AUDIT.lean`.
- Full Theorems 3.3 and 3.7 remain incomplete; no additional hypothesis has been introduced, and all new proofs await **user's** compiler.
- Toolchain 4.33.0, cached Mathlib and the PASS-ONCE incremental `run.cmd` unchanged other than package identity. No local compilation performed.
