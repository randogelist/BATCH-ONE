# Section 2 round 018: directed union of finite pole presentations

## Newly formalized targets (pending user-native Lean 4.33 compiler)

1. Full finite cutoff arithmetic: polynomial-part stability, old residue
   preservation, new pole residue zero, exact zero-padded residue formula.
2. A canonical same-presentation equivalence relation identifying finite
   polynomial-plus-pole data regardless of cutoff.
3. A quotient type `RationalMomentDomain`, not a synthetic paper-theorem
   assumption. Its well-defined moment map is built with `Quotient.liftOn`
   and a proved compatibility theorem.
4. A pointwise rational evaluation map on the SAME quotient. Every
   zero-residue cutoff extension preserves both evaluations and moments.
5. A **global common-cutoff polynomial normalizer**, independent of the
   presentation cutoff, whose exact equality is equivalent to equality
   of the genuine polynomial part and all positive-index residues.
6. `SECTION2_DIRECTED_UNION_ALGEBRAIC_CHAIN`: packages the already present
   all-finite-pole normal forms and the new independent representative
   invariance laws.

## Important scope restriction

The underlying presentation equivalence uses equality of polynomial parts
and zero-padded residues. Identifying this quotient with the full field of
rational functions requires a separate injectivity/surjectivity bridge from
polynomial-fraction equality. The earlier source proves injectivity at each
fixed finite pole set. Do not report the full paper or Section 2 as
compiler-certified from this ZIP alone. Proof additions have NOT been
compiled locally; the user's Windows compiler remains the only authority.

The new source files do not declare additional axioms, use `sorry` or
`admit`, or depend upon the quantitative `Witness`.

PASS-ONCE: all previous Lean source files are preserved byte-for-byte.
Only the six new `S2_*.lean` modules and their dependent audit need native
compilation unless the user's persistent cache detects invalidated imports.
