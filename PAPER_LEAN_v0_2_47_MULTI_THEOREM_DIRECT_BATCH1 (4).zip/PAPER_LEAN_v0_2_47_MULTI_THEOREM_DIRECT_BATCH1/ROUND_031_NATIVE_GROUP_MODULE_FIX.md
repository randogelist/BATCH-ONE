# Section 2 — native AddCommGroup and Q-module source repair (v0.2.31)

Last native diagnostic: `S2_GlobalModuleInstances.lean` lacks `nsmul`,
`zsmul`, `neg_add_cancel` and a `Polynomial` namespace opening.

Source-level repair:
- `open Polynomial` resolves polynomial constant `C`.
- `neg_add_cancel := rationalAdd_left_neg` is the required `AddGroup` field.
- `nsmul := nsmulRec` and `zsmul := zsmulRec` use Mathlib's
  canonical additive monoid/group scalar recursions. These replace
  the missing default scalar fields without assumptions.
- The pre-existing global additive and rational scaling operations,
  theorem statements, and proofs are unchanged.

This is a proposed source-level Lean fix; native compilation and axiom
certification remain exclusively on the user's Windows 4.33.0 toolchain.
The persistent PASS-ONCE cache is not deleted or invalidated by packaging.
