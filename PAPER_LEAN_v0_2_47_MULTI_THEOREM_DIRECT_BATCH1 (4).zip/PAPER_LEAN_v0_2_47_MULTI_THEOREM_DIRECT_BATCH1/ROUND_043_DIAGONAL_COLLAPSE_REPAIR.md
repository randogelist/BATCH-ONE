# Round 043 — native Windows Lean proof repair (no local compilation)

- Repair `Principal_T3_3_WeightedAtomicGram.lean`: after `Matrix.mul_apply`, explicitly collapse the inner sum against a diagonal matrix using `Matrix.diagonal_apply`, then normalize the remaining commutative ring identity.
- Apply the same source-level repair to the still-unverified `Principal_T3_3_QuadraticIdentity.lean`, which used the same fragile rewrite sequence.
- No changes to theorem statements, mathematical assumptions, or previously certified source modules.
- Compiles only on the user's native Lean 4.33.0 compiler; PASS-ONCE cache stays in the existing persistent location.
- `sorryAx` in an error-producing `#print axioms` output is not accepted as a certificate. It must disappear once the module successfully compiles.
