# Principal-theorem transition — v0.2.40

## Newly submitted source files (USER COMPILER NOT YET RUN)

1. `Principal_T3_3_SpectralSplit.lean`: unconditional left/right classification of EVERY indexed spectral zero of actual odd-zeta pencils by the sign of the constructed nonzero eigenvalue parameter. The exact inertia/number of roots on each side remains open.
2. `Principal_T3_7_LaguerreSOS.lean`: all-finite-dimensional Laguerre/Turán sum-of-squares identity for the factored expressions and nonnegative inequality. The identification of those expressions with polynomial derivatives is not included.
3. `Principal_T3_9_FeketeTransfer.lean`: five character-Fekete factors positive for 0<z<1 and abstract finite hyperbolicity transfer. The Hurwitz/Dirichlet integral identity is not included.
4. `PRINCIPAL_CHAIN.lean`: unconditional spectral theorem for the ACTUAL odd-zeta Hankel pencil plus all-dimensional finite Turán identity.
5. `PRINCIPAL_AUDIT.lean`: native compiler axiom checks.

## Source fidelity

Original Section 2 modules and all earlier source files preserved byte-for-byte from v0.2.39. No complete proof of Theorems 3.3, 3.7, or 3.9 is asserted. No arithmetic witness is introduced. The project's existing single witness is unchanged and remains relevant only to quantitative irrationality endpoints.

## Verification

Archive/file/order/static local-import audit only. No local Lean compilation; new files are awaiting the user's native Lean 4.33.0 check. PASS-ONCE source/dependency cache unchanged.
