# v0.2.34 — Definition 2.1 full Q-linearity

Last user compiler checkpoint: v0.2.33 `PROJECT_MODULES_NEW_OR_CHANGED=4`, `PROJECT_MODULES_FROZEN_REUSED=135`, `CHRONOLOGICAL_BUILD=PASS`. Treat all those 139 compiled modules as frozen when their toolchain/dependencies remain unchanged; no local Lean compiler has been run.

Four additive modules now prove the missing source-faithful bridge from fixed-degree/fixed-pole sums to the original input-dependent `Zetahyperbolic.muFunctionalPoly` and then to `muOnRationalDomain`, based on the already compiled quotient vector-space implementation. Goals:

1. `S2_GlobalMomentBounded`: arbitrary polynomial-bound independence by `Polynomial.sum_over_range`; arbitrary pole-bound independence by padding. Exactly identify input-dependent moments with bounded sums.
2. `S2_GlobalMomentLinearity`: for arbitrary rational moment functions with *different* degrees and pole supports, prove full Q-additivity and Q-homogeneity, descends through the verified directed union.
3. `S2_GlobalMomentLinearMap`: construct an actual `LinearMap ℚ` from the quotient to `ℚ[X]`, not a named abstract assumption.
4. `S2_GlobalMomentLinearAudit`: check theorem types and `#print axioms` for the new mathematical endpoints.

These are new sources requiring the user's native Windows Lean 4.33 compiler. No previous `.lean` source files were edited. No `sorry`, `admit`, or custom `axiom` declarations in the new modules. The paper's arithmetic estimates and global irrationality endpoints are not implied by this algebraic work.
