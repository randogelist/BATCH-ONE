import Lake
open Lake DSL

package paper_chronological_native where

require mathlib from git
  "https://github.com/leanprover-community/mathlib4" @ "db584cd6d46c92f209a44c0f1c829460d327499d"

lean_lib PaperChronological where
  roots := #[`PaperChronological.MAIN_CHAIN, `PaperChronological.AUDIT]

lean_lib PaperNative where
  roots := #[`PaperNative.MAIN_CHAIN, `PaperNative.AUDIT]
