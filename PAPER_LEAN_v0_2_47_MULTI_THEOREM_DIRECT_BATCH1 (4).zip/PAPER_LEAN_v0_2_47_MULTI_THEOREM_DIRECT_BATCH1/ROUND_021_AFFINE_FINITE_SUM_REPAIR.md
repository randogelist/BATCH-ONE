# v0.2.21: Theorem 2.8 exact affine moment pencil finite-sum repair

Native compiler error: `PaperChronological/S2_ExactPencilAssembly.lean` at lines 44 and 61, unsolved goals. The prior proof mixed reverse-oriented `C`/`Finset` normalizations in one simplification.

Changed only `PaperChronological/S2_ExactPencilAssembly.lean`: explicit single-pole ring-hom multiplicativity, constant-coefficient sum identity, slope-coefficient sum identity, distribution of a common `X`, and a four-stage finite-sum proof. Statement unchanged. No `sorry`, `admit`, custom axioms, or local compilation. Existing PASS-ONCE cache remains authoritative on the user's machine. The proof is pending native Lean 4.33.0 verification.
