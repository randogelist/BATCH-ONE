# PAPER_CHRONOLOGICAL_NATIVE_LEAN v0.2.42

- Proof modules unchanged: all v0.2.41 modules.
- New direct theorem modules: `Principal_T3_3_QuadraticIdentity`,
  `Principal_T3_7_StrictActual`, `Principal_T3_8_PoleKernelDet`.
- New chain/audit: `PRINCIPAL_STAGE3_CHAIN`, `PRINCIPAL_STAGE3_AUDIT`.
- One native Windows `run.cmd`, with the established PASS-ONCE persistent cache.
- No local Lean compilation. User compiler determines PASS/FAIL.

## Round 043
Two direct Gram identities had a diagonal inner sum left after matrix multiplication expansion. Both are now reduced explicitly, awaiting the user's native compiler. No local Lean compilation.
