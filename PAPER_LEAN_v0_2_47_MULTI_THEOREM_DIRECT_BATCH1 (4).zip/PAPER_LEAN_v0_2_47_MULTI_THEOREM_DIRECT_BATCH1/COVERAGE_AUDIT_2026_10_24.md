# PAPER COVERAGE CHECKPOINT — 24 OCTOBER 2026

## Source-faithful theorem-level coverage

**Estimated substantive complete coverage: approximately 10–16% of the indexed paper items.**
This is an estimate, **not** a proof that 10–16% of all detailed PDF claims have been Leaned.

- PDF theorem-index ledger: **51 items** (Definitions, Lemmas, Theorems, Corollaries, Remarks and one Conjecture).
- Entries marked `proved` in packaged STATUS.csv: **4/51 = 7.8%**, specifically 2.1, 2.4, 3.1, 5.4.
- Additional entry marked `proved_transfer`: **1** (4.1); proves a general implication with explicit assumptions, not the unconditional estimates.
- Additional **3** Section 2 items with previously checked finite generator/span or matrix content, but **not yet verified to cover their entire printed PDF statements** (2.2, 2.3, 2.5).
- Thus **5–8 / 51 = 9.8%–15.7%** have some form of completed/advanced core endpoint, counting liberally at the high end.
- At least one substantive proof component/conditional interface is recorded for **24 / 51 = 47.1%**; this is NOT a completion percentage.
- The remaining **27 / 51** are marked open, require review, conjectural, erroneous as printed, or merely observations.

## Chronological section-level assessment (rough)

- **Section 2 algebraic structure:** approximately 80–90% of *the finite algebraic program* drafted/compiled across previous rounds. Global quotient-space linearity and source-faithful equivalence across all rational-function presentations remain subject to the latest native compiler and theorem audit. Do **not** call Section 2 100% certified.
- **Section 3 spectral results:** approximately 15–25% of the mathematical claims, with 3.1 supported most strongly and later theorems only partially.
- **Section 4 Diophantine estimates:** approximately 5–10%; theorem 4.1 transfer is present but 4.4 quantitative inputs remain a single Witness, and additional claims require proofs.
- **Section 5 weight seven:** approximately 10–20%, substantial finite identities but no complete analytic and p-adic endpoints.
- **Section 6 extensions:** approximately 5–10%, mostly partial finite algebra; known PDF errata must be respected.

## Native Lean certification status

- Last **explicit full chronological PASS** supplied: v0.2.33, `PROJECT_MODULES_NEW_OR_CHANGED=4`, `PROJECT_MODULES_FROZEN_REUSED=135`, `CHRONOLOGICAL_BUILD=PASS`.
- Later v0.2.37 encountered a `S2_GlobalMomentLinearMap.lean` scalar-action mismatch; the current v0.2.38 source proposed its repair. **No native PASS for that newest correction has yet been supplied.**
- No Lean compilation performed locally. `AXIOM_AUDIT=CHECK_RUN_LOG` is **not** itself a completed axiom audit.
- The count of Lean modules (currently 163 source files) is not a completion metric and includes wrappers, utilities, audits, and partial proof kernels.
- The assertion `FULL_PAPER=PROVED` is **not justified** by this archive.

## PASS-ONCE preservation

This checkpoint only appends the coverage report and renames the package for an unambiguous launch. All Lean proof sources are byte-for-byte unchanged from v0.2.38. The persistent cache at `%USERPROFILE%\lean-native\paper_chronological_fastcore_433` is retained. Only new/edited/dependency-invalidated modules require native compilation.
