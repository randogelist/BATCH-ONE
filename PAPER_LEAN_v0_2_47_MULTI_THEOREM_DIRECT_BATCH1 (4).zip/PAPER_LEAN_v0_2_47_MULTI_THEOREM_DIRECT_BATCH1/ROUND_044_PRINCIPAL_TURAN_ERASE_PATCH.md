# v0.2.44 — strict derivative Turan product factorization

Native Lean 4.33.0 only. No Lean compilation performed during packaging.

`PaperChronological/Principal_T3_7_StrictActual.lean` now replaces the unavailable `Finset.not_mem_erase` constant with an explicit fact `have ha_not : a ∉ s.erase a := by simp`. The stable `Finset.prod_insert ha_not` lemma then discharges the actual finite product identity.

This is a proof-term/tactic repair without changing theorem types, assumptions, or mathematical claims. Source-hash change invalidates only this module and transitive imported dependents in the PASS-ONCE user cache. Source from earlier passed modules remains unchanged.

The final `#print axioms` should no longer report `sorryAx` for the two strict Turan theorems once this module compiles; the user's native compiler must confirm this.
