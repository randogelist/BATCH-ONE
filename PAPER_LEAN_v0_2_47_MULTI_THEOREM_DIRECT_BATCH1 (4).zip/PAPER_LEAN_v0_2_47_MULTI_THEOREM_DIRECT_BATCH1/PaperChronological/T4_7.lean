import PaperChronological.T4_6

/-!
# Theorem 4.7: Macroscopic exponential root collapse and separation

PDF p. 21. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 4.7 is still a formalization target. -/

end PaperChronological
