import PaperChronological.T3_6_Corrected
import PaperChronological.T3_5_CorrectedTwoByTwo

/-!
# Corollary 3.6: exact discrete moment Gram matrix

The paper's reciprocal-even-power moments form a FINITELY supported
positive Stieltjes moment sequence. We prove their finite Hankel Gram
factorization and positive SEMIDEFINITENESS at every order, not the
incorrect assertion of strict positivity at orders beyond the support.

This is independent of the arithmetic Witness and is purely finite.
Status: new, awaiting user's native Lean compiler.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/-- `S_r = Σ_a u_a^r` for a finite atomic measure. -/
def finiteAtomicMoment {h : ℕ} (u : Fin h → ℝ) (r : ℕ) : ℝ :=
  ∑ a : Fin h, u a ^ r

/-- The order-`d` Hankel moment matrix of the finite atomic measure. -/
def finiteAtomicHankel {h : ℕ} (u : Fin h → ℝ) (d : ℕ) :
    Matrix (Fin d) (Fin d) ℝ :=
  fun i j => finiteAtomicMoment u (i.val + j.val)

/-- Finite monomial evaluation matrix on the atoms. -/
def atomicVandermonde {h : ℕ} (u : Fin h → ℝ) (d : ℕ) :
    Matrix (Fin d) (Fin h) ℝ :=
  fun i a => u a ^ i.val

/-- Exact Gram factorization, `H = V * V.transpose`, for every finite
atomic moment sequence, with no analytic convergence assumptions. -/
theorem COROLLARY_3_6_FINITE_ATOMIC_GRAM
    {h : ℕ} (u : Fin h → ℝ) (d : ℕ) :
    finiteAtomicHankel u d =
      atomicVandermonde u d * (atomicVandermonde u d).transpose := by
  classical
  ext i j
  simp [finiteAtomicHankel, finiteAtomicMoment, atomicVandermonde,
    Matrix.mul_apply, pow_add]

/-- Exact sum-of-squares form of a finite moment-matrix quadratic form. -/
theorem COROLLARY_3_6_FINITE_ATOMIC_QUADRATIC
    {h d : ℕ} (u : Fin h → ℝ) (x : Fin d → ℝ) :
    (∑ i : Fin d, ∑ j : Fin d,
      x i * finiteAtomicHankel u d i j * x j) =
      ∑ a : Fin h, (∑ i : Fin d, x i * u a ^ i.val) ^ 2 := by
  classical
  simp only [finiteAtomicHankel, finiteAtomicMoment, pow_add]
  calc
    (∑ i : Fin d, ∑ j : Fin d,
      x i * (∑ a : Fin h, (u a ^ i.val) * (u a ^ j.val)) * x j) =
      ∑ i : Fin d, ∑ j : Fin d, ∑ a : Fin h,
        (x i * u a ^ i.val) * (x j * u a ^ j.val) := by
          apply Finset.sum_congr rfl
          intro i _
          apply Finset.sum_congr rfl
          intro j _
          rw [Finset.mul_sum, Finset.sum_mul]
          apply Finset.sum_congr rfl
          intro a _
          ring
    _ = ∑ i : Fin d, ∑ a : Fin h, ∑ j : Fin d,
          (x i * u a ^ i.val) * (x j * u a ^ j.val) := by
          apply Finset.sum_congr rfl
          intro i _
          rw [Finset.sum_comm]
    _ = ∑ a : Fin h, ∑ i : Fin d, ∑ j : Fin d,
          (x i * u a ^ i.val) * (x j * u a ^ j.val) := by
          rw [Finset.sum_comm]
    _ = ∑ a : Fin h, (∑ i : Fin d, x i * u a ^ i.val) ^ 2 := by
          apply Finset.sum_congr rfl
          intro a _
          -- Factor the inner and outer sums separately. This prevents
          -- Lean from picking the wrong orientation in a combined rewrite.
          calc
            (∑ i : Fin d, ∑ j : Fin d,
              (x i * u a ^ i.val) * (x j * u a ^ j.val)) =
                ∑ i : Fin d, (x i * u a ^ i.val) *
                  (∑ j : Fin d, x j * u a ^ j.val) := by
                    simp only [Finset.mul_sum]
            _ = (∑ i : Fin d, x i * u a ^ i.val) *
                  (∑ j : Fin d, x j * u a ^ j.val) := by
                    simp only [Finset.sum_mul]
            _ = (∑ i : Fin d, x i * u a ^ i.val) ^ 2 := by
                  rw [pow_two]

/-- At EVERY finite order the reciprocal-root Stieltjes moment Hankel
quadratic form is nonnegative; strict positivity can fail beyond its rank. -/
theorem COROLLARY_3_6_FINITE_ATOMIC_PSD
    {h d : ℕ} (u : Fin h → ℝ) (x : Fin d → ℝ) :
    0 ≤ ∑ i : Fin d, ∑ j : Fin d,
      x i * finiteAtomicHankel u d i j * x j := by
  rw [COROLLARY_3_6_FINITE_ATOMIC_QUADRATIC u x]
  exact Finset.sum_nonneg (fun a _ => sq_nonneg _)

end PaperChronological
