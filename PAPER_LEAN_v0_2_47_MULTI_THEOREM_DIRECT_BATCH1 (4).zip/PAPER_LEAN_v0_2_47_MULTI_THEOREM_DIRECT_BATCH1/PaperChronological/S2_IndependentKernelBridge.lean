import PaperChronological.S2_ExactPencilAssembly

/-!
# Section 2: bridge the two genuinely independent kernel constructions

The assembled source has TWO non-definitionally-identical realizations of
D_N, kernel numerators and simple pole residues: the Mathlib partial-fraction
construction of `Zetahyperbolic.Section2Checked`, and the direct polynomial
quotient/derivative formulas of `ManuscriptChain.Real`.

The denominator conventions are proved identical by induction. Hence the
kernel numerators agree, and the residue obtained by the actual Mathlib
partial-fraction decomposition equals the derivative-quotient residue in
Definition 2.1. No identification of independently chosen quotient polynomials
is postulated: that last polynomial-division compatibility is tracked as a
separate, still-open bridge in the round notes.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The paper's admissible real parameters also furnish the exact Mathlib
partial-fraction parameter structure. -/
def asHankelParams (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) : Zetahyperbolic.HankelParams :=
  { N := p.N
    K := p.K
    m := p.m
    hN := by
      have h := hp.N_pos
      omega
    hK := hp.N_lt_K
    hm := by
      have h := hp.m_pos
      omega }

/-- The two denominator conventions (range vs. closed integer interval)
are equal as rational polynomials, including the empty product. -/
theorem denominatorMoment_agreement (M : ℕ) :
    ManuscriptChain.Real.D M = Zetahyperbolic.D_poly M := by
  induction M with
  | zero =>
      simp [ManuscriptChain.Real.D, Zetahyperbolic.D_poly]
  | succ M ih =>
      change (∏ j ∈ Finset.range (M + 1),
          (X + C (((j + 1 : ℕ) : ℚ) ^ 2))) =
        ∏ j ∈ Finset.Icc 1 (M + 1),
          (X + C ((j : ℚ) ^ 2))
      rw [Finset.prod_range_succ,
        Finset.prod_Icc_succ_top (by omega : 1 ≤ M + 1)]
      exact congrArg
        (fun P : ℚ[X] => P * (X + C ((((M + 1 : ℕ) : ℚ) ^ 2)))) ih

/-- The two tail products are definitionally the same. -/
theorem tailPolynomial_agreement
    (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.Real.tailD p =
      Zetahyperbolic.tailPolynomial p.N p.K := by
  rfl

/-- The exact polynomial kernel numerator in (2.8) agrees between the
rational-moment pencil and the partial-fraction construction. -/
theorem kernelNumerator_agreement
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) (d : ℕ) :
    ManuscriptChain.Real.numerator p d 0 =
      Zetahyperbolic.kernelNumerator (asHankelParams p hp) d := by
  unfold ManuscriptChain.Real.numerator
    Zetahyperbolic.kernelNumerator
  rw [denominatorMoment_agreement]
  simp [asHankelParams]

/-- The residue from the *proved Mathlib partial-fraction decomposition*
equals the explicit derivative quotient in Definition 2.1, for every actual
tail pole. This is the independent-source arithmetic identification. -/
theorem kernelResidue_agreement
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) (d a : ℕ)
    (ha : a ∈ Finset.Icc (p.N + 1) p.K) :
    ManuscriptChain.Real.residue p d 0 a =
      (Zetahyperbolic.kernelRatElem (asHankelParams p hp) d).poleRes a := by
  have ha' : a ∈ Finset.Icc
      ((asHankelParams p hp).N + 1) (asHankelParams p hp).K := by
    simpa [asHankelParams] using ha
  rw [Zetahyperbolic.kernelRatElem_poleRes_eq_prod
    (asHankelParams p hp) d a ha']
  -- Normalize the elaborated HankelParams projection to the original
  -- manuscript p.N/p.K interval. `rw` does not unfold this dependent
  -- record projection automatically when searching for the product.
  change ManuscriptChain.Real.residue p d 0 a =
    Polynomial.eval (-((a : ℚ) ^ 2))
      (Zetahyperbolic.kernelNumerator (asHankelParams p hp) d) /
      ∏ b ∈ (Finset.Icc (p.N + 1) p.K).erase a,
        ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)
  rw [← ManuscriptChain.PoleDiagonalization.tailD_derivative_eval p a ha]
  rw [← kernelNumerator_agreement p hp d]
  rfl

end PaperChronological.Section2
