import PaperChronological.PRINCIPAL_STAGE4_CHAIN
import PaperChronological.Principal_T3_5_ExactThreeStep
import PaperChronological.Principal_T3_6_TwoAtomExactRank
import PaperChronological.Principal_T3_9_PositiveCharacterKernels
import PaperChronological.Principal_T4_8_FiniteFactorBounds
import PaperChronological.Principal_T5_2_RectangularGram
import PaperChronological.Principal_T6_1_HarmonicLocalDifference

/-!
# Fifth direct principal-theorem stage: one integrated PDF-wide proof batch

No extra global hypothesis is created. Every imported theorem is a theorem
about its actual algebraic objects, and incomplete manuscript analytic/p-adic
claims are recorded separately rather than silently postulated.
-/

noncomputable section
namespace PaperChronological.Principal

/-- The complete actual odd-zeta pole-kernel characteristic polynomial
identity, inherited from Section 2 and Theorem 3.8(1). -/
theorem PRINCIPAL_STAGE5_ACTUAL_CHARACTERISTIC_POLYNOMIAL
    (p : ManuscriptChain.Real.Parameters) :
    ((ManuscriptChain.Real.gram p
       (ManuscriptChain.Real.zeta p.weight))⁻¹ *
         ManuscriptChain.Real.derivativeMatrix p).charpoly =
      (Matrix.diagonal
        (fun a : Fin p.h =>
          (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ)) *
          actualZetaPoleKernel p).charpoly :=
  THEOREM_3_8_ACTUAL_ZETA_CENTER_POLE_KERNEL_SPECTRUM p

end PaperChronological.Principal

#print axioms PaperChronological.Principal.PRINCIPAL_STAGE5_ACTUAL_CHARACTERISTIC_POLYNOMIAL
