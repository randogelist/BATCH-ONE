import PaperChronological.S2_MomentReconciliation

/-!
# Section 2: exact Q-linearity and well-definedness of pole presentations

The paper's moment functional is linear in the polynomial-plus-residue data.
Its input-side cleared numerator must therefore be linear in those data too.
These facts are checked algebraically, using uniqueness from the original
Lagrange proof, without quotient-ring extensionality assumptions.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The cleared rational presentation sends zero data to the zero polynomial. -/
theorem clearedResidue_zero (p : ManuscriptChain.Real.Parameters) :
    clearedResidueNumerator p 0 (fun _ => 0) = 0 := by
  simp [clearedResidueNumerator, normalizedNumerator]

/-- Additivity of genuine simple-pole residues, with exactly the original
rational polynomial quotient, before and after clearing denominators. -/
theorem clearedResidue_add (p : ManuscriptChain.Real.Parameters)
    (Q₁ Q₂ : ℚ[X]) (c₁ c₂ : Fin p.h → ℚ) :
    clearedResidueNumerator p (Q₁ + Q₂) (fun a => c₁ a + c₂ a) =
      clearedResidueNumerator p Q₁ c₁ +
        clearedResidueNumerator p Q₂ c₂ := by
  have hcoeff :
      (fun a : Fin p.h => (c₁ a + c₂ a) * poleDerivative p a) =
        (fun a => c₁ a * poleDerivative p a) +
          (fun a => c₂ a * poleDerivative p a) := by
    funext a
    simp only [Pi.add_apply, add_mul]
  change normalizedNumerator p (Q₁ + Q₂)
      (fun a => (c₁ a + c₂ a) * poleDerivative p a) =
    normalizedNumerator p Q₁ (fun a => c₁ a * poleDerivative p a) +
      normalizedNumerator p Q₂ (fun a => c₂ a * poleDerivative p a)
  rw [hcoeff]
  exact normalizedNumerator_add p Q₁ Q₂
    (fun a => c₁ a * poleDerivative p a)
    (fun a => c₂ a * poleDerivative p a)

/-- Multiplication by a rational scalar commutes with forming a normalized
polynomial numerator. -/
theorem normalizedNumerator_scale (p : ManuscriptChain.Real.Parameters)
    (r : ℚ) (Q : ℚ[X]) (c : Fin p.h → ℚ) :
    normalizedNumerator p (C r * Q) (fun a => r * c a) =
      C r * normalizedNumerator p Q c := by
  unfold normalizedNumerator
  rw [mul_add, Finset.mul_sum]
  congr 1
  · ring
  · apply Finset.sum_congr rfl
    intro a ha
    simp only [map_mul]
    ring

/-- Rational scalar linearity persists for ordinary residues after their
conversion to Lagrange coefficients. -/
theorem clearedResidue_scale (p : ManuscriptChain.Real.Parameters)
    (r : ℚ) (Q : ℚ[X]) (c : Fin p.h → ℚ) :
    clearedResidueNumerator p (C r * Q) (fun a => r * c a) =
      C r * clearedResidueNumerator p Q c := by
  have hcoeff :
      (fun a : Fin p.h => (r * c a) * poleDerivative p a) =
        (fun a => r * (c a * poleDerivative p a)) := by
    funext a
    ring
  change normalizedNumerator p (C r * Q)
      (fun a => (r * c a) * poleDerivative p a) =
      C r * normalizedNumerator p Q
        (fun a => c a * poleDerivative p a)
  rw [hcoeff]
  exact normalizedNumerator_scale p r Q
    (fun a => c a * poleDerivative p a)

/-- The pole-only part of the order-s moment polynomial is additive. -/
def finitePoleMoment (p : ManuscriptChain.Real.Parameters) (k : ℕ)
    (c : Fin p.h → ℚ) : ℚ[X] :=
  ∑ a : Fin p.h,
    C (c a) * Zetahyperbolic.muPolePoly k
      (ManuscriptChain.PoleDiagonalization.poleIndex p a)

theorem finitePoleMoment_add (p : ManuscriptChain.Real.Parameters) (k : ℕ)
    (c₁ c₂ : Fin p.h → ℚ) :
    finitePoleMoment p k (fun a => c₁ a + c₂ a) =
      finitePoleMoment p k c₁ + finitePoleMoment p k c₂ := by
  unfold finitePoleMoment
  simp only [map_add, add_mul, Finset.sum_add_distrib]

/-- Homogeneity of the moment functional on all simple-pole coefficients. -/
theorem finitePoleMoment_scale (p : ManuscriptChain.Real.Parameters) (k : ℕ)
    (r : ℚ) (c : Fin p.h → ℚ) :
    finitePoleMoment p k (fun a => r * c a) =
      C r * finitePoleMoment p k c := by
  unfold finitePoleMoment
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a ha
  simp only [map_mul]
  ring

end PaperChronological.Section2
