import PaperChronological.T6_18

/-!
# CHRONOLOGICAL PAPER MAIN CHAIN
Every numbered PDF theorem is represented by a separate import in source order.
The strongest global proof *currently closed* is the odd-weight Section 2--3
Hankel spectral chain, with independent proof of the pole cancellation at 5.4.

Do not infer that every imported numbered file has a proved theorem; check the
chronological STATUS.csv. No theorem here assumes existence of `Witness`.
-/

noncomputable section
namespace PaperChronological

/-- Unconditional Sections 2--3 result on the paper's actual Hankel matrices. -/
theorem MAIN_CHAIN_UNCONDITIONAL
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    (ManuscriptChain.Real.delta p).natDegree = p.h ∧
    (ManuscriptChain.Real.gram p
      (ManuscriptChain.Real.zeta p.weight)).PosDef ∧
    ManuscriptChain.General.GeneralStatement p := by
  exact ⟨THEOREM_2_5_EXACT_DEGREE p,
    THEOREM_3_1_GRAM_POSITIVE p hp,
    THEOREM_3_1_UNIVERSAL_HYPERBOLICITY p hp⟩

/-- The quantitative weight-five application is deliberately secondary.
No witness existence is asserted; it must be supplied explicitly. -/
theorem APPLICATION_ZETA5_FROM_WITNESS (w : PaperNative.Witness) :
    Irrational (riemannZeta 5).re :=
  THEOREM_4_4_APPLICATION_FROM_WITNESS w

end PaperChronological
