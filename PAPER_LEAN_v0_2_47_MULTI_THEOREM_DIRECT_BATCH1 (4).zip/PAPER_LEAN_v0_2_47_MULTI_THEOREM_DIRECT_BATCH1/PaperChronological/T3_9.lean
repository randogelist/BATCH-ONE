import PaperChronological.T3_8

/-!
# Theorem 3.9: Hyperbolicity for Hurwitz and Dirichlet Hankel determinants

PDF p. 13. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 3.9 is still a formalization target. -/

end PaperChronological
