import PaperChronological.T4_9

/-!
# Remark 4.10: Lee-Yang-type phase transition

PDF p. 22. Audit status: REQUIRES_REVIEW.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Remark 4.10 is still a formalization target. -/

end PaperChronological
