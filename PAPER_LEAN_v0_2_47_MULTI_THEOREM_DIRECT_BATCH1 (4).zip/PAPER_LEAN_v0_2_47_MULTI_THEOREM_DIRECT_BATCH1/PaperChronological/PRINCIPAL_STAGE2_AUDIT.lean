import PaperChronological.PRINCIPAL_STAGE2_CHAIN

/-!
# Native compiler audit of new principal theorem endpoints

Inspect the output for `sorryAx` or any unexpected custom axiom.
Only standard Lean foundational axioms are accepted.
-/

#print PaperChronological.Principal.PRINCIPAL_STAGE2_ACTUAL_ODD_ZETA_TURAN
#print PaperChronological.Principal.PRINCIPAL_STAGE2_FINITE_STRICT_DETERMINANT
#print axioms PaperChronological.Principal.derivativeTuran_mul
#print axioms PaperChronological.Principal.derivativeTuran_prod_nonneg
#print axioms PaperChronological.Principal.THEOREM_3_7_ACTUAL_ODD_ZETA_FIRST_TURAN
#print axioms PaperChronological.Principal.weightedAtomicHankel_det_formula
#print axioms PaperChronological.Principal.THEOREM_3_3_WEIGHTED_ATOMIC_HANKEL_DET_POS
#print axioms PaperChronological.Principal.PRINCIPAL_STAGE2_ACTUAL_ODD_ZETA_TURAN
#print axioms PaperChronological.Principal.PRINCIPAL_STAGE2_FINITE_STRICT_DETERMINANT
