import PaperChronological.S2_FullChain

/-!
# Section 2: rational-function interpretation of canonical pole data

The paper uses *ordinary simple-pole residues* `c_a/(t+a²)`, whereas the
Lagrange numerator uses interpolation coefficients `r_a`. The conversion is
`r_a = c_a D_tail'(-a²)`. We prove this conversion, uniqueness, and the
actual rational evaluation identity away from the negative-square poles.

No analytic measure, arithmetic Witness, `sorry`, or new axioms are used.
Equality of fractions is expressed algebraically by cross multiplication;
we do not silently identify a finite presentation with an arbitrary quotient
field element outside its stated pole domain.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

open ManuscriptChain.PoleDiagonalization

/-- The derivative of the tail denominator at the pole indexed by `a`. -/
def poleDerivative (p : ManuscriptChain.Real.Parameters) (a : Fin p.h) : ℚ :=
  (derivative (ManuscriptChain.Real.tailD p)).eval (poleNode p a)

/-- Convert ordinary residues `c_a/(t+a²)` to the Lagrange numerator:
`Q D_tail + ∑_a c_a D_tail'(-a²) L_a`. -/
def clearedResidueNumerator (p : ManuscriptChain.Real.Parameters)
    (Q : ℚ[X]) (c : Fin p.h → ℚ) : ℚ[X] :=
  normalizedNumerator p Q (fun a => c a * poleDerivative p a)

/-- Residue recovery: evaluating the cleared numerator at `-a²`
returns exactly `c_a D_tail'(-a²)`. -/
theorem clearedResidue_eval_node (p : ManuscriptChain.Real.Parameters)
    (Q : ℚ[X]) (c : Fin p.h → ℚ) (a : Fin p.h) :
    (clearedResidueNumerator p Q c).eval (poleNode p a) =
      c a * poleDerivative p a :=
  normalizedNumerator_eval_node p Q (fun a => c a * poleDerivative p a) a

/-- The cleared numerator determines *the actual residues* and the
polynomial part uniquely, using the nonzero pole derivatives (2.11). -/
theorem clearedResidue_unique (p : ManuscriptChain.Real.Parameters)
    (Q₁ Q₂ : ℚ[X]) (c₁ c₂ : Fin p.h → ℚ)
    (h : clearedResidueNumerator p Q₁ c₁ =
         clearedResidueNumerator p Q₂ c₂) :
    Q₁ = Q₂ ∧ c₁ = c₂ := by
  have hh := normalizedPresentation_unique p Q₁ Q₂
      (fun a => c₁ a * poleDerivative p a)
      (fun a => c₂ a * poleDerivative p a) h
  refine ⟨hh.1, ?_⟩
  funext a
  have hm := congrFun hh.2 a
  apply mul_right_cancel₀ (LAGRANGE_DERIVATIVE_NONZERO p a)
  exact hm

/-- Evaluation is permitted precisely away from the tail's negative-square
poles. This is a domain restriction, not an unproved theorem hypothesis. -/
def OffTailPoles (p : ManuscriptChain.Real.Parameters) (t : ℚ) : Prop :=
  ∀ b ∈ Finset.Icc (p.N + 1) p.K, t + (b : ℚ) ^ 2 ≠ 0

/-- In particular every nonnegative rational is off the negative-square
pole lattice. -/
theorem offTailPoles_of_nonneg (p : ManuscriptChain.Real.Parameters)
    (t : ℚ) (ht : 0 ≤ t) : OffTailPoles p t := by
  intro b hb
  have hbpos : 0 < b := by
    have hlow := (Finset.mem_Icc.mp hb).1
    omega
  have hbposQ : (0 : ℚ) < b := by exact_mod_cast hbpos
  have hpos : 0 < t + (b : ℚ) ^ 2 := by positivity
  exact ne_of_gt hpos

/-- Outside the poles, the tail denominator really is nonzero. -/
theorem tailD_eval_ne_zero_at (p : ManuscriptChain.Real.Parameters)
    (t : ℚ) (ht : OffTailPoles p t) :
    (ManuscriptChain.Real.tailD p).eval t ≠ 0 := by
  simp only [ManuscriptChain.Real.tailD, Polynomial.eval_prod,
    Polynomial.eval_add, Polynomial.eval_X, Polynomial.eval_C]
  apply Finset.prod_ne_zero_iff.mpr
  intro b hb
  exact ht b hb

/-- Each pole term is cleared *exactly*, not just by an asymptotic argument. -/
theorem residue_term_cleared (p : ManuscriptChain.Real.Parameters)
    (a : Fin p.h) (c t : ℚ) (ht : OffTailPoles p t) :
    (c / (t + (poleIndex p a : ℚ) ^ 2)) *
        (ManuscriptChain.Real.tailD p).eval t =
      (c * poleDerivative p a) * (L p a).eval t := by
  have ha : t + (poleIndex p a : ℚ) ^ 2 ≠ 0 :=
    ht (poleIndex p a) (poleIndex_mem p a)
  have hpoly :
      (t + (poleIndex p a : ℚ) ^ 2) * (L p a).eval t *
        poleDerivative p a = (ManuscriptChain.Real.tailD p).eval t := by
    have hv := congrArg (Polynomial.eval t)
      (LAGRANGE_CLEARED_DENOMINATOR p a)
    simpa only [Polynomial.eval_mul, Polynomial.eval_add, Polynomial.eval_X,
      Polynomial.eval_C, poleDerivative] using hv
  calc
    (c / (t + (poleIndex p a : ℚ) ^ 2)) *
        (ManuscriptChain.Real.tailD p).eval t =
      (c / (t + (poleIndex p a : ℚ) ^ 2)) *
        ((t + (poleIndex p a : ℚ) ^ 2) * (L p a).eval t *
          poleDerivative p a) := by rw [hpoly]
    _ = (c * poleDerivative p a) * (L p a).eval t := by
      field_simp [ha] <;> ring

/-- Equation of rational functions on their shared pole-free domain:
`(Q(t) + ∑ c_a/(t+a²)) D_tail(t)` is precisely the Lagrange numerator. -/
theorem clearedResidue_eval_eq (p : ManuscriptChain.Real.Parameters)
    (Q : ℚ[X]) (c : Fin p.h → ℚ) (t : ℚ)
    (ht : OffTailPoles p t) :
    (Q.eval t + ∑ a : Fin p.h, c a /
          (t + (poleIndex p a : ℚ) ^ 2)) *
        (ManuscriptChain.Real.tailD p).eval t =
      (clearedResidueNumerator p Q c).eval t := by
  rw [add_mul, Finset.sum_mul]
  unfold clearedResidueNumerator normalizedNumerator
  simp only [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_finsetSum,
    Polynomial.eval_C]
  congr 1
  apply Finset.sum_congr rfl
  intro a ha
  exact residue_term_cleared p a (c a) t ht

/-- The same identity in genuine rational-function notation, at every
rational argument outside the pole lattice. -/
theorem residueValue_eq_quotient (p : ManuscriptChain.Real.Parameters)
    (Q : ℚ[X]) (c : Fin p.h → ℚ) (t : ℚ)
    (ht : OffTailPoles p t) :
    Q.eval t + ∑ a : Fin p.h, c a /
        (t + (poleIndex p a : ℚ) ^ 2) =
      (clearedResidueNumerator p Q c).eval t /
        (ManuscriptChain.Real.tailD p).eval t := by
  apply (eq_div_iff (tailD_eval_ne_zero_at p t ht)).2
  exact clearedResidue_eval_eq p Q c t ht

/-- No artificial equality of presentations is assumed: equality as rational
fractions (cross-multiplication) forces equality of genuine residue data. -/
theorem clearedFraction_unique (p : ManuscriptChain.Real.Parameters)
    (Q₁ Q₂ : ℚ[X]) (c₁ c₂ : Fin p.h → ℚ)
    (hcross : clearedResidueNumerator p Q₁ c₁ *
        ManuscriptChain.Real.tailD p =
      clearedResidueNumerator p Q₂ c₂ *
        ManuscriptChain.Real.tailD p) :
    Q₁ = Q₂ ∧ c₁ = c₂ := by
  have hnum : clearedResidueNumerator p Q₁ c₁ =
      clearedResidueNumerator p Q₂ c₂ := by
    apply mul_right_cancel₀ (tailD_ne_zero p)
    exact hcross
  exact clearedResidue_unique p Q₁ Q₂ c₁ c₂ hnum

end PaperChronological.Section2
