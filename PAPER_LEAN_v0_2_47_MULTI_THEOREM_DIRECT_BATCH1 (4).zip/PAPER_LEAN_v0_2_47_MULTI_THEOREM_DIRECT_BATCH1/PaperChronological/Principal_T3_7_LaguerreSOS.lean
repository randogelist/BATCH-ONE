import PaperChronological.T3_7

/-!
# Manuscript Theorem 3.7 — all-dimensional Laguerre/Turan SOS

The elementary part of the Turan theorem is the exact identity
  (P * L)^2 - P * (P * (L^2 - Q)) = P^2 * Q,
where P is the product over finite real-root factors,
L = sum of reciprocal differences, and Q is the sum of their squares.
This is unconditional for EVERY dimension, and nonnegative on R.

The identification of P*L and P*(L^2-Q) with the first and second
ordinary polynomial derivatives is not asserted by this module; that is
a separate remaining source-faithfulness obligation for Theorem 3.7.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological.Principal

/-- Product of linear factors, evaluated at a real argument. -/
def rootProduct {n : ℕ} (r : Fin n → ℝ) (x : ℝ) : ℝ :=
  ∏ i : Fin n, (x - r i)

/-- Finite logarithmic-derivative sum, interpreted algebraically. -/
def rootReciprocalSum {n : ℕ} (r : Fin n → ℝ) (x : ℝ) : ℝ :=
  ∑ i : Fin n, (x - r i)⁻¹

/-- Finite sum of nonnegative reciprocal squares. -/
def rootReciprocalSquares {n : ℕ} (r : Fin n → ℝ) (x : ℝ) : ℝ :=
  ∑ i : Fin n, ((x - r i)⁻¹) ^ 2

/-- Finite factored expressions that agree with first and second ordinary
derivatives of the root polynomial away from roots. -/
def factoredFirst {n : ℕ} (r : Fin n → ℝ) (x : ℝ) : ℝ :=
  rootProduct r x * rootReciprocalSum r x

def factoredSecond {n : ℕ} (r : Fin n → ℝ) (x : ℝ) : ℝ :=
  rootProduct r x *
    ((rootReciprocalSum r x) ^ 2 - rootReciprocalSquares r x)

/-- Exact SOS identity, with NO restriction on dimension or positions of
real roots and NO need to divide by the polynomial value. -/
theorem universal_laguerre_sos_identity
    {n : ℕ} (r : Fin n → ℝ) (x : ℝ) :
    (factoredFirst r x) ^ 2 -
       rootProduct r x * factoredSecond r x =
         (rootProduct r x) ^ 2 * rootReciprocalSquares r x := by
  unfold factoredFirst factoredSecond
  ring

/-- Every finite reciprocal-square sum is nonnegative, including at
arguments equal to roots (where Lean's totalized inverse is zero). -/
theorem reciprocal_square_sum_nonneg
    {n : ℕ} (r : Fin n → ℝ) (x : ℝ) :
    0 ≤ rootReciprocalSquares r x := by
  unfold rootReciprocalSquares
  exact Finset.sum_nonneg (fun i hi => sq_nonneg _)

/-- The full all-degree finite real-root Turan expression is nonnegative. -/
theorem universal_laguerre_turan_nonnegative
    {n : ℕ} (r : Fin n → ℝ) (x : ℝ) :
    0 ≤ (factoredFirst r x) ^ 2 -
       rootProduct r x * factoredSecond r x := by
  rw [universal_laguerre_sos_identity]
  exact mul_nonneg (sq_nonneg _) (reciprocal_square_sum_nonneg r x)

/-- For points away from every root the product is nonzero, making
the finite logarithmic-derivative representation legitimate. -/
theorem rootProduct_ne_zero_of_avoids_roots
    {n : ℕ} (r : Fin n → ℝ) (x : ℝ)
    (h : ∀ i : Fin n, x ≠ r i) : rootProduct r x ≠ 0 := by
  unfold rootProduct
  exact Finset.prod_ne_zero_iff.mpr (by
    intro i hi
    exact sub_ne_zero.mpr (h i))

end PaperChronological.Principal

#print axioms PaperChronological.Principal.universal_laguerre_turan_nonnegative
