import PaperChronological.T2_2

/-!
# Lemma 2.2, finite-span closure

The paper's rational-function domain is polynomial part plus finitely many
simple negative-square poles. This file extends the already proved generator
identities to the *whole finite partial-fraction presentation* by linearity.

The right hand side is the expanded tau-evaluation of
`x^(2*k+1) * R(-x^2)` on those generators; it is not defined by copying the
left hand side. This theorem is about finite presentations; it does not separately prove
uniqueness of their interpretation as rational functions.

Status: NEW / awaiting user's native Lean compilation.
-/

noncomputable section
open scoped BigOperators Polynomial
open Polynomial

namespace PaperChronological

/-- The tau pullback of a polynomial-plus-simple-poles presentation, obtained
by expanding `x^(2k+1) * R(-x^2)` on the paper's generator basis. -/
noncomputable def tauPullbackOnPresentation (k : ℕ)
    (R : Zetahyperbolic.RatMomentElem) : ℚ[X] :=
  (∑ e ∈ Finset.range (R.polyPart.natDegree + 1),
    Polynomial.C (R.polyPart.coeff e *
      ((-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1)))) +
  ∑ j ∈ Finset.Icc 1 R.maxPole,
    Polynomial.C (R.poleRes j) *
      (Polynomial.C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        Polynomial.C ((j : ℚ) ^ (2 * k) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
           Zetahyperbolic.tauPolePoly k (-(j : ℤ))))

/-- Lemma 2.2, equation (2.5), for every canonical finite partial-fraction
presentation, rather than separately for its monomial and pole generators. -/
theorem LEMMA_2_2_FINITE_SPAN
    (k : ℕ) (hk : 1 ≤ k) (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k R =
      tauPullbackOnPresentation k R := by
  unfold Zetahyperbolic.muFunctionalPoly tauPullbackOnPresentation
  congr 1
  · apply Finset.sum_congr rfl
    intro e he
    rw [LEMMA_2_2_MONOMIAL k e hk]
  · apply Finset.sum_congr rfl
    intro j hj
    rw [LEMMA_2_2_POLE k j hk (Finset.mem_Icc.mp hj).1]

end PaperChronological
