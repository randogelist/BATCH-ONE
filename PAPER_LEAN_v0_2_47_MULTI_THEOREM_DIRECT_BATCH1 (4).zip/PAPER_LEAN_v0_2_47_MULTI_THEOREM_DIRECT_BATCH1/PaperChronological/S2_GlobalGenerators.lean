import PaperChronological.S2_GlobalCoordinates

/-!
# Section 2: the defining polynomial and simple-pole generators

The polynomial-only and pole-only generators are represented by actual
points of the **global** rational-function quotient.  These results ensure
that the quotient model of Definition 2.1 has exactly the defining moments
(2.2) and (2.3), not merely a suitable coefficient array.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- A polynomial regarded as a rational function with no poles. -/
def polynomialPresentation (P : ℚ[X]) : Zetahyperbolic.RatMomentElem :=
  { polyPart := P
    maxPole := 0
    poleRes := fun _ => 0 }

/-- The simple pole `(t+j²)⁻¹` is permitted precisely when `j ≥ 1`. -/
def simplePolePresentation (j : ℕ) : Zetahyperbolic.RatMomentElem :=
  { polyPart := 0
    maxPole := j
    poleRes := fun a => if a = j then 1 else 0 }

@[simp] theorem polynomialPresentation_polyPart (P : ℚ[X]) :
    polynomialPartOnDomain
      (Quotient.mk finitePoleSetoid (polynomialPresentation P)) = P :=
  rfl

@[simp] theorem polynomialPresentation_residue (P : ℚ[X])
    (j : ℕ) (hj : 1 ≤ j) :
    poleResidueOnDomain j
      (Quotient.mk finitePoleSetoid (polynomialPresentation P)) = 0 := by
  rw [poleResidueOnDomain_mk j hj]
  simp [paddedResidue, polynomialPresentation]

@[simp] theorem simplePolePresentation_polyPart (j : ℕ) :
    polynomialPartOnDomain
      (Quotient.mk finitePoleSetoid (simplePolePresentation j)) = 0 :=
  rfl

/-- All the coordinates of a simple pole are zero except the one at `j`. -/
theorem simplePolePresentation_residue (j a : ℕ) (ha : 1 ≤ a) :
    poleResidueOnDomain a
      (Quotient.mk finitePoleSetoid (simplePolePresentation j)) =
        if a = j then 1 else 0 := by
  rw [poleResidueOnDomain_mk a ha]
  by_cases hle : a ≤ j
  · simp [paddedResidue, simplePolePresentation, hle]
  · have hne : a ≠ j := by omega
    simp [paddedResidue, simplePolePresentation, hle, hne]

/-- Equation (2.2) on the quotient: the polynomial contribution is precisely
the Bernoulli-weighted monomial functional on its finite coefficient list. -/
theorem polynomialPresentation_moment (k : ℕ) (P : ℚ[X]) :
    muOnRationalDomain k
        (Quotient.mk finitePoleSetoid (polynomialPresentation P)) =
      ∑ e ∈ Finset.range (P.natDegree + 1),
        C (P.coeff e * Zetahyperbolic.muMonomial k e) := by
  simp [muOnRationalDomain_mk, Zetahyperbolic.muFunctionalPoly,
    polynomialPresentation]

/-- Equation (2.3) on the quotient: the bare simple-pole generator evaluates
to the exact affine polynomial, including both its harmonic constant and its
X-slope. -/
theorem simplePolePresentation_moment (k j : ℕ) (hj : 1 ≤ j) :
    muOnRationalDomain k
        (Quotient.mk finitePoleSetoid (simplePolePresentation j)) =
          Zetahyperbolic.muPolePoly k j := by
  rw [muOnRationalDomain_mk]
  change (∑ e ∈ Finset.range ((0 : ℚ[X]).natDegree + 1),
          C ((0 : ℚ[X]).coeff e * Zetahyperbolic.muMonomial k e)) +
        (∑ a ∈ Finset.Icc 1 j,
          C (if a = j then (1 : ℚ) else 0) *
            Zetahyperbolic.muPolePoly k a) =
      Zetahyperbolic.muPolePoly k j
  have hzero :
      (∑ e ∈ Finset.range ((0 : ℚ[X]).natDegree + 1),
          C ((0 : ℚ[X]).coeff e * Zetahyperbolic.muMonomial k e)) = 0 := by
    simp
  rw [hzero, zero_add]
  rw [Finset.sum_eq_single j]
  · simp
  · intro a _ hne
    simp [hne]
  · intro hnot
    exact (hnot (Finset.mem_Icc.mpr ⟨hj, le_rfl⟩)).elim

end PaperChronological.Section2
