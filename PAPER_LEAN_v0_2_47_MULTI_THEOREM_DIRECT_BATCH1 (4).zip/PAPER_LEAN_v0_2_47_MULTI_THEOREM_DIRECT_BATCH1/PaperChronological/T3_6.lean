import PaperChronological.T3_5

/-!
# Corollary 3.6: Stieltjes reciprocal-root power sums

PDF p. 11. Audit status: ERRATUM.

The printed proposition needs correction: do not certify it as written.
Only the demonstrable repaired finite claim below (if present) is formalized.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- The moment Hankel matrix of a single atom already has rank one.
Thus the printed all-orders STRICT Hankel-positivity statement is false. -/
theorem COROLLARY_3_6_RANK_ONE_OBSTRUCTION (u : ℝ) :
    (1 : ℝ) * u ^ 2 - u * u = 0 := by ring

/-- A corrected two-atom power-sum envelope before reciprocal powers. -/
theorem COROLLARY_3_6_POWER_SUM_TWO_ATOMS
    (u v : ℝ) (hu : 0 ≤ u) (hv : 0 ≤ v) :
    max u v ≤ u + v ∧ u + v ≤ 2 * max u v := by
  constructor
  · exact max_le (by linarith) (by linarith)
  · calc
      u + v ≤ max u v + max u v :=
        add_le_add (le_max_left u v) (le_max_right u v)
      _ = 2 * max u v := by ring

end PaperChronological
