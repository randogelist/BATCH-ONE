import PaperChronological.Principal_T3_7_DerivativeTuran

/-!
# Direct manuscript Theorem 3.7(1) — strict first Turan inequality

This module proves strict positivity of the ACTUAL odd-weight Hankel
polynomial's ordinary-derivative Turan expression away from its roots,
including at zeta(s), for every strictly positive pencil dimension.
No substitute polynomial, analytic witness, or new axiom is used.

The higher-derivative (m > 1) and coefficient Newton parts of Theorem 3.7
are distinct future targets, not asserted here.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Principal

/-- Product propagation of strict ordinary-derivative Turan positivity. -/
theorem derivativeTuran_mul_pos_of_left
    (P Q : ℝ[X]) (x : ℝ)
    (hP : 0 < derivativeTuran P x)
    (hQ : 0 ≤ derivativeTuran Q x)
    (hQx : Q.eval x ≠ 0) :
    0 < derivativeTuran (P * Q) x := by
  rw [derivativeTuran_mul]
  exact add_pos_of_pos_of_nonneg
    (mul_pos (sq_pos_of_ne_zero hQx) hP)
    (mul_nonneg (sq_nonneg _) hQ)

/-- A nonempty product of individually strictly Turan-positive factors is
strictly Turan-positive wherever no factor vanishes. The proof is a finite
factorization argument, so it applies in EVERY dimension and at real roots
of other polynomials. -/
theorem derivativeTuran_prod_pos
    {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (F : ι → ℝ[X]) (x : ℝ)
    (hs : s.Nonempty)
    (hF : ∀ i, 0 < derivativeTuran (F i) x)
    (hEval : ∀ i, (F i).eval x ≠ 0) :
    0 < derivativeTuran (∏ i ∈ s, F i) x := by
  classical
  obtain ⟨a, ha⟩ := hs
  have hq : (∏ i ∈ s.erase a, F i).eval x ≠ 0 := by
    simp only [Polynomial.eval_prod]
    apply Finset.prod_ne_zero_iff.mpr
    intro i hi
    exact hEval i
  have hremain : 0 ≤ derivativeTuran (∏ i ∈ s.erase a, F i) x := by
    apply derivativeTuran_prod_nonneg (s := s.erase a) (F := F) (x := x)
    intro i
    exact le_of_lt (hF i)
  have hsplit : (∏ i ∈ s, F i) = F a * (∏ i ∈ s.erase a, F i) := by
    calc
      (∏ i ∈ s, F i) = ∏ i ∈ insert a (s.erase a), F i := by
        rw [Finset.insert_erase ha]
      _ = F a * (∏ i ∈ s.erase a, F i) := by
        have ha_not : a ∉ s.erase a := by simp
        rw [Finset.prod_insert ha_not]
  rw [hsplit]
  exact derivativeTuran_mul_pos_of_left (F a)
    (∏ i ∈ s.erase a, F i) x (hF a) hremain hq

/-- An arbitrary real symmetric affine pencil with a proven spectral
factorization has STRICT ordinary-derivative Turan positivity wherever its
actual determinant has no root, provided its dimension is positive. -/
theorem derivativeTuran_strict_of_spectralFactorization
    {n : ℕ} {p : ManuscriptChain.Spectral.SymmetricAffinePencil n}
    (c : ManuscriptChain.Spectral.RootFactorization p)
    (hn : 0 < n) (x : ℝ)
    (havoid : ∀ i : Fin n, x ≠ c.root i) :
    0 < derivativeTuran p.detPolynomial x := by
  have hpositive : 0 < derivativeTuran
      (∏ i : Fin n,
        ManuscriptChain.Spectral.spectralFactor p.center (c.beta i)) x := by
    apply derivativeTuran_prod_pos
      (s := (Finset.univ : Finset (Fin n)))
      (F := fun i => ManuscriptChain.Spectral.spectralFactor p.center (c.beta i))
      (x := x)
    · exact ⟨⟨0, hn⟩, Finset.mem_univ _⟩
    · intro i
      rw [derivativeTuran_spectralFactor]
      exact sq_pos_of_ne_zero (c.beta_ne_zero i)
    · intro i hzero
      have heq : 1 + (x - p.center) * c.beta i = 0 := by
        simpa only [ManuscriptChain.Spectral.eval_spectralFactor] using hzero
      exact havoid i
        ((ManuscriptChain.Spectral.linear_factor_eq_zero_iff
          p.center (c.beta i) x (c.beta_ne_zero i)).mp heq)
  rw [c.factorization, derivativeTuran_C_mul]
  exact mul_pos (sq_pos_of_ne_zero c.base_det_ne_zero) hpositive

/-- The actual odd-weight zeta Hankel determinant: strict first Turan
inequality at EVERY real point that is not one of its roots. -/
theorem THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_OFF_ROOTS
    (q : ManuscriptChain.Real.Parameters)
    (hq : ManuscriptChain.Real.Admissible q)
    (hh : 0 < q.h) (x : ℝ)
    (hx : (ManuscriptChain.Real.manuscriptPencil q).detPolynomial.eval x ≠ 0) :
    0 < derivativeTuran
      (ManuscriptChain.Real.manuscriptPencil q).detPolynomial x := by
  let c := ManuscriptChain.General.factorization q
    (ManuscriptChain.GRAM_POSITIVE q hq)
  apply derivativeTuran_strict_of_spectralFactorization c hh x
  intro i heq
  have hz := c.eval_root i
  rw [← heq] at hz
  exact hx hz

/-- In particular the theorem is STRICT at its zeta center: Gram
positivity already proves nonvanishing there. -/
theorem THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_AT_CENTER
    (q : ManuscriptChain.Real.Parameters)
    (hq : ManuscriptChain.Real.Admissible q)
    (hh : 0 < q.h) :
    0 < derivativeTuran
      (ManuscriptChain.Real.manuscriptPencil q).detPolynomial
      (ManuscriptChain.Real.zeta q.weight) := by
  have hx :
      (ManuscriptChain.Real.manuscriptPencil q).detPolynomial.eval
        (ManuscriptChain.Real.zeta q.weight) ≠ 0 := by
    have hG := ManuscriptChain.GRAM_POSITIVE q hq
    simpa only [ManuscriptChain.Real.manuscriptPencil_center] using
      (ManuscriptChain.Real.manuscriptPencil q).center_nonvanishing_of_positive hG
  exact THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_OFF_ROOTS q hq hh _ hx

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_AT_CENTER
#print axioms PaperChronological.Principal.THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_OFF_ROOTS
