import PaperChronological.S2_RationalEndpoint

/-!
# Section 2: native compile/axiom audit of newly formalized rational bridge
Prints theorem types and native axiom reports in the user's build log.
-/

#check PaperChronological.Section2.poleDerivative
#check PaperChronological.Section2.clearedResidueNumerator
#check PaperChronological.Section2.clearedResidue_eval_node
#check PaperChronological.Section2.clearedResidue_unique
#check PaperChronological.Section2.offTailPoles_of_nonneg
#check PaperChronological.Section2.tailD_eval_ne_zero_at
#check PaperChronological.Section2.residue_term_cleared
#check PaperChronological.Section2.clearedResidue_eval_eq
#check PaperChronological.Section2.residueValue_eq_quotient
#check PaperChronological.Section2.clearedFraction_unique
#check PaperChronological.Section2.SECTION2_RATIONAL_ALGEBRAIC_CHAIN

#print axioms PaperChronological.Section2.clearedResidue_unique
#print axioms PaperChronological.Section2.residueValue_eq_quotient
#print axioms PaperChronological.Section2.clearedFraction_unique
#print axioms PaperChronological.Section2.SECTION2_RATIONAL_ALGEBRAIC_CHAIN
