import PaperChronological.PRINCIPAL_CHAIN

/-!
# Native axiom audit — new principal-theorem endpoints

Only standard Lean foundations `propext`, `Classical.choice`, `Quot.sound`
are permitted by this project. Any unexpected `sorryAx` in these outputs
is a failure and should be treated as a blocking regression.
-/

#print PaperChronological.Principal.PRINCIPAL_SPECTRAL_ODD_ZETA_CHAIN
#print PaperChronological.Principal.PRINCIPAL_TURAN_SOS_ALL_FINITE_DIMENSIONS
#print axioms PaperChronological.Principal.PRINCIPAL_SPECTRAL_ODD_ZETA_CHAIN
#print axioms PaperChronological.Principal.PRINCIPAL_TURAN_SOS_ALL_FINITE_DIMENSIONS
#print axioms PaperChronological.Principal.root_counts_eq_beta_sign_counts
#print axioms PaperChronological.Principal.universal_finite_character_pencil_hyperbolicity
