import PaperChronological.T3_6

/-!
# Theorem 3.7: Turanian non-negativity and Newton log-concavity

PDF p. 11. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 3.7: Turanian inequality in the exact two-real-root case.
The full all-degree Newton/Turan statement remains to be formalized. -/
theorem THEOREM_3_7_QUADRATIC_TURAN
    (x r s : ℝ) :
    0 ≤ (2 * x - r - s) ^ 2 - 2 * (x - r) * (x - s) := by
  have hid : (2 * x - r - s) ^ 2 - 2 * (x - r) * (x - s) =
      (x - r) ^ 2 + (x - s) ^ 2 := by ring
  rw [hid]
  positivity

end PaperChronological
