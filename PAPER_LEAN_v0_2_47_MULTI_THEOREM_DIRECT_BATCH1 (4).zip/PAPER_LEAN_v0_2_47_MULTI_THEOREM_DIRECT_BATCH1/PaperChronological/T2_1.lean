import Mathlib
import Zetahyperbolic.Section2Checked

/-!
# Definition 2.1: Order-s rational moment functional

PDF p. 3. Audit status: PROVED.

This module links an actual mathematical theorem to previously
proved source declarations; no manuscript premise is silently postulated.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


open Polynomial

/-- Definition 2.1: monomial moments have no X-dependence. -/
def monomialMoment (k e : ℕ) : ℚ := Zetahyperbolic.muMonomial k e

/-- Definition 2.1: the pole dependence has the slope printed in equation (2.3). -/
theorem DEF_2_1_POLE_SLOPE (k j : ℕ) :
    (Zetahyperbolic.muPolePoly k j).coeff 1 = (j : ℚ) ^ (2 * k) :=
  Zetahyperbolic.muPolePoly_coeff_one k j

/-- Equation (2.1): the empty product is one. -/
theorem DEF_2_1_EMPTY_DENOMINATOR : Zetahyperbolic.D_poly 0 = 1 :=
  Zetahyperbolic.D_poly_zero

end PaperChronological
