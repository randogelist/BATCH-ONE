import PaperChronological.T3_3
import MAIN_CHAIN_ASSEMBLED

/-!
# Manuscript Theorem 3.3 — real-root location and spectral sign split

For the ACTUAL zeta-Hankel pencil, the unconditional theorem of 3.1 constructs
its nonzero real spectral parameters beta. This module derives, at every
finite dimension and without a witness, which side of zeta each indexed root
occupies. Root indices count algebraic multiplicity.

The manuscript's stronger exact alternating inertia COUNT and Carleman/total
positivity assertions remain separate and are not claimed here.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological.Principal

open ManuscriptChain

variable {n : ℕ} {p : Spectral.SymmetricAffinePencil n}

/-- Every spectral root lies below the center exactly when its eigenvalue
parameter is positive. No hypothesis about zeta irrationality is used. -/
theorem root_lt_center_iff_beta_pos
    (c : Spectral.RootFactorization p) (i : Fin n) :
    c.root i < p.center ↔ 0 < c.beta i := by
  unfold Spectral.RootFactorization.root
  constructor
  · intro h
    have hinv : 0 < (c.beta i)⁻¹ := by linarith
    exact inv_pos.mp hinv
  · intro hb
    have hinv : 0 < (c.beta i)⁻¹ := inv_pos.mpr hb
    linarith

/-- The other side of the zeta center corresponds to a negative spectral
parameter; zero is impossible by the proved nonsingular derivative. -/
theorem root_gt_center_iff_beta_neg
    (c : Spectral.RootFactorization p) (i : Fin n) :
    p.center < c.root i ↔ c.beta i < 0 := by
  have hbelow := root_lt_center_iff_beta_pos c i
  constructor
  · intro hr
    rcases lt_trichotomy (c.beta i) 0 with hn | hz | hp
    · exact hn
    · exact False.elim ((c.beta_ne_zero i) hz)
    · have hl : c.root i < p.center := hbelow.mpr hp
      linarith
  · intro hn
    rcases lt_trichotomy (c.root i) p.center with hl | heq | hr
    · have hp : 0 < c.beta i := hbelow.mp hl
      linarith
    · exact False.elim ((c.root_ne_center i) heq)
    · exact hr

/-- Multiplicity-counted spectral roots below the center. -/
def rootsBelowCount (c : Spectral.RootFactorization p) : ℕ :=
  (Finset.univ.filter (fun i : Fin n => c.root i < p.center)).card

/-- Multiplicity-counted spectral roots above the center. -/
def rootsAboveCount (c : Spectral.RootFactorization p) : ℕ :=
  (Finset.univ.filter (fun i : Fin n => p.center < c.root i)).card

def positiveBetaCount (c : Spectral.RootFactorization p) : ℕ :=
  (Finset.univ.filter (fun i : Fin n => 0 < c.beta i)).card

def negativeBetaCount (c : Spectral.RootFactorization p) : ℕ :=
  (Finset.univ.filter (fun i : Fin n => c.beta i < 0)).card

/-- Full-dimensional root counts reduce EXACTLY to eigenvalue-sign counts. -/
theorem root_counts_eq_beta_sign_counts
    (c : Spectral.RootFactorization p) :
    rootsBelowCount c = positiveBetaCount c ∧
    rootsAboveCount c = negativeBetaCount c := by
  constructor
  · simp [rootsBelowCount, positiveBetaCount,
      root_lt_center_iff_beta_pos]
  · simp [rootsAboveCount, negativeBetaCount,
      root_gt_center_iff_beta_neg]

/-- Every spectral root is on precisely one of the two sides of the center. -/
theorem root_strictly_bilateral
    (c : Spectral.RootFactorization p) (i : Fin n) :
    c.root i < p.center ∨ p.center < c.root i := by
  rcases lt_trichotomy (c.root i) p.center with hl | heq | hr
  · exact Or.inl hl
  · exact False.elim ((c.root_ne_center i) heq)
  · exact Or.inr hr

/-- Theorem 3.3, unconditional classification for the ACTUAL odd-zeta
Hankel determinant: all its indexed real roots avoid the zeta center,
with exact left/right classification by spectral parameter sign. -/
theorem actual_odd_zeta_bilateral_spectral_roots
    (q : Real.Parameters) (hq : Real.Admissible q) :
    ∃ beta : Fin q.h → ℝ,
      (∀ i, beta i ≠ 0) ∧
      (∀ i, Real.zeta q.weight - (beta i)⁻¹ < Real.zeta q.weight ↔
         0 < beta i) ∧
      (∀ i, Real.zeta q.weight < Real.zeta q.weight - (beta i)⁻¹ ↔
         beta i < 0) ∧
      (∀ i, General.ComplexRoot q
        ((Real.zeta q.weight - (beta i)⁻¹ : ℝ) : ℂ)) := by
  let hg := ManuscriptChain.GRAM_POSITIVE q hq
  let c := General.factorization q hg
  refine ⟨c.beta, c.beta_ne_zero, ?_, ?_, ?_⟩
  · intro i
    simpa only [Real.manuscriptPencil_center,
      Spectral.RootFactorization.root] using
      (root_lt_center_iff_beta_pos c i)
  · intro i
    simpa only [Real.manuscriptPencil_center,
      Spectral.RootFactorization.root] using
      (root_gt_center_iff_beta_neg c i)
  · intro i
    have hz : General.ComplexRoot q (c.root i : ℂ) :=
      (General.complex_root_iff q hg (c.root i : ℂ)).mpr ⟨i, rfl⟩
    simpa only [Real.manuscriptPencil_center,
      Spectral.RootFactorization.root] using hz

end PaperChronological.Principal

#print axioms PaperChronological.Principal.actual_odd_zeta_bilateral_spectral_roots
