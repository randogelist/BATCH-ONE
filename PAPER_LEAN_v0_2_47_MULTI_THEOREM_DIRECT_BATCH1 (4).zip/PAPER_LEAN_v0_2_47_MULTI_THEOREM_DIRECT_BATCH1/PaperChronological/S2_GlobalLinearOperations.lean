import PaperChronological.S2_GlobalGenerators

/-!
# Section 2: operations on the rational-function quotient

The manuscript's Q-linearity requires that the directed union be closed under
addition and rational scaling independently of any choice of finite cutoff.
We define these operations on finite presentations and prove that they descend
to the *same quotient* used by the global moment functional. We also establish
their intrinsic polynomial/residue coordinate formulas and basic algebraic
identities. The moment-homomorphism proof is reserved as a separate independent
module; this module does not silently assume it.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- Addition of two finite pole presentations, padded to a common cutoff. -/
def addFinitePresentations
    (R S : Zetahyperbolic.RatMomentElem) : Zetahyperbolic.RatMomentElem :=
  { polyPart := R.polyPart + S.polyPart
    maxPole := max R.maxPole S.maxPole
    poleRes := fun j => paddedResidue R j + paddedResidue S j }

/-- At every index, even outside the common cutoff, adding presentations
adds the zero-padded residues. -/
theorem paddedResidue_addFinitePresentations
    (R S : Zetahyperbolic.RatMomentElem) (j : ℕ) :
    paddedResidue (addFinitePresentations R S) j =
      paddedResidue R j + paddedResidue S j := by
  by_cases hbound : j ≤ max R.maxPole S.maxPole
  · simp [paddedResidue, addFinitePresentations, hbound]
  · have hR : ¬ j ≤ R.maxPole := by omega
    have hS : ¬ j ≤ S.maxPole := by omega
    simp [paddedResidue, addFinitePresentations, hbound, hR, hS]

/-- Addition respects the quotient equivalence relation on both inputs. -/
theorem sameFinitePoleData_add
    (R R' S S' : Zetahyperbolic.RatMomentElem)
    (hR : sameFinitePoleData R R')
    (hS : sameFinitePoleData S S') :
    sameFinitePoleData (addFinitePresentations R S)
      (addFinitePresentations R' S') := by
  constructor
  · simp only [addFinitePresentations, hR.1, hS.1]
  · intro j hj
    rw [paddedResidue_addFinitePresentations,
      paddedResidue_addFinitePresentations, hR.2 j hj, hS.2 j hj]

/-- Addition on the quotient, *defined using a proved congruence theorem*. -/
noncomputable def rationalAdd
    (R S : RationalMomentDomain) : RationalMomentDomain :=
  Quotient.liftOn₂ R S
    (fun r s => Quotient.mk finitePoleSetoid (addFinitePresentations r s))
    (fun r r' s s' hr hs => Quotient.sound (sameFinitePoleData_add r s r' s' hr hs))

@[simp] theorem rationalAdd_mk
    (R S : Zetahyperbolic.RatMomentElem) :
    rationalAdd (Quotient.mk finitePoleSetoid R)
      (Quotient.mk finitePoleSetoid S) =
        Quotient.mk finitePoleSetoid (addFinitePresentations R S) :=
  rfl

/-- Rational scaling of both polynomial and ordinary pole residue data. -/
def scaleFinitePresentation
    (q : ℚ) (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.RatMomentElem :=
  { polyPart := C q * R.polyPart
    maxPole := R.maxPole
    poleRes := fun j => q * R.poleRes j }

/-- Scaling commutes with zero-padding, also outside the finite support. -/
theorem paddedResidue_scaleFinitePresentation
    (q : ℚ) (R : Zetahyperbolic.RatMomentElem) (j : ℕ) :
    paddedResidue (scaleFinitePresentation q R) j =
      q * paddedResidue R j := by
  by_cases hbound : j ≤ R.maxPole
  · simp [paddedResidue, scaleFinitePresentation, hbound]
  · simp [paddedResidue, scaleFinitePresentation, hbound]

/-- Rational scalar multiplication preserves equality of rational functions. -/
theorem sameFinitePoleData_scale (q : ℚ)
    (R S : Zetahyperbolic.RatMomentElem)
    (h : sameFinitePoleData R S) :
    sameFinitePoleData (scaleFinitePresentation q R)
      (scaleFinitePresentation q S) := by
  constructor
  · simp only [scaleFinitePresentation, h.1]
  · intro j hj
    rw [paddedResidue_scaleFinitePresentation,
      paddedResidue_scaleFinitePresentation, h.2 j hj]

/-- Rational scalar multiplication on the directed union, not dependent on
an individual representative or its finite cutoff. -/
noncomputable def rationalScale (q : ℚ)
    (R : RationalMomentDomain) : RationalMomentDomain :=
  Quotient.liftOn R
    (fun r => Quotient.mk finitePoleSetoid (scaleFinitePresentation q r))
    (fun r s h => Quotient.sound (sameFinitePoleData_scale q r s h))

@[simp] theorem rationalScale_mk (q : ℚ)
    (R : Zetahyperbolic.RatMomentElem) :
    rationalScale q (Quotient.mk finitePoleSetoid R) =
      Quotient.mk finitePoleSetoid (scaleFinitePresentation q R) :=
  rfl

/-- Polynomial coordinates preserve quotient addition. -/
@[simp] theorem polynomialPartOnDomain_rationalAdd
    (R S : RationalMomentDomain) :
    polynomialPartOnDomain (rationalAdd R S) =
      polynomialPartOnDomain R + polynomialPartOnDomain S := by
  refine Quotient.inductionOn₂ R S ?_
  intro r s
  rfl

/-- Every individual residue coordinate preserves quotient addition. -/
theorem poleResidueOnDomain_rationalAdd
    (j : ℕ) (R S : RationalMomentDomain) :
    poleResidueOnDomain j (rationalAdd R S) =
      poleResidueOnDomain j R + poleResidueOnDomain j S := by
  refine Quotient.inductionOn₂ R S ?_
  intro r s
  by_cases hj : 1 ≤ j
  · simp only [rationalAdd_mk, poleResidueOnDomain_mk j hj]
    exact paddedResidue_addFinitePresentations r s j
  · simp [poleResidueOnDomain, hj]

/-- Polynomial coordinates preserve rational scaling. -/
@[simp] theorem polynomialPartOnDomain_rationalScale
    (q : ℚ) (R : RationalMomentDomain) :
    polynomialPartOnDomain (rationalScale q R) =
      C q * polynomialPartOnDomain R := by
  refine Quotient.inductionOn R ?_
  intro r
  rfl

/-- Residues preserve rational scaling. -/
theorem poleResidueOnDomain_rationalScale
    (q : ℚ) (j : ℕ) (R : RationalMomentDomain) :
    poleResidueOnDomain j (rationalScale q R) =
      q * poleResidueOnDomain j R := by
  refine Quotient.inductionOn R ?_
  intro r
  by_cases hj : 1 ≤ j
  · simp only [rationalScale_mk, poleResidueOnDomain_mk j hj]
    exact paddedResidue_scaleFinitePresentation q r j
  · simp [poleResidueOnDomain, hj]

/-- Global addition is commutative. The proof uses the quotient's *intrinsic*
coordinates; it does not rely on matching artificial finite cutoffs. -/
theorem rationalAdd_comm (R S : RationalMomentDomain) :
    rationalAdd R S = rationalAdd S R := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalAdd]
    exact add_comm _ _
  · intro j hj
    simp only [poleResidueOnDomain_rationalAdd]
    exact add_comm _ _

/-- Global addition is associative, even for three unrelated cutoff bounds. -/
theorem rationalAdd_assoc (R S T : RationalMomentDomain) :
    rationalAdd (rationalAdd R S) T = rationalAdd R (rationalAdd S T) := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalAdd]
    exact add_assoc _ _ _
  · intro j hj
    simp only [poleResidueOnDomain_rationalAdd]
    exact add_assoc _ _ _

/-- Scalar multiplication is compatible with successive rational scalars. -/
theorem rationalScale_mul (q r : ℚ) (R : RationalMomentDomain) :
    rationalScale (q * r) R = rationalScale q (rationalScale r R) := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalScale, map_mul]
    ring
  · intro j hj
    simp only [poleResidueOnDomain_rationalScale]
    ring

/-- The scalar distributes over two rational functions. -/
theorem rationalScale_add (q : ℚ) (R S : RationalMomentDomain) :
    rationalScale q (rationalAdd R S) =
      rationalAdd (rationalScale q R) (rationalScale q S) := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalAdd,
      polynomialPartOnDomain_rationalScale]
    ring
  · intro j hj
    simp only [poleResidueOnDomain_rationalAdd,
      poleResidueOnDomain_rationalScale]
    ring

end PaperChronological.Section2

namespace PaperChronological.Section2

/-- The finite-pole quotient is stable under both algebraic operations,
with explicit coordinate laws. Installing the full Q-module instance and
proving moment-functional homomorphism are independent subsequent tasks. -/
structure GlobalLinearOperationsChain : Prop where
  coordinates : GlobalCoordinatesChain
  addComm : ∀ R S : RationalMomentDomain,
    rationalAdd R S = rationalAdd S R
  addAssoc : ∀ R S T : RationalMomentDomain,
    rationalAdd (rationalAdd R S) T = rationalAdd R (rationalAdd S T)
  scaleMul : ∀ q r : ℚ, ∀ R : RationalMomentDomain,
    rationalScale (q * r) R = rationalScale q (rationalScale r R)
  scaleDistributes : ∀ q : ℚ, ∀ R S : RationalMomentDomain,
    rationalScale q (rationalAdd R S) =
      rationalAdd (rationalScale q R) (rationalScale q S)

/-- A witness-free assembly of actual quotient arithmetic and finite support. -/
theorem SECTION2_GLOBAL_LINEAR_OPERATIONS : GlobalLinearOperationsChain := by
  exact {
    coordinates := SECTION2_GLOBAL_COORDINATES
    addComm := rationalAdd_comm
    addAssoc := rationalAdd_assoc
    scaleMul := rationalScale_mul
    scaleDistributes := rationalScale_add
  }

end PaperChronological.Section2
