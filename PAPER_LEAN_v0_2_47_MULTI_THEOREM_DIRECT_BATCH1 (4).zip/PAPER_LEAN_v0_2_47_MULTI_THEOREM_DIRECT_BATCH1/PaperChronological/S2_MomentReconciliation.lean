import PaperChronological.S2_AllFinitePoles
import Zetahyperbolic.ManuscriptCompatibility

/-!
# Section 2, formulas (2.2)--(2.3): two source implementations reconciled

The project has two constructions of the same rational moment data:
`ManuscriptChain.Real` and `Zetahyperbolic`. We establish their equality
on Bernoulli monomials, generalized harmonic numbers, and entire affine
simple-pole moment polynomials. This closes a definitional-compatibility gap
without postulating equality of the different implementations.

The resulting finite-pole moment functional is genuinely affine in X, with
an exactly identified X-slope independent of the polynomial part.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- Bernoulli/factorial monomial moments agree exactly between source branches. -/
theorem monomial_moment_agreement (k e : ℕ) :
    ManuscriptChain.Real.monomialMoment k e =
      Zetahyperbolic.muMonomial k e := by
  rfl

/-- The two finite-sum conventions for `H_n^(s)` are equal. -/
theorem harmonic_moment_agreement (s n : ℕ) :
    ManuscriptChain.Real.harmonic s n =
      Zetahyperbolic.harmonicWeight s n := by
  induction n with
  | zero =>
      simp [ManuscriptChain.Real.harmonic,
        Zetahyperbolic.harmonicWeight]
  | succ n ih =>
      rw [Zetahyperbolic.harmonicWeight_succ, ← ih]
      change (∑ j ∈ Finset.range (n + 1),
        (1 : ℚ) / (((j + 1 : ℕ) : ℚ) ^ s)) =
        ManuscriptChain.Real.harmonic s n +
          ((((n + 1 : ℕ) : ℚ) ^ s)⁻¹)
      rw [Finset.sum_range_succ]
      change ManuscriptChain.Real.harmonic s n +
        (1 : ℚ) / ((((n + 1 : ℕ) : ℚ) ^ s)) =
        ManuscriptChain.Real.harmonic s n +
          ((((n + 1 : ℕ) : ℚ) ^ s)⁻¹)
      simp only [one_div]

/-- Formula (2.3), including BOTH its constant term and its X-coefficient.
This makes the two independent source constructions definitionally compatible
at every simple negative-square pole. -/
theorem simple_pole_moment_affine (k j : ℕ) :
    Zetahyperbolic.muPolePoly k j =
      C (ManuscriptChain.Real.poleConstant k j) +
        C ((j : ℚ) ^ (2 * k)) * X := by
  exact Zetahyperbolic.ManuscriptCompatibility.muPolePoly_eq_affine k j

/-- The actual order-s rational moment polynomial of a finite presentation;
this uses genuine simple-pole residues, not interpolation coefficients. -/
def finiteMomentPolynomial (p : ManuscriptChain.Real.Parameters)
    (k : ℕ) (Q : ℚ[X]) (c : Fin p.h → ℚ) : ℚ[X] :=
  C (ManuscriptChain.Real.polynomialMoment k Q) +
    ∑ a : Fin p.h,
      C (c a) * Zetahyperbolic.muPolePoly k
        (ManuscriptChain.PoleDiagonalization.poleIndex p a)

/-- The exact X-slope of the finite rational functional. No polynomial
moment or harmonic constant can contribute to this derivative matrix. -/
theorem finiteMomentPolynomial_slope
    (p : ManuscriptChain.Real.Parameters) (k : ℕ)
    (Q : ℚ[X]) (c : Fin p.h → ℚ) :
    (finiteMomentPolynomial p k Q c).coeff 1 =
      ∑ a : Fin p.h,
        c a * (ManuscriptChain.PoleDiagonalization.poleIndex p a : ℚ) ^
          (2 * k) := by
  simp [finiteMomentPolynomial, Polynomial.coeff_C_mul,
    Zetahyperbolic.muPolePoly_coeff_one]

/-- With all residues zero, the functional is independent of `X`. -/
theorem finiteMomentPolynomial_without_poles
    (p : ManuscriptChain.Real.Parameters) (k : ℕ) (Q : ℚ[X]) :
    finiteMomentPolynomial p k Q (fun _ => 0) =
      C (ManuscriptChain.Real.polynomialMoment k Q) := by
  simp [finiteMomentPolynomial]

/-- A single simple-pole generator is sent to exactly its prescribed moment. -/
theorem finiteMomentPolynomial_single_pole
    (p : ManuscriptChain.Real.Parameters) (k : ℕ)
    (a : Fin p.h) (c : ℚ) :
    finiteMomentPolynomial p k 0 (fun b => if b = a then c else 0) =
      C c * Zetahyperbolic.muPolePoly k
        (ManuscriptChain.PoleDiagonalization.poleIndex p a) := by
  calc
    finiteMomentPolynomial p k 0 (fun b => if b = a then c else 0) =
        ∑ b : Fin p.h, C (if b = a then c else 0) *
          Zetahyperbolic.muPolePoly k
            (ManuscriptChain.PoleDiagonalization.poleIndex p b) := by
        simp [finiteMomentPolynomial, ManuscriptChain.Real.polynomialMoment]
    _ = _ := by
      rw [Finset.sum_eq_single a]
      · simp
      · intro b _ hba
        simp [hba]
      · intro hnot
        exact (hnot (Finset.mem_univ a)).elim

end PaperChronological.Section2
