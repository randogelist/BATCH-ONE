import PaperChronological.S2_GlobalLinearOperations

/-!
# Native verification of Section 2 intrinsic quotient coordinates

Run all checks with the user's pinned native Lean 4.33.0 compiler. The
source-level package does not claim a successful compile until the user
returns `CHRONOLOGICAL_BUILD=PASS` and the complete axiom audit.
-/

#check PaperChronological.Section2.polynomialPartOnDomain
#check PaperChronological.Section2.poleResidueOnDomain
#check PaperChronological.Section2.poleResidueOnDomain_eventually_zero
#check PaperChronological.Section2.rationalMomentDomain_ext
#check PaperChronological.Section2.rationalMomentDomain_eq_iff
#check PaperChronological.Section2.muOnRationalDomain_slope
#check PaperChronological.Section2.SECTION2_GLOBAL_COORDINATES
#check PaperChronological.Section2.polynomialPresentation_moment
#check PaperChronological.Section2.simplePolePresentation_moment
#check PaperChronological.Section2.sameFinitePoleData_add
#check PaperChronological.Section2.sameFinitePoleData_scale
#check PaperChronological.Section2.rationalAdd_comm
#check PaperChronological.Section2.rationalAdd_assoc
#check PaperChronological.Section2.rationalScale_mul
#check PaperChronological.Section2.rationalScale_add
#check PaperChronological.Section2.SECTION2_GLOBAL_LINEAR_OPERATIONS

#print axioms PaperChronological.Section2.poleResidueOnDomain_eventually_zero
#print axioms PaperChronological.Section2.rationalMomentDomain_ext
#print axioms PaperChronological.Section2.muOnRationalDomain_slope
#print axioms PaperChronological.Section2.SECTION2_GLOBAL_COORDINATES
#print axioms PaperChronological.Section2.simplePolePresentation_moment
#print axioms PaperChronological.Section2.sameFinitePoleData_add
#print axioms PaperChronological.Section2.rationalAdd_assoc
#print axioms PaperChronological.Section2.rationalScale_add
#print axioms PaperChronological.Section2.SECTION2_GLOBAL_LINEAR_OPERATIONS
