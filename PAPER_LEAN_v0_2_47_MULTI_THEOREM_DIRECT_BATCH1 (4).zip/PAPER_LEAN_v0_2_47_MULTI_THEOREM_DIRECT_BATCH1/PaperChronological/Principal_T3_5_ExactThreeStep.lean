import PaperChronological.T3_5
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp

/-!
# Corollary 3.5, correct three-step Jacobi / Schur recurrence

The printed unnormalised J fraction is not asserted. We prove the exact
tridiagonal continuant at order three, with its nonzero-denominator resolvent
identity. These are the finite algebraic relations needed for a CORRECT
Stieltjes/Jacobi fraction; they do not assert Lanczos without cyclicity.
-/

noncomputable section
namespace PaperChronological.Principal

private def continuantTwo (a b u : ℝ) : ℝ := a * b - u ^ 2

private def continuantThree (a b c u v : ℝ) : ℝ :=
  a * b * c - c * u ^ 2 - a * v ^ 2

/-- Exact third-order tridiagonal determinant recurrence. -/
theorem THREE_STEP_CONTINUANT_RECURRENCE (a b c u v : ℝ) :
    continuantThree a b c u v =
      c * continuantTwo a b u - v ^ 2 * a := by
  unfold continuantTwo continuantThree
  ring

/-- Corrected last-step resolvent equation, retaining normalization. -/
theorem THREE_STEP_CORRECTED_RESOLVENT
    (a b c u v : ℝ)
    (h : continuantThree a b c u v ≠ 0) :
    (continuantTwo a b u / continuantThree a b c u v) * c =
      1 + (v ^ 2 * a) / continuantThree a b c u v := by
  field_simp [h]
  unfold continuantTwo continuantThree
  ring

/-- The last-step pivot is nonzero whenever the first two continuants
and the full third continuant are nonzero. -/
theorem THREE_STEP_LAST_SCHUR_NONZERO
    (a b c u v : ℝ)
    (h2 : continuantTwo a b u ≠ 0)
    (h3 : continuantThree a b c u v ≠ 0) :
    c - v ^ 2 * a / continuantTwo a b u ≠ 0 := by
  intro hz
  have hcalc :
      (c - v ^ 2 * a / continuantTwo a b u) * continuantTwo a b u =
        c * continuantTwo a b u - v ^ 2 * a := by
    field_simp [h2]
    ring
  have hz' : c * continuantTwo a b u - v ^ 2 * a = 0 := by
    calc
      c * continuantTwo a b u - v ^ 2 * a =
          (c - v ^ 2 * a / continuantTwo a b u) * continuantTwo a b u := hcalc.symm
      _ = 0 := by rw [hz]; ring
  have hzero : continuantThree a b c u v = 0 := by
    rw [THREE_STEP_CONTINUANT_RECURRENCE]
    exact hz' 
  exact h3 hzero

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THREE_STEP_CONTINUANT_RECURRENCE
#print axioms PaperChronological.Principal.THREE_STEP_CORRECTED_RESOLVENT
#print axioms PaperChronological.Principal.THREE_STEP_LAST_SCHUR_NONZERO
