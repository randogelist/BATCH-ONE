import PaperChronological.T4_4

/-!
# Theorem 4.5: Irrationality/measure for b zeta 5 + a zeta 3

PDF p. 18. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 4.5 is still a formalization target. -/

end PaperChronological
