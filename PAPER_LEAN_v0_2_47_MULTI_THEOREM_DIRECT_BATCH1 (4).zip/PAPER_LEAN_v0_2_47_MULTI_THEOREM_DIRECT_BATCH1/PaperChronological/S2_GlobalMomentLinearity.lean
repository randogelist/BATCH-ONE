import PaperChronological.S2_GlobalMomentBounded

/-!
# Section 2 — Q-linearity on the full directed-union rational-function domain

A key point in Definition 2.1 is that polynomials of different degrees and
presentations with different pole cutoffs must all be evaluated by the *same*
linear map.  The proofs below choose a common cutoff for each pair of
functions, appeal to the already-proved fixed-cutoff linearity, and descend
the result through the verified quotient.  No new mathematical assumptions,
`axiom`, `sorry`, or numerical witness are used.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The actual variable-degree/pole-cutoff moment respects addition of
finite rational presentations, not just addition of their fixed arrays. -/
theorem muFunctionalPoly_addFinitePresentations
    (k : ℕ) (R S : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k (addFinitePresentations R S) =
      Zetahyperbolic.muFunctionalPoly k R +
        Zetahyperbolic.muFunctionalPoly k S := by
  let B := Nat.succ
    (max (R.polyPart + S.polyPart).natDegree
      (max R.polyPart.natDegree S.polyPart.natDegree))
  let J := max R.maxPole S.maxPole
  have hBadd : (addFinitePresentations R S).polyPart.natDegree < B := by
    change (R.polyPart + S.polyPart).natDegree < B
    dsimp [B]
    omega
  have hBR : R.polyPart.natDegree < B := by
    dsimp [B]
    omega
  have hBS : S.polyPart.natDegree < B := by
    dsimp [B]
    omega
  have hJadd : (addFinitePresentations R S).maxPole ≤ J := le_rfl
  have hJR : R.maxPole ≤ J := Nat.le_max_left _ _
  have hJS : S.maxPole ≤ J := Nat.le_max_right _ _
  rw [muFunctionalPoly_eq_truncated_of_bounds k B J
       (addFinitePresentations R S) hBadd hJadd,
      muFunctionalPoly_eq_truncated_of_bounds k B J R hBR hJR,
      muFunctionalPoly_eq_truncated_of_bounds k B J S hBS hJS]
  have hr : paddedResidue (addFinitePresentations R S) =
      (fun j => paddedResidue R j + paddedResidue S j) := by
    funext j
    exact paddedResidue_addFinitePresentations R S j
  change truncatedMoment k B J (R.polyPart + S.polyPart)
      (paddedResidue (addFinitePresentations R S)) =
      truncatedMoment k B J R.polyPart (paddedResidue R) +
        truncatedMoment k B J S.polyPart (paddedResidue S)
  rw [hr]
  exact truncatedMoment_add k B J R.polyPart S.polyPart
    (paddedResidue R) (paddedResidue S)

/-- Rational homogeneity holds for the actual input-dependent degree bound,
including the cases where multiplication changes the polynomial degree. -/
theorem muFunctionalPoly_scaleFinitePresentation
    (k : ℕ) (q : ℚ) (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k (scaleFinitePresentation q R) =
      C q * Zetahyperbolic.muFunctionalPoly k R := by
  let B := Nat.succ
    (max (C q * R.polyPart).natDegree R.polyPart.natDegree)
  let J := R.maxPole
  have hBscale : (scaleFinitePresentation q R).polyPart.natDegree < B := by
    change (C q * R.polyPart).natDegree < B
    dsimp [B]
    omega
  have hBR : R.polyPart.natDegree < B := by
    dsimp [B]
    omega
  have hJscale : (scaleFinitePresentation q R).maxPole ≤ J := le_rfl
  have hJR : R.maxPole ≤ J := le_rfl
  rw [muFunctionalPoly_eq_truncated_of_bounds k B J
        (scaleFinitePresentation q R) hBscale hJscale,
      muFunctionalPoly_eq_truncated_of_bounds k B J R hBR hJR]
  have hr : paddedResidue (scaleFinitePresentation q R) =
      (fun j => q * paddedResidue R j) := by
    funext j
    exact paddedResidue_scaleFinitePresentation q R j
  change truncatedMoment k B J (C q * R.polyPart)
      (paddedResidue (scaleFinitePresentation q R)) =
      C q * truncatedMoment k B J R.polyPart (paddedResidue R)
  rw [hr]
  exact truncatedMoment_scale k B J q R.polyPart (paddedResidue R)

/-- Global linearity (additivity) of the *actual* rational-moment functional
of Definition 2.1 on the quotient of all finite negative-square pole sets. -/
theorem muOnRationalDomain_add
    (k : ℕ) (R S : RationalMomentDomain) :
    muOnRationalDomain k (R + S) =
      muOnRationalDomain k R + muOnRationalDomain k S := by
  refine Quotient.inductionOn₂ R S ?_
  intro r s
  change Zetahyperbolic.muFunctionalPoly k (addFinitePresentations r s) =
    Zetahyperbolic.muFunctionalPoly k r + Zetahyperbolic.muFunctionalPoly k s
  exact muFunctionalPoly_addFinitePresentations k r s

/-- Global Q-homogeneity for the same functional. -/
theorem muOnRationalDomain_smul
    (k : ℕ) (q : ℚ) (R : RationalMomentDomain) :
    muOnRationalDomain k (q • R) =
      C q * muOnRationalDomain k R := by
  refine Quotient.inductionOn R ?_
  intro r
  change Zetahyperbolic.muFunctionalPoly k (scaleFinitePresentation q r) =
    C q * Zetahyperbolic.muFunctionalPoly k r
  exact muFunctionalPoly_scaleFinitePresentation k q r

/-- Source-faithful Q-linearity certificate: the two equations are now
proved for arbitrary rational functions, not postulated as an assumption. -/
structure GlobalMomentLinearityChain : Prop where
  additive : ∀ k : ℕ, ∀ R S : RationalMomentDomain,
    muOnRationalDomain k (R + S) =
      muOnRationalDomain k R + muOnRationalDomain k S
  homogeneous : ∀ k : ℕ, ∀ q : ℚ, ∀ R : RationalMomentDomain,
    muOnRationalDomain k (q • R) =
      C q * muOnRationalDomain k R

/-- No arithmetic or analytic Witness is needed for the linearity asserted
in Definition 2.1. -/
theorem SECTION2_GLOBAL_MOMENT_LINEARITY : GlobalMomentLinearityChain := by
  exact ⟨muOnRationalDomain_add, muOnRationalDomain_smul⟩

end PaperChronological.Section2
