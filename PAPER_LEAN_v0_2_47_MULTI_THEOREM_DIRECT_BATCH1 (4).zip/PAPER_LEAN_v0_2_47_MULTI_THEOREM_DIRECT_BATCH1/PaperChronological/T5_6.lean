import PaperChronological.T5_5

/-!
# Theorem 5.6: Weight seven prime sums and pole-ordered refinement

PDF p. 26. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Exact rational integral of one affine branch b+c*y on [l,r]. -/
def affineIntegral (l r b c : ℚ) : ℚ :=
  b * (r - l) + c * (r ^ 2 - l ^ 2) / 2

/-- The 11 affine-piece integrations in PDF Table 1, checked as exact
rational arithmetic. Still requires proving the integrand is equal to the
claimed affine piece on each interval. -/
theorem THEOREM_5_6_ELEVEN_AFFINE_PIECES :
    affineIntegral (1/3) (43/120) (51/8) (-5) = 223/1920 ∧
    affineIntegral (43/120) (29/80) (513/40) (-23) = 2177/115200 ∧
    affineIntegral (29/80) (37/100) (571/40) (-27) = 10527/320000 ∧
    affineIntegral (37/100) (37/80) (497/40) (-22) = 48359/160000 ∧
    affineIntegral (37/80) (29/60) (41/10) (-4) = 53/1152 ∧
    affineIntegral (29/60) (1/2) (53/20) (-1) = 259/7200 ∧
    affineIntegral (1/2) (43/80) (7/2) 1 = 1929/12800 ∧
    affineIntegral (43/80) (37/60) (121/10) (-15) = 10469/38400 ∧
    affineIntegral (37/60) (37/40) (41/4) (-12) = 37/120 ∧
    affineIntegral (37/40) 1 1 (-2) = -111/1600 ∧
    affineIntegral 1 (37/20) (37/20) (-1) = 289/800 := by
  norm_num [affineIntegral]

/-- Exact total of the printed 11 rational affine integrals in Theorem 5.6. -/
theorem THEOREM_5_6_OUTER_RATIONAL_SUM :
    (223/1920 : ℚ) + 2177/115200 + 10527/320000 +
      48359/160000 + 53/1152 + 259/7200 + 1929/12800 +
      10469/38400 + 37/120 - 111/1600 + 289/800 = 453803/288000 := by
  norm_num

end PaperChronological
