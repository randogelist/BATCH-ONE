import PaperChronological.T2_3
import Theorem_2_4_Canonical_Basis_Invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Theorem 2.4: Canonical basis invariance

PDF p. 6. Audit status: PROVED.

This module links an actual mathematical theorem to previously
proved source declarations; no manuscript premise is silently postulated.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 2.4: exact equality of primitive integer determinants up to sign.
The proof constructs primitive normalizations, rather than treating them as
external witness assumptions. -/
theorem THEOREM_2_4_CANONICAL_BASIS_INVARIANCE
    (p : ManuscriptChain.Real.Parameters)
    (A B : Matrix (Fin p.h) (Fin p.h) ℚ)
    (hA : Matrix.det A ≠ 0) (hB : Matrix.det B ≠ 0) :
    let n₀ := ManuscriptChain.BasisInvariance.primitiveNormalization
      (ManuscriptChain.Real.delta p)
      (ManuscriptChain.PoleDiagonalization.delta_ne_zero p)
    let nAB := ManuscriptChain.BasisInvariance.primitiveNormalization
      (Matrix.det (ManuscriptChain.BasisInvariance.changeBasisPencil
        (ManuscriptChain.Real.pencil p) A B))
      ((ManuscriptChain.BasisInvariance.det_changeBasisPencil_ne_zero_iff
          (ManuscriptChain.Real.pencil p) A B hA hB).mpr
        (ManuscriptChain.PoleDiagonalization.delta_ne_zero p))
    nAB.polynomial = n₀.polynomial ∨ nAB.polynomial = -n₀.polynomial :=
  ManuscriptChain.BasisInvariance.theorem_2_4_constructed_canonical_basis_invariance
    p A B hA hB (ManuscriptChain.PoleDiagonalization.delta_ne_zero p)

end PaperChronological
