import PaperChronological.T3_9

/-!
# Remark 3.10: Non-classicality of the Hankel family

PDF p. 14. Audit status: REQUIRES_REVIEW.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Remark 3.10 is still a formalization target. -/

end PaperChronological
