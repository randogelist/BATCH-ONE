import PaperChronological.S2_GlobalModuleInstances

/-!
Native Lean 4.33.0 audit entrypoint for the global Q-vector-space structure.
No local compilation was performed while packaging this source.
-/

#check PaperChronological.Section2.rationalZero
#check PaperChronological.Section2.rationalNeg
#check PaperChronological.Section2.rationalAdd_zero
#check PaperChronological.Section2.rationalZero_add
#check PaperChronological.Section2.rationalAdd_left_neg
#check PaperChronological.Section2.rationalScale_one
#check PaperChronological.Section2.rationalScale_zeroScalar
#check PaperChronological.Section2.rationalScale_zeroArgument
#check PaperChronological.Section2.rationalScale_addScalars
#check PaperChronological.Section2.SECTION2_GLOBAL_Q_MODULE_LAWS
#check PaperChronological.Section2.rationalMomentDomainAddCommGroup
#check PaperChronological.Section2.rationalMomentDomainModule
#check PaperChronological.Section2.polynomialPartOnDomain_add
#check PaperChronological.Section2.polynomialPartOnDomain_smul

#print axioms PaperChronological.Section2.SECTION2_GLOBAL_Q_MODULE_LAWS
#print axioms PaperChronological.Section2.rationalMomentDomainAddCommGroup
#print axioms PaperChronological.Section2.rationalMomentDomainModule
#print axioms PaperChronological.Section2.polynomialPartOnDomain_add
