import PaperChronological.T3_6

/-!
# Corrected Corollary 3.6: finite reciprocal-power-sum bounds

For a finite family of nonnegative atoms u_i with maximum U attained,
  U^r <= sum_i u_i^r <= h*U^r.
This is the finite power-sum envelope behind the corrected reciprocal-root
limit. The PDF's all-orders strict Hankel determinant claim is false beyond
the support size; no such claim is assumed here.

Status: NEW / awaiting user's native Lean compilation.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/-- Finite-atom power-sum bounds, valid for every natural exponent. -/
theorem COROLLARY_3_6_GENERAL_POWER_SUM_BOUNDS
    {h r : ℕ} (u : Fin h → ℝ) (U : ℝ)
    (hu : ∀ i, 0 ≤ u i)
    (hupper : ∀ i, u i ≤ U)
    (hattains : ∃ i, u i = U) :
    U ^ r ≤ (∑ i : Fin h, u i ^ r) ∧
      (∑ i : Fin h, u i ^ r) ≤ (h : ℝ) * U ^ r := by
  obtain ⟨i, hi⟩ := hattains
  constructor
  · have hterm : u i ^ r ≤ ∑ j : Fin h, u j ^ r := by
      have hnonneg : ∀ j ∈ (Finset.univ : Finset (Fin h)), 0 ≤ u j ^ r := by
        intro j _
        exact pow_nonneg (hu j) r
      exact Finset.single_le_sum
        (f := fun j : Fin h => u j ^ r)
        (s := (Finset.univ : Finset (Fin h)))
        (a := i) hnonneg (Finset.mem_univ i)
    simpa [hi] using hterm
  · calc
      (∑ j : Fin h, u j ^ r) ≤ ∑ _j : Fin h, U ^ r := by
        apply Finset.sum_le_sum
        intro j hj
        exact pow_le_pow_left₀ (hu j) (hupper j) r
      _ = (h : ℝ) * U ^ r := by simp [mul_comm]

end PaperChronological
