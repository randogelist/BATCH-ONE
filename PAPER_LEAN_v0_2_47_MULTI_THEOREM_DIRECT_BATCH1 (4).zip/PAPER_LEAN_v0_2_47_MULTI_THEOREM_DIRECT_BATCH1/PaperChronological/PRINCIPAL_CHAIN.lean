import PaperChronological.Principal_T3_3_SpectralSplit
import PaperChronological.Principal_T3_7_LaguerreSOS
import PaperChronological.Principal_T3_9_FeketeTransfer
import PaperChronological.MAIN_CHAIN

/-!
# Principal theorem transition — unconditional and witness-independent layer

This is the first principal-theorem-focused stage following Section 2.
It is ADDITIVE to the already frozen chronological package and has no
proof placeholders, custom axioms, or unproved analytic hypotheses in its
completed odd-zeta endpoint.

It DOES NOT state that all of Theorems 3.3, 3.7, 3.9 are now proved:
- exact spectral inertia and Carleman total positivity remain open;
- identifying the SOS with ordinary derivatives remains open;
- the specific Hurwitz/Dirichlet integral bridges remain open;
- Section 4 quantitative determinant bounds remain witness-dependent.
-/

noncomputable section

namespace PaperChronological.Principal

/-- The unconditional principal zeta-Hankel spectral chain, extending 3.1
with a complete spectral sign classification of its indexed roots. -/
theorem PRINCIPAL_SPECTRAL_ODD_ZETA_CHAIN
    (q : ManuscriptChain.Real.Parameters)
    (hq : ManuscriptChain.Real.Admissible q) :
    (ManuscriptChain.Real.delta q).natDegree = q.h ∧
    (ManuscriptChain.Real.gram q
      (ManuscriptChain.Real.zeta q.weight)).PosDef ∧
    (∃ beta : Fin q.h → ℝ,
      (∀ i, beta i ≠ 0) ∧
      (∀ i, ManuscriptChain.Real.zeta q.weight - (beta i)⁻¹ <
            ManuscriptChain.Real.zeta q.weight ↔ 0 < beta i) ∧
      (∀ i, ManuscriptChain.Real.zeta q.weight <
            ManuscriptChain.Real.zeta q.weight - (beta i)⁻¹ ↔
            beta i < 0) ∧
      (∀ i, ManuscriptChain.General.ComplexRoot q
        ((ManuscriptChain.Real.zeta q.weight - (beta i)⁻¹ : ℝ) : ℂ))) := by
  exact ⟨PaperChronological.THEOREM_2_5_EXACT_DEGREE q,
    ManuscriptChain.GRAM_POSITIVE q hq,
    actual_odd_zeta_bilateral_spectral_roots q hq⟩

/-- All-dimensional nonnegative Turan SOS, entirely unconditional. -/
theorem PRINCIPAL_TURAN_SOS_ALL_FINITE_DIMENSIONS
    {n : ℕ} (r : Fin n → ℝ) (x : ℝ) :
    0 ≤ (factoredFirst r x) ^ 2 -
      rootProduct r x * factoredSecond r x :=
  universal_laguerre_turan_nonnegative r x

end PaperChronological.Principal

#print axioms PaperChronological.Principal.PRINCIPAL_SPECTRAL_ODD_ZETA_CHAIN
#print axioms PaperChronological.Principal.PRINCIPAL_TURAN_SOS_ALL_FINITE_DIMENSIONS
