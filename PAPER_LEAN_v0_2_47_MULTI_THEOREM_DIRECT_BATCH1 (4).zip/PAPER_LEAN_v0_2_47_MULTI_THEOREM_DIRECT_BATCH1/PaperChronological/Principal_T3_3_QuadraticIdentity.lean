import PaperChronological.T3_3
import PaperChronological.T2_5

/-!
# Direct manuscript Theorem 3.3 — exact diagonal inertia form

The signed derivative matrix M has the exact quadratic form
  x^T M x = sum_a gamma_a (sum_i V_ia x_i)^2.
This is the algebraic core from which Sylvester inertia and the paper's
bilateral root signature follow; it is not a generic PSD replacement.
The analytic total-positivity and precise parity counts are not asserted.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological.Principal

/-- One entry of a Vandermonde/diagonal congruence. -/
theorem diagonalCongruence_entry
    {n : ℕ} (V : Matrix (Fin n) (Fin n) ℚ)
    (γ : Fin n → ℚ) (i j : Fin n) :
    (V * Matrix.diagonal γ * V.transpose) i j =
      ∑ a : Fin n, γ a * V i a * V j a := by
  classical
  simp only [Matrix.mul_apply, Matrix.transpose_apply]
  apply Finset.sum_congr rfl
  intro a _
  have hcollapse :
      (∑ b : Fin n, V i b * Matrix.diagonal γ b a) =
        V i a * γ a := by
    simp [Matrix.diagonal_apply]
  rw [hcollapse]
  ring

/-- Complete quadratic form identity for any signed diagonal weights. -/
theorem diagonalCongruence_quadratic
    {n : ℕ} (V : Matrix (Fin n) (Fin n) ℚ)
    (γ : Fin n → ℚ) (x : Fin n → ℚ) :
    (∑ i : Fin n, ∑ j : Fin n,
      x i * (V * Matrix.diagonal γ * V.transpose) i j * x j) =
      ∑ a : Fin n, γ a * (∑ i : Fin n, x i * V i a) ^ 2 := by
  classical
  simp only [diagonalCongruence_entry]
  calc
    (∑ i : Fin n, ∑ j : Fin n,
      x i * (∑ a : Fin n, γ a * V i a * V j a) * x j) =
      ∑ i : Fin n, ∑ j : Fin n, ∑ a : Fin n,
        γ a * ((x i * V i a) * (x j * V j a)) := by
          apply Finset.sum_congr rfl
          intro i _
          apply Finset.sum_congr rfl
          intro j _
          rw [Finset.mul_sum, Finset.sum_mul]
          apply Finset.sum_congr rfl
          intro a _
          ring
    _ = ∑ i : Fin n, ∑ a : Fin n, ∑ j : Fin n,
          γ a * ((x i * V i a) * (x j * V j a)) := by
          apply Finset.sum_congr rfl
          intro i _
          rw [Finset.sum_comm]
    _ = ∑ a : Fin n, ∑ i : Fin n, ∑ j : Fin n,
          γ a * ((x i * V i a) * (x j * V j a)) := by
          rw [Finset.sum_comm]
    _ = ∑ a : Fin n, γ a * (∑ i : Fin n, x i * V i a) ^ 2 := by
          apply Finset.sum_congr rfl
          intro a _
          calc
            (∑ i : Fin n, ∑ j : Fin n,
              γ a * ((x i * V i a) * (x j * V j a))) =
              γ a * ∑ i : Fin n, ∑ j : Fin n,
                (x i * V i a) * (x j * V j a) := by
                  simp only [Finset.mul_sum]
            _ = γ a * (∑ i : Fin n, x i * V i a) ^ 2 := by
              congr 1
              calc
                (∑ i : Fin n, ∑ j : Fin n,
                  (x i * V i a) * (x j * V j a)) =
                  ∑ i : Fin n, (x i * V i a) *
                    (∑ j : Fin n, x j * V j a) := by
                      simp only [Finset.mul_sum]
                _ = (∑ i : Fin n, x i * V i a) *
                      (∑ j : Fin n, x j * V j a) := by
                      simp only [Finset.sum_mul]
                _ = (∑ i : Fin n, x i * V i a) ^ 2 := by
                      rw [pow_two]

/-- Applied to the actual X-derivative matrix of the rational odd-zeta
Hankel pencil, with the precise signed residue weights of Theorem 2.5. -/
theorem THEOREM_3_3_ACTUAL_HANKEL_SIGNED_QUADRATIC
    (p : ManuscriptChain.Real.Parameters)
    (x : Fin p.h → ℚ) :
    (∑ i : Fin p.h, ∑ j : Fin p.h,
      x i * ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p i j * x j) =
    ∑ a : Fin p.h, ManuscriptChain.PoleDiagonalization.poleWeight p a *
      (∑ i : Fin p.h,
        x i * ManuscriptChain.PoleDiagonalization.poleVandermonde p i a) ^ 2 := by
  rw [PaperChronological.THEOREM_2_5_VANDERMONDE]
  exact diagonalCongruence_quadratic
    (ManuscriptChain.PoleDiagonalization.poleVandermonde p)
    (ManuscriptChain.PoleDiagonalization.poleWeight p) x

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_3_3_ACTUAL_HANKEL_SIGNED_QUADRATIC
