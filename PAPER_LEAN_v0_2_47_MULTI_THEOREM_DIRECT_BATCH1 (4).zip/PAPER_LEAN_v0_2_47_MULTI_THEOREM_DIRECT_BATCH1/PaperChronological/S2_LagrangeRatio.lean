import PaperChronological.S2_CanonicalPresentation

/-!
# Section 2, Theorem 2.5: Lagrange ratio identity (2.10)

Unlike a mere redefinition of the transformed matrix pencil, this proves the
polynomial identity obtained by clearing the denominator in the manuscript's
formula L_a(t) = D_tail(t) / ((t + a²) D_tail'(-a²)). The derivative is nonzero
because the tail poles are distinct. It is valid at every admissible tail
node without any arithmetic witness or analytic assumption.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

open ManuscriptChain.PoleDiagonalization

/-- Equation (2.10), with its denominator cleared as a polynomial identity.
The derivative is separately known to be nonzero in the source chain. -/
theorem LAGRANGE_CLEARED_DENOMINATOR
    (p : ManuscriptChain.Real.Parameters) (a : Fin p.h) :
    (X + C ((poleIndex p a : ℚ) ^ 2)) * L p a *
        C ((derivative (ManuscriptChain.Real.tailD p)).eval (poleNode p a)) =
      ManuscriptChain.Real.tailD p := by
  classical
  let s : Finset ℕ :=
    (Finset.Icc (p.N + 1) p.K).erase (poleIndex p a)
  let d : ℕ → ℚ := fun b => (b : ℚ) ^ 2 - (poleIndex p a : ℚ) ^ 2
  let F : ℕ → ℚ[X] := fun b => X + C ((b : ℚ) ^ 2)
  have ha : poleIndex p a ∈ Finset.Icc (p.N + 1) p.K := poleIndex_mem p a
  have htail : ManuscriptChain.Real.tailD p =
      (X + C ((poleIndex p a : ℚ) ^ 2)) * ∏ b ∈ s, F b := by
    dsimp [s, F, ManuscriptChain.Real.tailD]
    exact (Finset.mul_prod_erase (Finset.Icc (p.N + 1) p.K)
      (fun b => (X + C ((b : ℚ) ^ 2) : ℚ[X])) ha).symm
  have hder : (derivative (ManuscriptChain.Real.tailD p)).eval (poleNode p a) =
      ∏ b ∈ s, d b := by
    simpa only [s, d, poleNode] using
      (tailD_derivative_eval p (poleIndex p a) ha)
  have hdnonzero : (∏ b ∈ s, d b) ≠ 0 := by
    rw [← hder]
    exact tailD_derivative_eval_ne_zero p (poleIndex p a) ha
  have hfactors : ∀ b ∈ s, d b ≠ 0 :=
    Finset.prod_ne_zero_iff.mp hdnonzero
  have hL : L p a = (∏ b ∈ s, F b) * (∏ b ∈ s, C ((d b)⁻¹)) := by
    change (∏ b ∈ s, F b * C ((d b)⁻¹)) = _
    rw [Finset.prod_mul_distrib]
  have hcder : C ((derivative (ManuscriptChain.Real.tailD p)).eval (poleNode p a)) =
      ∏ b ∈ s, C (d b) := by
    rw [hder, map_prod]
  have hcancel : (∏ b ∈ s, C ((d b)⁻¹)) * (∏ b ∈ s, C (d b)) =
      (1 : ℚ[X]) := by
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_eq_one
    intro b hb
    rw [← Polynomial.C_mul, inv_mul_cancel₀ (hfactors b hb), map_one]
  calc
    (X + C ((poleIndex p a : ℚ) ^ 2)) * L p a *
        C ((derivative (ManuscriptChain.Real.tailD p)).eval (poleNode p a)) =
      (X + C ((poleIndex p a : ℚ) ^ 2)) *
        ((∏ b ∈ s, F b) * (∏ b ∈ s, C ((d b)⁻¹))) *
        (∏ b ∈ s, C (d b)) := by rw [hL, hcder]
    _ = (X + C ((poleIndex p a : ℚ) ^ 2)) * (∏ b ∈ s, F b) := by
      calc
        _ = ((X + C ((poleIndex p a : ℚ) ^ 2)) * (∏ b ∈ s, F b)) *
          ((∏ b ∈ s, C ((d b)⁻¹)) * (∏ b ∈ s, C (d b))) := by ring
        _ = _ := by rw [hcancel]; ring
    _ = ManuscriptChain.Real.tailD p := htail.symm

/-- The denominator in (2.10) is nonzero, as required to read the preceding
cleared identity as an equality of rational functions. -/
theorem LAGRANGE_DERIVATIVE_NONZERO
    (p : ManuscriptChain.Real.Parameters) (a : Fin p.h) :
    (derivative (ManuscriptChain.Real.tailD p)).eval (poleNode p a) ≠ 0 :=
  tailD_derivative_eval_ne_zero p (poleIndex p a) (poleIndex_mem p a)

/-- Independent Lagrange atoms have independent coefficients, by evaluation.
This is a finite basis-injectivity theorem, not an assumption of linearity. -/
theorem LAGRANGE_LINEAR_COMBINATION_INJECTIVE
    (p : ManuscriptChain.Real.Parameters)
    (c : Fin p.h → ℚ)
    (hzero : (∑ a : Fin p.h, C (c a) * L p a) = 0) :
    ∀ a, c a = 0 := by
  intro a
  have h := normalizedPresentation_unique p (0 : ℚ[X]) (0 : ℚ[X])
    c (fun _ => 0) (by simpa [normalizedNumerator] using hzero)
  simpa using congrFun h.2 a

end PaperChronological.Section2
