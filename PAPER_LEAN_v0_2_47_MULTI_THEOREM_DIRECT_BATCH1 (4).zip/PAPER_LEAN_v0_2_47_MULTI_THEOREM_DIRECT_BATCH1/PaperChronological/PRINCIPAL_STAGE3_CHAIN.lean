import PaperChronological.PRINCIPAL_STAGE2_CHAIN
import PaperChronological.Principal_T3_3_QuadraticIdentity
import PaperChronological.Principal_T3_7_StrictActual
import PaperChronological.Principal_T3_8_PoleKernelDet

/-!
# Paper principal theorem chain — third incremental stage

All three conclusions concern the genuine mathematical objects defined
upstream in the manuscript's Section 2, not placeholder approximants.
No quantitative arithmetic Witness occurs in these unconditional conclusions.
The full PDF remains partially formalized; the precisely named remaining
obligations are documented separately.
-/

noncomputable section
namespace PaperChronological.Principal

/-- Genuine Hankel derivative signed quadratic form (Theorem 3.3) AND
genuine pole-kernel determinant identity (Theorem 3.8), with arbitrary
parameter tuple. -/
theorem PRINCIPAL_STAGE3_SIGNED_HANKEL_AND_POLE_KERNEL
    (p : ManuscriptChain.Real.Parameters)
    (x : Fin p.h → ℚ)
    (H : Matrix (Fin p.h) (Fin p.h) ℚ) :
    ((∑ i : Fin p.h, ∑ j : Fin p.h,
      x i * ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p i j * x j) =
        ∑ a : Fin p.h, ManuscriptChain.PoleDiagonalization.poleWeight p a *
          (∑ i : Fin p.h,
            x i * ManuscriptChain.PoleDiagonalization.poleVandermonde p i a)^2) ∧
    (Matrix.det (H * ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p) =
      Matrix.det (
        Matrix.diagonal (ManuscriptChain.PoleDiagonalization.poleWeight p) *
        ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).transpose *
         H * ManuscriptChain.PoleDiagonalization.poleVandermonde p))) := by
  exact ⟨THEOREM_3_3_ACTUAL_HANKEL_SIGNED_QUADRATIC p x,
    THEOREM_3_8_ACTUAL_POLE_KERNEL_DETERMINANT p H⟩

/-- Ordinary-derivative first Turan is strictly positive at the actual
odd-zeta center in every positive-dimensional admissible Hankel pencil. -/
theorem PRINCIPAL_STAGE3_STRICT_ZETA_TURAN
    (q : ManuscriptChain.Real.Parameters)
    (hq : ManuscriptChain.Real.Admissible q)
    (hh : 0 < q.h) :
    0 < derivativeTuran
      (ManuscriptChain.Real.manuscriptPencil q).detPolynomial
      (ManuscriptChain.Real.zeta q.weight) := by
  exact THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_AT_CENTER q hq hh

end PaperChronological.Principal

#print axioms PaperChronological.Principal.PRINCIPAL_STAGE3_SIGNED_HANKEL_AND_POLE_KERNEL
#print axioms PaperChronological.Principal.PRINCIPAL_STAGE3_STRICT_ZETA_TURAN
