import PaperChronological.S2_RationalEndpoint

/-!
# Section 2: all finite initial segments of the pole lattice

Definition 2.1 allows an arbitrary finite set of simple poles selected from
`-1^2, -2^2, ...`, not just a particular matrix tail `N < j <= K`.
Taking `N=0`, `K=J` in the *already proved* canonical residue construction
provides the full initial segment `1 <= j <= J`, including `J=0`.

This is the explicit finite-pole exhaustion needed before forming the directed
union of all rational functions with finitely many allowed simple poles.
It does not assume any analytic or quantitative witness.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The first `J` negative square poles, without the supplementary conditions
on `N` imposed only for the paper's later Hankel construction. -/
def allPoleParameters (k J : ℕ) : ManuscriptChain.Real.Parameters :=
  { k := k, m := 1, N := 0, K := J }

@[simp] theorem allPoleParameters_h (k J : ℕ) :
    (allPoleParameters k J).h = J := by
  rfl

/-- The coordinate `a : Fin J` corresponds exactly to the pole `-(a+1)^2`. -/
theorem allPole_index (k J : ℕ) (a : Fin J) :
    ManuscriptChain.PoleDiagonalization.poleIndex
        (allPoleParameters k J) a = a.val + 1 := by
  simp [allPoleParameters, ManuscriptChain.PoleDiagonalization.poleIndex, Nat.add_comm]

/-- Cleared numerator for an *arbitrary finite initial pole segment*. -/
def allPoleNumerator (k J : ℕ) (Q : ℚ[X]) (c : Fin J → ℚ) : ℚ[X] :=
  clearedResidueNumerator (allPoleParameters k J) Q c

/-- Every finite presentation in the paper's rational-function domain is
unique once a common pole bound has been fixed. The zero-residue case is
included; no positivity, irrationality, or analytic premise enters. -/
theorem allPoleNumerator_unique (k J : ℕ)
    (Q₁ Q₂ : ℚ[X]) (c₁ c₂ : Fin J → ℚ)
    (h : allPoleNumerator k J Q₁ c₁ = allPoleNumerator k J Q₂ c₂) :
    Q₁ = Q₂ ∧ c₁ = c₂ := by
  exact clearedResidue_unique (allPoleParameters k J) Q₁ Q₂ c₁ c₂ h

/-- Cross-multiplied equality of fractions with the same pole denominator
also forces equality of both the polynomial part and every pole residue. -/
theorem allPoleFraction_unique (k J : ℕ)
    (Q₁ Q₂ : ℚ[X]) (c₁ c₂ : Fin J → ℚ)
    (h : allPoleNumerator k J Q₁ c₁ *
          ManuscriptChain.Real.tailD (allPoleParameters k J) =
         allPoleNumerator k J Q₂ c₂ *
          ManuscriptChain.Real.tailD (allPoleParameters k J)) :
    Q₁ = Q₂ ∧ c₁ = c₂ := by
  exact clearedFraction_unique (allPoleParameters k J) Q₁ Q₂ c₁ c₂ h

/-- The literal rational-function evaluation, for every finite pole bound,
uses the genuine residue coefficients, not the Lagrange coefficients. -/
theorem allPole_fraction_evaluation (k J : ℕ)
    (Q : ℚ[X]) (c : Fin J → ℚ) (t : ℚ)
    (ht : OffTailPoles (allPoleParameters k J) t) :
    Q.eval t + ∑ a : Fin J,
        c a / (t + (ManuscriptChain.PoleDiagonalization.poleIndex
          (allPoleParameters k J) a : ℚ) ^ 2) =
      (allPoleNumerator k J Q c).eval t /
        (ManuscriptChain.Real.tailD (allPoleParameters k J)).eval t := by
  exact residueValue_eq_quotient (allPoleParameters k J) Q c t ht

/-- No pole lies on the nonnegative rational axis, uniformly in the bound. -/
theorem allPole_nonnegative_domain (k J : ℕ) (t : ℚ) (ht : 0 ≤ t) :
    OffTailPoles (allPoleParameters k J) t :=
  offTailPoles_of_nonneg (allPoleParameters k J) t ht

/-- The polynomial denominator cannot vanish identically, including when
`J=0`. -/
theorem allPole_denominator_nonzero (k J : ℕ) :
    ManuscriptChain.Real.tailD (allPoleParameters k J) ≠ 0 :=
  tailD_ne_zero (allPoleParameters k J)

end PaperChronological.Section2
