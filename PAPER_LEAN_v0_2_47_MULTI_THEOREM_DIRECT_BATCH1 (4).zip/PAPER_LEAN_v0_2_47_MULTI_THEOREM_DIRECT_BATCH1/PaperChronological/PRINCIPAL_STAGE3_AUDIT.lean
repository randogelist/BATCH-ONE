import PaperChronological.PRINCIPAL_STAGE3_CHAIN

/-!
# Axiom audit (native Windows Lean 4.33.0)

Check the exact theorem declarations and their axioms. Reject `sorryAx`,
custom axioms, or unintended additional assumptions. Standard Lean
`propext`, `Classical.choice`, and `Quot.sound` are permitted.
-/

#print PaperChronological.Principal.PRINCIPAL_STAGE3_SIGNED_HANKEL_AND_POLE_KERNEL
#print PaperChronological.Principal.PRINCIPAL_STAGE3_STRICT_ZETA_TURAN
#print axioms PaperChronological.Principal.THEOREM_3_3_ACTUAL_HANKEL_SIGNED_QUADRATIC
#print axioms PaperChronological.Principal.THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_OFF_ROOTS
#print axioms PaperChronological.Principal.THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_AT_CENTER
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_POLE_KERNEL_DETERMINANT
#print axioms PaperChronological.Principal.PRINCIPAL_STAGE3_SIGNED_HANKEL_AND_POLE_KERNEL
#print axioms PaperChronological.Principal.PRINCIPAL_STAGE3_STRICT_ZETA_TURAN
