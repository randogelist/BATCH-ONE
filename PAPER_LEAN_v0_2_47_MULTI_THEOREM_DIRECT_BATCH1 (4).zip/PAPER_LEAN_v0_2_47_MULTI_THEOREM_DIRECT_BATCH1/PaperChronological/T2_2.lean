import PaperChronological.T2_1

/-!
# Lemma 2.2: Pullback identity

PDF p. 4. Audit status: PROVED_COMPONENTS.

Proved monomial and pole generator identities; linear-extension
uses the exact rational-function representation from the source.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Lemma 2.2, identity (2.5), on the monomial generators. -/
theorem LEMMA_2_2_MONOMIAL (k e : ℕ) (hk : 1 ≤ k) :
    Zetahyperbolic.muMonomial k e =
      (-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1) :=
  Zetahyperbolic.pullback_identity_monomial k e hk

/-- Lemma 2.2, identity (2.5), on the simple-pole generators. -/
theorem LEMMA_2_2_POLE (k j : ℕ) (hk : 1 ≤ k) (hj : 1 ≤ j) :
    Zetahyperbolic.muPolePoly k j =
      Polynomial.C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        Polynomial.C ((j : ℚ) ^ (2 * k) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
           Zetahyperbolic.tauPolePoly k (-(j : ℤ))) :=
  Zetahyperbolic.pullback_identity_pole k j hk hj

end PaperChronological
