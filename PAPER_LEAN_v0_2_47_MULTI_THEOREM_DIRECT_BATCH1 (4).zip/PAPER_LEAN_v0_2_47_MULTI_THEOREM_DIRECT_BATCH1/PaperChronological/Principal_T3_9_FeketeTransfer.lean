import PaperChronological.T3_9
import Zetahyperbolic.Section3Elementary
import PaperChronological.T3_2

/-!
# Manuscript Theorem 3.9 — proved finite character/positivity kernel

Combines the five exact Fekete factor-positivity conclusions with
unconditional hyperbolicity of every finite symmetric affine pencil
whose base is positive definite and whose direction is nonsingular.

The analytic identification with each particular Hurwitz/Dirichlet
L-value (Hermite integral) remains open, and is NOT smuggled into an
assumption of the main odd-zeta endpoint.
-/

noncomputable section
namespace PaperChronological.Principal

/-- Five real-character Fekete factors are strictly positive on (0,1).
These are the concrete factors used in the paper's Dirichlet extension. -/
theorem five_fekete_factors_positive {z : ℝ} (hz0 : 0 < z) (hz1 : z < 1) :
    0 < z * (1-z) ∧
    0 < z * (1-z^2) ∧
    0 < z * (1-z)^2 * (1+z) ∧
    0 < z * (1-z^2) * (1-z^4) ∧
    0 < z * (1+z^2) * (1-z^4) :=
  Zetahyperbolic.fekete_polynomial_positivity_basic hz0 hz1

/-- The finite generalized-eigenvalue theorem applies at every dimension:
positive Gram + symmetric nonsingular direction implies exact degree and
all roots real. The concrete Dirichlet integral bridge remains separate. -/
theorem universal_finite_character_pencil_hyperbolicity
    {n : ℕ} (P : ManuscriptChain.Spectral.SymmetricAffinePencil n)
    (hG : P.base.PosDef) (hM : P.direction.det ≠ 0) :
    P.detPolynomial.natDegree = n ∧
    ∀ z : ℂ,
      Polynomial.eval₂ (algebraMap ℝ ℂ) z P.detPolynomial = 0 →
        z.im = 0 :=
  PaperChronological.PROP_3_2_ABSTRACT_REAL_PENCIL P hG hM

end PaperChronological.Principal

#print axioms PaperChronological.Principal.universal_finite_character_pencil_hyperbolicity
