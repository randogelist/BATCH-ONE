import PaperChronological.T3_10
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion

/-!
# Theorem 4.1: Spectral irrationality measure criterion

PDF p. 14. Audit status: PROVED_TRANSFER.

This module links an actual mathematical theorem to previously
proved source declarations; no manuscript premise is silently postulated.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

 
/-- Theorem 4.1's verified Diophantine transfer from the explicit local
comparison, decay, and index selection bounds. -/
theorem THEOREM_4_1_SPECTRAL_TRANSFER
    {Q : ℕ → Polynomial ℤ} {xi : ℝ} {radius budget : ℕ → ℝ}
    {n0 mu b0 : ℕ}
    (comparison : ManuscriptChain.RealTransfer.LocalComparison Q xi radius n0)
    (decay : ManuscriptChain.RealTransfer.Decay Q xi budget n0)
    (index : ManuscriptChain.RealTransfer.IndexBudget Q radius budget n0 mu b0) :
    ManuscriptChain.RealTransfer.RationalMeasure xi mu b0 :=
  ManuscriptChain.RealTransfer.conditional_measure comparison decay index

end PaperChronological
