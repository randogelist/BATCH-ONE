import PaperChronological.S2_UniversalFiniteChain

/-!
# Section 2: genuinely directed finite-pole presentations

A finite rational presentation only records the coefficients of the poles
`-1^2,...,-J^2`.  It MUST NOT depend on the arbitrary upper pole cutoff.
The previous module proved that adding one zero residue leaves the moment
unchanged.  Here we identify the entire finite cutoff extension, including
its polynomial part, original residues and newly introduced zero residues.

All statements are finite identities over Q; no `Witness`, analytic
hypothesis, numerical estimate, or paper-specific odd-zeta claim is used.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- Residue of a finite presentation, padded by zero outside its cutoff. -/
def paddedResidue (R : Zetahyperbolic.RatMomentElem) (j : ℕ) : ℚ :=
  if j ≤ R.maxPole then R.poleRes j else 0

/-- A finite sequence of zero-residue extensions has the expected cutoff. -/
@[simp] theorem extendMomentCutoffN_maxPole
    (R : Zetahyperbolic.RatMomentElem) (n : ℕ) :
    (extendMomentCutoffN R n).maxPole = R.maxPole + n := by
  induction n with
  | zero => rfl
  | succ n ih =>
      change (extendMomentCutoffN R n).maxPole + 1 = R.maxPole + (n + 1)
      rw [ih]
      omega

/-- The polynomial part is never changed by introducing zero-residue poles. -/
@[simp] theorem extendMomentCutoffN_polyPart
    (R : Zetahyperbolic.RatMomentElem) (n : ℕ) :
    (extendMomentCutoffN R n).polyPart = R.polyPart := by
  induction n with
  | zero => rfl
  | succ n ih =>
      change (extendMomentCutoffN R n).polyPart = R.polyPart
      exact ih

/-- Original pole residues survive every cutoff extension. -/
theorem extendMomentCutoffN_oldResidue
    (R : Zetahyperbolic.RatMomentElem) (n j : ℕ)
    (hj : j ≤ R.maxPole) :
    (extendMomentCutoffN R n).poleRes j = R.poleRes j := by
  induction n with
  | zero => rfl
  | succ n ih =>
      change (if j = (extendMomentCutoffN R n).maxPole + 1 then
        (0 : ℚ) else (extendMomentCutoffN R n).poleRes j) = R.poleRes j
      have hne : j ≠ (extendMomentCutoffN R n).maxPole + 1 := by
        rw [extendMomentCutoffN_maxPole]
        omega
      simpa only [if_neg hne] using ih

/-- Every newly introduced pole has exactly zero residue. -/
theorem extendMomentCutoffN_newResidue
    (R : Zetahyperbolic.RatMomentElem) (j : ℕ)
    (hlo : R.maxPole < j) :
    ∀ n : ℕ, j ≤ R.maxPole + n →
      (extendMomentCutoffN R n).poleRes j = 0 := by
  intro n
  induction n with
  | zero =>
      intro h
      omega
  | succ n ih =>
      intro h
      change (if j = (extendMomentCutoffN R n).maxPole + 1 then
        (0 : ℚ) else (extendMomentCutoffN R n).poleRes j) = 0
      by_cases heq : j = (extendMomentCutoffN R n).maxPole + 1
      · simp only [if_pos heq]
      · have hprev : j ≤ R.maxPole + n := by
          rw [extendMomentCutoffN_maxPole] at heq
          omega
        simpa only [if_neg heq] using ih hprev

/-- Every pole up to the enlarged cutoff has precisely the zero-padded
original residue, uniformly in the enlargement length. -/
theorem extendMomentCutoffN_poleRes_eq_padded
    (R : Zetahyperbolic.RatMomentElem) (n j : ℕ)
    (hj : j ≤ R.maxPole + n) :
    (extendMomentCutoffN R n).poleRes j = paddedResidue R j := by
  by_cases hold : j ≤ R.maxPole
  · rw [extendMomentCutoffN_oldResidue R n j hold]
    simp only [paddedResidue, if_pos hold]
  · have hlo : R.maxPole < j := by omega
    rw [extendMomentCutoffN_newResidue R j hlo n hj]
    simp only [paddedResidue, if_neg hold]

/-- Enlarging an already finite presentation to an arbitrary larger cutoff. -/
def extendToCutoff (R : Zetahyperbolic.RatMomentElem)
    (J : ℕ) : Zetahyperbolic.RatMomentElem :=
  extendMomentCutoffN R (J - R.maxPole)

/-- The extension reaches precisely the requested upper bound. -/
theorem extendToCutoff_maxPole (R : Zetahyperbolic.RatMomentElem)
    (J : ℕ) (h : R.maxPole ≤ J) :
    (extendToCutoff R J).maxPole = J := by
  simp only [extendToCutoff, extendMomentCutoffN_maxPole]
  omega

/-- The functional is constant along all directed cutoff extensions. -/
theorem muFunctionalPoly_extendToCutoff (k J : ℕ)
    (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k (extendToCutoff R J) =
      Zetahyperbolic.muFunctionalPoly k R :=
  muFunctionalPoly_extendCutoff_iterate k R (J - R.maxPole)

end PaperChronological.Section2
