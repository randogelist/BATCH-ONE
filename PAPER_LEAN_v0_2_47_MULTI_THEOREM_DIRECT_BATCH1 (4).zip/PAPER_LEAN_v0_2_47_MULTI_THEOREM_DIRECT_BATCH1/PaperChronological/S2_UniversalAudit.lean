import PaperChronological.S2_UniversalFiniteChain

/-!
# Native Lean 4.33.0 audit: new universal Section 2 proofs

This file runs on the user's compiler. `#check` checks exact statements;
`#print axioms` exposes any unexpectedly admitted axioms.
The compiler, not the ZIP generator, is the proof authority.
-/

#check PaperChronological.Section2.allPoleParameters
#check PaperChronological.Section2.allPoleNumerator_unique
#check PaperChronological.Section2.allPole_fraction_evaluation
#check PaperChronological.Section2.monomial_moment_agreement
#check PaperChronological.Section2.harmonic_moment_agreement
#check PaperChronological.Section2.simple_pole_moment_affine
#check PaperChronological.Section2.finiteMomentPolynomial_slope
#check PaperChronological.Section2.clearedResidue_add
#check PaperChronological.Section2.clearedResidue_scale
#check PaperChronological.Section2.finitePoleMoment_add
#check PaperChronological.Section2.finitePoleMoment_scale
#check PaperChronological.Section2.finiteMomentPolynomial_affine
#check PaperChronological.Section2.exact_hankel_moment_pencil
#check PaperChronological.Section2.denominatorMoment_agreement
#check PaperChronological.Section2.kernelNumerator_agreement
#check PaperChronological.Section2.kernelResidue_agreement
#check PaperChronological.Section2.muFunctionalPoly_extendMomentCutoff
#check PaperChronological.Section2.muFunctionalPoly_extendCutoff_iterate
#check PaperChronological.Section2.SECTION2_ALL_FINITE_POLE_CHAIN

#print axioms PaperChronological.Section2.allPoleNumerator_unique
#print axioms PaperChronological.Section2.harmonic_moment_agreement
#print axioms PaperChronological.Section2.simple_pole_moment_affine
#print axioms PaperChronological.Section2.finiteMomentPolynomial_slope
#print axioms PaperChronological.Section2.clearedResidue_scale
#print axioms PaperChronological.Section2.exact_hankel_moment_pencil
#print axioms PaperChronological.Section2.kernelResidue_agreement
#print axioms PaperChronological.Section2.muFunctionalPoly_extendCutoff_iterate
#print axioms PaperChronological.Section2.SECTION2_ALL_FINITE_POLE_CHAIN
