import PaperChronological.T3_6
import Mathlib.Tactic.Ring

/-!
# Corollary 3.6 — full two-atom finite-rank identity

For a positive measure supported on precisely two distinct positive atoms,
the first 2x2 Hankel determinant is positive but the 3x3 Hankel determinant
is exactly ZERO. This proves the sharp rank obstruction to the manuscript's
unrestricted strict Hankel positivity. No additional hypothesis is inserted.
-/

noncomputable section
namespace PaperChronological.Principal

private def twoAtomMoment (u v wu wv : ℝ) (n : ℕ) : ℝ :=
  wu * u ^ n + wv * v ^ n

/-- 2x2 Hankel determinant of the two-point moment measure. -/
theorem TWO_ATOM_FIRST_HANKEL_DETERMINANT (u v wu wv : ℝ) :
    twoAtomMoment u v wu wv 0 * twoAtomMoment u v wu wv 2 -
      (twoAtomMoment u v wu wv 1) ^ 2 =
      wu * wv * (u - v) ^ 2 := by
  unfold twoAtomMoment
  ring

/-- It is strictly positive for positive masses and distinct atoms. -/
theorem TWO_ATOM_FIRST_HANKEL_STRICT (u v wu wv : ℝ)
    (hwu : 0 < wu) (hwv : 0 < wv) (huv : u ≠ v) :
    0 < twoAtomMoment u v wu wv 0 * twoAtomMoment u v wu wv 2 -
      (twoAtomMoment u v wu wv 1) ^ 2 := by
  rw [TWO_ATOM_FIRST_HANKEL_DETERMINANT]
  exact mul_pos (mul_pos hwu hwv) (sq_pos_of_ne_zero (sub_ne_zero.mpr huv))

/-- The 3x3 Hankel determinant of a two-atom measure necessarily vanishes.
This is the exact support-rank correction to the printed assertion. -/
theorem TWO_ATOM_THREE_BY_THREE_HANKEL_ZERO (u v wu wv : ℝ) :
    twoAtomMoment u v wu wv 0 *
        (twoAtomMoment u v wu wv 2 * twoAtomMoment u v wu wv 4 -
          (twoAtomMoment u v wu wv 3) ^ 2) -
      twoAtomMoment u v wu wv 1 *
        (twoAtomMoment u v wu wv 1 * twoAtomMoment u v wu wv 4 -
          twoAtomMoment u v wu wv 2 * twoAtomMoment u v wu wv 3) +
      twoAtomMoment u v wu wv 2 *
        (twoAtomMoment u v wu wv 1 * twoAtomMoment u v wu wv 3 -
          (twoAtomMoment u v wu wv 2) ^ 2) = 0 := by
  unfold twoAtomMoment
  ring

end PaperChronological.Principal

#print axioms PaperChronological.Principal.TWO_ATOM_FIRST_HANKEL_STRICT
#print axioms PaperChronological.Principal.TWO_ATOM_THREE_BY_THREE_HANKEL_ZERO
