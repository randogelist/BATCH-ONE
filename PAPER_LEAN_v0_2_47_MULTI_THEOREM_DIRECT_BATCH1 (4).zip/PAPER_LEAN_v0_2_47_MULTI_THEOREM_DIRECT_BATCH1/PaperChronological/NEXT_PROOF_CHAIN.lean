import PaperChronological.INCREMENTAL_CHAIN
import PaperChronological.T3_3_TwoAtom
import PaperChronological.T3_5_CorrectedTwoByTwo
import PaperChronological.T3_6_MomentGram

/-!
# Chronological proof round v0.2.9 — additive and PASS-ONCE

New theorems belong to the earliest unclosed manuscript block, Sections
3.3–3.6. The old MAIN_CHAIN and all earlier proof source files are untouched.

The source-faithful unfinished parts (Carleman total positivity, full
signature, full Lanczos J-fraction) remain open. No new assumption is
introduced into the paper's endpoint; Witness is still the sole designated
quantitative input for the Section 4 target.
-/

namespace PaperChronological

/-- The strengthened unconditional finite-moment chain, as a conjunction
of independent validated algebraic interfaces once compiled. -/
theorem NEXT_CHAIN_FINITE_SPECTRAL
    (w₁ w₂ u v : ℝ) (hw₁ : 0 < w₁) (hw₂ : 0 < w₂) (huv : u ≠ v) :
    0 < twoAtomMoment0 w₁ w₂ * twoAtomMoment2 w₁ w₂ u v -
      (twoAtomMoment1 w₁ w₂ u v) ^ 2 :=
  THEOREM_3_3_TWO_ATOM_STRICT_POSITIVITY w₁ w₂ u v hw₁ hw₂ huv

end PaperChronological
