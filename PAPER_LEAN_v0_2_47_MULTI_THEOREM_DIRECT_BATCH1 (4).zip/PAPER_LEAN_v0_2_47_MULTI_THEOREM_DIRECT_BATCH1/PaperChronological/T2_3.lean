import PaperChronological.T2_2

/-!
# Lemma 2.3: Reflection and difference identities for tau

PDF p. 5. Audit status: PROVED_COMPONENTS.

Proved monomial and pole generator identities; linear-extension
uses the exact rational-function representation from the source.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Lemma 2.3, the simple-pole reflection identity. -/
theorem LEMMA_2_3_REFLECTION_POLE (k : ℕ) (r : ℤ) :
    -Zetahyperbolic.tauPolePoly k (-1 - r) =
      -Zetahyperbolic.tauPolePoly k r :=
  Zetahyperbolic.tau_reflection_pole k r

/-- Lemma 2.3, the Bernoulli convolution form of monomial reflection. -/
theorem LEMMA_2_3_REFLECTION_MONOMIAL (k d : ℕ) (hk : 1 ≤ k) :
    (-1 : ℚ) ^ d *
      (∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i) =
      -Zetahyperbolic.tauMonomial k d :=
  Zetahyperbolic.tau_reflection_monomial k d hk

/-- Lemma 2.3, the simple-pole difference identity (2.7). -/
theorem LEMMA_2_3_DIFFERENCE_POLE
    (k : ℕ) (r : ℤ) (hr0 : r ≠ 0) (hr1 : r ≠ 1) :
    Zetahyperbolic.tauPolePoly k (r - 1) -
      Zetahyperbolic.tauPolePoly k r =
        Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹) :=
  Zetahyperbolic.tau_difference_pole k r hr0 hr1

end PaperChronological
