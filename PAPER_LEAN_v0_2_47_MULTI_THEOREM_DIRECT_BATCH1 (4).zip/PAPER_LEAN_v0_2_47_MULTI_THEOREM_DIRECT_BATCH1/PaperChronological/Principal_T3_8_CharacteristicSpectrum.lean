import PaperChronological.Principal_T3_8_PoleKernelDet
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic

/-!
# Theorem 3.8(1) — complete finite pole-kernel characteristic polynomial identity

We upgrade the previously established equality of determinants to equality of
*entire characteristic polynomials*. This proves that the actual finite
matrix H*M, with M the manuscript's derivative matrix, and the weighted
negative-pole Christoffel-Darboux evaluation matrix have identical spectra,
counting algebraic multiplicity. The identity is valid for any H; taking H
as the inverse of the actual positive definite zeta Gram matrix gives the
manuscript's specific pole-kernel matrix. No witness is needed.

The additional tau-deformed Jacobi integral identity in Theorem 3.8(2) is a
separate analytic problem and is NOT asserted by this module.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological.Principal

/-- Sylvester AB/BA characteristic-polynomial transfer, specialized to the
pole diagonalization pattern. Holds over any commutative ring at every size. -/
theorem poleKernel_charpoly_identity
    {R : Type*} [CommRing R] {n : ℕ}
    (H V : Matrix (Fin n) (Fin n) R) (γ : Fin n → R) :
    (H * (V * Matrix.diagonal γ * V.transpose)).charpoly =
      (Matrix.diagonal γ * (V.transpose * H * V)).charpoly := by
  simpa only [Matrix.mul_assoc] using
    (Matrix.charpoly_mul_comm
      (H * V) (Matrix.diagonal γ * V.transpose))

/-- Exact whole-spectrum identity for the actual rational odd-zeta slope
matrix; it is not merely equality of the product of its eigenvalues. -/
theorem THEOREM_3_8_ACTUAL_RATIONAL_POLE_KERNEL_CHARPOLY
    (p : ManuscriptChain.Real.Parameters)
    (H : Matrix (Fin p.h) (Fin p.h) ℚ) :
    (H * ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p).charpoly =
      (Matrix.diagonal (ManuscriptChain.PoleDiagonalization.poleWeight p) *
        ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).transpose *
           H * ManuscriptChain.PoleDiagonalization.poleVandermonde p)).charpoly := by
  rw [PaperChronological.THEOREM_2_5_VANDERMONDE]
  exact poleKernel_charpoly_identity H
    (ManuscriptChain.PoleDiagonalization.poleVandermonde p)
    (ManuscriptChain.PoleDiagonalization.poleWeight p)

/-- The paper's real derivative matrix is literally the rational derivative
matrix mapped through the natural embedding of rational numbers in reals. -/
theorem actualDerivativeMatrix_real_eq_rationalMap
    (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.Real.derivativeMatrix p =
      (ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p).map
        (Rat.castHom ℝ) := rfl

/-- The actual REAL derivative matrix has the exact signed pole-diagonal
congruence obtained from the rational moment functional, with no analytic
input and no hypothetical Gram matrix. -/
theorem actualDerivativeMatrix_real_poleFactorization
    (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.Real.derivativeMatrix p =
      ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).map
          (Rat.castHom ℝ)) *
        Matrix.diagonal
          (fun a : Fin p.h =>
            (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ)) *
        (((ManuscriptChain.PoleDiagonalization.poleVandermonde p).map
          (Rat.castHom ℝ))).transpose := by
  have hdiag :
      (Matrix.diagonal
        (ManuscriptChain.PoleDiagonalization.poleWeight p)).map
          (Rat.castHom ℝ) =
      Matrix.diagonal
        (fun a : Fin p.h =>
          (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ)) := by
    ext i j
    by_cases hij : i = j
    · subst j
      simp [Matrix.diagonal_apply]
    · simp [Matrix.diagonal_apply, hij]
  rw [actualDerivativeMatrix_real_eq_rationalMap,
    ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix_factorization]
  simp only [Matrix.map_mul, Matrix.transpose_map, hdiag]

/-- Full real characteristic-polynomial equality: for any real left factor
H, the eigenvalues of H*M coincide with those of the weighted pole kernel. -/
theorem THEOREM_3_8_ACTUAL_REAL_POLE_KERNEL_CHARPOLY
    (p : ManuscriptChain.Real.Parameters)
    (H : Matrix (Fin p.h) (Fin p.h) ℝ) :
    (H * ManuscriptChain.Real.derivativeMatrix p).charpoly =
      (Matrix.diagonal
        (fun a : Fin p.h =>
          (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ)) *
        ((((ManuscriptChain.PoleDiagonalization.poleVandermonde p).map
          (Rat.castHom ℝ))).transpose * H *
           ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).map
          (Rat.castHom ℝ)))).charpoly := by
  rw [actualDerivativeMatrix_real_poleFactorization]
  exact poleKernel_charpoly_identity H
    ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).map
       (Rat.castHom ℝ))
    (fun a => (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ))

/-- Christoffel-Darboux pole-kernel matrix at the *actual* zeta center,
expressed as evaluations of the inverse positive Gram matrix. -/
def actualZetaPoleKernel (p : ManuscriptChain.Real.Parameters) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).map
     (Rat.castHom ℝ)).transpose *
    (ManuscriptChain.Real.gram p (ManuscriptChain.Real.zeta p.weight))⁻¹ *
    ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).map
      (Rat.castHom ℝ))

/-- The paper's actual zeta-centered inverse-Gram spectral matrix and its
weighted pole-kernel matrix have IDENTICAL real characteristic polynomials.
This is the finite spectral identity of Theorem 3.8(1), including multiplicities.
No independent or conjectural analytic witness has been introduced. -/
theorem THEOREM_3_8_ACTUAL_ZETA_CENTER_POLE_KERNEL_SPECTRUM
    (p : ManuscriptChain.Real.Parameters) :
    ((ManuscriptChain.Real.gram p
        (ManuscriptChain.Real.zeta p.weight))⁻¹ *
          ManuscriptChain.Real.derivativeMatrix p).charpoly =
      (Matrix.diagonal
        (fun a : Fin p.h =>
          (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ)) *
         actualZetaPoleKernel p).charpoly := by
  exact THEOREM_3_8_ACTUAL_REAL_POLE_KERNEL_CHARPOLY p
    ((ManuscriptChain.Real.gram p
      (ManuscriptChain.Real.zeta p.weight))⁻¹)

/-- In particular, equality of every eigenvalue equation follows as a
corollary without separately proving a polynomial splitting theorem. -/
theorem THEOREM_3_8_ACTUAL_ZETA_POLE_EIGENVALUE_IFF
    (p : ManuscriptChain.Real.Parameters) (eig : ℝ) :
    Polynomial.eval eig
      (((ManuscriptChain.Real.gram p
        (ManuscriptChain.Real.zeta p.weight))⁻¹ *
          ManuscriptChain.Real.derivativeMatrix p).charpoly) = 0 ↔
    Polynomial.eval eig
      ((Matrix.diagonal
        (fun a : Fin p.h =>
          (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ)) *
            actualZetaPoleKernel p).charpoly) = 0 := by
  rw [THEOREM_3_8_ACTUAL_ZETA_CENTER_POLE_KERNEL_SPECTRUM]

end PaperChronological.Principal

#print axioms PaperChronological.Principal.poleKernel_charpoly_identity
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_RATIONAL_POLE_KERNEL_CHARPOLY
#print axioms PaperChronological.Principal.actualDerivativeMatrix_real_poleFactorization
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_ZETA_CENTER_POLE_KERNEL_SPECTRUM
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_ZETA_POLE_EIGENVALUE_IFF
