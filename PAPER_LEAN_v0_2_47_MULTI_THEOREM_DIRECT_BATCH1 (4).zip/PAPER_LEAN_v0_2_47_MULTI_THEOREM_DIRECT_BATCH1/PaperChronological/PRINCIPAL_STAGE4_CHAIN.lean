import PaperChronological.PRINCIPAL_STAGE3_CHAIN
import PaperChronological.Principal_T3_8_CharacteristicSpectrum
import PaperChronological.Principal_T4_7_ExactBilateralGap

/-!
# Chronological principal theorem chain — fourth direct stage

Theorem 3.8(1): identical characteristic polynomials of the actual
inverse Gram/derivative matrix and the actual weighted pole kernel.

Theorem 4.7(2), exact structural predecessor: opposite-side actual roots
are separated by at least twice the exact zero-free spectral radius.

Both are unconditional and witness-free. This does NOT prove the additional
Jacobi deformation formula or the numerical exponential bound of 4.7.
-/

noncomputable section

namespace PaperChronological.Principal

/-- Genuine zeta-centered pole-kernel equality (not only equal determinant). -/
theorem PRINCIPAL_STAGE4_ACTUAL_POLE_SPECTRUM
    (p : ManuscriptChain.Real.Parameters) :
    ((ManuscriptChain.Real.gram p
       (ManuscriptChain.Real.zeta p.weight))⁻¹ *
         ManuscriptChain.Real.derivativeMatrix p).charpoly =
      (Matrix.diagonal
        (fun a : Fin p.h =>
          (ManuscriptChain.PoleDiagonalization.poleWeight p a : ℝ)) *
          actualZetaPoleKernel p).charpoly := by
  exact THEOREM_3_8_ACTUAL_ZETA_CENTER_POLE_KERNEL_SPECTRUM p

end PaperChronological.Principal

#print axioms PaperChronological.Principal.PRINCIPAL_STAGE4_ACTUAL_POLE_SPECTRUM
