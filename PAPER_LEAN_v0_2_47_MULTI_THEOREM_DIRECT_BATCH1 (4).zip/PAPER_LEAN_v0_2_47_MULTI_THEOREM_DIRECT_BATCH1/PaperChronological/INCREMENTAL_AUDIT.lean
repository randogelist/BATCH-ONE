import PaperChronological.INCREMENTAL_CHAIN

/-!
NEW-only audit: this file is compiled and its output examined by the user's
Windows Lean 4.33.0. Old source and audit modules remain cached unchanged.
-/

#check PaperChronological.LEMMA_2_2_FINITE_SPAN
#check PaperChronological.LEMMA_2_3_FULL_REFLECTION_SPAN
#check PaperChronological.LEMMA_2_3_FINITE_POLE_DIFFERENCE
#check PaperChronological.COROLLARY_3_6_GENERAL_POWER_SUM_BOUNDS
#check PaperChronological.MAIN_CHAIN_SECTION2_FINITE_PRESENTATIONS

#print axioms PaperChronological.LEMMA_2_2_FINITE_SPAN
#print axioms PaperChronological.LEMMA_2_3_FULL_REFLECTION_SPAN
#print axioms PaperChronological.LEMMA_2_3_FINITE_POLE_DIFFERENCE
#print axioms PaperChronological.COROLLARY_3_6_GENERAL_POWER_SUM_BOUNDS
#print axioms PaperChronological.MAIN_CHAIN_SECTION2_FINITE_PRESENTATIONS
