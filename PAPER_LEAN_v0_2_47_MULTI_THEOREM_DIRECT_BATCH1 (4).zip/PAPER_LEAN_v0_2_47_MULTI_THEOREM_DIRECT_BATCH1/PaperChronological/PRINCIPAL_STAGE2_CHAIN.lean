import PaperChronological.PRINCIPAL_CHAIN
import PaperChronological.Principal_T3_3_WeightedAtomicGram
import PaperChronological.Principal_T3_7_DerivativeTuran

/-!
# Stage 2 of the source-faithful principal theorem chain

The new unconditional mathematical endpoints are the strict determinant
of a positive finite weighted atomic Hankel moment matrix and the genuine
ordinary-derivative order-one Turan inequality of the actual odd-zeta
Hankel determinant. No theorem statement is replaced by a placeholder.
No additional Witness hypothesis is introduced.

The full manuscript Theorems 3.3 and 3.7 remain PARTIAL, because the
continuous total-positivity/Carleman and higher-derivative/Newton parts
have not yet been formalized.
-/

noncomputable section

namespace PaperChronological.Principal

/-- The actual odd-zeta Hankel first Turan inequality (ordinary
polynomial derivatives) in every admissible finite dimension. -/
theorem PRINCIPAL_STAGE2_ACTUAL_ODD_ZETA_TURAN
    (q : ManuscriptChain.Real.Parameters)
    (hq : ManuscriptChain.Real.Admissible q) (x : ℝ) :
    0 ≤ derivativeTuran
      (ManuscriptChain.Real.manuscriptPencil q).detPolynomial x := by
  exact THEOREM_3_7_ACTUAL_ODD_ZETA_FIRST_TURAN q hq x

/-- A direct positive finite atomic determinant certificate at all sizes. -/
theorem PRINCIPAL_STAGE2_FINITE_STRICT_DETERMINANT
    {h : ℕ} (u w : Fin h → ℝ)
    (hu : Function.Injective u) (hw : ∀ a, 0 < w a) :
    0 < (weightedAtomicHankel u w).det :=
  THEOREM_3_3_WEIGHTED_ATOMIC_HANKEL_DET_POS u w hu hw

end PaperChronological.Principal

#print axioms PaperChronological.Principal.PRINCIPAL_STAGE2_ACTUAL_ODD_ZETA_TURAN
#print axioms PaperChronological.Principal.PRINCIPAL_STAGE2_FINITE_STRICT_DETERMINANT
