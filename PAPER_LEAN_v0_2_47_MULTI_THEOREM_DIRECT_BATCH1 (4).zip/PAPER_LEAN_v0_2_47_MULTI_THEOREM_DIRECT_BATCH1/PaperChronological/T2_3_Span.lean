import PaperChronological.T2_3

/-!
# Lemma 2.3, finite-span reflection and shift

Proofs on the generators are already in T2_3. Here we construct an arbitrary
finite polynomial-plus-integer-simple-poles presentation for tau and prove
that the paper's reflection law extends to its entire Q-linear span.

The finite-difference identity is extended over any finite family of allowed
simple poles, excluding the manuscript's exceptional indices 0 and 1.

Status: NEW / awaiting user's native Lean compilation.
-/

noncomputable section
open scoped BigOperators Polynomial
open Polynomial

namespace PaperChronological

/-- Formal finite presentation of an element of tau's rational-function
domain: a polynomial and finitely many integer simple poles. -/
structure TauPresentation where
  degree : ℕ
  coefficient : ℕ → ℚ
  poleSet : Finset ℤ
  residue : ℤ → ℚ

/-- Tau on the polynomial part. -/
noncomputable def tauPolynomialValue (k : ℕ) (P : TauPresentation) : ℚ[X] :=
  ∑ d ∈ Finset.range (P.degree + 1),
    Polynomial.C (P.coefficient d * Zetahyperbolic.tauMonomial k d)

/-- Tau on the finite simple-pole part. -/
noncomputable def tauPoleValue (k : ℕ) (P : TauPresentation) : ℚ[X] :=
  ∑ r ∈ P.poleSet,
    Polynomial.C (P.residue r) * Zetahyperbolic.tauPolePoly k r

/-- Tau on the complete finite presentation. -/
noncomputable def tauPresentationValue (k : ℕ) (P : TauPresentation) : ℚ[X] :=
  tauPolynomialValue k P + tauPoleValue k P

/-- Expanded tau of the reflected polynomial `P(-1-x)`, using the binomial
theorem and the sign `(-1)^d` for each monomial of degree `d`. -/
noncomputable def tauReflectedPolynomialValue (k : ℕ) (P : TauPresentation) : ℚ[X] :=
  ∑ d ∈ Finset.range (P.degree + 1),
    Polynomial.C (P.coefficient d *
      ((-1 : ℚ) ^ d *
        (∑ i ∈ Finset.range (d + 1),
          (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i)))

/-- Under `x -> -1-x`, the pole `(x-r)^-1` becomes
`-(x-(-1-r))^-1`. -/
noncomputable def tauReflectedPoleValue (k : ℕ) (P : TauPresentation) : ℚ[X] :=
  ∑ r ∈ P.poleSet,
    Polynomial.C (P.residue r) *
      (-Zetahyperbolic.tauPolePoly k (-1 - r))

/-- Tau applied to the reflected complete presentation. -/
noncomputable def tauReflectedPresentationValue (k : ℕ)
    (P : TauPresentation) : ℚ[X] :=
  tauReflectedPolynomialValue k P + tauReflectedPoleValue k P

/-- Polynomial part of Lemma 2.3, extended to arbitrary finite coefficients. -/
theorem LEMMA_2_3_REFLECTION_POLYNOMIAL_SPAN
    (k : ℕ) (hk : 1 ≤ k) (P : TauPresentation) :
    tauReflectedPolynomialValue k P = -tauPolynomialValue k P := by
  unfold tauReflectedPolynomialValue tauPolynomialValue
  rw [← Finset.sum_neg_distrib]
  apply Finset.sum_congr rfl
  intro d hd
  rw [LEMMA_2_3_REFLECTION_MONOMIAL k d hk]
  simp

/-- Pole part of Lemma 2.3, extended to arbitrary finite residues. -/
theorem LEMMA_2_3_REFLECTION_POLE_SPAN
    (k : ℕ) (P : TauPresentation) :
    tauReflectedPoleValue k P = -tauPoleValue k P := by
  unfold tauReflectedPoleValue tauPoleValue
  rw [← Finset.sum_neg_distrib]
  apply Finset.sum_congr rfl
  intro r hr
  rw [LEMMA_2_3_REFLECTION_POLE k r]
  ring

/-- Lemma 2.3 (2.6): tau is anti-invariant under `x -> -1-x` on
its entire finite polynomial-plus-simple-pole presentation. -/
theorem LEMMA_2_3_FULL_REFLECTION_SPAN
    (k : ℕ) (hk : 1 ≤ k) (P : TauPresentation) :
    tauReflectedPresentationValue k P =
      -tauPresentationValue k P := by
  unfold tauReflectedPresentationValue tauPresentationValue
  rw [LEMMA_2_3_REFLECTION_POLYNOMIAL_SPAN k hk P,
      LEMMA_2_3_REFLECTION_POLE_SPAN k P]
  ring

/-- Finite linear combination of shifted simple-pole differences. -/
noncomputable def tauPoleShiftDifference (k : ℕ)
    (P : TauPresentation) : ℚ[X] :=
  ∑ r ∈ P.poleSet,
    Polynomial.C (P.residue r) *
      (Zetahyperbolic.tauPolePoly k (r - 1) -
       Zetahyperbolic.tauPolePoly k r)

/-- Expected derivative-value sum from equation (2.7). -/
noncomputable def tauPoleShiftDerivative (k : ℕ)
    (P : TauPresentation) : ℚ[X] :=
  ∑ r ∈ P.poleSet,
    Polynomial.C (P.residue r) *
      Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹)

/-- Lemma 2.3 (2.7), extended to finite combinations of admissible poles. -/
theorem LEMMA_2_3_FINITE_POLE_DIFFERENCE
    (k : ℕ) (P : TauPresentation)
    (hallowed : ∀ r ∈ P.poleSet, r ≠ 0 ∧ r ≠ 1) :
    tauPoleShiftDifference k P = tauPoleShiftDerivative k P := by
  unfold tauPoleShiftDifference tauPoleShiftDerivative
  apply Finset.sum_congr rfl
  intro r hr
  rw [LEMMA_2_3_DIFFERENCE_POLE k r
    (hallowed r hr).1 (hallowed r hr).2]

end PaperChronological
