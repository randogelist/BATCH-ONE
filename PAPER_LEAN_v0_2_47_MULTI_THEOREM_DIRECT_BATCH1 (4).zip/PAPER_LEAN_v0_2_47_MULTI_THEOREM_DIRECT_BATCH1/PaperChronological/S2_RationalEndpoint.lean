import PaperChronological.S2_ResidueInterpretation

/-!
# Manuscript Section 2: explicit rational-residue completion

The unconditional `AlgebraicChain` of v0.2.13 is extended by the precise
comparison of ordinary pole residues with the cleared Lagrange numerator.
The only hypotheses below are the normal pole-domain restrictions for
evaluating rational functions. Nothing from Section 4's Witness is assumed.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

structure RationalAlgebraicChain (p : ManuscriptChain.Real.Parameters) : Prop where
  algebraic : AlgebraicChain p
  recoverActualResidue : ∀ (Q : ℚ[X]) (c : Fin p.h → ℚ) (a : Fin p.h),
    (clearedResidueNumerator p Q c).eval
      (ManuscriptChain.PoleDiagonalization.poleNode p a) =
        c a * poleDerivative p a
  poleFreeNonnegative : ∀ (t : ℚ), 0 ≤ t → OffTailPoles p t
  literalRationalValue : ∀ (Q : ℚ[X]) (c : Fin p.h → ℚ)
    (t : ℚ), OffTailPoles p t →
    Q.eval t + ∑ a : Fin p.h, c a /
      (t + (ManuscriptChain.PoleDiagonalization.poleIndex p a : ℚ) ^ 2) =
      (clearedResidueNumerator p Q c).eval t /
        (ManuscriptChain.Real.tailD p).eval t
  rationalFractionUniqueness : ∀ (Q₁ Q₂ : ℚ[X])
      (c₁ c₂ : Fin p.h → ℚ),
    clearedResidueNumerator p Q₁ c₁ * ManuscriptChain.Real.tailD p =
      clearedResidueNumerator p Q₂ c₂ * ManuscriptChain.Real.tailD p →
    Q₁ = Q₂ ∧ c₁ = c₂

/-- Section 2's finite algebraic chain and its explicit ordinary-residue
rational-function realization. No arithmetic/analytic witness. -/
theorem SECTION2_RATIONAL_ALGEBRAIC_CHAIN
    (p : ManuscriptChain.Real.Parameters) : RationalAlgebraicChain p := by
  refine {
    algebraic := SECTION2_UNCONDITIONAL_ALGEBRAIC_CHAIN p
    recoverActualResidue := clearedResidue_eval_node p
    poleFreeNonnegative := offTailPoles_of_nonneg p
    literalRationalValue := residueValue_eq_quotient p
    rationalFractionUniqueness := clearedFraction_unique p }

end PaperChronological.Section2
