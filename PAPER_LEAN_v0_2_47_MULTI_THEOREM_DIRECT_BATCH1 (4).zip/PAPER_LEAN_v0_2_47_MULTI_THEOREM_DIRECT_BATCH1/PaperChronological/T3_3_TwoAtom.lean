import PaperChronological.T3_3

/-!
# Theorem 3.3: exact strict 2x2 Hankel positivity on a two-atom measure

This is a fully finite, source-faithful case of the paper's total-positivity
mechanism. It is an *actual determinant identity*, not a redefinition of
positivity and not the paper's full infinite Stieltjes/Carleman theorem.

No hypothesis concerns zeta irrationality. Source status: new, uncompiled.
-/

noncomputable section

namespace PaperChronological

/-- The first three moments of a two-atom positive measure. -/
def twoAtomMoment0 (w₁ w₂ : ℝ) : ℝ := w₁ + w₂
def twoAtomMoment1 (w₁ w₂ u v : ℝ) : ℝ := w₁ * u + w₂ * v
def twoAtomMoment2 (w₁ w₂ u v : ℝ) : ℝ := w₁ * u ^ 2 + w₂ * v ^ 2

/-- Theorem 3.3(1), finite two-atom exact 2x2 Hankel minor formula.
The right side is strictly positive for positive weights and distinct nodes. -/
theorem THEOREM_3_3_TWO_ATOM_HANKEL_DET
    (w₁ w₂ u v : ℝ) :
    twoAtomMoment0 w₁ w₂ * twoAtomMoment2 w₁ w₂ u v -
      (twoAtomMoment1 w₁ w₂ u v) ^ 2 = w₁ * w₂ * (u - v) ^ 2 := by
  unfold twoAtomMoment0 twoAtomMoment1 twoAtomMoment2
  ring

/-- Strict 2x2 Hankel positivity, without invoking analytic hypotheses. -/
theorem THEOREM_3_3_TWO_ATOM_STRICT_POSITIVITY
    (w₁ w₂ u v : ℝ) (hw₁ : 0 < w₁) (hw₂ : 0 < w₂)
    (huv : u ≠ v) :
    0 < twoAtomMoment0 w₁ w₂ * twoAtomMoment2 w₁ w₂ u v -
      (twoAtomMoment1 w₁ w₂ u v) ^ 2 := by
  rw [THEOREM_3_3_TWO_ATOM_HANKEL_DET]
  have hsq : 0 < (u - v) ^ 2 := sq_pos_of_ne_zero (sub_ne_zero.mpr huv)
  exact mul_pos (mul_pos hw₁ hw₂) hsq

/-- Every first and second moment is positive when both atoms are positive. -/
theorem THEOREM_3_3_TWO_ATOM_ENTRY_POSITIVITY
    (w₁ w₂ u v : ℝ)
    (hw₁ : 0 < w₁) (hw₂ : 0 < w₂)
    (hu : 0 < u) (hv : 0 < v) :
    0 < twoAtomMoment0 w₁ w₂ ∧
    0 < twoAtomMoment1 w₁ w₂ u v ∧
    0 < twoAtomMoment2 w₁ w₂ u v := by
  unfold twoAtomMoment0 twoAtomMoment1 twoAtomMoment2
  constructor
  · exact add_pos hw₁ hw₂
  constructor
  · exact add_pos (mul_pos hw₁ hu) (mul_pos hw₂ hv)
  · exact add_pos (mul_pos hw₁ (sq_pos_of_pos hu))
        (mul_pos hw₂ (sq_pos_of_pos hv))

end PaperChronological
