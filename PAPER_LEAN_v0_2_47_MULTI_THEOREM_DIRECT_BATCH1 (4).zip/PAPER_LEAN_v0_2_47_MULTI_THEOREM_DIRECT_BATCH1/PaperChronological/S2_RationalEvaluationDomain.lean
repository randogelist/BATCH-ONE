import PaperChronological.S2_DirectedUnionMoment

/-!
# Section 2: pointwise realization of the directed-union rational domain

The *same* quotient domain carrying the rational moment functional carries
an explicit pointwise rational-function evaluation map. Its value is
independent of the finite presentation and of the arbitrary pole cutoff.

At nonnegative rational arguments all original denominators are strictly
positive; at the negative square pole lattice one must use the separate
pole-free domain restriction from `S2_ResidueInterpretation`.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- Literal evaluation of the rational function represented by the finite
polynomial part and its simple pole residues. -/
noncomputable def finiteRationalValue
    (R : Zetahyperbolic.RatMomentElem) (t : ℚ) : ℚ :=
  R.polyPart.eval t +
    ∑ j ∈ Finset.Icc 1 R.maxPole,
      R.poleRes j / (t + (j : ℚ) ^ 2)

/-- Introducing one additional zero-residue pole does not change the
rational-function value, at any rational argument. -/
theorem finiteRationalValue_extendMomentCutoff
    (R : Zetahyperbolic.RatMomentElem) (t : ℚ) :
    finiteRationalValue (extendMomentCutoff R) t =
      finiteRationalValue R t := by
  change R.polyPart.eval t +
      (∑ j ∈ Finset.Icc 1 (R.maxPole + 1),
        (if j = R.maxPole + 1 then (0 : ℚ) else R.poleRes j) /
          (t + (j : ℚ) ^ 2)) =
    R.polyPart.eval t +
      ∑ j ∈ Finset.Icc 1 R.maxPole,
        R.poleRes j / (t + (j : ℚ) ^ 2)
  rw [Finset.sum_Icc_succ_top (by omega : 1 ≤ R.maxPole + 1)]
  have hlast :
      (if R.maxPole + 1 = R.maxPole + 1 then (0 : ℚ) else
          R.poleRes (R.maxPole + 1)) /
        (t + ((R.maxPole + 1 : ℕ) : ℚ) ^ 2) = 0 := by simp
  rw [hlast, add_zero]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  have hne : j ≠ R.maxPole + 1 := by
    have hjmax : j ≤ R.maxPole := (Finset.mem_Icc.mp hj).2
    omega
  simp only [if_neg hne]

/-- Any finite sequence of zero-residue extensions preserves the literal
rational-function evaluation. -/
theorem finiteRationalValue_extendMomentCutoffN
    (R : Zetahyperbolic.RatMomentElem) (n : ℕ) (t : ℚ) :
    finiteRationalValue (extendMomentCutoffN R n) t =
      finiteRationalValue R t := by
  induction n with
  | zero => rfl
  | succ n ih =>
      change finiteRationalValue
          (extendMomentCutoff (extendMomentCutoffN R n)) t =
            finiteRationalValue R t
      rw [finiteRationalValue_extendMomentCutoff, ih]

/-- Two finite presentations with the same polynomial part, same cutoff,
and same active residues evaluate identically. -/
theorem finiteRationalValue_congr_sameCutoff
    (R S : Zetahyperbolic.RatMomentElem) (t : ℚ)
    (hpoly : R.polyPart = S.polyPart)
    (hmax : R.maxPole = S.maxPole)
    (hres : ∀ j : ℕ, 1 ≤ j → j ≤ S.maxPole →
      R.poleRes j = S.poleRes j) :
    finiteRationalValue R t = finiteRationalValue S t := by
  unfold finiteRationalValue
  apply congrArg₂ (fun a b : ℚ => a + b)
  · rw [hpoly]
  · rw [hmax]
    apply Finset.sum_congr rfl
    intro j hj
    rw [hres j (Finset.mem_Icc.mp hj).1
      (Finset.mem_Icc.mp hj).2]

/-- Literal rational evaluation is independent of the choice of finite
pole cutoff; this is a separate theorem from moment well-definedness. -/
theorem finiteRationalValue_wellDefined
    (R S : Zetahyperbolic.RatMomentElem) (t : ℚ)
    (h : sameFinitePoleData R S) :
    finiteRationalValue R t = finiteRationalValue S t := by
  let J := max R.maxPole S.maxPole
  let R' := extendToCutoff R J
  let S' := extendToCutoff S J
  have hRJ : R.maxPole ≤ J := Nat.le_max_left _ _
  have hSJ : S.maxPole ≤ J := Nat.le_max_right _ _
  have hRmax : R'.maxPole = J := extendToCutoff_maxPole R J hRJ
  have hSmax : S'.maxPole = J := extendToCutoff_maxPole S J hSJ
  have hpoly : R'.polyPart = S'.polyPart := by
    change (extendMomentCutoffN R (J - R.maxPole)).polyPart =
      (extendMomentCutoffN S (J - S.maxPole)).polyPart
    rw [extendMomentCutoffN_polyPart, extendMomentCutoffN_polyPart]
    exact h.1
  have hmax : R'.maxPole = S'.maxPole := hRmax.trans hSmax.symm
  have hres : ∀ j : ℕ, 1 ≤ j → j ≤ S'.maxPole →
      R'.poleRes j = S'.poleRes j := by
    intro j hjpos hj
    have hjJ : j ≤ J := by simpa only [hSmax] using hj
    have hjR : j ≤ R.maxPole + (J - R.maxPole) := by omega
    have hjS : j ≤ S.maxPole + (J - S.maxPole) := by omega
    have hr : R'.poleRes j = paddedResidue R j :=
      extendMomentCutoffN_poleRes_eq_padded R (J - R.maxPole) j hjR
    have hs : S'.poleRes j = paddedResidue S j :=
      extendMomentCutoffN_poleRes_eq_padded S (J - S.maxPole) j hjS
    exact hr.trans ((h.2 j hjpos).trans hs.symm)
  calc
    finiteRationalValue R t = finiteRationalValue R' t :=
      (finiteRationalValue_extendMomentCutoffN R (J - R.maxPole) t).symm
    _ = finiteRationalValue S' t :=
      finiteRationalValue_congr_sameCutoff R' S' t hpoly hmax hres
    _ = finiteRationalValue S t :=
      finiteRationalValue_extendMomentCutoffN S (J - S.maxPole) t

/-- The literal rational-function evaluation descends to the same quotient
on which the paper's rational moment functional is defined. -/
noncomputable def rationalValueOnDomain (t : ℚ) :
    RationalMomentDomain → ℚ :=
  fun R => Quotient.liftOn R (fun r => finiteRationalValue r t)
    (fun a b hab => finiteRationalValue_wellDefined a b t hab)

@[simp] theorem rationalValueOnDomain_mk (t : ℚ)
    (R : Zetahyperbolic.RatMomentElem) :
    rationalValueOnDomain t (Quotient.mk finitePoleSetoid R) =
      finiteRationalValue R t := rfl

end PaperChronological.Section2
