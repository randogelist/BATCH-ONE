import PaperChronological.S2_FullChain

/-!
# Section 2 proof and axiom audit

Compiled by the user's native Lean 4.33.0 FASTCORE command only.
The print-axioms output must be inspected for any nonstandard axioms.
This audit is new and does not require rerunning frozen prior audits.
-/

#check PaperChronological.DEF_2_1_POLE_SLOPE
#check PaperChronological.LEMMA_2_2_FINITE_SPAN
#check PaperChronological.LEMMA_2_3_FULL_REFLECTION_SPAN
#check PaperChronological.LEMMA_2_3_FINITE_POLE_DIFFERENCE
#check PaperChronological.THEOREM_2_4_CANONICAL_BASIS_INVARIANCE
#check PaperChronological.THEOREM_2_5_VANDERMONDE
#check PaperChronological.THEOREM_2_5_EXACT_DEGREE
#check PaperChronological.Section2.L_eval
#check PaperChronological.Section2.normalizedPresentation_unique
#check PaperChronological.Section2.normalizedNumerator_add
#check PaperChronological.Section2.LAGRANGE_CLEARED_DENOMINATOR
#check PaperChronological.Section2.LAGRANGE_LINEAR_COMBINATION_INJECTIVE
#check PaperChronological.Section2.SECTION2_UNCONDITIONAL_ALGEBRAIC_CHAIN

#print axioms PaperChronological.LEMMA_2_2_FINITE_SPAN
#print axioms PaperChronological.LEMMA_2_3_FULL_REFLECTION_SPAN
#print axioms PaperChronological.LEMMA_2_3_FINITE_POLE_DIFFERENCE
#print axioms PaperChronological.THEOREM_2_4_CANONICAL_BASIS_INVARIANCE
#print axioms PaperChronological.THEOREM_2_5_VANDERMONDE
#print axioms PaperChronological.Section2.normalizedPresentation_unique
#print axioms PaperChronological.Section2.LAGRANGE_CLEARED_DENOMINATOR
#print axioms PaperChronological.Section2.SECTION2_UNCONDITIONAL_ALGEBRAIC_CHAIN
