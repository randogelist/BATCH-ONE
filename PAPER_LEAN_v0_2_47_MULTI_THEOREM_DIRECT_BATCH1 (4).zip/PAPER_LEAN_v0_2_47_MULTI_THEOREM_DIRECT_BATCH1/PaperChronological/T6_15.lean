import PaperChronological.T6_14

/-!
# Theorem 6.15: Arithmetic transcendence and beta odd Pade pencil

PDF p. 46. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 6.15 is still a formalization target. -/

end PaperChronological
