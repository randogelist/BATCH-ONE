import PaperChronological.T2_5
import MAIN_CHAIN_ASSEMBLED

/-!
# Theorem 3.1: Universal hyperbolicity and zero-free disk

PDF p. 7. Audit status: PROVED.

This module links an actual mathematical theorem to previously
proved source declarations; no manuscript premise is silently postulated.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 3.1, for the ACTUAL odd-zeta Hankel pencil, not an arbitrary
surrogate. The integral and positivity bridge is already proved upstream. -/
theorem THEOREM_3_1_UNIVERSAL_HYPERBOLICITY
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- The Gram matrix at the actual zeta value is strictly positive definite. -/
theorem THEOREM_3_1_GRAM_POSITIVE
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    (ManuscriptChain.Real.gram p
      (ManuscriptChain.Real.zeta p.weight)).PosDef :=
  ManuscriptChain.GRAM_POSITIVE p hp

/-- Exact positive zero-free radius; a root attains the boundary radius. -/
theorem THEOREM_3_1_EXACT_DISK
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ∃ radius : ℝ, 0 < radius ∧
      (∀ z : ℂ, ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ < radius →
        ¬ ManuscriptChain.General.ComplexRoot p z) ∧
      (∃ z : ℂ, ManuscriptChain.General.ComplexRoot p z ∧
        ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ = radius) :=
  ManuscriptChain.EXACT_ZERO_FREE_DISK p hp

end PaperChronological
