import PaperChronological.Principal_T4_7_ExactBilateralGap
import Mathlib.Tactic.Ring

/-!
# Proposition 4.8 — all-dimensional polynomial factor-distance estimates

Proves upper/lower factor-product envelopes for ALL finite root families,
then applies the lower bound to ACTUAL spectral roots of the manuscript
Hankel pencil, using only the unconditional radius in Theorem 3.1.
This is the algebraic part of the factor-degree argument, without asserting
the external irrationality exponent or coefficient-height hypotheses.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronological.Principal

/-- Uniform zero separation implies a lower bound for the full product. -/
theorem finite_root_product_lower
    {n : ℕ} (r : Fin n → ℝ) (x radius : ℝ)
    (hradius : 0 ≤ radius)
    (hsep : ∀ i : Fin n, radius ≤ |x - r i|) :
    radius ^ n ≤ |∏ i : Fin n, (x - r i)| := by
  classical
  have aux : ∀ s : Finset (Fin n),
      radius ^ s.card ≤ |∏ i ∈ s, (x - r i)| := by
    intro s
    induction s using Finset.induction_on with
    | empty => simp
    | @insert a s ha ih =>
        rw [Finset.card_insert_of_not_mem ha, Finset.prod_insert ha,
          pow_succ, abs_mul]
        calc
          radius ^ s.card * radius ≤
              |∏ i ∈ s, (x - r i)| * |x - r a| :=
            mul_le_mul ih (hsep a) hradius (abs_nonneg _)
          _ = |x - r a| * |∏ i ∈ s, (x - r i)| := by ring
  simpa only [Finset.card_univ, Fintype.card_fin] using
    (aux (Finset.univ : Finset (Fin n)))

/-- Uniform root clustering gives the complementary upper bound. -/
theorem finite_root_product_upper
    {n : ℕ} (r : Fin n → ℝ) (x radius : ℝ)
    (hradius : 0 ≤ radius)
    (hsep : ∀ i : Fin n, |x - r i| ≤ radius) :
    |∏ i : Fin n, (x - r i)| ≤ radius ^ n := by
  classical
  have aux : ∀ s : Finset (Fin n),
      |∏ i ∈ s, (x - r i)| ≤ radius ^ s.card := by
    intro s
    induction s using Finset.induction_on with
    | empty => simp
    | @insert a s ha ih =>
        rw [Finset.card_insert_of_not_mem ha, Finset.prod_insert ha,
          pow_succ, abs_mul]
        calc
          |x - r a| * |∏ i ∈ s, (x - r i)| ≤
              radius * radius ^ s.card :=
            mul_le_mul (hsep a) ih (abs_nonneg _) hradius
          _ = radius ^ s.card * radius := by ring
  simpa only [Finset.card_univ, Fintype.card_fin] using
    (aux (Finset.univ : Finset (Fin n)))

/-- The paper's ACTUAL odd-zeta roots have an unconditional exponential-free
factor-product lower bound centered at zeta(s), in EVERY dimension. -/
theorem THEOREM_4_8_ACTUAL_ZETA_CENTER_PRODUCT_LOWER
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    (ManuscriptChain.General.zeroFreeRadius p hp
       (ManuscriptChain.GRAM_POSITIVE p hp)) ^ p.h ≤
      |∏ i : Fin p.h,
          (ManuscriptChain.Real.zeta p.weight -
            (ManuscriptChain.General.factorization p
               (ManuscriptChain.GRAM_POSITIVE p hp)).root i)| := by
  let positive := ManuscriptChain.GRAM_POSITIVE p hp
  have hpos : 0 ≤ ManuscriptChain.General.zeroFreeRadius p hp positive :=
    le_of_lt (ManuscriptChain.General.zeroFreeRadius_pos p hp positive)
  apply finite_root_product_lower
    (r := fun i => (ManuscriptChain.General.factorization p positive).root i)
    (x := ManuscriptChain.Real.zeta p.weight)
    (radius := ManuscriptChain.General.zeroFreeRadius p hp positive)
  · exact hpos
  · intro i
    have hd := (ManuscriptChain.General.factorization p positive).root_distance_lower_bound
      (ManuscriptChain.General.spectralRadius p hp positive)
      (ManuscriptChain.General.beta_abs_le p hp positive) i
    simpa only [ManuscriptChain.General.zeroFreeRadius, abs_sub_comm] using hd

end PaperChronological.Principal

#print axioms PaperChronological.Principal.finite_root_product_lower
#print axioms PaperChronological.Principal.finite_root_product_upper
#print axioms PaperChronological.Principal.THEOREM_4_8_ACTUAL_ZETA_CENTER_PRODUCT_LOWER
