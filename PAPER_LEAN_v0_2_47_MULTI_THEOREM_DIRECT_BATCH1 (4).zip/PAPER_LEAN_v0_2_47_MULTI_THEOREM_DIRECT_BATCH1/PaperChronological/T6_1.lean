import PaperChronological.T5_7

/-!
# Theorem 6.1: Divided-difference p-adic valuation and barrier

PDF p. 29. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 6.1 is still a formalization target. -/

end PaperChronological
