import PaperChronological.T3_5
import PaperChronological.T3_3_TwoAtom

/-!
# Corollary 3.5: repaired finite continued-fraction identity

The printed J-fraction (3.6) omits the correct normalization. The exact
2x2 Schur complement is proved below with its genuine nonvanishing
hypotheses. This does not assert the paper's false unnormalized formula.

Status: new, awaiting user's Lean compiler.
-/

noncomputable section

namespace PaperChronological

/-- The two-by-two determinant Schur factorization (no division by zero). -/
theorem COROLLARY_3_5_SCHUR_FACTOR
    (a b d : ℝ) (ha : a ≠ 0) :
    a * (d - b ^ 2 / a) = a * d - b ^ 2 := by
  field_simp [ha]

/-- Corrected 2x2 ratio of consecutive leading principal minors:
`Delta_1/Delta_2 = 1/(d-b^2/a)` for the symmetric matrix `[[a,b],[b,d]]`.
In contrast, the printed equation lacks its required Gram normalization. -/
theorem COROLLARY_3_5_CORRECTED_TWO_BY_TWO
    (a b d : ℝ) (ha : a ≠ 0)
    (hdet : a * d - b ^ 2 ≠ 0) :
    a / (a * d - b ^ 2) = 1 / (d - b ^ 2 / a) := by
  have hfactor := COROLLARY_3_5_SCHUR_FACTOR a b d ha
  have hschur : d - b ^ 2 / a ≠ 0 := by
    intro hzero
    apply hdet
    rw [hzero, mul_zero] at hfactor
    exact hfactor.symm
  calc
    a / (a * d - b ^ 2) = a / (a * (d - b ^ 2 / a)) := by rw [hfactor]
    _ = 1 / (d - b ^ 2 / a) := by
      field_simp [ha, hschur]

/-- The corrected Schur quotient applies equally to an affine matrix pencil. -/
theorem COROLLARY_3_5_CORRECTED_AFFINE_PENCIL
    (g₀ g₁ g₂ m₀ m₁ m₂ x xi : ℝ)
    (ha : g₀ + (x - xi) * m₀ ≠ 0)
    (hdet :
      (g₀ + (x - xi) * m₀) * (g₂ + (x - xi) * m₂) -
       (g₁ + (x - xi) * m₁) ^ 2 ≠ 0) :
    (g₀ + (x - xi) * m₀) /
      ((g₀ + (x - xi) * m₀) * (g₂ + (x - xi) * m₂) -
       (g₁ + (x - xi) * m₁) ^ 2) =
      1 / ((g₂ + (x - xi) * m₂) -
         (g₁ + (x - xi) * m₁) ^ 2 / (g₀ + (x - xi) * m₀)) := by
  exact COROLLARY_3_5_CORRECTED_TWO_BY_TWO
    (g₀ + (x - xi) * m₀) (g₁ + (x - xi) * m₁)
    (g₂ + (x - xi) * m₂) ha hdet

end PaperChronological
