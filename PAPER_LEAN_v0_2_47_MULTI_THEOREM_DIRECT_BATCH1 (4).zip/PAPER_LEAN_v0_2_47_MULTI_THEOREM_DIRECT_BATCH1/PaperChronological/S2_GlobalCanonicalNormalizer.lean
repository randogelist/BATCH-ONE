import PaperChronological.S2_RationalEvaluationDomain

/-!
# Section 2: a single primitive finite normal form at a common pole cutoff

Given *any two* polynomial-plus-simple-pole presentations, choose a finite
bound `J` at least as large as both cutoffs.  Map each into the canonical
cleared numerator at exactly the poles 1,...,J by padding the absent
residues with zero.  The already proved fixed-cutoff uniqueness theorem
then proves that equality of the resulting polynomials is equivalent to
identity of the actual polynomial and pole data, independent of cutoffs.

This is an algebraic bridge from the quotient presentation domain to the
original rational-fraction normalization.  In particular the artificial
index zero plays no role in the rational-function domain.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The true all-poles numerator at finite cutoff `J`, including zero residues
at every unused pole. The parameter `k` occurs only because it is part of the
source's fixed Parameters structure; the resulting polynomial is independent
of this harmless choice of moment weight. -/
def canonicalNumeratorAt (k J : ℕ)
    (R : Zetahyperbolic.RatMomentElem) : ℚ[X] :=
  allPoleNumerator k J R.polyPart
    (fun a : Fin J => paddedResidue R (a.val + 1))

/-- Presentations that differ only by a cutoff have exactly the same cleared
numerator at every common finite pole bound. -/
theorem canonicalNumeratorAt_congr (k J : ℕ)
    (R S : Zetahyperbolic.RatMomentElem)
    (h : sameFinitePoleData R S) :
    canonicalNumeratorAt k J R = canonicalNumeratorAt k J S := by
  unfold canonicalNumeratorAt
  have hcoeff :
      (fun a : Fin J => paddedResidue R (a.val + 1)) =
        (fun a : Fin J => paddedResidue S (a.val + 1)) := by
    funext a
    exact h.2 (a.val + 1) (by omega)
  rw [h.1, hcoeff]

/-- A canonical numerator at one common cutoff determines the entire finite
presentation (including all real poles, not just those originally listed). -/
theorem canonicalNumeratorAt_injective (k J : ℕ)
    (R S : Zetahyperbolic.RatMomentElem)
    (hR : R.maxPole ≤ J) (hS : S.maxPole ≤ J)
    (hnum : canonicalNumeratorAt k J R =
      canonicalNumeratorAt k J S) :
    sameFinitePoleData R S := by
  have hh : R.polyPart = S.polyPart ∧
      (fun a : Fin J => paddedResidue R (a.val + 1)) =
        (fun a : Fin J => paddedResidue S (a.val + 1)) :=
    allPoleNumerator_unique k J R.polyPart S.polyPart
      (fun a : Fin J => paddedResidue R (a.val + 1))
      (fun a : Fin J => paddedResidue S (a.val + 1)) hnum
  refine ⟨hh.1, ?_⟩
  intro j hjpos
  by_cases hjJ : j ≤ J
  · let a : Fin J := ⟨j - 1, by omega⟩
    have ha : a.val + 1 = j := by
      dsimp [a]
      omega
    have heq := congrFun hh.2 a
    simpa only [ha] using heq
  · have hjR : ¬ j ≤ R.maxPole := by omega
    have hjS : ¬ j ≤ S.maxPole := by omega
    simp only [paddedResidue, if_neg hjR, if_neg hjS]

/-- Data equality and equality of canonical rational-fraction numerators are
*equivalent* as soon as one works at a common pole bound. -/
theorem sameFinitePoleData_iff_canonicalNumeratorAt (k J : ℕ)
    (R S : Zetahyperbolic.RatMomentElem)
    (hR : R.maxPole ≤ J) (hS : S.maxPole ≤ J) :
    sameFinitePoleData R S ↔
      canonicalNumeratorAt k J R = canonicalNumeratorAt k J S := by
  constructor
  · exact canonicalNumeratorAt_congr k J R S
  · exact canonicalNumeratorAt_injective k J R S hR hS

/-- There is a common explicit polynomial certificate for equality of any
two presentations, independent of how their individual cutoffs were chosen. -/
theorem sameFinitePoleData_iff_commonNumerator (k : ℕ)
    (R S : Zetahyperbolic.RatMomentElem) :
    sameFinitePoleData R S ↔
      canonicalNumeratorAt k (max R.maxPole S.maxPole) R =
        canonicalNumeratorAt k (max R.maxPole S.maxPole) S := by
  exact sameFinitePoleData_iff_canonicalNumeratorAt k
    (max R.maxPole S.maxPole) R S
    (Nat.le_max_left _ _) (Nat.le_max_right _ _)

end PaperChronological.Section2
