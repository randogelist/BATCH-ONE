import PaperChronological.MAIN_CHAIN
import PaperChronological.T2_2_Span
import PaperChronological.T2_3_Span
import PaperChronological.T3_6_Corrected

/-!
# Chronological paper chain, PASS-ONCE extension v0.2.3

The existing previously compiled source modules are deliberately untouched.
New source files extend Lemma 2.2 and Lemma 2.3 to complete finite rational
presentations, and give the corrected general power sum bound for Cor. 3.6.

This does NOT certify the remaining PDF theorems, the analytic extension of
these presentations to arbitrary unverified domains, or Witness existence.
-/

noncomputable section
namespace PaperChronological

/-- Two exact Section 2 identities valid for arbitrary finite generator
presentations; the first full odd-zeta spectral endpoint remains imported
from the unchanged chronological main chain. -/
theorem MAIN_CHAIN_SECTION2_FINITE_PRESENTATIONS
    (k : ℕ) (hk : 1 ≤ k)
    (R : Zetahyperbolic.RatMomentElem)
    (P : TauPresentation) :
    Zetahyperbolic.muFunctionalPoly k R =
      tauPullbackOnPresentation k R ∧
    tauReflectedPresentationValue k P =
      -tauPresentationValue k P := by
  exact ⟨LEMMA_2_2_FINITE_SPAN k hk R,
    LEMMA_2_3_FULL_REFLECTION_SPAN k hk P⟩

end PaperChronological
