import PaperChronological.Principal_T3_9_FeketeTransfer
import Mathlib.Tactic.Linarith

/-!
# Theorem 3.9 — all five character generating kernels are positive

Extends the proved factorizations of the five Fekete polynomials to their
complete rational generating functions F_chi(z)/(1-z^q), 0<z<1.
The identification with each particular Dirichlet L-value integral and
hyperbolic Hankel pencil remains a separate analytic bridge.
-/

noncomputable section
namespace PaperChronological.Principal

/-- Positive subunit interval is stable under arbitrary natural powers. -/
theorem subunit_power_le_one {z : ℝ} (hz0 : 0 < z) (hz1 : z < 1)
    (n : ℕ) : z ^ n ≤ 1 := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [pow_succ]
      calc
        z ^ n * z ≤ 1 * z := mul_le_mul_of_nonneg_right ih (le_of_lt hz0)
        _ ≤ 1 := by simpa using (le_of_lt hz1)

/-- In particular every denominator 1-z^(n+1) is strictly positive. -/
theorem subunit_denominator_pos {z : ℝ} (hz0 : 0 < z) (hz1 : z < 1)
    (n : ℕ) : 0 < 1 - z ^ (n + 1) := by
  have hle := subunit_power_le_one hz0 hz1 n
  have hm : z ^ n * z ≤ z := by
    simpa using (mul_le_mul_of_nonneg_right hle (le_of_lt hz0))
  rw [pow_succ]
  linarith

/-- Five full finite character generating kernels are strictly positive.
The denominators correspond to conductors 3,4,5,8,8 respectively. -/
theorem THEOREM_3_9_FIVE_RATIONAL_CHARACTER_KERNELS_POSITIVE
    {z : ℝ} (hz0 : 0 < z) (hz1 : z < 1) :
    0 < z * (1-z) / (1-z^3) ∧
    0 < z * (1-z^2) / (1-z^4) ∧
    0 < z * (1-z)^2 * (1+z) / (1-z^5) ∧
    0 < z * (1-z^2) * (1-z^4) / (1-z^8) ∧
    0 < z * (1+z^2) * (1-z^4) / (1-z^8) := by
  rcases five_fekete_factors_positive hz0 hz1 with
    ⟨h3, h4, h5, h8, h8neg⟩
  have hd3 : 0 < 1 - z ^ 3 := by
    simpa using (subunit_denominator_pos hz0 hz1 2)
  have hd4 : 0 < 1 - z ^ 4 := by
    simpa using (subunit_denominator_pos hz0 hz1 3)
  have hd5 : 0 < 1 - z ^ 5 := by
    simpa using (subunit_denominator_pos hz0 hz1 4)
  have hd8 : 0 < 1 - z ^ 8 := by
    simpa using (subunit_denominator_pos hz0 hz1 7)
  exact ⟨div_pos h3 hd3, div_pos h4 hd4, div_pos h5 hd5,
    div_pos h8 hd8, div_pos h8neg hd8⟩

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_3_9_FIVE_RATIONAL_CHARACTER_KERNELS_POSITIVE
