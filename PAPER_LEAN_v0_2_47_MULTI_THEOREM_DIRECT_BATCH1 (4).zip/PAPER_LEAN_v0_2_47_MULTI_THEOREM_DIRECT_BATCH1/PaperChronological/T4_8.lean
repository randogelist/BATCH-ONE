import PaperChronological.T4_7

/-!
# Proposition 4.8: Rational root exclusion and cluster factor degree bounds

PDF p. 21. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Proposition 4.8 is still a formalization target. -/

end PaperChronological
