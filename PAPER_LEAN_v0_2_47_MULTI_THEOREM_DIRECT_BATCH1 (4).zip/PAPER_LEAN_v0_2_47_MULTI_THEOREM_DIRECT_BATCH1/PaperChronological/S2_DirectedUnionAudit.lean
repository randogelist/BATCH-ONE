import PaperChronological.S2_DirectedUnionEndpoint

/-!
# Native Lean 4.33 audit for the directed-union rational-moment construction

All declarations are intended to elaborate without `sorry`, `admit`, custom
axioms or a numerical/quantitative Witness. This file is executed by the
user's native Windows compiler, not by the archive generator.
-/

#check PaperChronological.Section2.paddedResidue
#check PaperChronological.Section2.extendMomentCutoffN_maxPole
#check PaperChronological.Section2.extendMomentCutoffN_oldResidue
#check PaperChronological.Section2.extendMomentCutoffN_newResidue
#check PaperChronological.Section2.extendMomentCutoffN_poleRes_eq_padded
#check PaperChronological.Section2.extendToCutoff_maxPole
#check PaperChronological.Section2.sameFinitePoleData
#check PaperChronological.Section2.finitePoleSetoid
#check PaperChronological.Section2.RationalMomentDomain
#check PaperChronological.Section2.muFunctionalPoly_wellDefined
#check PaperChronological.Section2.muOnRationalDomain
#check PaperChronological.Section2.muOnRationalDomain_mk
#check PaperChronological.Section2.quotient_zeroResidueExtension
#check PaperChronological.Section2.finiteRationalValue
#check PaperChronological.Section2.finiteRationalValue_wellDefined
#check PaperChronological.Section2.rationalValueOnDomain
#check PaperChronological.Section2.canonicalNumeratorAt
#check PaperChronological.Section2.canonicalNumeratorAt_injective
#check PaperChronological.Section2.sameFinitePoleData_iff_commonNumerator
#check PaperChronological.Section2.SECTION2_DIRECTED_UNION_ALGEBRAIC_CHAIN

#print axioms PaperChronological.Section2.extendMomentCutoffN_poleRes_eq_padded
#print axioms PaperChronological.Section2.muFunctionalPoly_wellDefined
#print axioms PaperChronological.Section2.quotient_zeroResidueExtension
#print axioms PaperChronological.Section2.finiteRationalValue_wellDefined
#print axioms PaperChronological.Section2.sameFinitePoleData_iff_commonNumerator
#print axioms PaperChronological.Section2.SECTION2_DIRECTED_UNION_ALGEBRAIC_CHAIN
