import PaperChronological.T2_4
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Theorem 2.5: Lagrange pole diagonalization

PDF p. 6. Audit status: PROVED.

This module links an actual mathematical theorem to previously
proved source declarations; no manuscript premise is silently postulated.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 2.5, exact Vandermonde factorization of X-derivative. -/
theorem THEOREM_2_5_VANDERMONDE
    (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p =
      ManuscriptChain.PoleDiagonalization.poleVandermonde p *
      Matrix.diagonal (ManuscriptChain.PoleDiagonalization.poleWeight p) *
      (ManuscriptChain.PoleDiagonalization.poleVandermonde p).transpose :=
  ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix_factorization p

/-- Theorem 2.5, nonsingular derivative matrix, for every parameter tuple. -/
theorem THEOREM_2_5_DERIVATIVE_NONSINGULAR
    (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.derivativeMatrix p).det ≠ 0 :=
  ManuscriptChain.PoleDiagonalization.derivativeMatrix_det_ne_zero p

/-- Exact degree h of the rational determinant. -/
theorem THEOREM_2_5_EXACT_DEGREE (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).natDegree = p.h :=
  ManuscriptChain.PoleDiagonalization.delta_natDegree p

end PaperChronological
