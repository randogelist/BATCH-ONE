import PaperChronological.Principal_T3_3_SpectralSplit
import MAIN_CHAIN_ASSEMBLED
import Mathlib.Tactic.Linarith

/-!
# Theorem 4.7(2) — direct unconditional bilateral root separation

The paper's quantitative exponent 11.411 is NOT assumed or claimed here.
We instead derive its exact algebraic predecessor from Theorem 3.1:
every pair of actual Hankel spectral roots lying on opposite sides of
zeta(s) has separation at least TWICE the existing exact zero-free radius.
This is proved for all odd weights and all admissible dimensions.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological.Principal

/-- The exact zero-free radius gives the bilateral root-gap inequality for
ACTUAL roots of the odd-zeta Hankel polynomial, in every admissible dimension. -/
theorem THEOREM_4_7_ACTUAL_STRADDLING_ROOT_SEPARATION
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    (i j : Fin p.h)
    (hleft :
      (ManuscriptChain.General.factorization p
        (ManuscriptChain.GRAM_POSITIVE p hp)).root i <
          ManuscriptChain.Real.zeta p.weight)
    (hright : ManuscriptChain.Real.zeta p.weight <
      (ManuscriptChain.General.factorization p
        (ManuscriptChain.GRAM_POSITIVE p hp)).root j) :
    2 * ManuscriptChain.General.zeroFreeRadius p hp
          (ManuscriptChain.GRAM_POSITIVE p hp) ≤
      (ManuscriptChain.General.factorization p
        (ManuscriptChain.GRAM_POSITIVE p hp)).root j -
      (ManuscriptChain.General.factorization p
        (ManuscriptChain.GRAM_POSITIVE p hp)).root i := by
  let g := ManuscriptChain.GRAM_POSITIVE p hp
  let c := ManuscriptChain.General.factorization p g
  have hdleft :
      ManuscriptChain.General.zeroFreeRadius p hp g ≤
        |c.root i - ManuscriptChain.Real.zeta p.weight| := by
    simpa only [ManuscriptChain.General.zeroFreeRadius,
      ManuscriptChain.Real.manuscriptPencil_center] using
      (c.root_distance_lower_bound
        (ManuscriptChain.General.spectralRadius p hp g)
        (ManuscriptChain.General.beta_abs_le p hp g) i)
  have hdright :
      ManuscriptChain.General.zeroFreeRadius p hp g ≤
        |c.root j - ManuscriptChain.Real.zeta p.weight| := by
    simpa only [ManuscriptChain.General.zeroFreeRadius,
      ManuscriptChain.Real.manuscriptPencil_center] using
      (c.root_distance_lower_bound
        (ManuscriptChain.General.spectralRadius p hp g)
        (ManuscriptChain.General.beta_abs_le p hp g) j)
  have hnegative :
      c.root i - ManuscriptChain.Real.zeta p.weight < 0 :=
    sub_neg.mpr hleft
  have hpositive :
      0 < c.root j - ManuscriptChain.Real.zeta p.weight :=
    sub_pos.mpr hright
  rw [abs_of_neg hnegative] at hdleft
  rw [abs_of_pos hpositive] at hdright
  linarith

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_4_7_ACTUAL_STRADDLING_ROOT_SEPARATION
