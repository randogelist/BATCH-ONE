import PaperChronological.S2_CutoffNormalization

/-!
# Section 2: a well-defined rational moment on the directed union

The moment functional of Definition 2.1 is initially implemented on finite
presentations `(Q, J, c)`.  Different bounds J can describe the same finite
rational function.  We prove the moment is independent of this choice, form
an explicit equivalence relation, and construct a SINGLE quotient-domain
functional using `Quotient.liftOn` with the proved compatibility theorem.

This is more than equality of two functions on fixed coefficient arrays:
the finite cutoff itself is quotiented out.  Nothing about zeta irrationality
or the quantitative Witness is used here.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- Canonical equality of the actual polynomial part and every pole residue,
with unused poles padded by zero on both sides. -/
def sameFinitePoleData (R S : Zetahyperbolic.RatMomentElem) : Prop :=
  R.polyPart = S.polyPart ∧ ∀ j : ℕ, 1 ≤ j →
    paddedResidue R j = paddedResidue S j

/-- The data equality above is an equivalence relation. -/
theorem sameFinitePoleData_refl (R : Zetahyperbolic.RatMomentElem) :
    sameFinitePoleData R R := by
  exact ⟨rfl, fun _ _ => rfl⟩

theorem sameFinitePoleData_symm (R S : Zetahyperbolic.RatMomentElem)
    (h : sameFinitePoleData R S) : sameFinitePoleData S R := by
  exact ⟨h.1.symm, fun j hj => (h.2 j hj).symm⟩

theorem sameFinitePoleData_trans (R S T : Zetahyperbolic.RatMomentElem)
    (h₁ : sameFinitePoleData R S) (h₂ : sameFinitePoleData S T) :
    sameFinitePoleData R T := by
  exact ⟨h₁.1.trans h₂.1, fun j hj =>
    (h₁.2 j hj).trans (h₂.2 j hj)⟩

/-- The explicit setoid of finitely supported simple-pole presentations. -/
def finitePoleSetoid : Setoid Zetahyperbolic.RatMomentElem where
  r := sameFinitePoleData
  iseqv := {
    refl := by
      intro R
      exact sameFinitePoleData_refl R
    symm := by
      intro R S hRS
      exact sameFinitePoleData_symm R S hRS
    trans := by
      intro R S T hRS hST
      exact sameFinitePoleData_trans R S T hRS hST
  }

/-- The directed union of finite negative-square pole presentations. -/
abbrev RationalMomentDomain : Type := Quotient finitePoleSetoid

/-- Equality of the moment functional for two presentations with the same
cutoff, polynomial part and every active residue. -/
theorem muFunctionalPoly_congr_sameCutoff (k : ℕ)
    (R S : Zetahyperbolic.RatMomentElem)
    (hpoly : R.polyPart = S.polyPart)
    (hmax : R.maxPole = S.maxPole)
    (hres : ∀ j : ℕ, 1 ≤ j → j ≤ S.maxPole →
      R.poleRes j = S.poleRes j) :
    Zetahyperbolic.muFunctionalPoly k R =
      Zetahyperbolic.muFunctionalPoly k S := by
  unfold Zetahyperbolic.muFunctionalPoly
  apply congrArg₂ (fun A B : ℚ[X] => A + B)
  · rw [hpoly]
  · rw [hmax]
    apply Finset.sum_congr rfl
    intro j hj
    rw [hres j (Finset.mem_Icc.mp hj).1
      (Finset.mem_Icc.mp hj).2]

/-- Definition 2.1 is well-defined independently of the arbitrary finite
pole cutoff. This theorem is the essential directed-union compatibility. -/
theorem muFunctionalPoly_wellDefined (k : ℕ)
    (R S : Zetahyperbolic.RatMomentElem)
    (h : sameFinitePoleData R S) :
    Zetahyperbolic.muFunctionalPoly k R =
      Zetahyperbolic.muFunctionalPoly k S := by
  let J := max R.maxPole S.maxPole
  let R' := extendToCutoff R J
  let S' := extendToCutoff S J
  have hRJ : R.maxPole ≤ J := Nat.le_max_left _ _
  have hSJ : S.maxPole ≤ J := Nat.le_max_right _ _
  have hRmax : R'.maxPole = J := extendToCutoff_maxPole R J hRJ
  have hSmax : S'.maxPole = J := extendToCutoff_maxPole S J hSJ
  have hpoly : R'.polyPart = S'.polyPart := by
    change (extendMomentCutoffN R (J - R.maxPole)).polyPart =
      (extendMomentCutoffN S (J - S.maxPole)).polyPart
    rw [extendMomentCutoffN_polyPart, extendMomentCutoffN_polyPart]
    exact h.1
  have hmax : R'.maxPole = S'.maxPole := hRmax.trans hSmax.symm
  have hres : ∀ j : ℕ, 1 ≤ j → j ≤ S'.maxPole →
      R'.poleRes j = S'.poleRes j := by
    intro j hjpos hj
    have hjJ : j ≤ J := by simpa only [hSmax] using hj
    have hjR : j ≤ R.maxPole + (J - R.maxPole) := by omega
    have hjS : j ≤ S.maxPole + (J - S.maxPole) := by omega
    have hr : R'.poleRes j = paddedResidue R j :=
      extendMomentCutoffN_poleRes_eq_padded R (J - R.maxPole) j hjR
    have hs : S'.poleRes j = paddedResidue S j :=
      extendMomentCutoffN_poleRes_eq_padded S (J - S.maxPole) j hjS
    exact hr.trans ((h.2 j hjpos).trans hs.symm)
  calc
    Zetahyperbolic.muFunctionalPoly k R =
        Zetahyperbolic.muFunctionalPoly k R' :=
          (muFunctionalPoly_extendToCutoff k J R).symm
    _ = Zetahyperbolic.muFunctionalPoly k S' :=
          muFunctionalPoly_congr_sameCutoff k R' S' hpoly hmax hres
    _ = Zetahyperbolic.muFunctionalPoly k S :=
          muFunctionalPoly_extendToCutoff k J S

/-- The global moment functional: its input is a rational presentation
modulo arbitrary changes of finite cutoff. The proof that this construction
is well-defined is supplied to the quotient eliminator, not postulated. -/
noncomputable def muOnRationalDomain (k : ℕ) :
    RationalMomentDomain → ℚ[X] :=
  fun R => Quotient.liftOn R (Zetahyperbolic.muFunctionalPoly k)
    (fun a b hab => muFunctionalPoly_wellDefined k a b hab)

/-- The quotient-level functional agrees on the nose with the original
finite-presentation formula. -/
@[simp] theorem muOnRationalDomain_mk (k : ℕ)
    (R : Zetahyperbolic.RatMomentElem) :
    muOnRationalDomain k (Quotient.mk finitePoleSetoid R) =
      Zetahyperbolic.muFunctionalPoly k R := rfl

/-- Changing the cutoff by finitely many zero-residue poles does not change
the rational presentation's equivalence class. -/
theorem zeroResidueExtension_sameFiniteData
    (R : Zetahyperbolic.RatMomentElem) (n : ℕ) :
    sameFinitePoleData (extendMomentCutoffN R n) R := by
  constructor
  · exact extendMomentCutoffN_polyPart R n
  · intro j hjpos
    by_cases hj : j ≤ R.maxPole + n
    · have hcore := extendMomentCutoffN_poleRes_eq_padded R n j hj
      simpa only [paddedResidue, extendMomentCutoffN_maxPole, if_pos hj]
        using hcore
    · have hjold : ¬ j ≤ R.maxPole := by omega
      simp [paddedResidue, extendMomentCutoffN_maxPole, hj, hjold]

/-- Every zero-residue extension represents exactly the same point of the
global quotient rational-moment domain. -/
theorem quotient_zeroResidueExtension
    (R : Zetahyperbolic.RatMomentElem) (n : ℕ) :
    (Quotient.mk finitePoleSetoid (extendMomentCutoffN R n) :
        RationalMomentDomain) = Quotient.mk finitePoleSetoid R := by
  apply Quotient.sound
  exact zeroResidueExtension_sameFiniteData R n

end PaperChronological.Section2
