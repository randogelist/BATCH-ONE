import PaperChronological.S2_TruncatedMomentLinearity

/-! Native Windows Lean 4.33.0 audit: fixed-level moment linearity and
its exact bridge to the original variable-degree Definition 2.1. -/

#check PaperChronological.Section2.truncatedMonomialMoment
#check PaperChronological.Section2.truncatedPoleMoment
#check PaperChronological.Section2.truncatedMoment
#check PaperChronological.Section2.truncatedMonomialMoment_add
#check PaperChronological.Section2.truncatedMonomialMoment_scale
#check PaperChronological.Section2.truncatedPoleMoment_add
#check PaperChronological.Section2.truncatedPoleMoment_scale
#check PaperChronological.Section2.truncatedMoment_add
#check PaperChronological.Section2.truncatedMoment_scale
#check PaperChronological.Section2.truncatedMoment_matches_muFunctionalPoly
#check PaperChronological.Section2.truncatedMoment_matches_global

#print axioms PaperChronological.Section2.truncatedMoment_add
#print axioms PaperChronological.Section2.truncatedMoment_scale
#print axioms PaperChronological.Section2.truncatedMoment_matches_global
