import PaperChronological.T6_16
import Zeta5Merge.Theorem6_17

/-!
# Theorem 6.17: Two-variable Zeta-Beta Krein and q-adic

PDF p. 48. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 6.17's corrected beta-harmonic index window, for all odd q>=3.
No global determinant valuation is inferred from this finite combinatorial fact. -/
theorem THEOREM_6_17_BETA_WINDOW
    {q rho : ℕ} (hq : 3 ≤ q) (hodd : q % 2 = 1)
    (hrho : rho < Zeta5Merge.Theorem6_17.height q) :
    ∃! nu : ℕ,
      nu < 2 * (rho + Zeta5Merge.Theorem6_17.shift q) ∧
      q ∣ 2 * nu + 1 :=
  Zeta5Merge.Theorem6_17.high_unique_multiple hq hodd hrho

end PaperChronological
