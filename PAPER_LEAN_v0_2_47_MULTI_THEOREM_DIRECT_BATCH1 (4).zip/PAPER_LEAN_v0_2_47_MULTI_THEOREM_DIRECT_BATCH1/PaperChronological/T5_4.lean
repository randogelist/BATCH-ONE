import PaperChronological.T5_3

/-!
# Theorem 5.4: Cancellation of higher zeta values on even pole pairs

PDF p. 25. Audit status: PROVED.

This module links an actual mathematical theorem to previously
proved source declarations; no manuscript premise is silently postulated.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 5.4: exact cancellation of X and higher odd-zeta values on
opposite simple poles, for all k>=1 and all j>=1. -/
theorem THEOREM_5_4_EVEN_POLE_PAIR (k j : ℕ) (hj : 1 ≤ j) :
    Zetahyperbolic.tauPolePoly k (j : ℤ) -
      Zetahyperbolic.tauPolePoly k (-(j : ℤ)) =
        Polynomial.C (((j : ℚ) ^ (2 * k + 1))⁻¹) := by
  have hdpos : Zetahyperbolic.dIndex (j : ℤ) = j := by
    simp [Zetahyperbolic.dIndex]
  have hdneg : Zetahyperbolic.dIndex (-(j : ℤ)) = j - 1 := by
    unfold Zetahyperbolic.dIndex
    have hn : ¬ (0 : ℤ) ≤ -(j : ℤ) := by omega
    rw [if_neg hn]
    have heq : -(-(j : ℤ)) - 1 = ((j - 1 : ℕ) : ℤ) := by omega
    rw [heq]
    simp
  have hsucc : j - 1 + 1 = j := by omega
  have hrec := Zetahyperbolic.harmonicWeight_succ (2 * k + 1) (j - 1)
  rw [hsucc] at hrec
  simp only [Zetahyperbolic.tauPolePoly, hdpos, hdneg]
  rw [hrec, Polynomial.C_add]
  ring

end PaperChronological
