import PaperChronological.T2_3_Span
import PaperChronological.T2_5
import Zetahyperbolic.LagrangeBasis

/-!
# Section 2: canonical finite rational presentations

We work with the actual tail denominator and the actual Lagrange polynomials
at the negative square poles. The coefficient of each Lagrange polynomial is
*recovered* by evaluating the cleared numerator at the corresponding pole.
Consequently the polynomial quotient and all normalized simple-pole data are
unique. This supplies the missing well-definedness/uniqueness argument for the
finite partial-fraction presentation underlying Definition 2.1 and Lemma 2.2.

This is finite algebra only. No analytic convergence or external witness is used.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

open ManuscriptChain.PoleDiagonalization

/-- The manuscript Lagrange polynomial, with pole `-a²` indexed by `Fin h`. -/
def L (p : ManuscriptChain.Real.Parameters) (a : Fin p.h) : ℚ[X] :=
  Zetahyperbolic.lagrangePolePolynomial p.N p.K (poleIndex p a)

private theorem poleIndex_injective (p : ManuscriptChain.Real.Parameters) :
    Function.Injective (poleIndex p) := by
  intro a b hab
  apply poleNode_injective p
  simp only [poleNode, hab]

/-- Interpolation identity `L_a(-b²) = δ_ab`, with indices in `Fin (K-N)`. -/
theorem L_eval (p : ManuscriptChain.Real.Parameters) (a b : Fin p.h) :
    (L p a).eval (poleNode p b) = if a = b then 1 else 0 := by
  have h := Zetahyperbolic.lagrangePolePolynomial_eval p.N p.K
    (poleIndex p a) (poleIndex p b) (poleIndex_mem p a) (poleIndex_mem p b)
  have hiff : poleIndex p a = poleIndex p b ↔ a = b := by
    constructor
    · intro hab
      exact (poleIndex_injective p) hab
    · intro hab
      rw [hab]
  simpa only [L, poleNode, hiff] using h

/-- Every tail factor vanishes at its corresponding negative square pole. -/
theorem tailD_eval_node (p : ManuscriptChain.Real.Parameters) (a : Fin p.h) :
    (ManuscriptChain.Real.tailD p).eval (poleNode p a) = 0 := by
  rw [ManuscriptChain.Real.tailD, Polynomial.eval_prod]
  apply Finset.prod_eq_zero (poleIndex_mem p a)
  simp [poleNode]

/-- The tail denominator is a nonzero polynomial. This also covers `h = 0`. -/
theorem tailD_ne_zero (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.Real.tailD p ≠ 0 := by
  have hp : (0 : ℚ) < (ManuscriptChain.Real.tailD p).eval 0 := by
    simp only [ManuscriptChain.Real.tailD, Polynomial.eval_prod,
      Polynomial.eval_add, Polynomial.eval_X, Polynomial.eval_C, zero_add]
    apply Finset.prod_pos
    intro a ha
    have ha0 : 0 < a := by
      have hb := (Finset.mem_Icc.mp ha).1
      omega
    have haq : (0 : ℚ) < a := by exact_mod_cast ha0
    positivity
  intro hz
  rw [hz] at hp
  norm_num at hp

/-- A polynomial quotient plus a finite Lagrange-coefficient family,
cleared to the common denominator `D_tail`. -/
def normalizedNumerator (p : ManuscriptChain.Real.Parameters)
    (Q : ℚ[X]) (r : Fin p.h → ℚ) : ℚ[X] :=
  Q * ManuscriptChain.Real.tailD p +
    ∑ a : Fin p.h, C (r a) * L p a

/-- The normalized coefficient at a pole is precisely the evaluation of
its cleared numerator at that pole. This is not true by definition: it uses
the genuine distinct-pole Lagrange interpolation theorem. -/
theorem normalizedNumerator_eval_node (p : ManuscriptChain.Real.Parameters)
    (Q : ℚ[X]) (r : Fin p.h → ℚ) (a : Fin p.h) :
    (normalizedNumerator p Q r).eval (poleNode p a) = r a := by
  unfold normalizedNumerator
  rw [Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_finsetSum]
  rw [tailD_eval_node p a]
  simp only [mul_zero, zero_add]
  calc
    (∑ b : Fin p.h, (C (r b) * L p b).eval (poleNode p a)) =
        ∑ b : Fin p.h, if b = a then r b else 0 := by
          apply Finset.sum_congr rfl
          intro b hb
          rw [Polynomial.eval_mul, Polynomial.eval_C, L_eval]
          by_cases hba : b = a
          · simp [hba]
          · simp [hba]
    _ = r a := by simp

/-- No two distinct polynomial-plus-finite-pole presentations have the same
cleared numerator: both the residues and polynomial quotient are unique. -/
theorem normalizedPresentation_unique
    (p : ManuscriptChain.Real.Parameters) (Q₁ Q₂ : ℚ[X])
    (r₁ r₂ : Fin p.h → ℚ)
    (h : normalizedNumerator p Q₁ r₁ = normalizedNumerator p Q₂ r₂) :
    Q₁ = Q₂ ∧ r₁ = r₂ := by
  have hr : r₁ = r₂ := by
    funext a
    have he := congrArg (fun f : ℚ[X] => f.eval (poleNode p a)) h
    rw [normalizedNumerator_eval_node, normalizedNumerator_eval_node] at he
    exact he
  have hm : Q₁ * ManuscriptChain.Real.tailD p =
      Q₂ * ManuscriptChain.Real.tailD p := by
    have hh := h
    rw [hr] at hh
    unfold normalizedNumerator at hh
    exact add_right_cancel hh
  have hd : (Q₁ - Q₂) * ManuscriptChain.Real.tailD p = 0 := by
    rw [sub_mul, sub_eq_zero.mpr hm]
  have hQ : Q₁ = Q₂ := by
    rcases mul_eq_zero.mp hd with hz | hz
    · exact sub_eq_zero.mp hz
    · exact (tailD_ne_zero p hz).elim
  exact ⟨hQ, hr⟩

/-- The rational presentation map is additive in its independent polynomial
and pole data. This algebraic fact underlies the Q-linear functional domain. -/
theorem normalizedNumerator_add (p : ManuscriptChain.Real.Parameters)
    (Q₁ Q₂ : ℚ[X]) (r₁ r₂ : Fin p.h → ℚ) :
    normalizedNumerator p (Q₁ + Q₂) (r₁ + r₂) =
      normalizedNumerator p Q₁ r₁ + normalizedNumerator p Q₂ r₂ := by
  unfold normalizedNumerator
  simp only [Pi.add_apply, map_add, add_mul, Finset.sum_add_distrib]
  ring

end PaperChronological.Section2
