import PaperChronological.S2_StableMomentDomain

/-!
# Manuscript (2.8): the *actual* rational moment functional equals the pencil

This module is the missing bridge between (2.2)-(2.3), rational residues,
and the entries of the original Hankel matrix. It proves the complete
finite polynomial identity (not merely its X coefficient):

  mu_X(Q + sum_a c_a/(t+a^2))
    = polynomialMoment(Q) + sum_a c_a poleConstant(a)
      + X sum_a c_a a^(2k).

Specializing to the quotient and residue *formulas used in the project's
pencil definition* identifies precisely that pencil. A further quotient-
remainder theorem is needed to show that the specified polynomial quotient
and residue coefficients jointly reconstruct the original kernel numerator.
This module does not assume that missing reconstruction as a hypothesis.
It uses neither an analytic integral representation nor a Witness.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

open ManuscriptChain.PoleDiagonalization

/-- The moment functional is an affine polynomial in X, with exact intercept
and exact slope computed from the finite residue data. -/
theorem finiteMomentPolynomial_affine
    (p : ManuscriptChain.Real.Parameters) (k : ℕ)
    (Q : ℚ[X]) (c : Fin p.h → ℚ) :
    finiteMomentPolynomial p k Q c =
      C (ManuscriptChain.Real.polynomialMoment k Q +
        ∑ a : Fin p.h,
          c a * ManuscriptChain.Real.poleConstant k (poleIndex p a)) +
      C (∑ a : Fin p.h, c a * (poleIndex p a : ℚ) ^ (2 * k)) * X := by
  unfold finiteMomentPolynomial
  have hatom : ∀ a : Fin p.h,
      C (c a) * Zetahyperbolic.muPolePoly k (poleIndex p a) =
        C (c a * ManuscriptChain.Real.poleConstant k (poleIndex p a)) +
          C (c a * (poleIndex p a : ℚ) ^ (2 * k)) * X := by
    intro a
    rw [simple_pole_moment_affine]
    simp only [map_mul, mul_add, mul_assoc]
  have hconst :
      (∑ a : Fin p.h,
        C (c a * ManuscriptChain.Real.poleConstant k (poleIndex p a))) =
      C (∑ a : Fin p.h,
        c a * ManuscriptChain.Real.poleConstant k (poleIndex p a)) := by
    simp only [map_sum]
  have hcoeff :
      (∑ a : Fin p.h,
        C (c a * (poleIndex p a : ℚ) ^ (2 * k))) =
      C (∑ a : Fin p.h,
        c a * (poleIndex p a : ℚ) ^ (2 * k)) := by
    simp only [map_sum]
  have hweighted :
      (∑ a : Fin p.h,
        C (c a * (poleIndex p a : ℚ) ^ (2 * k)) * X) =
      C (∑ a : Fin p.h,
        c a * (poleIndex p a : ℚ) ^ (2 * k)) * X := by
    rw [← Finset.sum_mul, hcoeff]
  calc
    C (ManuscriptChain.Real.polynomialMoment k Q) +
        (∑ a : Fin p.h,
          C (c a) * Zetahyperbolic.muPolePoly k (poleIndex p a)) =
      C (ManuscriptChain.Real.polynomialMoment k Q) +
        (∑ a : Fin p.h,
          (C (c a * ManuscriptChain.Real.poleConstant k (poleIndex p a)) +
           C (c a * (poleIndex p a : ℚ) ^ (2 * k)) * X)) := by
      congr 1
      apply Finset.sum_congr rfl
      intro a ha
      exact hatom a
    _ = C (ManuscriptChain.Real.polynomialMoment k Q) +
        ((∑ a : Fin p.h,
           C (c a * ManuscriptChain.Real.poleConstant k (poleIndex p a))) +
         (∑ a : Fin p.h,
           C (c a * (poleIndex p a : ℚ) ^ (2 * k)) * X)) := by
      rw [Finset.sum_add_distrib]
    _ = C (ManuscriptChain.Real.polynomialMoment k Q) +
        (C (∑ a : Fin p.h,
           c a * ManuscriptChain.Real.poleConstant k (poleIndex p a)) +
         C (∑ a : Fin p.h,
           c a * (poleIndex p a : ℚ) ^ (2 * k)) * X) := by
      rw [hconst, hweighted]
    _ = C (ManuscriptChain.Real.polynomialMoment k Q +
          ∑ a : Fin p.h,
            c a * ManuscriptChain.Real.poleConstant k (poleIndex p a)) +
        C (∑ a : Fin p.h,
          c a * (poleIndex p a : ℚ) ^ (2 * k)) * X := by
      rw [map_add]
      ring

/-- Equation (2.8) without any analytic or arithmetic hypothesis: the
finite moment functional evaluated at the specific polynomial quotient
and residue formulas used by the source is *exactly* the source Hankel
pencil entry. Kernel partial-fraction reconstruction is separate. -/
theorem exact_hankel_moment_pencil
    (p : ManuscriptChain.Real.Parameters) (i j : Fin p.h) :
    finiteMomentPolynomial p p.k
      (ManuscriptChain.Real.quotient p i.val j.val)
      (fun a : Fin p.h =>
        ManuscriptChain.Real.residue p i.val j.val (poleIndex p a)) =
    ManuscriptChain.Real.pencil p i j := by
  rw [finiteMomentPolynomial_affine]
  have hA :
      ManuscriptChain.Real.polynomialMoment p.k
          (ManuscriptChain.Real.quotient p i.val j.val) +
        (∑ a : Fin p.h,
          ManuscriptChain.Real.residue p i.val j.val (poleIndex p a) *
            ManuscriptChain.Real.poleConstant p.k (poleIndex p a)) =
          ManuscriptChain.Real.entryA p i.val j.val := by
    rw [ManuscriptChain.Real.entryA,
      ManuscriptChain.PoleDiagonalization.sum_tail_eq_fin]
  have hM :
      (∑ a : Fin p.h,
        ManuscriptChain.Real.residue p i.val j.val (poleIndex p a) *
          (poleIndex p a : ℚ) ^ (2 * p.k)) =
          ManuscriptChain.Real.entryM p i.val j.val := by
    rw [ManuscriptChain.Real.entryM,
      ManuscriptChain.PoleDiagonalization.sum_tail_eq_fin]
  rw [hA, hM]
  rfl

end PaperChronological.Section2
