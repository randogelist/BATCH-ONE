import PaperChronological.T4_3
import PaperNative.SECTION_04

/-!
# Theorem 4.4: Sharpened spectral bound and effective measure for zeta 5

PDF p. 16. Audit status: SINGLE_WITNESS.

Only the isolated downstream quantitative zeta(5) application
depends on the ONE existing PaperNative.Witness interface.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 4.4 is a downstream application, not the organizing spine.
Its only open argument is the NON-TAUTOLOGICAL quantitative `Witness` from
the preceding source; no proof of the witness is claimed here. -/
theorem THEOREM_4_4_APPLICATION_FROM_WITNESS
    (w : PaperNative.Witness) :
    Irrational (riemannZeta 5).re :=
  PaperNative.THEOREM_4_4_IRRATIONAL_ZETA5 w

end PaperChronological
