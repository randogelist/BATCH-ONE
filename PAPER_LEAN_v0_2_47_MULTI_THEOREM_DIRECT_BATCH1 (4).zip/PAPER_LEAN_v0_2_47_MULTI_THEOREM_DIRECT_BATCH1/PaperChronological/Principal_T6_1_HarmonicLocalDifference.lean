import PaperChronological.T6_1
import Mathlib.Tactic.Ring

/-!
# Theorem 6.1 — finite rational divided-difference identities

The weight-six harmonic moment is a rational partial sum. We derive its
exact nearest-neighbor finite difference and the consequent divided-
difference identity used in the local p-adic obstruction. The remaining
valuation theorem is NOT asserted without an actual p-adic proof.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronological.Principal

/-- Exact increment at arbitrary weight. -/
theorem GENERAL_HARMONIC_SUCCESSOR (s n : ℕ) :
    ManuscriptChain.Real.harmonic s (n + 1) =
      ManuscriptChain.Real.harmonic s n +
        1 / (((n + 1 : ℕ) : ℚ) ^ s) := by
  simp only [ManuscriptChain.Real.harmonic, Finset.sum_range_succ]

/-- The 6th-harmonic divided difference for adjacent indices is exactly
one positive rational pole term; this is the local source of denominators. -/
theorem THEOREM_6_1_ADJACENT_DIVIDED_DIFFERENCE (n : ℕ) :
    (ManuscriptChain.Real.harmonic 6 (n + 1) -
       ManuscriptChain.Real.harmonic 6 n) / (6 : ℚ) =
      1 / (6 * (((n + 1 : ℕ) : ℚ) ^ 6)) := by
  rw [GENERAL_HARMONIC_SUCCESSOR]
  have hn : ((((n + 1 : ℕ) : ℚ) ^ 6)) ≠ 0 := by positivity
  field_simp [hn]
  ring

end PaperChronological.Principal

#print axioms PaperChronological.Principal.GENERAL_HARMONIC_SUCCESSOR
#print axioms PaperChronological.Principal.THEOREM_6_1_ADJACENT_DIVIDED_DIFFERENCE
