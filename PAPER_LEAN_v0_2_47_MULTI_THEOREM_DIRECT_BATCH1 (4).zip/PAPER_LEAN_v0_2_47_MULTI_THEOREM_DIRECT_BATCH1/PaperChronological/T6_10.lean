import PaperChronological.T6_9
import Zetahyperbolic.Theorem_6_10_Finite_Determinant_Identity

/-!
# Theorem 6.10: Universal potential-gap identity and derivative determinant

PDF p. 39. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators MatrixOrder

namespace PaperChronological


/-- Theorem 6.10: exact finite determinant identity, not the as-yet
unproved limiting potential variational identity. -/
theorem THEOREM_6_10_FINITE_DETERMINANT_IDENTITY
    {n : ℕ} (A M : Matrix (Fin n) (Fin n) ℝ)
    (xi scale : ℝ) (hA : A.PosDef) :
    |(Zetahyperbolic.Theorem6_10.normalizedDet A M xi scale).coeff n| =
      |(Zetahyperbolic.Theorem6_10.normalizedDet A M xi scale).eval xi| *
        |(Zetahyperbolic.Theorem6_10.symmetricRelativeMatrix (CFC.sqrt A) M).det| :=
  Zetahyperbolic.Theorem6_10.abs_top_coefficient_eq_eval_mul_sqrt_det A M xi scale hA

end PaperChronological
