import PaperChronological.T4_2

/-!
# Proposition 4.3: Ultrametric zero-free disk over Qp

PDF p. 15. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Proposition 4.3 is still a formalization target. -/

end PaperChronological
