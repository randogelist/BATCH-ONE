import PaperChronological.S2_GlobalCanonicalNormalizer

/-!
# Section 2: single unconditional directed-union endpoint

This file asserts a genuinely verified-if-it-compiles collection of
independent claims, not an invented theorem declaring the manuscript done.
The previous finite-level chain plus the global directed-union quotient show:

* every finite initial pole segment has canonical numerator/normal form;
* every finite cutoff enlargement is harmless;
* arbitrary representatives with the same polynomial part and finitely
  supported actual residues have identical order-s moment polynomials;
* their literal rational-function evaluations agree for every rational t;
* both operations descend to the same quotient of finite presentations.

Sections 3--6 and the paper's quantitative `Witness` are deliberately absent.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

structure DirectedUnionAlgebraicChain : Prop where
  globalNumeratorCertificate : ∀ k : ℕ,
    ∀ R S : Zetahyperbolic.RatMomentElem,
      sameFinitePoleData R S ↔
        canonicalNumeratorAt k (max R.maxPole S.maxPole) R =
          canonicalNumeratorAt k (max R.maxPole S.maxPole) S
  finiteNormalForms : ∀ k J : ℕ, UniversalFiniteChain k J
  arbitraryCutoffMoment : ∀ (k : ℕ)
    (R S : Zetahyperbolic.RatMomentElem),
      sameFinitePoleData R S →
      Zetahyperbolic.muFunctionalPoly k R =
        Zetahyperbolic.muFunctionalPoly k S
  arbitraryCutoffEvaluation : ∀ (t : ℚ)
    (R S : Zetahyperbolic.RatMomentElem),
      sameFinitePoleData R S →
      finiteRationalValue R t = finiteRationalValue S t
  zeroExtensionClass : ∀ (R : Zetahyperbolic.RatMomentElem)
    (n : ℕ),
      (Quotient.mk finitePoleSetoid (extendMomentCutoffN R n) :
        RationalMomentDomain) = Quotient.mk finitePoleSetoid R

/-- Unconditional Section 2 foundation on the directed union of *all*
finite simple negative-square pole presentations. -/
theorem SECTION2_DIRECTED_UNION_ALGEBRAIC_CHAIN :
    DirectedUnionAlgebraicChain := by
  exact {
    globalNumeratorCertificate := sameFinitePoleData_iff_commonNumerator
    finiteNormalForms := SECTION2_ALL_FINITE_POLE_CHAIN
    arbitraryCutoffMoment := fun k R S h =>
      muFunctionalPoly_wellDefined k R S h
    arbitraryCutoffEvaluation := fun t R S h =>
      finiteRationalValue_wellDefined R S t h
    zeroExtensionClass := quotient_zeroResidueExtension
  }

end PaperChronological.Section2
