import PaperChronological.S2_GlobalModuleLaws

/-!
# Section 2 — actual additive group and rational vector-space instances

This module upgrades the independently proved quotient-coordinate identities
into typeclass structure. It is isolated so a new instance-construction error
cannot invalidate the existing frozen Lemmas 2.2--2.3 or Theorems 2.4--2.5.
-/

noncomputable section
open Polynomial

namespace PaperChronological.Section2

/-! The recursion functions `nsmulRec` and `zsmulRec` require pre-existing
  `Zero`, `Add` and `Neg` instances during elaboration of `AddCommGroup`.
  They are the operations already proved on the rational-function quotient,
  NOT new axioms or a competing mathematical definition. -/

/-- Native zero is exactly the empty polynomial-and-residue presentation. -/
noncomputable instance rationalMomentDomainZero : Zero RationalMomentDomain :=
  ⟨rationalZero⟩

/-- Native addition is the existing congruence-proved quotient operation. -/
noncomputable instance rationalMomentDomainAdd : Add RationalMomentDomain :=
  ⟨rationalAdd⟩

/-- Native negation acts on both polynomial and residue coordinates. -/
noncomputable instance rationalMomentDomainNeg : Neg RationalMomentDomain :=
  ⟨rationalNeg⟩

/-- Native subtraction is by addition of the quotient's inverse. -/
noncomputable instance rationalMomentDomainSub : Sub RationalMomentDomain :=
  ⟨fun R S => rationalAdd R (rationalNeg S)⟩

/-- Additive abelian group of finite simple-pole rational functions. -/
noncomputable instance rationalMomentDomainAddCommGroup :
    AddCommGroup RationalMomentDomain where
  add := rationalAdd
  add_assoc := rationalAdd_assoc
  zero := rationalZero
  zero_add := rationalZero_add
  add_zero := rationalAdd_zero
  neg := rationalNeg
  neg_add_cancel := rationalAdd_left_neg
  nsmul := nsmulRec
  zsmul := zsmulRec
  add_comm := rationalAdd_comm

/-- A genuine Q-vector-space, proved from the global polynomial and residue
coordinates, rather than a separately postulated module instance. -/
noncomputable instance rationalMomentDomainModule :
    Module ℚ RationalMomentDomain where
  smul := rationalScale
  one_smul := rationalScale_one
  mul_smul := rationalScale_mul
  smul_add := rationalScale_add
  smul_zero := rationalScale_zeroArgument
  add_smul := rationalScale_addScalars
  zero_smul := rationalScale_zeroScalar

/-- The structure's addition equals the previously constructed quotient addition. -/
theorem rationalModule_add_eq (R S : RationalMomentDomain) :
    R + S = rationalAdd R S := rfl

/-- The structure's scalar action equals the previously constructed quotient scaling. -/
theorem rationalModule_smul_eq (q : ℚ) (R : RationalMomentDomain) :
    q • R = rationalScale q R := rfl

/-- The quotient's polynomial coordinate map is additive in the native
Q-vector-space structure. -/
theorem polynomialPartOnDomain_add (R S : RationalMomentDomain) :
    polynomialPartOnDomain (R + S) =
      polynomialPartOnDomain R + polynomialPartOnDomain S := by
  exact polynomialPartOnDomain_rationalAdd R S

/-- Native vector-space scalar compatibility of the polynomial coordinate. -/
theorem polynomialPartOnDomain_smul (q : ℚ) (R : RationalMomentDomain) :
    polynomialPartOnDomain (q • R) = C q * polynomialPartOnDomain R := by
  exact polynomialPartOnDomain_rationalScale q R

end PaperChronological.Section2
