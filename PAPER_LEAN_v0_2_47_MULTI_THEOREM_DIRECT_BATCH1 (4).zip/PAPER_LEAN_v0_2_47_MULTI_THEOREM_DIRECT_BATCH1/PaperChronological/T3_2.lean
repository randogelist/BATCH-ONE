import PaperChronological.T3_1
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk

/-!
# Proposition 3.2: Continuous hyperbolic pencil for all real s > 1

PDF p. 8. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Proposition 3.2, its finite spectral argument valid for any center,
including continuous parameter families. The PAPER'S specific Γ-weight
integration and identification for each real s>1 are still open. -/
theorem PROP_3_2_ABSTRACT_REAL_PENCIL
    {n : ℕ} (p : ManuscriptChain.Spectral.SymmetricAffinePencil n)
    (hG : p.base.PosDef) (hM : p.direction.det ≠ 0) :
    p.detPolynomial.natDegree = n ∧
      ∀ z : ℂ, Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial = 0 →
        z.im = 0 := by
  exact ⟨ManuscriptChain.Spectral.theorem_3_1_degree_of_posDef p hG hM,
    fun z hz => ManuscriptChain.Spectral.theorem_3_1_hyperbolicity_of_posDef p hG hM z hz⟩

end PaperChronological
