import PaperChronological.T3_3

/-!
# Theorem 3.4: Root interlacing and Dodgson condensation

PDF p. 9. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 3.4, the exact symmetric 3-by-3 Jacobi-Dodgson algebraic
identity. The PDF's full sequence of interlacing spectral assertions is
NOT discharged by this finite identity. -/
theorem THEOREM_3_4_DODGSON_THREE_BY_THREE
    (a b c d e f : ℝ) :
    (a * d * f + 2 * b * c * e - a * e ^ 2 - d * c ^ 2 - f * b ^ 2) * a =
      (a * d - b ^ 2) * (a * f - c ^ 2) - (a * e - b * c) ^ 2 := by
  ring

end PaperChronological
