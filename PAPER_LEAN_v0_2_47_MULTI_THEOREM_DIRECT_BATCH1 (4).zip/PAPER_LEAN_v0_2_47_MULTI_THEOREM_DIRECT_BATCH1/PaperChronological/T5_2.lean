import PaperChronological.T5_1
import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil

/-!
# Theorem 5.2: Dual hyperbolicity and Krein-space decomposition

PDF p. 23. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 5.2: exact finite tail/certificate implication. The full
unconditional Krein cones are NOT imported as proved. -/
theorem THEOREM_5_2_FINITE_POSITIVE_CONE
    {h K M : ℕ} (c : Fin h → Fin (K + 1) → ℚ)
    (tail : ManuscriptChain.Extensions.WeightSevenTailBound c M)
    (cert : ManuscriptChain.Extensions.FinitePositiveCertificate c M) :
    ManuscriptChain.Extensions.PositiveQForm
      (ManuscriptChain.Extensions.weightSevenGram c) :=
  ManuscriptChain.Extensions.weight_seven_positive_from_finite_certificate c tail cert

end PaperChronological
