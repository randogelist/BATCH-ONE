import PaperChronological.T6_8
import Zetahyperbolic.Theorem_6_9_Triple_Pole_Hermite_Repair

/-!
# Theorem 6.9: Triple-pole and multi-weight Hankel determinants

PDF p. 38. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

 
/-- Theorem 6.9: exact local Hermite 3-jet determinant, without claiming
the full prime valuation asymptotic. -/
theorem THEOREM_6_9_LOCAL_HERMITE_BLOCK
    (w : Fin 3 → ℚ) :
    (Zetahyperbolic.TriplePoleRepair.localBlock w).det =
      -(w 2) ^ 3 :=
  Zetahyperbolic.TriplePoleRepair.localBlock_det w

end PaperChronological
