import PaperChronological.T6_4

/-!
# Theorem 6.5: q-adic nonvanishing for beta 4 determinant at zero

PDF p. 34. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 6.5 is still a formalization target. -/

end PaperChronological
