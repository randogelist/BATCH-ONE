import PaperChronological.S2_IndependentKernelBridge

/-!
# Certified-target Section 2 finite rational-function chain

This aggregates *proved statements*, rather than assuming a synthetic
"everything in the paper" proposition. The theorem gives:
  * canonical uniqueness for all finite initial pole segments;
  * exact pointwise rational-function realization away from the poles;
  * Q-additivity and Q-homogeneity of genuine pole residues;
  * agreement of the independent rational moment implementations;
  * exact moment slopes and compatibility across finite pole cutoffs.

Only proof source imports occur; there are no manuscript hypotheses or
arithmetic witnesses. The theorem does NOT claim Section 3 analytic
integration or Section 4 determinant decay.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- Unconditional finite-algebra completion target for all bounded
initial pole segments, including the empty segment. -/
structure UniversalFiniteChain (k J : ℕ) : Prop where
  numeratorUnique : ∀ (Q₁ Q₂ : ℚ[X]) (c₁ c₂ : Fin J → ℚ),
    allPoleNumerator k J Q₁ c₁ = allPoleNumerator k J Q₂ c₂ →
      Q₁ = Q₂ ∧ c₁ = c₂
  pointwiseFraction : ∀ (Q : ℚ[X]) (c : Fin J → ℚ) (t : ℚ),
    OffTailPoles (allPoleParameters k J) t →
    Q.eval t + ∑ a : Fin J,
      c a / (t + (ManuscriptChain.PoleDiagonalization.poleIndex
        (allPoleParameters k J) a : ℚ) ^ 2) =
      (allPoleNumerator k J Q c).eval t /
        (ManuscriptChain.Real.tailD (allPoleParameters k J)).eval t
  residueAdditive : ∀ (Q₁ Q₂ : ℚ[X]) (c₁ c₂ : Fin J → ℚ),
    clearedResidueNumerator (allPoleParameters k J)
      (Q₁ + Q₂) (fun a => c₁ a + c₂ a) =
      clearedResidueNumerator (allPoleParameters k J) Q₁ c₁ +
        clearedResidueNumerator (allPoleParameters k J) Q₂ c₂
  residueHomogeneous : ∀ (r : ℚ) (Q : ℚ[X]) (c : Fin J → ℚ),
    clearedResidueNumerator (allPoleParameters k J)
      (C r * Q) (fun a => r * c a) =
      C r * clearedResidueNumerator (allPoleParameters k J) Q c
  momentSlope : ∀ (Q : ℚ[X]) (c : Fin J → ℚ),
    (finiteMomentPolynomial (allPoleParameters k J) k Q c).coeff 1 =
      ∑ a : Fin J,
        c a * (ManuscriptChain.PoleDiagonalization.poleIndex
          (allPoleParameters k J) a : ℚ) ^ (2 * k)
  hankelPencil : ∀ (p : ManuscriptChain.Real.Parameters)
      (i j : Fin p.h),
    finiteMomentPolynomial p p.k
      (ManuscriptChain.Real.quotient p i.val j.val)
      (fun a : Fin p.h => ManuscriptChain.Real.residue p i.val j.val
        (ManuscriptChain.PoleDiagonalization.poleIndex p a)) =
      ManuscriptChain.Real.pencil p i j
  residueBridge : ∀ (p : ManuscriptChain.Real.Parameters)
      (hp : ManuscriptChain.Real.Admissible p) (d a : ℕ),
    a ∈ Finset.Icc (p.N + 1) p.K →
      ManuscriptChain.Real.residue p d 0 a =
        (Zetahyperbolic.kernelRatElem (asHankelParams p hp) d).poleRes a
  stableCutoff : ∀ (R : Zetahyperbolic.RatMomentElem) (n : ℕ),
    Zetahyperbolic.muFunctionalPoly k
      (extendMomentCutoffN R n) =
        Zetahyperbolic.muFunctionalPoly k R

/-- One unconditional construction of the Section 2 finite algebraic chain
for every odd weight (parameterized by k) and every finite pole cutoff J. -/
theorem SECTION2_ALL_FINITE_POLE_CHAIN (k J : ℕ) :
    UniversalFiniteChain k J := by
  exact {
    numeratorUnique := allPoleNumerator_unique k J
    pointwiseFraction := allPole_fraction_evaluation k J
    residueAdditive := clearedResidue_add (allPoleParameters k J)
    residueHomogeneous := clearedResidue_scale (allPoleParameters k J)
    momentSlope := finiteMomentPolynomial_slope (allPoleParameters k J) k
    hankelPencil := exact_hankel_moment_pencil
    residueBridge := kernelResidue_agreement
    stableCutoff := muFunctionalPoly_extendCutoff_iterate k
  }

end PaperChronological.Section2
