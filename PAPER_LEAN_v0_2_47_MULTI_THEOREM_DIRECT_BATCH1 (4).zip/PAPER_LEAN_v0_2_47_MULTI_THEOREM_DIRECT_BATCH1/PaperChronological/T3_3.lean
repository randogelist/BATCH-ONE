import PaperChronological.T3_2

/-!
# Theorem 3.3: Total positivity, leading sign, universal signature

PDF p. 8. Audit status: PARTIAL.

A finite/structural subclaim is proved or imported; the COMPLETE
manuscript theorem remains open and is not hidden in a named axiom.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological


/-- Theorem 3.3's determinant leading-coefficient component. The total
positivity, Carleman determination, and exact inertia are not discharged. -/
theorem THEOREM_3_3_LEADING_COEFF_NONZERO
    (p : ManuscriptChain.Real.Parameters) :
    (ManuscriptChain.Real.delta p).coeff p.h ≠ 0 := by
  rw [ManuscriptChain.PoleDiagonalization.delta_coeff_dimension]
  exact ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix_det_ne_zero p

end PaperChronological
