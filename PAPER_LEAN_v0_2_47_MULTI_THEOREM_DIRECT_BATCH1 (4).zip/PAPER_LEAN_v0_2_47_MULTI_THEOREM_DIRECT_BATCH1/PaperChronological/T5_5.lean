import PaperChronological.T5_4

/-!
# Remark 5.5: Simple pole scope restriction

PDF p. 25. Audit status: OBSERVATION.

This module links an actual mathematical theorem to previously
proved source declarations; no manuscript premise is silently postulated.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Remark 5.5 is still a formalization target. -/

end PaperChronological
