import PaperChronological.T3_4

/-!
# Corollary 3.5: Stieltjes J-fraction from interlacing roots

PDF p. 10. Audit status: ERRATUM.

The printed proposition needs correction: do not certify it as written.
Only the demonstrable repaired finite claim below (if present) is formalized.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

 
/-- Corrected rank-one normalization of the printed J-fraction.
The full printed identity (3.6) is FALSE as written. -/
theorem COROLLARY_3_5_CORRECTED_ONE_BY_ONE
    (g m xi x : ℝ) (hg : g ≠ 0) :
    g * (1 + (x - xi) * (m / g)) = g + (x - xi) * m := by
  field_simp [hg]

/-- A positive center Gram entry and negative direction cannot obey the
unadjusted printed rank-one identity at the center. -/
theorem COROLLARY_3_5_WRONG_SIGN_COUNTEREXAMPLE
    (g m : ℝ) (hg : 0 < g) (hm : m < 0) :
    1 / g ≠ g / m := by
  have hl : 0 < 1 / g := one_div_pos.mpr hg
  have hr : g / m < 0 := div_neg_of_pos_of_neg hg hm
  exact ne_of_gt (lt_trans hr hl)

end PaperChronological
