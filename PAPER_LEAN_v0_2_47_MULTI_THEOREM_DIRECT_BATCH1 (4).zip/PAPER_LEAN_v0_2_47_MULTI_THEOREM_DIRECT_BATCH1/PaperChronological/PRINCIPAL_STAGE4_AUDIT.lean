import PaperChronological.PRINCIPAL_STAGE4_CHAIN

/-!
# Audit: source-faithful principal Theorem 3.8 and exact Theorem 4.7(2)
All new proofs must elaborate and report no `sorryAx` or custom axioms.
Only standard Lean foundational axioms are admissible. The complete PDF
remains partially open and is not declared proved by this audit.
-/

#print PaperChronological.Principal.THEOREM_3_8_ACTUAL_ZETA_CENTER_POLE_KERNEL_SPECTRUM
#print PaperChronological.Principal.THEOREM_4_7_ACTUAL_STRADDLING_ROOT_SEPARATION
#print axioms PaperChronological.Principal.poleKernel_charpoly_identity
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_RATIONAL_POLE_KERNEL_CHARPOLY
#print axioms PaperChronological.Principal.actualDerivativeMatrix_real_eq_rationalMap
#print axioms PaperChronological.Principal.actualDerivativeMatrix_real_poleFactorization
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_REAL_POLE_KERNEL_CHARPOLY
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_ZETA_CENTER_POLE_KERNEL_SPECTRUM
#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_ZETA_POLE_EIGENVALUE_IFF
#print axioms PaperChronological.Principal.THEOREM_4_7_ACTUAL_STRADDLING_ROOT_SEPARATION
#print axioms PaperChronological.Principal.PRINCIPAL_STAGE4_ACTUAL_POLE_SPECTRUM
