import PaperChronological.T3_6_MomentGram
import PaperChronological.T3_3_TwoAtom

/-!
# Principal Theorem 3.3: strict finite atomic Hankel determinant

A finite discrete positive measure with h distinct real atoms and positive
weights has an h-by-h Hankel moment matrix whose determinant is strictly
positive. This is proved by its exact weighted Vandermonde congruence and
the Vandermonde determinant theorem, at every h including h=0.

The result is a genuine strictly positive determinant, not a positivity
hypothesis. Full strict total positivity for the paper's CONTINUOUS measure,
Carleman determinacy and the exact spectral inertia require additional work.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological.Principal

/-- Distinct atomic nodes make the square monomial evaluation matrix
nonsingular, by the general Vandermonde determinant formula. -/
theorem atomicVandermonde_det_ne_zero
    {h : ℕ} (u : Fin h → ℝ) (hu : Function.Injective u) :
    (PaperChronological.atomicVandermonde u h).det ≠ 0 := by
  change (Matrix.vandermonde u).transpose.det ≠ 0
  rw [Matrix.det_transpose]
  exact Matrix.det_vandermonde_ne_zero_iff.mpr hu

/-- The unweighted atomic Hankel determinant is the exact square of a
Vandermonde determinant. -/
theorem finiteAtomicHankel_det_eq_sq
    {h : ℕ} (u : Fin h → ℝ) :
    (PaperChronological.finiteAtomicHankel u h).det =
      (PaperChronological.atomicVandermonde u h).det ^ 2 := by
  rw [PaperChronological.COROLLARY_3_6_FINITE_ATOMIC_GRAM,
    Matrix.det_mul, Matrix.det_transpose]
  ring

/-- Strict positivity of the full square finite-atomic Hankel determinant. -/
theorem finiteAtomicHankel_det_pos
    {h : ℕ} (u : Fin h → ℝ) (hu : Function.Injective u) :
    0 < (PaperChronological.finiteAtomicHankel u h).det := by
  rw [finiteAtomicHankel_det_eq_sq]
  exact sq_pos_of_ne_zero (atomicVandermonde_det_ne_zero u hu)

/-- A weighted finite moment matrix, with genuine moments
M_ij = sum_a w_a u_a^(i+j), not a matrix defined by its factorization. -/
def weightedAtomicHankel {h : ℕ} (u w : Fin h → ℝ) :
    Matrix (Fin h) (Fin h) ℝ :=
  fun i j => ∑ a : Fin h, w a * u a ^ (i.val + j.val)

/-- The exact weighted Gram/Vandermonde factorization of the moments. -/
theorem weightedAtomicHankel_factorization
    {h : ℕ} (u w : Fin h → ℝ) :
    weightedAtomicHankel u w =
      PaperChronological.atomicVandermonde u h *
        Matrix.diagonal w *
        (PaperChronological.atomicVandermonde u h).transpose := by
  classical
  ext i j
  simp only [weightedAtomicHankel, Matrix.mul_apply,
    Matrix.transpose_apply, PaperChronological.atomicVandermonde, pow_add]
  apply Finset.sum_congr rfl
  intro a _
  have hcollapse :
      (∑ x : Fin h, u x ^ i.val * Matrix.diagonal w x a) =
        u a ^ i.val * w a := by
    simp [Matrix.diagonal_apply]
  rw [hcollapse]
  ring

/-- Weighted finite atomic Hankel determinant formula, at every dimension. -/
theorem weightedAtomicHankel_det_formula
    {h : ℕ} (u w : Fin h → ℝ) :
    (weightedAtomicHankel u w).det =
      (PaperChronological.atomicVandermonde u h).det ^ 2 *
        ∏ a : Fin h, w a := by
  rw [weightedAtomicHankel_factorization,
    Matrix.det_mul, Matrix.det_mul, Matrix.det_diagonal,
    Matrix.det_transpose]
  ring

/-- Main finite-atomic strict determinant: distinct nodes AND positive
weights imply determinant > 0, with no zeta or arithmetic assumptions. -/
theorem THEOREM_3_3_WEIGHTED_ATOMIC_HANKEL_DET_POS
    {h : ℕ} (u w : Fin h → ℝ)
    (hu : Function.Injective u) (hw : ∀ a, 0 < w a) :
    0 < (weightedAtomicHankel u w).det := by
  rw [weightedAtomicHankel_det_formula]
  exact mul_pos
    (sq_pos_of_ne_zero (atomicVandermonde_det_ne_zero u hu))
    (Finset.prod_pos (fun a _ => hw a))

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_3_3_WEIGHTED_ATOMIC_HANKEL_DET_POS
