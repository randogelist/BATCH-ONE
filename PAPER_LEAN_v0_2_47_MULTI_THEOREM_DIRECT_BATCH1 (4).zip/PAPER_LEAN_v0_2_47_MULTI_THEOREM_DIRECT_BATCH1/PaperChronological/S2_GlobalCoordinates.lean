import PaperChronological.S2_DirectedUnionAudit

/-!
# Section 2: intrinsic polynomial and residue coordinates on the directed union

Definition 2.1 is a Q-linear functional on the rational functions with finitely
many simple negative-square poles. The already certified directed-union quotient
removes the artificial cutoff. This file establishes its **intrinsic**
coordinates, their finite support, an extensionality theorem, and the exact
X-slope of the global moment functional.

No asymptotic bound, witness, zeta irrationality hypothesis, `sorry`, or new
axiom occurs here. All source files from the v0.2.25 PASS checkpoint remain
unchanged. Native Lean verification is deliberately left to the user's setup.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The polynomial part is independent of the finite pole cutoff. -/
noncomputable def polynomialPartOnDomain (R : RationalMomentDomain) : ℚ[X] :=
  Quotient.liftOn R (fun r : Zetahyperbolic.RatMomentElem => r.polyPart)
    (fun _ _ h => h.1)

@[simp] theorem polynomialPartOnDomain_mk
    (R : Zetahyperbolic.RatMomentElem) :
    polynomialPartOnDomain (Quotient.mk finitePoleSetoid R) = R.polyPart :=
  rfl

/-- The coefficient of 1/(t+j²) in a rational function. At j=0 there is no
allowed pole and this intrinsic coordinate is defined to be zero. -/
noncomputable def poleResidueOnDomain (j : ℕ)
    (R : RationalMomentDomain) : ℚ :=
  if hj : 1 ≤ j then
    Quotient.liftOn R (fun r : Zetahyperbolic.RatMomentElem => paddedResidue r j)
      (fun r s h => h.2 j hj)
  else 0

@[simp] theorem poleResidueOnDomain_mk (j : ℕ) (hj : 1 ≤ j)
    (R : Zetahyperbolic.RatMomentElem) :
    poleResidueOnDomain j (Quotient.mk finitePoleSetoid R) =
      paddedResidue R j := by
  simp [poleResidueOnDomain, hj]

@[simp] theorem poleResidueOnDomain_zero (R : RationalMomentDomain) :
    poleResidueOnDomain 0 R = 0 := by
  simp [poleResidueOnDomain]

/-- Every rational function in this directed union has only finitely many
nonzero pole coordinates, even though its representative has no canonical
cutoff. -/
theorem poleResidueOnDomain_eventually_zero (R : RationalMomentDomain) :
    ∃ J : ℕ, ∀ j : ℕ, J < j → poleResidueOnDomain j R = 0 := by
  refine Quotient.inductionOn R ?_
  intro r
  refine ⟨r.maxPole, ?_⟩
  intro j hj
  by_cases hpos : 1 ≤ j
  · have hnot : ¬ j ≤ r.maxPole := Nat.not_le.mpr hj
    simp [poleResidueOnDomain, hpos, paddedResidue, hnot]
  · simp [poleResidueOnDomain, hpos]

/-- Equality of the intrinsic polynomial part and every intrinsic residue
implies equality *of rational functions*, not merely equality of two cutoff
representatives. -/
theorem rationalMomentDomain_ext (R S : RationalMomentDomain) :
    polynomialPartOnDomain R = polynomialPartOnDomain S →
    (∀ j : ℕ, 1 ≤ j →
      poleResidueOnDomain j R = poleResidueOnDomain j S) → R = S := by
  refine Quotient.inductionOn₂ R S ?_
  intro r s hp hr
  apply Quotient.sound
  refine ⟨hp, ?_⟩
  intro j hj
  calc
    paddedResidue r j =
        poleResidueOnDomain j (Quotient.mk finitePoleSetoid r) :=
      (poleResidueOnDomain_mk j hj r).symm
    _ = poleResidueOnDomain j (Quotient.mk finitePoleSetoid s) := hr j hj
    _ = paddedResidue s j := poleResidueOnDomain_mk j hj s

/-- Intrinsic normal form is complete: these coordinates characterize the
quotient equality relation in both directions. -/
theorem rationalMomentDomain_eq_iff (R S : RationalMomentDomain) :
    R = S ↔
      polynomialPartOnDomain R = polynomialPartOnDomain S ∧
        ∀ j : ℕ, 1 ≤ j →
          poleResidueOnDomain j R = poleResidueOnDomain j S := by
  constructor
  · intro h
    subst S
    exact ⟨rfl, fun _ _ => rfl⟩
  · intro h
    exact rationalMomentDomain_ext R S h.1 h.2

/-- The coefficient of X in the complete directed-union moment polynomial is
always a **finite** weighted sum of its intrinsic simple-pole residues. -/
theorem muOnRationalDomain_slope (k : ℕ) (R : RationalMomentDomain) :
    ∃ J : ℕ,
      (muOnRationalDomain k R).coeff 1 =
        ∑ j ∈ Finset.Icc 1 J,
          poleResidueOnDomain j R * (j : ℚ) ^ (2 * k) := by
  refine Quotient.inductionOn R ?_
  intro r
  refine ⟨r.maxPole, ?_⟩
  rw [muOnRationalDomain_mk, Zetahyperbolic.muFunctionalPoly_coeff_one]
  apply Finset.sum_congr rfl
  intro j hj
  have hpos : 1 ≤ j := (Finset.mem_Icc.mp hj).1
  have hbound : j ≤ r.maxPole := (Finset.mem_Icc.mp hj).2
  rw [poleResidueOnDomain_mk j hpos r]
  simp [paddedResidue, hbound]

/-- The exact Section 2 global coordinate interface: these are theorems
constructible from the quotient, not additional conditions on the paper. -/
structure GlobalCoordinatesChain : Prop where
  intrinsicExtensionality : ∀ R S : RationalMomentDomain,
    polynomialPartOnDomain R = polynomialPartOnDomain S →
    (∀ j : ℕ, 1 ≤ j →
      poleResidueOnDomain j R = poleResidueOnDomain j S) → R = S
  finitePoleSupport : ∀ R : RationalMomentDomain,
    ∃ J : ℕ, ∀ j : ℕ, J < j → poleResidueOnDomain j R = 0
  momentSlope : ∀ (k : ℕ) (R : RationalMomentDomain),
    ∃ J : ℕ,
      (muOnRationalDomain k R).coeff 1 =
        ∑ j ∈ Finset.Icc 1 J,
          poleResidueOnDomain j R * (j : ℚ) ^ (2 * k)

/-- Unconditional, arbitrary-finite-pole Section 2 coordinate completion. -/
theorem SECTION2_GLOBAL_COORDINATES : GlobalCoordinatesChain := by
  exact {
    intrinsicExtensionality := rationalMomentDomain_ext
    finitePoleSupport := poleResidueOnDomain_eventually_zero
    momentSlope := muOnRationalDomain_slope
  }

end PaperChronological.Section2
