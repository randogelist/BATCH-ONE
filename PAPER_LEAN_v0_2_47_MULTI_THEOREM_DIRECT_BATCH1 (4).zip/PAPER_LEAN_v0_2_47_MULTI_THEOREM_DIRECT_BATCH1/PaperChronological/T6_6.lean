import PaperChronological.T6_5

/-!
# Theorem 6.6: Generalized multi-weight positive-definite pencil

PDF p. 35. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 6.6 is still a formalization target. -/

end PaperChronological
