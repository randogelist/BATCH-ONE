import PaperChronological.Principal_T3_7_LaguerreSOS
import PaperChronological.Principal_T3_3_SpectralSplit

/-!
# Principal Theorem 3.7: genuine derivative Turan for the odd-zeta determinant

The earlier Section 3 proof established a finite factored sum-of-squares
identity. Here we work with the ACTUAL first and second ordinary polynomial
derivatives, not only formal factored analogues. The product identity

  L(P Q) = Q(x)^2 L(P) + P(x)^2 L(Q),
  L(P) = P'(x)^2 - P(x) P''(x),

and L(a+bX) = b^2 prove the first Turan inequality for ANY finite product of
real linear factors. The independently established odd-zeta spectral
factorization transports this statement to the actual determinant polynomial.

This proves the m=1 (first derivative) part of Theorem 3.7(1) in arbitrary
finite dimension, unconditionally. Higher derivatives and Newton coefficient
inequalities are NOT claimed by this module.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Principal

/-- The ordinary-derivative Laguerre/Turan expression of a real polynomial. -/
def derivativeTuran (P : ℝ[X]) (x : ℝ) : ℝ :=
  (derivative P).eval x ^ 2 - P.eval x * (derivative (derivative P)).eval x

/-- Exact product identity, valid at ALL real points including roots. -/
theorem derivativeTuran_mul (P Q : ℝ[X]) (x : ℝ) :
    derivativeTuran (P * Q) x =
      (Q.eval x) ^ 2 * derivativeTuran P x +
      (P.eval x) ^ 2 * derivativeTuran Q x := by
  simp only [derivativeTuran, derivative_mul, derivative_add,
    Polynomial.eval_mul, Polynomial.eval_add]
  ring

/-- Scaling by a real constant multiplies the Turan form by its square. -/
theorem derivativeTuran_C_mul (a : ℝ) (P : ℝ[X]) (x : ℝ) :
    derivativeTuran (C a * P) x = a ^ 2 * derivativeTuran P x := by
  rw [derivativeTuran_mul]
  simp [derivativeTuran]

/-- The manuscript spectral linear factor has exact Turan value beta squared. -/
theorem derivativeTuran_spectralFactor (center beta x : ℝ) :
    derivativeTuran (ManuscriptChain.Spectral.spectralFactor center beta) x =
      beta ^ 2 := by
  simp [derivativeTuran, ManuscriptChain.Spectral.spectralFactor,
    derivative_add, derivative_mul, derivative_sub]

/-- Products of finitely many polynomials with nonnegative Turan forms
again have nonnegative Turan form. There is NO non-root restriction. -/
theorem derivativeTuran_prod_nonneg
    {ι : Type*} [DecidableEq ι] (s : Finset ι) (F : ι → ℝ[X]) (x : ℝ)
    (hF : ∀ i, 0 ≤ derivativeTuran (F i) x) :
    0 ≤ derivativeTuran (∏ i ∈ s, F i) x := by
  classical
  induction s using Finset.induction_on with
  | empty =>
      simp [derivativeTuran]
  | @insert i s hi ih =>
      rw [Finset.prod_insert hi, derivativeTuran_mul]
      exact add_nonneg
        (mul_nonneg (sq_nonneg _) (hF i))
        (mul_nonneg (sq_nonneg _) ih)

/-- Every real symmetric affine pencil with an already CONSTRUCTED real
spectral factorization satisfies the TRUE ordinary-derivative Turan
inequality at every real argument. -/
theorem derivativeTuran_of_spectralFactorization
    {n : ℕ} {p : ManuscriptChain.Spectral.SymmetricAffinePencil n}
    (c : ManuscriptChain.Spectral.RootFactorization p) (x : ℝ) :
    0 ≤ derivativeTuran p.detPolynomial x := by
  have hs : 0 ≤ derivativeTuran
      (∏ i : Fin n,
        ManuscriptChain.Spectral.spectralFactor p.center (c.beta i)) x := by
    apply derivativeTuran_prod_nonneg
      (s := (Finset.univ : Finset (Fin n)))
      (F := fun i => ManuscriptChain.Spectral.spectralFactor p.center (c.beta i))
    intro i
    rw [derivativeTuran_spectralFactor]
    exact sq_nonneg _
  rw [c.factorization, derivativeTuran_C_mul]
  exact mul_nonneg (sq_nonneg _) hs

/-- Theorem 3.7(1), order-one case, on the ACTUAL odd-weight zeta Hankel
determinant and the ordinary polynomial first and second derivatives. -/
theorem THEOREM_3_7_ACTUAL_ODD_ZETA_FIRST_TURAN
    (q : ManuscriptChain.Real.Parameters)
    (hq : ManuscriptChain.Real.Admissible q) (x : ℝ) :
    0 ≤ (derivative (ManuscriptChain.Real.manuscriptPencil q).detPolynomial).eval x ^ 2 -
      (ManuscriptChain.Real.manuscriptPencil q).detPolynomial.eval x *
      (derivative (derivative
        (ManuscriptChain.Real.manuscriptPencil q).detPolynomial)).eval x := by
  change 0 ≤ derivativeTuran
    (ManuscriptChain.Real.manuscriptPencil q).detPolynomial x
  let c := ManuscriptChain.General.factorization q
    (ManuscriptChain.GRAM_POSITIVE q hq)
  exact derivativeTuran_of_spectralFactorization c x

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_3_7_ACTUAL_ODD_ZETA_FIRST_TURAN
