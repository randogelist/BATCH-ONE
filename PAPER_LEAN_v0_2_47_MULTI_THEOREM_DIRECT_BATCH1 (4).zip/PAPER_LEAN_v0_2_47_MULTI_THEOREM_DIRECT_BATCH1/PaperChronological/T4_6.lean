import PaperChronological.T4_5

/-!
# Theorem 4.6: Two-sided determinant bounds and coefficient heights

PDF p. 19. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 4.6 is still a formalization target. -/

end PaperChronological
