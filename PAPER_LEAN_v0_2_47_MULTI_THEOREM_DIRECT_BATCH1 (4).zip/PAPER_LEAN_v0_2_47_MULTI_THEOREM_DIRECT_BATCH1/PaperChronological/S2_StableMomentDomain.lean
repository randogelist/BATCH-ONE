import PaperChronological.S2_ResidueLinearity

/-!
# Definition 2.1: enlarging the finite simple-pole cutoff

The finite pole bound is auxiliary: adding a new pole with ZERO residue must
not change the moment functional. This is essential before the union of all
finite-pole presentations can be treated as the paper's rational-function
domain. The proof is a finite-sum identity; no convergence or limiting
hypothesis is involved.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- Extend a canonical rational moment presentation from the pole set
`1..M` to `1..(M+1)` by assigning residue zero at the newly added pole. -/
def extendMomentCutoff (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.RatMomentElem :=
  { polyPart := R.polyPart
    maxPole := R.maxPole + 1
    poleRes := fun j =>
      if j = R.maxPole + 1 then 0 else R.poleRes j }

/-- The original mu-functional is stable under zero-residue extension of
its finite cutoff. Both the polynomial and all existing pole data survive
unchanged, so this result is independent of `X`. -/
theorem muFunctionalPoly_extendMomentCutoff (k : ℕ)
    (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k (extendMomentCutoff R) =
      Zetahyperbolic.muFunctionalPoly k R := by
  have hsum :
      (∑ j ∈ Finset.Icc 1 (R.maxPole + 1),
        C (if j = R.maxPole + 1 then (0 : ℚ) else R.poleRes j) *
          Zetahyperbolic.muPolePoly k j) =
      ∑ j ∈ Finset.Icc 1 R.maxPole,
        C (R.poleRes j) * Zetahyperbolic.muPolePoly k j := by
    rw [Finset.sum_Icc_succ_top (by omega : 1 ≤ R.maxPole + 1)]
    have hlast :
        C (if R.maxPole + 1 = R.maxPole + 1 then (0 : ℚ)
            else R.poleRes (R.maxPole + 1)) *
          Zetahyperbolic.muPolePoly k (R.maxPole + 1) = 0 := by
      simp
    rw [hlast, add_zero]
    apply Finset.sum_congr rfl
    intro j hj
    have hjmax : j ≤ R.maxPole := (Finset.mem_Icc.mp hj).2
    have hne : j ≠ R.maxPole + 1 := by omega
    simp [hne]
  unfold Zetahyperbolic.muFunctionalPoly extendMomentCutoff
  rw [hsum]

/-- Iterating a zero-residue cutoff extension with a recursive definition
whose successor case is definitionally a fresh zero-residue pole. -/
def extendMomentCutoffN (R : Zetahyperbolic.RatMomentElem) :
    ℕ → Zetahyperbolic.RatMomentElem
  | 0 => R
  | n + 1 => extendMomentCutoff (extendMomentCutoffN R n)

/-- Iterated zero-residue cutoff extensions preserve the mu-moment polynomial
at every finite iteration. This is the directed-union compatibility theorem
for Definition 2.1's pole domain. -/
theorem muFunctionalPoly_extendCutoff_iterate (k : ℕ)
    (R : Zetahyperbolic.RatMomentElem) (n : ℕ) :
    Zetahyperbolic.muFunctionalPoly k (extendMomentCutoffN R n) =
      Zetahyperbolic.muFunctionalPoly k R := by
  induction n with
  | zero => rfl
  | succ n ih =>
      change Zetahyperbolic.muFunctionalPoly k
        (extendMomentCutoff (extendMomentCutoffN R n)) =
          Zetahyperbolic.muFunctionalPoly k R
      rw [muFunctionalPoly_extendMomentCutoff, ih]

end PaperChronological.Section2
