import PaperChronological.T3_8
import PaperChronological.T2_5

/-!
# Direct manuscript Theorem 3.8(1) — pole-kernel determinant identity

With M = V diag(gamma) V^T, the determinant of the Gram-inverse-weighted
matrix H M equals the determinant of the finite pole-kernel matrix
  diag(gamma) V^T H V.
This is proved as an all-dimensional matrix identity and then specialized
to the paper's ACTUAL pole Vandermonde and derivative matrix.

The separate assertion of matching entire characteristic polynomials and
the Jacobi analytic deformation identity (3.8) remain open.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological.Principal

/-- General determinant identity behind the Christoffel-Darboux pole
kernel representation, without a commutativity assumption on matrices. -/
theorem poleKernel_det_identity
    {R : Type*} [CommRing R] {n : ℕ}
    (H V : Matrix (Fin n) (Fin n) R) (γ : Fin n → R) :
    Matrix.det (H * (V * Matrix.diagonal γ * V.transpose)) =
      Matrix.det (Matrix.diagonal γ * (V.transpose * H * V)) := by
  simp only [Matrix.det_mul, Matrix.det_transpose, Matrix.det_diagonal]
  ring

/-- EXACT determinant identity for the manuscript derivative matrix,
without replacing it by a hypothetical matrix. H can be any rational
matrix, notably any invertible rational Gram approximation. -/
theorem THEOREM_3_8_ACTUAL_POLE_KERNEL_DETERMINANT
    (p : ManuscriptChain.Real.Parameters)
    (H : Matrix (Fin p.h) (Fin p.h) ℚ) :
    Matrix.det (H * ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p) =
      Matrix.det (
        Matrix.diagonal (ManuscriptChain.PoleDiagonalization.poleWeight p) *
          ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).transpose *
             H * ManuscriptChain.PoleDiagonalization.poleVandermonde p)) := by
  rw [PaperChronological.THEOREM_2_5_VANDERMONDE]
  exact poleKernel_det_identity H
    (ManuscriptChain.PoleDiagonalization.poleVandermonde p)
    (ManuscriptChain.PoleDiagonalization.poleWeight p)

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_3_8_ACTUAL_POLE_KERNEL_DETERMINANT
