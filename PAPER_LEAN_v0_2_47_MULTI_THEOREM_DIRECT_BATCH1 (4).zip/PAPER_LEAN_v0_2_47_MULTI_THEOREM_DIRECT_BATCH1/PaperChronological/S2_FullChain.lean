import PaperChronological.S2_LagrangeRatio
import PaperChronological.T2_2_Span

/-!
# Manuscript Section 2: chronological unconditional algebraic chain

This file bundles the actual formal statements from Definition 2.1,
Lemmas 2.2-2.3, and Theorems 2.4-2.5. In particular the finite-pole
partial fractions are not taken as an external assumption: existence is
proved in `Zetahyperbolic.Section2Checked`, and uniqueness is supplied by
`S2_CanonicalPresentation`. The Lagrange ratio (2.10), determinant scaling,
primitive normalization and nonsingular Vandermonde factorization are proved.

The only prospective single Witness belongs to Section 4; none is an input
here. The package makes NO claim to prove the analytic Section 3 moment
representation or any subsequent effective irrationality measure.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- A theorem-level certificate for the paper's finite algebraic Section 2.
This is a `Prop` with proofs constructed below, not an assumed hypothesis. -/
structure AlgebraicChain (p : ManuscriptChain.Real.Parameters) : Prop where
  denominatorEmpty : Zetahyperbolic.D_poly 0 = 1
  poleSlope : ∀ k j : ℕ,
    (Zetahyperbolic.muPolePoly k j).coeff 1 = (j : ℚ) ^ (2 * k)
  finitePartialFractions : ∀ (q : Zetahyperbolic.HankelParams) (d : ℕ),
    Nonempty (Zetahyperbolic.KernelPartialFractionData q d)
  pullback : ∀ (k : ℕ) (hk : 1 ≤ k) (R : Zetahyperbolic.RatMomentElem),
    Zetahyperbolic.muFunctionalPoly k R =
      PaperChronological.tauPullbackOnPresentation k R
  reflection : ∀ (k : ℕ) (hk : 1 ≤ k) (P : PaperChronological.TauPresentation),
    PaperChronological.tauReflectedPresentationValue k P =
      -PaperChronological.tauPresentationValue k P
  poleDifference : ∀ (k : ℕ) (P : PaperChronological.TauPresentation),
    (∀ r ∈ P.poleSet, r ≠ 0 ∧ r ≠ 1) →
      PaperChronological.tauPoleShiftDifference k P =
        PaperChronological.tauPoleShiftDerivative k P
  basisInvariant : ∀ (A B : Matrix (Fin p.h) (Fin p.h) ℚ)
    (hA : Matrix.det A ≠ 0) (hB : Matrix.det B ≠ 0),
    let n₀ := ManuscriptChain.BasisInvariance.primitiveNormalization
      (ManuscriptChain.Real.delta p)
      (ManuscriptChain.PoleDiagonalization.delta_ne_zero p)
    let nAB := ManuscriptChain.BasisInvariance.primitiveNormalization
      (Matrix.det (ManuscriptChain.BasisInvariance.changeBasisPencil
        (ManuscriptChain.Real.pencil p) A B))
      ((ManuscriptChain.BasisInvariance.det_changeBasisPencil_ne_zero_iff
          (ManuscriptChain.Real.pencil p) A B hA hB).mpr
        (ManuscriptChain.PoleDiagonalization.delta_ne_zero p))
    nAB.polynomial = n₀.polynomial ∨ nAB.polynomial = -n₀.polynomial
  lagrangeEvaluation : ∀ a b : Fin p.h,
    (L p a).eval (ManuscriptChain.PoleDiagonalization.poleNode p b) =
      if a = b then 1 else 0
  lagrangeRatio : ∀ a : Fin p.h,
    (X + C ((ManuscriptChain.PoleDiagonalization.poleIndex p a : ℚ) ^ 2)) *
      L p a * C ((derivative (ManuscriptChain.Real.tailD p)).eval
        (ManuscriptChain.PoleDiagonalization.poleNode p a)) =
      ManuscriptChain.Real.tailD p
  lagrangeDenominatorNonzero : ∀ a : Fin p.h,
    (derivative (ManuscriptChain.Real.tailD p)).eval
      (ManuscriptChain.PoleDiagonalization.poleNode p a) ≠ 0
  presentationUniqueness : ∀ (Q₁ Q₂ : ℚ[X]) (r₁ r₂ : Fin p.h → ℚ),
    normalizedNumerator p Q₁ r₁ = normalizedNumerator p Q₂ r₂ →
      Q₁ = Q₂ ∧ r₁ = r₂
  derivativeFactorization :
    ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix p =
      ManuscriptChain.PoleDiagonalization.poleVandermonde p *
        Matrix.diagonal (ManuscriptChain.PoleDiagonalization.poleWeight p) *
        (ManuscriptChain.PoleDiagonalization.poleVandermonde p).transpose
  derivativeInvertible : (ManuscriptChain.Real.derivativeMatrix p).det ≠ 0
  determinantExactDegree : (ManuscriptChain.Real.delta p).natDegree = p.h

/-- The manuscript's entire finite algebraic spine (2.1)-(2.11), with a
canonical presentation uniqueness theorem, assembled without a Witness. -/
theorem SECTION2_UNCONDITIONAL_ALGEBRAIC_CHAIN
    (p : ManuscriptChain.Real.Parameters) : AlgebraicChain p := by
  refine {
    denominatorEmpty := PaperChronological.DEF_2_1_EMPTY_DENOMINATOR
    poleSlope := PaperChronological.DEF_2_1_POLE_SLOPE
    finitePartialFractions := Zetahyperbolic.kernelNumerator_partial_fraction_exists
    pullback := fun k hk R => PaperChronological.LEMMA_2_2_FINITE_SPAN k hk R
    reflection := fun k hk P => PaperChronological.LEMMA_2_3_FULL_REFLECTION_SPAN k hk P
    poleDifference := fun k P h => PaperChronological.LEMMA_2_3_FINITE_POLE_DIFFERENCE k P h
    basisInvariant := fun A B hA hB =>
      PaperChronological.THEOREM_2_4_CANONICAL_BASIS_INVARIANCE p A B hA hB
    lagrangeEvaluation := L_eval p
    lagrangeRatio := LAGRANGE_CLEARED_DENOMINATOR p
    lagrangeDenominatorNonzero := LAGRANGE_DERIVATIVE_NONZERO p
    presentationUniqueness := fun Q₁ Q₂ r₁ r₂ h =>
      normalizedPresentation_unique p Q₁ Q₂ r₁ r₂ h
    derivativeFactorization := PaperChronological.THEOREM_2_5_VANDERMONDE p
    derivativeInvertible := PaperChronological.THEOREM_2_5_DERIVATIVE_NONSINGULAR p
    determinantExactDegree := PaperChronological.THEOREM_2_5_EXACT_DEGREE p }

end PaperChronological.Section2
