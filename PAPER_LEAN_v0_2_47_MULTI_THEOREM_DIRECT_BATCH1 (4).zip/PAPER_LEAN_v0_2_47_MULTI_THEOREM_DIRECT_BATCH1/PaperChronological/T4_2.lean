import PaperChronological.T4_1

/-!
# Proposition 4.2: Transfer criterion for algebraic approximations

PDF p. 15. Audit status: OPEN.

This theorem is NOT represented as proved here. Retained in the
chronological import chain as an exact location for a future proof.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Proposition 4.2 is still a formalization target. -/

end PaperChronological
