import PaperChronological.S2_GlobalMomentLinearity

/-!
# Definition 2.1 — a native Lean linear map, not a merely named functional

The quotient of all finite polynomial-plus-simple-pole presentations is a
Q-vector-space (previous native PASS). The polynomial-valued moment is
proved additive/homogeneous in the preceding module, permitting an actual
LinearMap constructor with no mathematical hypotheses.
-/

noncomputable section
open Polynomial

namespace PaperChronological.Section2

/-- The order-(2k+1) rational moment as a native rational linear map. -/
noncomputable def muRationalLinearMap (k : ℕ) :
    RationalMomentDomain →ₗ[ℚ] ℚ[X] where
  toFun := muOnRationalDomain k
  map_add' := muOnRationalDomain_add k
  map_smul' := by
    intro q R
    -- A LinearMap's scalar on the target is the native polynomial smul.
    -- The previously proved moment homogeneity uses its equal C-mul form.
    simpa only [RingHom.id_apply, Polynomial.smul_eq_C_mul] using
      (muOnRationalDomain_smul k q R)

/-- Native linear-map evaluation is definitionally the paper's functional. -/
theorem muRationalLinearMap_apply (k : ℕ) (R : RationalMomentDomain) :
    muRationalLinearMap k R = muOnRationalDomain k R := rfl

/-- The linear functional maps the zero rational function to zero. -/
theorem muOnRationalDomain_zero (k : ℕ) :
    muOnRationalDomain k (0 : RationalMomentDomain) = 0 := by
  exact (muRationalLinearMap k).map_zero

end PaperChronological.Section2
