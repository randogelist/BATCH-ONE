import PaperChronological.T5_2
import Mathlib.Tactic.Ring

/-!
# Theorem 5.2(1) — exact rectangular coefficient Gram identity

For an arbitrary h x (K+1) rational-polynomial coefficient matrix C,
its derivative direction is CC^T. This proves the exact finite-dimensional
quadratic sum-of-squares identity and its positive-definiteness criterion
for ALL dimensions, not only square Vandermonde specializations.
The separate signed infinite Krein decomposition is not claimed.
-/

noncomputable section
open scoped BigOperators
namespace PaperChronological.Principal

private def rectangularGram {h k : ℕ} (C : Matrix (Fin h) (Fin k) ℝ) :
    Matrix (Fin h) (Fin h) ℝ := C * C.transpose

/-- Entrywise identity for CC^T. -/
theorem RECTANGULAR_GRAM_ENTRY {h k : ℕ}
    (C : Matrix (Fin h) (Fin k) ℝ) (i j : Fin h) :
    rectangularGram C i j = ∑ a : Fin k, C i a * C j a := by
  simp [rectangularGram, Matrix.mul_apply, Matrix.transpose_apply]

/-- Genuine bilinear quadratic form of the DUAL derivative pencil. -/
theorem THEOREM_5_2_RECTANGULAR_GRAM_SOS
    {h k : ℕ} (C : Matrix (Fin h) (Fin k) ℝ)
    (x : Fin h → ℝ) :
    (∑ i : Fin h, ∑ j : Fin h,
      x i * rectangularGram C i j * x j) =
      ∑ a : Fin k, (∑ i : Fin h, x i * C i a) ^ 2 := by
  classical
  simp only [RECTANGULAR_GRAM_ENTRY]
  calc
    (∑ i : Fin h, ∑ j : Fin h,
        x i * (∑ a : Fin k, C i a * C j a) * x j) =
      ∑ i : Fin h, ∑ j : Fin h, ∑ a : Fin k,
        (x i * C i a) * (x j * C j a) := by
      apply Finset.sum_congr rfl
      intro i _
      apply Finset.sum_congr rfl
      intro j _
      rw [Finset.mul_sum, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro a _
      ring
    _ = ∑ i : Fin h, ∑ a : Fin k, ∑ j : Fin h,
          (x i * C i a) * (x j * C j a) := by
      apply Finset.sum_congr rfl
      intro i _
      rw [Finset.sum_comm]
    _ = ∑ a : Fin k, ∑ i : Fin h, ∑ j : Fin h,
          (x i * C i a) * (x j * C j a) := by
      rw [Finset.sum_comm]
    _ = ∑ a : Fin k, (∑ i : Fin h, x i * C i a) ^ 2 := by
      apply Finset.sum_congr rfl
      intro a _
      calc
        (∑ i : Fin h, ∑ j : Fin h,
          (x i * C i a) * (x j * C j a)) =
          ∑ i : Fin h, (x i * C i a) *
            (∑ j : Fin h, x j * C j a) := by
          simp only [Finset.mul_sum]
        _ = (∑ i : Fin h, x i * C i a) *
            (∑ j : Fin h, x j * C j a) := by
          simp only [Finset.sum_mul]
        _ = (∑ i : Fin h, x i * C i a) ^ 2 := by
          rw [pow_two]

/-- Positive semidefinite without extra assumptions. -/
theorem THEOREM_5_2_RECTANGULAR_GRAM_NONNEG
    {h k : ℕ} (C : Matrix (Fin h) (Fin k) ℝ)
    (x : Fin h → ℝ) :
    0 ≤ ∑ i : Fin h, ∑ j : Fin h,
      x i * rectangularGram C i j * x j := by
  rw [THEOREM_5_2_RECTANGULAR_GRAM_SOS]
  exact Finset.sum_nonneg (fun a ha => sq_nonneg _)

/-- Positive definiteness when the coefficient map detects the vector. -/
theorem THEOREM_5_2_RECTANGULAR_GRAM_STRICT
    {h k : ℕ} (C : Matrix (Fin h) (Fin k) ℝ)
    (x : Fin h → ℝ)
    (hx : ∃ a : Fin k, (∑ i : Fin h, x i * C i a) ≠ 0) :
    0 < ∑ i : Fin h, ∑ j : Fin h,
      x i * rectangularGram C i j * x j := by
  rw [THEOREM_5_2_RECTANGULAR_GRAM_SOS]
  obtain ⟨a, ha⟩ := hx
  apply Finset.sum_pos'
  · intro b hb
    exact sq_nonneg _
  · exact ⟨a, Finset.mem_univ _, sq_pos_of_ne_zero ha⟩

end PaperChronological.Principal

#print axioms PaperChronological.Principal.THEOREM_5_2_RECTANGULAR_GRAM_SOS
#print axioms PaperChronological.Principal.THEOREM_5_2_RECTANGULAR_GRAM_STRICT
