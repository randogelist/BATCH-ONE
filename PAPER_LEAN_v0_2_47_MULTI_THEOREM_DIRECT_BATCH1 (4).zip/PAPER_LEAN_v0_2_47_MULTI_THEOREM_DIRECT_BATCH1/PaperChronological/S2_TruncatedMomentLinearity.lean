import PaperChronological.S2_GlobalModuleInstances

/-!
# Section 2, Definition 2.1 — finite-level Q-linearity

A proof of the full functional's linearity cannot be obtained merely by naming
an abstract `LinearMap`: Definition 2.1 sums the polynomial coefficients only
through the input-dependent degree. This module first establishes exact
linearity on a *fixed* degree bound and a *fixed* finite pole cutoff, and then
identifies the bounded formula with the manuscript's original moment expression
at its natural bounds.

The subsequent global-linear-map step can use the truncation/stabilization
identity without changing the previously certified finite-pole construction.
No `sorry`, custom axiom, or arithmetic/analytic witness occurs here.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The polynomial part of the order-(2k+1) moment, cut off at a fixed
coefficient bound `B` that is independent of the input polynomial. -/
noncomputable def truncatedMonomialMoment (k B : ℕ) (P : ℚ[X]) : ℚ[X] :=
  ∑ e ∈ Finset.range B,
    C (P.coeff e * Zetahyperbolic.muMonomial k e)

/-- The original finite pole contribution at the initial square-pole lattice. -/
noncomputable def truncatedPoleMoment (k J : ℕ) (c : ℕ → ℚ) : ℚ[X] :=
  ∑ j ∈ Finset.Icc 1 J,
    C (c j) * Zetahyperbolic.muPolePoly k j

/-- Formula (2.2) is additive on every fixed monomial cutoff. -/
theorem truncatedMonomialMoment_add
    (k B : ℕ) (P Q : ℚ[X]) :
    truncatedMonomialMoment k B (P + Q) =
      truncatedMonomialMoment k B P + truncatedMonomialMoment k B Q := by
  unfold truncatedMonomialMoment
  simp only [coeff_add, add_mul, map_add, Finset.sum_add_distrib]

/-- Formula (2.2) is homogeneous for arbitrary rational scalars. -/
theorem truncatedMonomialMoment_scale
    (k B : ℕ) (q : ℚ) (P : ℚ[X]) :
    truncatedMonomialMoment k B (C q * P) =
      C q * truncatedMonomialMoment k B P := by
  unfold truncatedMonomialMoment
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e he
  rw [coeff_C_mul]
  simp only [map_mul]
  ring

/-- Formula (2.3) is additive in arbitrary finite lists of simple residues. -/
theorem truncatedPoleMoment_add
    (k J : ℕ) (c d : ℕ → ℚ) :
    truncatedPoleMoment k J (fun j => c j + d j) =
      truncatedPoleMoment k J c + truncatedPoleMoment k J d := by
  unfold truncatedPoleMoment
  simp only [map_add, add_mul, Finset.sum_add_distrib]

/-- Formula (2.3) is homogeneous in every simple-pole residue. -/
theorem truncatedPoleMoment_scale
    (k J : ℕ) (q : ℚ) (c : ℕ → ℚ) :
    truncatedPoleMoment k J (fun j => q * c j) =
      C q * truncatedPoleMoment k J c := by
  unfold truncatedPoleMoment
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  simp only [map_mul]
  ring

/-- The combined order-(2k+1) rational moment at two fixed cutoffs. -/
noncomputable def truncatedMoment (k B J : ℕ)
    (P : ℚ[X]) (c : ℕ → ℚ) : ℚ[X] :=
  truncatedMonomialMoment k B P + truncatedPoleMoment k J c

/-- At fixed bounds, the *entire* moment is additive in its two families of
independent rational coordinates. -/
theorem truncatedMoment_add
    (k B J : ℕ) (P Q : ℚ[X]) (c d : ℕ → ℚ) :
    truncatedMoment k B J (P + Q) (fun j => c j + d j) =
      truncatedMoment k B J P c + truncatedMoment k B J Q d := by
  simp only [truncatedMoment, truncatedMonomialMoment_add,
    truncatedPoleMoment_add]
  abel

/-- At fixed bounds, the *entire* moment is rationally homogeneous. -/
theorem truncatedMoment_scale
    (k B J : ℕ) (q : ℚ) (P : ℚ[X]) (c : ℕ → ℚ) :
    truncatedMoment k B J (C q * P) (fun j => q * c j) =
      C q * truncatedMoment k B J P c := by
  simp only [truncatedMoment, truncatedMonomialMoment_scale,
    truncatedPoleMoment_scale, mul_add]

/-- The finite-level definition is **exactly** the PDF's existing
`muFunctionalPoly`, without replacing the variable-degree formula. -/
theorem truncatedMoment_matches_muFunctionalPoly (k : ℕ)
    (R : Zetahyperbolic.RatMomentElem) :
    truncatedMoment k (R.polyPart.natDegree + 1) R.maxPole
      R.polyPart R.poleRes = Zetahyperbolic.muFunctionalPoly k R := by
  rfl

/-- Consequently, the truncated formula also agrees with the global
quotient moment on every representative, with its natural finite bounds. -/
theorem truncatedMoment_matches_global (k : ℕ)
    (R : Zetahyperbolic.RatMomentElem) :
    truncatedMoment k (R.polyPart.natDegree + 1) R.maxPole
      R.polyPart R.poleRes =
        muOnRationalDomain k (Quotient.mk finitePoleSetoid R) := by
  rw [truncatedMoment_matches_muFunctionalPoly, muOnRationalDomain_mk]

end PaperChronological.Section2
