import PaperChronological.S2_TruncatedMomentLinearity

/-!
# Definition 2.1 — exact elimination of artificial moment cutoffs

The coefficient sum in the paper uses the natural degree of the polynomial
part, whereas the truncated functional uses an arbitrary fixed B.  The two
formulas agree whenever B exceeds that degree.  Similarly zero-padded pole
residues make a larger finite pole cutoff indistinguishable from the original.
These are the two required bridges from bounded algebra to the actual
moment on rational functions with finitely many negative-square poles.

All arguments are over the rational numbers; no analytic estimate or
hypothesis about an odd zeta value is introduced.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronological.Section2

/-- The truncated Bernoulli moment is independent of the chosen bound once
that bound exceeds the degree of the polynomial. -/
theorem truncatedMonomialMoment_eq_polynomialMoment
    (k B : ℕ) (P : ℚ[X]) (hB : P.natDegree < B) :
    truncatedMonomialMoment k B P =
      C (ManuscriptChain.Real.polynomialMoment k P) := by
  unfold truncatedMonomialMoment
  rw [← map_sum]
  congr 1
  have h := P.sum_over_range'
    (f := fun e a => a * Zetahyperbolic.muMonomial k e)
    (by intro n; simp) B hB
  -- First change the summation cutoff, and only then reconcile the two
  -- (definitionally equal) monomial moment functions. Keeping those steps
  -- separate avoids rewriting a different side of the range-sum equality.
  calc
    (∑ e ∈ Finset.range B, P.coeff e * Zetahyperbolic.muMonomial k e) =
        ∑ e ∈ P.support, P.coeff e * Zetahyperbolic.muMonomial k e := h.symm
    _ = ManuscriptChain.Real.polynomialMoment k P := by
      unfold ManuscriptChain.Real.polynomialMoment
      apply Finset.sum_congr rfl
      intro e he
      exact congrArg (fun v : ℚ => P.coeff e * v)
        (monomial_moment_agreement k e).symm

/-- Extending a finite pole cutoff by zero residues does not change its
order-s rational moment. -/
theorem truncatedPoleMoment_padded
    (k J : ℕ) (R : Zetahyperbolic.RatMomentElem)
    (hJ : R.maxPole ≤ J) :
    truncatedPoleMoment k J (paddedResidue R) =
      truncatedPoleMoment k R.maxPole R.poleRes := by
  unfold truncatedPoleMoment
  calc
    (∑ j ∈ Finset.Icc 1 J,
        C (paddedResidue R j) * Zetahyperbolic.muPolePoly k j) =
        ∑ j ∈ Finset.Icc 1 R.maxPole,
          C (paddedResidue R j) * Zetahyperbolic.muPolePoly k j := by
      symm
      apply Finset.sum_subset
      · intro j hj
        exact Finset.mem_Icc.mpr
          ⟨(Finset.mem_Icc.mp hj).1, (Finset.mem_Icc.mp hj).2.trans hJ⟩
      · intro j hj hnot
        have hjout : ¬ j ≤ R.maxPole := by
          intro hle
          exact hnot (Finset.mem_Icc.mpr ⟨(Finset.mem_Icc.mp hj).1, hle⟩)
        simp [paddedResidue, hjout]
    _ = ∑ j ∈ Finset.Icc 1 R.maxPole,
          C (R.poleRes j) * Zetahyperbolic.muPolePoly k j := by
      apply Finset.sum_congr rfl
      intro j hj
      simp [paddedResidue, (Finset.mem_Icc.mp hj).2]

/-- At any sufficiently large *common* polynomial degree and pole cutoff,
Definition 2.1 is exactly the previously established truncated functional. -/
theorem muFunctionalPoly_eq_truncated_of_bounds
    (k B J : ℕ) (R : Zetahyperbolic.RatMomentElem)
    (hB : R.polyPart.natDegree < B) (hJ : R.maxPole ≤ J) :
    Zetahyperbolic.muFunctionalPoly k R =
      truncatedMoment k B J R.polyPart (paddedResidue R) := by
  rw [← truncatedMoment_matches_muFunctionalPoly k R]
  unfold truncatedMoment
  rw [truncatedMonomialMoment_eq_polynomialMoment
      k (R.polyPart.natDegree + 1) R.polyPart (by omega),
    truncatedMonomialMoment_eq_polynomialMoment k B R.polyPart hB,
    truncatedPoleMoment_padded k J R hJ]

end PaperChronological.Section2
