import PaperChronological.S2_GlobalLinearOperations

/-!
# Section 2 — quotient Q-module identities, without additional hypotheses

The manuscript's domain of finite simple negative-square pole rational functions
is the already-constructed directed-union quotient. This file proves the
remaining zero, inverse, and scalar distributivity identities by extensionality
of its intrinsic polynomial and ordinary-residue coordinates.

No pre-existing verified proof modules are modified. No `sorry`, custom axioms,
quantitative witness, or assumption of irrationality enters the construction.
-/

noncomputable section
open Polynomial

namespace PaperChronological.Section2

/-- The zero rational function, represented by the zero polynomial and no poles. -/
noncomputable def rationalZero : RationalMomentDomain :=
  Quotient.mk finitePoleSetoid (polynomialPresentation 0)

/-- Additive inverse: multiply all the polynomial and pole coordinates by -1. -/
noncomputable def rationalNeg (R : RationalMomentDomain) : RationalMomentDomain :=
  rationalScale (-1) R

@[simp] theorem polynomialPartOnDomain_rationalZero :
    polynomialPartOnDomain rationalZero = 0 := rfl

@[simp] theorem poleResidueOnDomain_rationalZero
    (j : ℕ) (hj : 1 ≤ j) :
    poleResidueOnDomain j rationalZero = 0 := by
  exact polynomialPresentation_residue 0 j hj

@[simp] theorem rationalAdd_zero (R : RationalMomentDomain) :
    rationalAdd R rationalZero = R := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalAdd,
      polynomialPartOnDomain_rationalZero, add_zero]
  · intro j hj
    simp only [poleResidueOnDomain_rationalAdd,
      poleResidueOnDomain_rationalZero j hj, add_zero]

@[simp] theorem rationalZero_add (R : RationalMomentDomain) :
    rationalAdd rationalZero R = R := by
  rw [rationalAdd_comm, rationalAdd_zero]

@[simp] theorem rationalScale_one (R : RationalMomentDomain) :
    rationalScale 1 R = R := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalScale, map_one, one_mul]
  · intro j hj
    simp only [poleResidueOnDomain_rationalScale, one_mul]

@[simp] theorem rationalScale_zeroScalar (R : RationalMomentDomain) :
    rationalScale 0 R = rationalZero := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalScale, map_zero, zero_mul,
      polynomialPartOnDomain_rationalZero]
  · intro j hj
    simp only [poleResidueOnDomain_rationalScale, zero_mul,
      poleResidueOnDomain_rationalZero j hj]

@[simp] theorem rationalScale_zeroArgument (q : ℚ) :
    rationalScale q rationalZero = rationalZero := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalScale,
      polynomialPartOnDomain_rationalZero, mul_zero]
  · intro j hj
    simp only [poleResidueOnDomain_rationalScale,
      poleResidueOnDomain_rationalZero j hj, mul_zero]

/-- Every point of the global rational-function quotient has an additive inverse. -/
theorem rationalAdd_left_neg (R : RationalMomentDomain) :
    rationalAdd (rationalNeg R) R = rationalZero := by
  apply rationalMomentDomain_ext
  · simp only [rationalNeg, polynomialPartOnDomain_rationalAdd,
      polynomialPartOnDomain_rationalScale, map_neg, map_one,
      polynomialPartOnDomain_rationalZero]
    ring
  · intro j hj
    simp only [rationalNeg, poleResidueOnDomain_rationalAdd,
      poleResidueOnDomain_rationalScale,
      poleResidueOnDomain_rationalZero j hj]
    ring

theorem rationalAdd_right_neg (R : RationalMomentDomain) :
    rationalAdd R (rationalNeg R) = rationalZero := by
  rw [rationalAdd_comm, rationalAdd_left_neg]

/-- Scalar sums distribute over every element of the quotient. -/
theorem rationalScale_addScalars (q r : ℚ) (R : RationalMomentDomain) :
    rationalScale (q + r) R =
      rationalAdd (rationalScale q R) (rationalScale r R) := by
  apply rationalMomentDomain_ext
  · simp only [polynomialPartOnDomain_rationalScale,
      polynomialPartOnDomain_rationalAdd, map_add]
    ring
  · intro j hj
    simp only [poleResidueOnDomain_rationalScale,
      poleResidueOnDomain_rationalAdd]
    ring

/-- Every defining axiom of the Q-vector-space operations is proved on the
quotient, rather than assumed via a free-standing abstract module. -/
structure RationalModuleLaws : Prop where
  addAssociative : ∀ R S T : RationalMomentDomain,
    rationalAdd (rationalAdd R S) T = rationalAdd R (rationalAdd S T)
  addCommutative : ∀ R S : RationalMomentDomain,
    rationalAdd R S = rationalAdd S R
  rightZero : ∀ R : RationalMomentDomain, rationalAdd R rationalZero = R
  leftZero : ∀ R : RationalMomentDomain, rationalAdd rationalZero R = R
  leftInverse : ∀ R : RationalMomentDomain,
    rationalAdd (rationalNeg R) R = rationalZero
  scalarOne : ∀ R : RationalMomentDomain, rationalScale 1 R = R
  scalarMultiplication : ∀ q r : ℚ, ∀ R : RationalMomentDomain,
    rationalScale (q * r) R = rationalScale q (rationalScale r R)
  scalarAddition : ∀ q r : ℚ, ∀ R : RationalMomentDomain,
    rationalScale (q + r) R =
      rationalAdd (rationalScale q R) (rationalScale r R)
  scalarDistributes : ∀ q : ℚ, ∀ R S : RationalMomentDomain,
    rationalScale q (rationalAdd R S) =
      rationalAdd (rationalScale q R) (rationalScale q S)
  zeroScalar : ∀ R : RationalMomentDomain, rationalScale 0 R = rationalZero
  scalarZero : ∀ q : ℚ, rationalScale q rationalZero = rationalZero

/-- Witness-free completion of the Q-module laws for all finite rational
presentations, independent of the pole cutoff. -/
theorem SECTION2_GLOBAL_Q_MODULE_LAWS : RationalModuleLaws := by
  exact {
    addAssociative := rationalAdd_assoc
    addCommutative := rationalAdd_comm
    rightZero := rationalAdd_zero
    leftZero := rationalZero_add
    leftInverse := rationalAdd_left_neg
    scalarOne := rationalScale_one
    scalarMultiplication := rationalScale_mul
    scalarAddition := rationalScale_addScalars
    scalarDistributes := rationalScale_add
    zeroScalar := rationalScale_zeroScalar
    scalarZero := rationalScale_zeroArgument
  }

end PaperChronological.Section2
