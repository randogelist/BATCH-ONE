import PaperChronological.T6_3

/-!
# Theorem 6.4: Character-Vandermonde sign cancellation for beta 4

PDF p. 33. Audit status: ERRATUM.

The printed proposition needs correction: do not certify it as written.
Only the demonstrable repaired finite claim below (if present) is formalized.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronological

/- The full source statement of Theorem 6.4 is still a formalization target. -/

end PaperChronological
