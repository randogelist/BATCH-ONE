# v0.2.27 Section 2 global-coordinate extensionality repair

Compiler error at `PaperChronological/S2_GlobalCoordinates.lean:76`:
The residue equality on the quotient is not definitionally the equality
between `paddedResidue` coordinates. This version converts the residue
equality with the existing proved `poleResidueOnDomain_mk` lemma on both
sides. No theorem statement has changed.

Only this Lean source changed relative to v0.2.26.
Reuse every previously passing `.olean` from the persistent PASS-ONCE cache.
Lean compilation remains exclusively on the user's Windows compiler.
