# v0.2.16 — Section 2 ordinary-residue interpretation

**New and awaiting user-native Lean verification**

1. `S2_ResidueInterpretation.lean` — the actual coefficient conversion `r_a = c_a D_tail′(-a²)`; injectivity of the cleared numerator in the ordinary simple-pole residues; exact evaluation of `Q(t)+Σ c_a/(t+a²)` as the ratio of the cleared Lagrange numerator and `D_tail(t)` at every rational point off the poles; cross-multiplication uniqueness.
2. `S2_RationalEndpoint.lean` — a new aggregate of Section 2's previous `AlgebraicChain` plus ordinary-residue correctness, without any external Witness.
3. `S2_RationalAudit.lean` — precise `#check`/`#print axioms` outputs.

**Faithful scope**: This is a proof attempt for the fixed *finite tail pole lattice*, not a claim that every arbitrary rational function in `ℚ(X)` has been formalized as a quotient field element. No analytic results are hidden inside the finite algebraic certificate. Unchanged old sources preserve their PASS-ONCE eligibility.

**Compilation status**: v0.2.12 is the last user-reported full successful native build. v0.2.15 Section 2 additions have not been confirmed as passing by the user; v0.2.16 likewise remains pending. No local Lean compilation was performed.
