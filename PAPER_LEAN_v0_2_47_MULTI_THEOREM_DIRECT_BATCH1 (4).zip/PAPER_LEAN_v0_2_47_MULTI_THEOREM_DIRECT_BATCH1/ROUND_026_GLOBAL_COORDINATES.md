# Round 026: intrinsic global coordinates and cutoff-independent linear operations

Native Lean 4.33.0 PASS-ONCE continuation of the user-certified v0.2.25 checkpoint.

User compiler evidence at v0.2.25: `CHRONOLOGICAL_BUILD=PASS`, `PROJECT_MODULES_NEW_OR_CHANGED=5`, `PROJECT_MODULES_FROZEN_REUSED=125`; the axiom audit remains subject to inspecting the full compiler log. All 150 old Lean sources and all 130 previously compiled BUILD_GRAPH modules have been left **byte-for-byte unchanged** in v0.2.26. The additions below are uncompiled proposals until the user's native compiler approves them.

## New source modules (no sorry/admit/custom axioms)

1. `S2_GlobalCoordinates.lean`: intrinsic polynomial coordinate, intrinsic pole coefficients (at j=0 exactly zero), finite-support certificate, global quotient extensionality, finite exact X-slope for every rational moment.
2. `S2_GlobalGenerators.lean`: original polynomial generator and single negative-square simple-pole generator realized inside the global quotient; source equations (2.2) and (2.3) as actual quotient-level moment identities.
3. `S2_GlobalLinearOperations.lean`: common-cutoff addition and scalar multiplication, their congruence for arbitrary representatives, quotient descent, coordinate formulas, associativity, commutativity, scalar composition and scalar distributivity. Does not claim to have proved the full moment-functional additivity or installed a complete `Module ℚ` instance.
4. `S2_GlobalAudit.lean`: native theorem-type and axiom dependency audit.

## Outstanding mathematics

- Prove global moment functional additivity and Q-homogeneity (its polynomial-part finite coefficient sum requires a genuine linearity proof).
- Finish connecting the quotient rational functions to a standard rational-function algebra with a formally stated isomorphism, if the manuscript requires one.
- Preserve previously identified manuscript errata; do not assume Section 3--6 or an irrationality result.

**Only the user's native Lean compiler is a compilation authority.** This package has undergone source/import/ZIP checks only, no Lean compilation.
