# v0.2.25 — setoid proof rerun

This release preserves the v0.2.24 repaired `Setoid` equivalence proof, in
which `Equivalence.refl/symm/trans` use explicit binders. The reported error
came from v0.2.23 and predates that correction. This ZIP has a new,
unambiguous version name and `run.cmd` checks the repaired source before
compilation. All Lean sources are byte-for-byte identical to v0.2.24.

PASS-ONCE uses the existing persistent Windows compiler cache. No Lean
compilation occurred during packaging; the user's Lean 4.33.0 compiler
provides proof verification.
