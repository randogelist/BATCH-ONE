# Section 2 — algebraic closure round v0.2.13

**Aim:** near-complete formalization of the finite algebraic part of the paper, in source order, without `sorry`, `admit`, an added `axiom`, or an external Witness.

| PDF item | Status after v0.2.12 native PASS | New target in this round |
|---|---|---|
| Definition 2.1, (2.1)–(2.3) | finite definitions, moments and pole slope compiled | incorporated in unconditional `AlgebraicChain` |
| Lemma 2.2, (2.5) | generator and finite presentation identity compiled | canonical uniqueness of cleared finite partial fractions |
| Lemma 2.3, (2.6)–(2.7) | finite-span reflection and allowed simple-pole difference compiled | incorporated in unconditional chain |
| Theorem 2.4 | rational determinant transform and constructive primitive normalizations compiled | incorporated in unconditional chain |
| Theorem 2.5, (2.10)–(2.11) | derivative factorization, nonsingularity, affine pencil, exact degree compiled | Lagrange polynomial formula as a **cleared-denominator identity** and injective coefficient representation |

The actual partial-fraction **existence theorem** comes from `Zetahyperbolic.kernelNumerator_partial_fraction_exists`, not from an assumed existence witness. New uniqueness is `PaperChronological.Section2.normalizedPresentation_unique`. The full source-faithful aggregate is `PaperChronological.Section2.SECTION2_UNCONDITIONAL_ALGEBRAIC_CHAIN`.

**Limitations to retain:**
- Pending your native compilation: `Zetahyperbolic.LagrangeBasis` and the four new `PaperChronological/S2_*.lean` modules. No local compiler was run.
- The span formulation uses explicit canonical finite polynomial/pole presentations, not a separate quotient-field-type equality for every arbitrary rational function. The new uniqueness theorem proves injectivity of the normalized cleared-numerator map within each fixed finite pole set. Do not call the *full PDF* certified until that representation correspondence and the paper errata have been audited.
- The analytic positivity/irrationality assertions of Sections 3–6 remain outside this algebraic closure and are **not** postulated in any new theorem.
- Lean's ordinary logical axioms (`propext`, `Classical.choice`, `Quot.sound`) are allowed. The axiom audit must be inspected in `CHRONOLOGICAL_LEAN_433_LOG.txt`.

**PASS-ONCE:** 129 existing `.lean` files preserved exactly. One existing but previously *unbuilt* Lagrange-basis source is activated; four new sources are added. The user-reported v0.2.12 `CHRONOLOGICAL_BUILD=PASS` with 108 cached modules is the baseline. Only newly activated/new modules and their dependents should compile.

## v0.2.21
The exact affine Section 2 moment assembly source was revised to expose and verify individually the coefficient and summation identities. Native compilation pending.

## v0.2.26: native pending global linear-algebra extension

Proof targets: intrinsic coordinates of the quotient, finite support of residues, quotient extensionality, source-equation generator identities, and cutoff-independent addition/scalar operations. The full Q-linearity of the moment functional remains open until its polynomial finite coefficient sum is proved additive; this release does not pretend otherwise. The user reported v0.2.25 as successful (`5` compiled, `125` reused), and these existing proof source files are unchanged.

## v0.2.34 — full Q-linearity bridge pending native compiler
Bounded polynomial moments are identified with the support-sum definition and zero-padded pole moments are cutoff-independent. The preceding quotient's group/module instance and variable-size presentation arithmetic then furnish the actual `muRationalLinearMap` if all four new modules compile. Section 2 theorem-level coverage must be audited separately from module count.
