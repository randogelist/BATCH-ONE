# v0.2.30 — bounded moment linearity

This round adds two independent, source-faithful modules:

* `S2_TruncatedMomentLinearity.lean` — proves rational additivity and homogeneity for the Section 2 Bernoulli monomial coefficient sum, for the simple-pole residue sum, and for their combined polynomial moment, when both finite index bounds are fixed.
* `S2_TruncatedMomentAudit.lean` — checks their theorem statements and axioms with the user's Lean compiler.

The truncation at degree `P.natDegree + 1` and pole cutoff `R.maxPole` is definitionally the manuscript's existing `muFunctionalPoly`; therefore this is a mathematically exact finite-level decomposition, not a surrogate or an assumed functional. The final extension of this fixed-level linearity to input-dependent degrees and arbitrary quotient representatives is left as the next proof step, rather than claimed without a proof.

This package does not certify or claim the Riemann Hypothesis, ζ(5) irrationality, or the complete PDF. It preserves the previous source files and the PASS-ONCE cache and runs NO local Lean compiler.
