# v0.2.12 — finite sums

Failed module: `PaperChronological/T3_6_MomentGram.lean`.
Native error: `Finset.mul_sum` rewrite pattern not found after `Finset.sum_mul`.

Repair: explicitly factor the inner `j`-sum, then the outer `i`-sum,
and use `pow_two` in a final separate step. This keeps the atom `a` fixed
and preserves the order of bound indices.

Unchanged: the other 128 `.lean` files, theorem signatures and imports.
No local Lean compilation performed. The proof awaits the user's compiler.
