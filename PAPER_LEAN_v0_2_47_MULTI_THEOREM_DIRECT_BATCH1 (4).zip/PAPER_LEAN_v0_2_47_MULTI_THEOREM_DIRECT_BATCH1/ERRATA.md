# v0.2.15 repackage for rerun

The full v0.2.14 patch is retained. `S2_CanonicalPresentation.lean` contains `exact (poleIndex_injective p) hab`. The only runtime changes are a clearly printed v0.2.15 package name and a preflight check for that patch. The script preserves the existing user-side PASS-ONCE cache. No local Lean compilation performed.

# Exact errata that block formalization of the PDF as printed

The source is the 52-page PDF **Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values**, 21 October 2026. These are not Lean compilation difficulties. They are counterexamples to literal assertions.

## A. Corollary 3.5, equation (3.6), PDF p. 10

The article states `Delta_(h-1)(X)/Delta_h(X) = 1/(a_1+(X-xi)-b_1^2/(...))` where `a_i` are diagonal entries of the tridiagonal reduction of `B_hat= L^-1 M L^-T`. The formula is not normalized.

For `h=1`, `Delta_0 = 1`, `Delta_1(X)=g+(X-xi)m`, and `a_1=m/g`. The printed claim becomes

    1/[g+(X-xi)m] = 1/[m/g+(X-xi)].

At `X=xi` this requires `1/g=g/m`. In the actual `s=3,N=1,K=2,m_kernel=1` instance, direct calculation from equations (2.2)-(2.3) gives

    Delta_1(X) = 29/2 - 12 X,
    m = -12,
    g = Delta_1(zeta(3)) > 0

(the last inequality follows from Theorem 3.1's positive integral). Thus `1/g > 0` whereas `g/m < 0`. Contradiction.

**Correct general normalization:** if `G=LL^T`, `t=X-xi`, and `Bhat=L^-1 M L^-T`, then

    Delta_(h-1)(X) / Delta_h(X)
    = (det G_(h-1)/det G_h) * [(I+t Bhat)^-1]_(h,h).

A Lanczos J-fraction for this resolvent, when Lanczos does not break down, uses diagonal terms `1+t a_i`, off-diagonal terms `t^2 b_i^2`, and prefactor `det G_(h-1)/det G_h`. It is NOT the fraction printed in (3.6). When Lanczos terminates early, use the shorter fraction rather than require every `b_i>0`.

## B. Corollary 3.6, PDF p. 11

For `h` real roots and `q0` avoiding them, put `u_j=(r_j-q0)^(-2)>0`. Then `S_(2r)=sum_j u_j^r` and `dmin = (max_j u_j)^(-1/2)`.

The printed claim `1 <= S_(2r)^(-1/(2r))/dmin <= h^(1/(2r))` has its direction reversed. The correct inequality is

    h^(-1/(2r)) <= S_(2r)^(-1/(2r))/dmin <= 1.

For `h=2` and `u_1=u_2=1`, the ratio at `r=1` is `1/sqrt(2)<1`, a direct contradiction.

Further, a moment sequence supported on `d<=h` distinct points has Hankel matrix rank at most `d`; all `n x n` Hankel determinants with `n>d` vanish. Strict positivity holds only for `n<=d` (positive masses, distinct support), not at **all** orders as printed. In particular the single-atom matrix `[[1,u],[u,u^2]]` has determinant zero.

## C. Theorem 6.4(1), claimed positive weight, PDF pp. 33-34

The paper prints the differential identity

    W_β^+(y) = y^4/24 * (-4/pi^2 * d^3/dy^3 + d/dy)
                         [1/(2*cosh(pi*y/2))]
             = +pi^2*y^4*sinh(pi*y/2)/(16*cosh(pi*y/2)^4) > 0.

Set `z=pi*y/2`, `f(z)=1/(2*cosh(z))`. Differentiation gives

    (d/dz - d^3/dz^3) f(z) = -3*sinh(z)/cosh(z)^4.

Since `d/dy = (pi/2)*d/dz`, the **actual** expression on the left equals

    W_β^+(y) = -pi*y^4*sinh(pi*y/2) /
                  (16*cosh(pi*y/2)^4) < 0   for all y>0.

At y=1, the left side is approximately -0.0113992611892; the asserted right side is approximately +0.0358118352083. The problem is not a rounding error but an opposite sign (and a missing factor of pi in the asserted equality). The Vandermonde/character parity proof in parts (2)-(3) is algebraically separable but does **not** repair part (1).

The same theorem's proof uses the Euler integral `integral_0^infty y^(2e)/cosh(pi*y/2) dy = |E_(2e)|/2^(2e)`. At e=1 the left is exactly **1**, not 1/4, by `beta(3)=pi^3/32`. This is an additional normalization discrepancy.

## D. Other unresolved proof obligations (not claimed false here)

- Sections 2-3: the supplied assembled Lean chain proves general real-rootedness and an exact zero-free disk for the actual moment pencil. It does not by itself prove all of 3.2-3.9; especially the exact J-fraction is false as printed.
- Section 4: the source's theorem-named file for 4.4 has explicit `MainNormalization`, `BaseValuePositive`, `MultiplierUpper`, `ArchimedeanUpper`, `MainSpectralData` inputs; the more refined primitive version still takes the needed uniform estimates as inputs. These are not discharged merely by importing its theorem file.
- Section 5: the supplied source for 5.1 defines the rational dual moments but explicitly says the full two-variable integral identity is not proved. The source for 5.2 proves finite-certificate implications with an analytic tail premise, not the full unconditional Krein claims.
- Section 6: the module bearing the 6.3 title calls its proof a conditional replacement for part (2). The module bearing the 6.4 title explicitly does not establish the printed beta integral or full hyperbolicity claim.
- Conjecture 4.11 is not a theorem and should remain marked as a conjecture rather than be silently assumed or `by trivial`-proved.

### Certification rule

`#print axioms` showing only `propext`, `Classical.choice`, `Quot.sound` indicates no **custom axioms used by that theorem**, but does not imply its **arguments** have been constructed. Inspect each endpoint's full type. There is no legitimate way to replace these counterexamples by unchecked hypotheses and still certify this PDF unchanged.

## 2026-10-24 runner-only repair v0.2.5

A Windows sharing violation caused `PaperChronological/T5_1.lean` to fail
importing `Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7`. This is a
compiler cache/publication issue, not a new mathematical manuscript erratum.
All Lean theorem source files remain identical to v0.2.4.


## v0.2.7 - Theorem 6.10 wrapper scope fix (Lean diagnostic, 2026-10-24)

The user compiler reported `failed to synthesize PartialOrder (Matrix (Fin n) (Fin n) ℝ)`
at `PaperChronological/T6_10.lean:26:62`. The imported producer theorem already
uses `open scoped MatrixOrder`, which supplies the scoped matrix Loewner order
required to elaborate `CFC.sqrt A`. The wrapper now opens the same scope.
The normalized determinant identity is unchanged; this repair changes only
the local instance scope, not the theorem or its assumptions.
The CMD runner now recognizes Lean diagnostics of the form `error(lean.*)`
and does not retry deterministic elaboration errors three times.
Existing source `.olean` cache remains authoritative; only the updated wrapper
and local dependents need rechecking. No Lean compilation was performed.


## v0.2.10 -- compiler repair for T3_6_Corrected

Native Lean error: `Finset.single_le_sum` could not be applied by tactic directly to the
finite univ sum. The local lemma `hnonneg` is now supplied as an explicit term, with
`f` and `s` named. Only `PaperChronological/T3_6_Corrected.lean` changed. Theorem
3.6 is not claimed fully closed; this is a repair of one finite bound.

## v0.2.11: finite Gram sum-order correction

`PaperChronological/T3_6_MomentGram.lean` uses directed `rw [pow_two, Finset.sum_mul, Finset.mul_sum]` after a fixed-atom sum congruence, avoiding a reversed-index normal form. No theorem statement changed. Await user native compiler.


## v0.2.12 — Corollary 3.6 finite sum product expansion

Native Lean 4.33.0 compiler (user machine) rejected the `Finset.mul_sum` rewrite
in `PaperChronological/T3_6_MomentGram.lean` line 80 after the previous
`Finset.sum_mul` rewrite. The replacement is a three-stage `calc` in which
the inner multiplication, outer multiplication, and square rewriting are
separate goals; the dummy sum indices remain ordered `i` then `j`. No
statements, dependencies or hypotheses change. Compiler verification is pending.

## v0.2.14 Section 2 injectivity application correction

`PaperChronological/S2_CanonicalPresentation.lean` at the proof of `L_eval`: the forward direction of the biconditional now introduces `hab` and applies `(poleIndex_injective p) hab`. The previous term supplied the injectivity theorem without an equality argument and did not elaborate. This is a tactic-term correction only; theorem statements and mathematical assumptions are unchanged. Await user native Lean 4.33.0 compilation.

## v0.2.21
Repair to two finite-sum normalization goals in `S2_ExactPencilAssembly.lean` with explicit finite-sum lemmas. User compiler still required.

### v0.2.22 native compile repair

`S2_IndependentKernelBridge.lean`: normalize the `asHankelParams` tail
interval definitionally with `change` before rewriting by the already proved
`tailD_derivative_eval`. Pending user-side verification.

## v0.2.28 — quotient addition congruence

Reordered the four representatives in the congruence proof supplied to `Quotient.liftOn₂` in `S2_GlobalLinearOperations.lean`. The kernel-proved `sameFinitePoleData_add` takes two equality pairs `(R,R')` and `(S,S')`, whereas Lean supplies representatives `(r,r')` and their equivalent copies `(s,s')`. The source now passes `(r,s,r',s')`, aligning the setoid hypotheses without changing theorem statements. All other Lean sources remain unchanged. Native compiler validation pending.

### v0.2.32 — native quotient arithmetic elaboration

Added explicit `Zero`, `Add`, `Neg`, `Sub` primitive instances before the `AddCommGroup` construction, so `nsmulRec` and `zsmulRec` can elaborate. No existing proved theorem is changed. Await native compiler.


# v0.2.38 — Section 2 native LinearMap scalar fix

The native Windows Lean 4.33.0 compiler reported in
`PaperChronological/S2_GlobalMomentLinearMap.lean:24:4` that `change`
was not definitionally equal to the target required by `map_smul'`.
The source replaces the `change` tactic with an explicit rewrite using
`RingHom.id_apply` and Mathlib's verified theorem
`Polynomial.smul_eq_C_mul`.

The proof calls the previously established
`muOnRationalDomain_smul k q R` without new axioms, conditions or changes
to its mathematical statement.

All other Lean sources are preserved byte-for-byte from v0.2.37;
PASS-ONCE retains already-compiling modules in the Windows cache and
rebuilds only changed sources and their import dependents.
No Lean compilation was performed while creating this archive.

## v0.2.44
- Strict Theorem 3.7 product factorization: removed nonexistent `Finset.not_mem_erase`, replaced with explicit `by simp` nonmembership and `Finset.prod_insert`. Pending Windows native Lean certification.
