# Round 022 — Section 2 independent kernel bridge

Native compiler identified an elaborator rewrite mismatch in
`PaperChronological/S2_IndependentKernelBridge.lean:90`: the existing
`kernelRatElem_poleRes_eq_prod` uses the pole interval projected from
`asHankelParams p hp`, while `tailD_derivative_eval` is stated with the
original `p.N` and `p.K` interval. Both are definitionally equal.

The repair inserts an explicit `change` to the original pole-indexed
product before applying the existing derivative-evaluation lemma. No
statement, hypothesis, quotient, residue or imported theorem is changed.

Only `S2_IndependentKernelBridge.lean` is a modified Lean source; all
other Lean sources are byte-identical to v0.2.21 and remain PASS-ONCE
cache candidates. This fix is **not locally Lean-compiled** and awaits
the user's native Lean 4.33.0 compiler.
