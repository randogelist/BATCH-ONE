# PASS-ONCE / FREEZE / INCREMENTAL

The authoritative certificate is the user's native Lean 4.33.0 output.

- Source equality: every reusable module must match the exact cached source bytes (Windows `fc /B`).
- Dependency equality: all local imports are represented in a topologically validated build graph, and recompilation propagates only along those edges.
- Toolchain equality: pinned Lean executable, Mathlib `.olean`, and the standard library command `.olean` metadata must match the cache signature.
- Proof success: cached `.olean` and source snapshots are created only after the user's `lean.exe` returns success.
- Audits: auditor modules are cached under the same rule, rather than rerun unconditionally. New audits are separate modules and run on first native build.
- Proven source content is frozen across release packages. `MAIN_CHAIN_UNCONDITIONAL` remains the prior theorem; new mathematics is appended via `INCREMENTAL_CHAIN` rather than rewriting old imports.

**First-run caveat:** the user has not supplied a confirmed successful native compilation log for the v0.2.2 ZIP in this conversation. If that older build has no valid cache in Downloads, the first native run must compile the baseline exactly once. No packaging-time certification has been claimed.

**Source-level scope:** the new span theorems work with the paper's finite generator presentations; remaining analytic and number-theoretic assertions are not discharged.

## v0.2.5 Windows lock recovery

The previous Windows run exhibited sharing violations when publishing/importing
`Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7.olean`, followed by
`unknown module prefix` in `PaperChronological/T5_1.lean`. These two files
were not both verified and are NOT frozen as passing.

The new runner does not invoke another Lean run during packaging. On the user's
compiler it isolates each compilation in a per-module log and staging folder,
checks compiler exit and .olean existence, then atomically publishes the olean
and PASS stamp. Temporary locks are retried (up to three attempts, serial for
retry). One-time recertification of the producer is recorded in persistent cache.
The build graph and all Lean sources remain unchanged.


## v0.2.8: abandoned-run lock recovery

The runner owns `%USERPROFILE%\lean-native\paper_chronological_fastcore_433\active_run.lock`.
Normal runs refuse to overwrite this directory. After a terminated/failed prior run
leaves it behind, and after confirming NO other Lean run is active, run
`call run.cmd recover`. This checks for an active `lean.exe`, deletes ONLY the
abandoned `active_run.lock` directory, acquires a fresh lock, and resumes all
uncertified modules. Existing `lib\lean` and `source_stamps` are preserved.
If any `lean.exe` process is active, recovery refuses to run.
The `recover` mode is explicitly opt-in because no PID-based ownership record
exists for prior lock directories; do not run two package instances concurrently.
On normal successful or failed exit the runner now recursively cleans its own
lock directory and reports cleanup failure.
