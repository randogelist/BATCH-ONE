# v0.2.38 — Section 2 native LinearMap scalar fix

The native Windows Lean 4.33.0 compiler reported in
`PaperChronological/S2_GlobalMomentLinearMap.lean:24:4` that `change`
was not definitionally equal to the target required by `map_smul'`.
The source replaces the `change` tactic with an explicit rewrite using
`RingHom.id_apply` and Mathlib's verified theorem
`Polynomial.smul_eq_C_mul`.

The proof calls the previously established
`muOnRationalDomain_smul k q R` without new axioms, conditions or changes
to its mathematical statement.

All other Lean sources are preserved byte-for-byte from v0.2.37;
PASS-ONCE retains already-compiling modules in the Windows cache and
rebuilds only changed sources and their import dependents.
No Lean compilation was performed while creating this archive.
