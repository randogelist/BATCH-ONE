# Native Lean 4.33.0 — principal theorem stage 3

## Direct source-faithful mathematical endpoints

### Theorem 3.3: signed derivative quadratic form
`THEOREM_3_3_ACTUAL_HANKEL_SIGNED_QUADRATIC` proves the actual rational
Hankel derivative matrix (from manuscript Theorem 2.5) satisfies exactly

  xᵀ M x = Σ_a γ_a (Σ_i V_ia x_i)²

at every finite dimension. No positive-semidefinite substitute is used:
γ_a is allowed to be negative. The precise alternating-sign parity,
Sylvester inertia count and full continuous strict total positivity remain
open as separate mathematical assertions.

### Theorem 3.7: strict ordinary-derivative Turan
`THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_OFF_ROOTS` proves for the actual odd-zeta
Hankel determinant in dimension h>0:

  P'(x)^2 - P(x) P''(x) > 0 whenever P(x) ≠ 0.

`THEOREM_3_7_ACTUAL_ODD_ZETA_STRICT_AT_CENTER` proves the strict inequality
at x=ζ(s) unconditionally, using the upstream actual Gram positivity and
spectral factorization. No arithmetic witness. The higher-derivative
inequalities and Newton normalized-coefficient inequalities are not yet
proved.

### Theorem 3.8: exact pole-kernel determinant
`THEOREM_3_8_ACTUAL_POLE_KERNEL_DETERMINANT` proves the actual finite
manuscript pencil derivative matrix M=V diag(γ) Vᵀ satisfies

  det(HM) = det(diag(γ) Vᵀ H V)

for any rational matrix H. This is the determinant-level algebraic part of
the Christoffel-Darboux pole-kernel statement. The full characteristic-
polynomial spectral equivalence with the actual ζ(s) Gram inverse and the
analytic Jacobi deformation identity remain open.

## Certification and chronology
The full source of v0.2.41 is carried forward unchanged. The five new
modules are appended to BUILD_GRAPH.txt and compiled after their imports.
The native Windows Lean 4.33.0 compiler is the sole compilation authority;
no Lean compilation was performed when authoring this package.

Only standard Lean foundations `propext`, `Classical.choice`, `Quot.sound`
are permitted. See PRINCIPAL_STAGE3_AUDIT for the theorem/axiom printout.
Any `sorryAx` or new nonstandard axiom must block certification.

This is a direct principal-theorem proof increment, **not** a claim of
complete PDF formalization or a proof of ζ(5) irrationality.
