# Chronological PDF large-batch rebuild — 2026-10-24

### Substantive developments in this single package

- Corollary 3.5: exact 3-step tridiagonal determinant and corrected resolvent identity.
- Corollary 3.6: 2-atom rank obstruction (positive 2x2, identically zero 3x3).
- Theorem 3.8(1): correction of forbidden Lean binder `λ`; preserved actual zeta-centered pole-kernel charpoly theorem.
- Theorem 3.9: positivity of all five full rational character generating kernels, with independent denominator bound.
- Proposition 4.8: n-dimensional lower and upper root-product bounds and an actual odd-zeta-center factor-product estimate from Theorem 3.1.
- Theorem 5.2(1): exact rectangular `CCᵀ` quadratic sum of squares with nonnegative and strict-positive forms.
- Theorem 6.1: rational harmonic successor and adjacent divided-difference identities.

### Qualification

A matching theorem name never means an entire manuscript theorem is proved when
an analytic, p-adic, asymptotic, or normalization bridge remains. The new
mathematical statements are local and unconditional, not new `Witness` fields.
No Lean compilation took place during packaging. Only user's native
Lean 4.33.0 machine certifies these sources.

### Previously confirmed baseline

v0.2.44: 157 frozen/reused project modules, CHRONOLOGICAL_BUILD=PASS.
v0.2.46: Principal_T3_8_CharacteristicSpectrum uncompiled due invalid binder.
The PASS-ONCE cache is NOT copied or modified by this ZIP.
