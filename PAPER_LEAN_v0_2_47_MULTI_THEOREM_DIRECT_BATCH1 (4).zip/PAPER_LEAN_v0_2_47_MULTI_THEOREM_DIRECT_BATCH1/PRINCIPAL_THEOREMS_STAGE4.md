# Principal theorem direct extension — round v0.2.45

## Already native-PASS in v0.2.44

Windows Lean 4.33.0 runner reported CHRONOLOGICAL_BUILD=PASS with
PROJECT_MODULES_FROZEN_REUSED=157, NEW_OR_CHANGED=0. These frozen sources
are UNCHANGED by this package. This is a build fact; it does not
certify that every PDF statement is represented or that all axioms were
audited in the printed log.

## New mathematical theorems, pending native compilation

1. Theorem 3.8(1): use `Matrix.charpoly_mul_comm` to upgrade equality
   of determinants to equality of characteristic POLYNOMIALS, uniformly
   in dimension, valid over every commutative ring.
2. Transport the actual rational pole Vandermonde congruence to REALS,
   without a hypothetical matrix factorization.
3. Apply the formula to H=G(zeta(s))^{-1}. This directly proves the
   paper's finite pole-kernel spectrum identity (including multiplicities)
   in its actual center Gram representation. No witness hypothesis.
4. Theorem 4.7(2): derive the exact (all weights, all finite dimensions)
   bilateral root-separation lower bound 2*zeroFreeRadius from the actual
   nonvanishing disk constructed in Theorem 3.1. No guessed numerical
   estimates, no witness hypothesis.

## Clearly open, not disguised

- The paper's tau-parametric Jacobi integral formula, Theorem 3.8(2).
- Its quantitative estimate zeroFreeRadius >= exp(-11.411*K), needed to
  specialize Theorem 4.7(2) to the printed numerical value.
- Theorem 3.3 continuous-measure strict total positivity, Carleman,
  and exact alternating spectral inertia counts.
- Full Section 4 arithmetic decay, integrality/prime valuations.

No local compilation was executed. The user Windows native compiler is
sole authority. PASS-ONCE source stamps and oleans are preserved.
