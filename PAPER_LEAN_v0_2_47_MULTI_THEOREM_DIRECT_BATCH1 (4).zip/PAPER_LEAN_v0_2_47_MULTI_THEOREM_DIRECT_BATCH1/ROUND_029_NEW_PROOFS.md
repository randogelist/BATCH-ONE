# Proof round 0.2.9: the first incomplete spectral block

- All 124 source files inherited from v0.2.8 are byte-for-byte unchanged.
- 5 new Lean sources: T3_3_TwoAtom, T3_5_CorrectedTwoByTwo,
  T3_6_MomentGram, NEXT_PROOF_CHAIN, NEXT_PROOF_AUDIT.
- Actual progress (if compiled): exact two-atom strict 2×2 Hankel minor,
  normalized two-by-two Schur continued fraction and its affine specialization,
  general finite-atomic Vandermonde Gram identity and PSD quadratic identity.
- No proof of infinite-dimensional Carleman / total positivity or complete
  principal-minor interlacing is claimed.
- The printed Corollary 3.5 and 3.6 require corrections; our added claims
  use the corrected formulas.
- All old unmodified sources should be frozen in the user's PASS-ONCE cache;
  previous final output shows compilation progress to T6_18, but not a final
  RUN=PASS; this package never promotes that unconfirmed result.
- The sole designated quantitative input remains PaperNative.Witness.
- No local Lean compilation was performed. Compile on Windows Lean 4.33.0.
