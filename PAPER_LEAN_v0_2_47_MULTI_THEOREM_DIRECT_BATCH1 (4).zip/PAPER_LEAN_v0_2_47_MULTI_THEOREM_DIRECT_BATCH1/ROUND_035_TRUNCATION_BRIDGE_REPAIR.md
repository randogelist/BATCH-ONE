# Round 35: compiler-first repair to bounded moment bridge

## Prior native output
`S2_GlobalMomentBounded.lean` failed at lines 33, 34, and 46. All previously passed modules remain frozen under the PASS-ONCE cache.

## Repairs
* Use `Polynomial.sum_over_range'`, whose required premises are `(∀ n, f n 0 = 0)`, a cutoff `B`, and `P.natDegree < B`. The earlier invocation of `sum_over_range` mistakenly gave `hB` as the zero-summand hypothesis, because that lemma fixes its bound to `P.natDegree+1`.
* The `Finset.sum_subset` theorem requires the same summand on both sides; first use zero-padded residues on both sides of the interval-extension identity, then recover actual residues over the original interval via `Finset.sum_congr`.
* The mathematical statements, finite moment definitions, and global linear map obligations are unchanged.

## Certification
No local Lean compiler was run. The user's native Lean 4.33.0 FASTCORE and persistent PASS-ONCE cache alone certify this delta.
