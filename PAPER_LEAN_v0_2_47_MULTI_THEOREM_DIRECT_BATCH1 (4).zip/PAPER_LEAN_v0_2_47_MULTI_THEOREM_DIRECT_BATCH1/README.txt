PAPER CHRONOLOGICAL NATIVE LEAN v0.2.3 -- PASS ONCE
================================================

COPY INTO WINDOWS CMD (FROM Downloads):
cd /d "%USERPROFILE%\Downloads" && tar -xf "PAPER_CHRONOLOGICAL_NATIVE_LEAN_v0_2_3_PASS_ONCE_SECTION2_SPAN.zip" && call "PAPER_CHRONOLOGICAL_NATIVE_LEAN_v0_2_3_PASS_ONCE_SECTION2_SPAN\run.cmd"

Lean 4.33.0 Windows native, -j 16, cached Mathlib, no Lake/network.
NO LOCAL COMPILATION was performed in producing this package.

COMPILATION RULE
---------------
All previously shipped 119 Lean files are byte-for-byte unchanged.
New files: PaperChronological/T2_2_Span.lean, T2_3_Span.lean,
T3_6_Corrected.lean, INCREMENTAL_CHAIN.lean, INCREMENTAL_AUDIT.lean.

After the FIRST successful native compile of a module, its compiled .olean
and exact source snapshot remain in:
%USERPROFILE%\lean-native\paper_chronological_fastcore_433
This folder SURVIVES extraction of subsequent paper ZIP releases.

Unchanged source AND unchanged dependencies -> FROZEN_REUSE, no compilation.
New/modified source OR imported module changed -> compile just those affected.
When the Lean binary/Mathlib root cache changes -> rebuild project only.
Optional `run.cmd full` triggers explicit project-only rebuild.

The runner can import successful prior modules from version 0.2.2's .build
folder in Downloads if its toolchain signature matches and a PASS log exists.
Each migrated module is still checked bytewise against this release.

The new source-level Section 2 finite-span theorems are NOT user-compiler
verified until the native log says PASS. They do not establish all of the
PDF's later analytical, arithmetic and valuation claims.

Output log: CHRONOLOGICAL_LEAN_433_LOG.txt
One ZIP / one run.cmd; only user compiler runs Lean.


v0.2.4 FIX1 (24 October 2026):
  PaperChronological/T3_5.lean: remove redundant `ring` after `field_simp [hg]`
  after native Lean reports `No goals to be solved` at 24:2.
  Cached PASS-ONCE outputs for unchanged modules are preserved.
  No local Lean compiler was run during this repair.


v0.2.5 WIN_LOCK_SAFE_FIX1 (24 October 2026):
  Fixes transient Windows sharing violations while building Theorem 5.1.
  The source graph is unchanged and already places Theorem 5.1 before T5_1.
  Uses private compiler logs and staged .olean files, atomic publishing,
  validates .olean and stamps, and retries transient failures using -j 1.
  Forces a one-time clean rebuild ONLY of the uncertified lock-affected
  Theorem 5.1 module and its dependent modules, then freezes them on PASS.
  Keeps the same user-side persistent cache signature and locations.
  All Lean source files remain byte-for-byte unchanged; no local compilation.

V0.2.16 ADDITION: S2_ResidueInterpretation / S2_RationalEndpoint / S2_RationalAudit; native compilation only.

ROUND 017: universal finite pole domain, moment reconciliations, residue linearity, stable cutoff. See ROUND_017_UNIVERSAL_FINITE_POLE.md.

ROUND 018: S2 directed-union rational moments and evaluation; native proof audit pending.
