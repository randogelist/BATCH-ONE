# Round 017 - Section 2 universal finite-pole and moment bridge

## Mathematical scope (fully source-faithful)

A finite presentation consists of Q(t) and coefficients c_j, 1 <= j <= J:

  R(t) = Q(t) + sum_{j=1}^J c_j/(t+j^2).

The genuine cleared numerator is

  N_R(t) = Q(t) D_J(t) + sum_j c_j D_J'(-j^2) L_j(t),
  D_J(t) = product_{j=1}^J (t+j^2).

1. `allPoleNumerator_unique`: equality of cleared numerators yields equality
   of the polynomial part and ALL finite residues, uniformly for J>=0.
2. `allPole_fraction_evaluation`: N_R/D_J realizes the indicated fraction
   at every point outside the pole lattice. The proof is purely algebraic.
3. `monomial_moment_agreement`: the Real and Zetahyperbolic Bernoulli
   definitions are identical.
4. `harmonic_moment_agreement`: the range-sum and Icc-sum definitions of
   generalized harmonic numbers agree for all weights and cutoffs.
5. `simple_pole_moment_affine`: identity (2.3) agrees in BOTH its slope and
   intercept across the two existing implementations.
6. `finiteMomentPolynomial_slope`: the coefficient of X is exactly
   sum_j c_j j^(2k); polynomial moments do not alter the slope.
7. `clearedResidue_add` and `_scale`: linearity of actual rational
   presentations, not just their synthetic indices.
8. `exact_hankel_moment_pencil`: the functional built from the specified
   quotient and residue formulas agrees with the source pencil entry by entry.
   The explicit Real-kernel partial-fraction reconstruction still requires
   its own proof and is not smuggled into this theorem.
9. `kernelResidue_agreement`: the two independently constructed kernel
   numerators coincide and the residue produced by Mathlib's partial
   fractions agrees with the derivative-residue formula at every tail pole.
10. `muFunctionalPoly_extendCutoff_iterate`: increasing a finite pole cutoff
   by any finite number of zero-residue poles leaves mu unchanged.
11. `SECTION2_ALL_FINITE_POLE_CHAIN`: bundles these proven component
   statements; no new hypothesis or Witness appears.

## Important completeness boundary

These are additive proof targets, not a pre-certified claim that the paper is
100% formalized. The Real-kernel quotient/remainder reconstruction remains
an independent algebraic obligation. The material does NOT prove the analytic identification
(3.2), the quantitative decay of Section 4, or every assertion in Sections
3-6. The original v0.2.16 additions have not yet returned a compiler PASS.

All v0.2.16 Lean sources are unchanged, and all new Lean files appear in
BUILD_GRAPH.txt in topological import order. PASS-ONCE cache is preserved.
No Lean compilation was run while generating this package.
