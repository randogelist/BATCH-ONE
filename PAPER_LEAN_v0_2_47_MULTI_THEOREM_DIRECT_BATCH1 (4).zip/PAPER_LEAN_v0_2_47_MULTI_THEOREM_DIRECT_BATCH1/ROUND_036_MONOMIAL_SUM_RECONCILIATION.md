# Round v0.2.36 — explicit finite-sum / polynomial-moment conversion

The native compiler reported the `sum_over_range'` equality in
`S2_GlobalMomentBounded.lean` could not be closed by `simpa` because the
range sum retained `Zetahyperbolic.muMonomial` while the polynomial moment
expanded to `ManuscriptChain.Real.monomialMoment`.

The source now proves the range-to-support equality first, then applies
`muMonomial_eq_monomialMoment` term-by-term under `Finset.sum_congr`.
No statement is changed or weakened. Only this Lean proof module is edited;
all other Lean source modules are byte-identical to v0.2.35.

Build: user-side only, Lean 4.33.0; PASS-ONCE cache retained; no local Lean
compilation performed. Full Section 2 closure and final axiom audit remain
subject to the user's native compiler.
