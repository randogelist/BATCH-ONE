import PAPER_CHRONOLOGICAL_CHAIN
import Theorem_3_3_Discrete_Total_Positivity_Samples
import Theorem_3_4_Dodgson_Three_By_Three

/-!
# Incremental manuscript chronology — 83 frozen modules + 3 new modules

Section 2 and the previously compiled Section 3 core are imported as proven.
The new order-two/order-three finite Gram certificates belong to Theorem 3.3.
The two exact 3×3 Jacobi identities belong to Theorem 3.4.
The manuscript's full continuous total positivity and arbitrary-size
interlacing require further proofs; the new theorems do NOT assume them.
The single Section 4 Witness is not used by this unconditional extension.
-/

namespace PaperChronology

/-- Unconditional finite two-atom strict Gram determinant. -/
theorem paper_theorem_3_3_two_atom_positive
    (a b u v : ℝ) (ha : 0 < a) (hb : 0 < b) (huv : u ≠ v) :
    0 < Theorem3_3.DiscreteSamples.twoMoment a b u v 0 *
        Theorem3_3.DiscreteSamples.twoMoment a b u v 2 -
      Theorem3_3.DiscreteSamples.twoMoment a b u v 1 *
        Theorem3_3.DiscreteSamples.twoMoment a b u v 1 :=
  Theorem3_3.DiscreteSamples.two_atom_hankel_det_pos a b u v ha hb huv

/-- Unconditional order-three specialization of the PDF Dodgson sign law. -/
theorem paper_theorem_3_4_dodgson_order_three
    (m0 m1 m2 m3 m4 : ℝ) (hm0 : 0 < m0)
    (hminor : m0 * m2 - m1 ^ 2 = 0) :
    Theorem3_4.Dodgson3.det3 m0 m1 m2 m3 m4 ≤ 0 :=
  Theorem3_4.Dodgson3.det3_nonpos_at_minor_root
    m0 m1 m2 m3 m4 hm0 hminor

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_3_two_atom_positive
#print axioms PaperChronology.paper_theorem_3_4_dodgson_order_three
