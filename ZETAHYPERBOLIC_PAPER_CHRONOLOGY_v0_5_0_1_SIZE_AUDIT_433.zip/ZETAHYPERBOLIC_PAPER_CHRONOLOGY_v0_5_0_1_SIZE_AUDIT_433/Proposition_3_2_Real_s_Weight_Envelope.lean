import Proposition_3_2_Real_s_Gram_Measure
import Theorem_3_1_Concrete_Moment_Realization
import Mathlib.Tactic

/-!
# Proposition 3.2: uniform odd-weight envelope for the continuous real-s weight

The actual density in the PDF is bounded pointwise by a positive linear
combination of TWO densities already verified in the odd-weight branch:
weights 1 and 2*k+1.  The interpolation is elementary:

  t^(s-1) <= 1 + t^(2*k),  1 < s <= 2*k+1, t > 0.

Apply this to t=(n+1)*y in every summand and sum using summability of
all three infinite series.  This is not an assumed estimate: the constants
are the exact ratios of the gamma and factorial normalizations.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory Set

namespace PaperChronology.Proposition3_2.Envelope

open PaperChronology.Proposition3_2.Analytic

/-- Common normalizing coefficient of the real-s density. -/
def realCoefficient (s : ℝ) : ℝ :=
  2 * (2 * Real.pi) ^ (s - 1) / Real.Gamma s

/-- Normalizing coefficient of the odd-integer density. -/
def oddCoefficient (k : ℕ) : ℝ :=
  2 * (2 * Real.pi) ^ (2 * k) / (Nat.factorial (2 * k) : ℝ)

lemma realCoefficient_pos (s : ℝ) (hs : 1 < s) :
    0 < realCoefficient s := by
  unfold realCoefficient
  exact div_pos (mul_pos (by norm_num) (Real.rpow_pos_of_pos (by positivity) _))
    (Real.Gamma_pos_of_pos (by linarith))

lemma oddCoefficient_pos (k : ℕ) : 0 < oddCoefficient k := by
  unfold oddCoefficient
  positivity

/-- We can always choose an odd integer weight at least as large as s. -/
lemma exists_odd_upper (s : ℝ) :
    ∃ k : ℕ, s - 1 ≤ ((2 * k : ℕ) : ℝ) := by
  obtain ⟨k, hk⟩ := exists_nat_gt (s - 1)
  refine ⟨k, ?_⟩
  have hkk : (k : ℝ) ≤ ((2 * k : ℕ) : ℝ) := by
    exact_mod_cast (show k ≤ 2 * k by omega)
  exact (le_of_lt hk).trans hkk

/-- The elementary interpolation inequality, valid on both sides of t=1. -/
lemma rpow_le_one_add_pow (s : ℝ) (k : ℕ) (hs : 1 < s)
    (hsk : s - 1 ≤ ((2 * k : ℕ) : ℝ))
    {t : ℝ} (ht : 0 < t) :
    t ^ (s - 1) ≤ 1 + t ^ (2 * k) := by
  by_cases ht1 : t ≤ 1
  · have h := Real.rpow_le_one ht.le ht1 (by linarith : 0 ≤ s - 1)
    exact h.trans (by nlinarith [pow_nonneg ht.le (2 * k)])
  · have ht1' : 1 ≤ t := le_of_lt (lt_of_not_ge ht1)
    calc
      t ^ (s - 1) ≤ t ^ (((2 * k : ℕ) : ℝ)) :=
        Real.rpow_le_rpow_of_exponent_le ht1' hsk
      _ = t ^ (2 * k) := by rw [Real.rpow_natCast]
      _ ≤ 1 + t ^ (2 * k) := by linarith

/-- Pointwise domination of the n-th summand; no summation interchange. -/
lemma realTerm_le_oddTerms (s : ℝ) (k n : ℕ) (hs : 1 < s)
    (hsk : s - 1 ≤ ((2 * k : ℕ) : ℝ)) {y : ℝ} (hy : 0 < y) :
    y ^ s * exponentialTerm s n y ≤
      y * ManuscriptChain.Hyperbolic.exponentialTerm 0 n y +
      y ^ (2 * k + 1) * ManuscriptChain.Hyperbolic.exponentialTerm k n y := by
  let x : ℝ := ((n + 1 : ℕ) : ℝ)
  have hx : 0 < x := by dsimp [x]; positivity
  have hyPower : y ^ s = y ^ (s - 1) * y := by
    -- Rewrite the exponent on the LEFT only. Rewriting `s` globally can
    -- also change the occurrence inside `s - 1` on the right.
    have hs : s = (s - 1) + (1 : ℝ) := by ring
    calc
      y ^ s = y ^ ((s - 1) + (1 : ℝ)) := congrArg (fun a : ℝ => y ^ a) hs
      _ = y ^ (s - 1) * y := by
        rw [Real.rpow_add hy, Real.rpow_one]
  have hidentity : y ^ s * x ^ (s - 1) = y * (x * y) ^ (s - 1) := by
    rw [hyPower, Real.mul_rpow hx.le hy.le]
    ring
  have hodd :
      y * (1 + (x * y) ^ (2 * k)) = y + y ^ (2 * k + 1) * x ^ (2 * k) := by
    calc
      y * (1 + (x * y) ^ (2 * k)) = y + y * (x ^ (2 * k) * y ^ (2 * k)) := by
        rw [mul_add, mul_one, mul_pow]
      _ = y + y ^ (2 * k + 1) * x ^ (2 * k) := by
        rw [show 2 * k + 1 = (2 * k) + 1 by omega, pow_succ]
        ring
  have hbound :
      y ^ s * x ^ (s - 1) ≤ y + y ^ (2 * k + 1) * x ^ (2 * k) := by
    calc
      y ^ s * x ^ (s - 1) = y * (x * y) ^ (s - 1) := hidentity
      _ ≤ y * (1 + (x * y) ^ (2 * k)) :=
        mul_le_mul_of_nonneg_left
          (rpow_le_one_add_pow s k hs hsk (mul_pos hx hy)) hy.le
      _ = _ := hodd
  have he : 0 ≤ Real.exp (-(2 * Real.pi * y) * x) := (Real.exp_pos _).le
  change y ^ s * (x ^ (s - 1) * Real.exp (-(2 * Real.pi * y) * x)) ≤
    y * (x ^ (2 * 0) * Real.exp (-(2 * Real.pi * y) * x)) +
    y ^ (2 * k + 1) * (x ^ (2 * k) * Real.exp (-(2 * Real.pi * y) * x))
  calc
    y ^ s * (x ^ (s - 1) * Real.exp (-(2 * Real.pi * y) * x)) =
        (y ^ s * x ^ (s - 1)) * Real.exp (-(2 * Real.pi * y) * x) := by ring
    _ ≤ (y + y ^ (2 * k + 1) * x ^ (2 * k)) *
          Real.exp (-(2 * Real.pi * y) * x) :=
          mul_le_mul_of_nonneg_right hbound he
    _ = _ := by simp only [mul_zero, pow_zero, one_mul]; ring

/-- Summing the termwise bound for the ACTUAL infinite series. -/
theorem raw_realWeight_le_oddShapes (s : ℝ) (k : ℕ) (hs : 1 < s)
    (hsk : s - 1 ≤ ((2 * k : ℕ) : ℝ)) {y : ℝ} (hy : 0 < y) :
    y ^ s * exponentialSeries s y ≤
      y * (∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm 0 n y) +
      y ^ (2 * k + 1) *
        (∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm k n y) := by
  have hleft : Summable (fun n : ℕ => y ^ s * exponentialTerm s n y) :=
    (summable_exponentialTerm s hy).mul_left _
  have hright0 : Summable (fun n : ℕ =>
      y * ManuscriptChain.Hyperbolic.exponentialTerm 0 n y) :=
    (ManuscriptChain.Hyperbolic.summable_exponentialTerm 0 hy).mul_left _
  have hrightk : Summable (fun n : ℕ =>
      y ^ (2 * k + 1) * ManuscriptChain.Hyperbolic.exponentialTerm k n y) :=
    (ManuscriptChain.Hyperbolic.summable_exponentialTerm k hy).mul_left _
  have hsum := Summable.tsum_le_tsum
    (fun n => realTerm_le_oddTerms s k n hs hsk hy)
    hleft (hright0.add hrightk)
  calc
    y ^ s * exponentialSeries s y =
        ∑' n : ℕ, y ^ s * exponentialTerm s n y := by
          simp only [exponentialSeries, tsum_mul_left]
    _ ≤ ∑' n : ℕ,
        (y * ManuscriptChain.Hyperbolic.exponentialTerm 0 n y +
          y ^ (2 * k + 1) * ManuscriptChain.Hyperbolic.exponentialTerm k n y) := hsum
    _ = _ := by
      rw [hright0.tsum_add hrightk, tsum_mul_left, tsum_mul_left]

/-- The odd-weight density is exactly the corresponding raw series times
its nonzero, positive normalization. -/
lemma oddDensity_eq_coefficient_mul (k : ℕ) (y : ℝ) :
    ManuscriptChain.Hyperbolic.density k y =
      oddCoefficient k *
        (y ^ (2 * k + 1) *
          (∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm k n y)) := by
  unfold ManuscriptChain.Hyperbolic.density oddCoefficient
  ring

lemma rawOdd_eq_coefficient_inv_mul (k : ℕ) (y : ℝ) :
    y ^ (2 * k + 1) *
        (∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm k n y) =
      (oddCoefficient k)⁻¹ * ManuscriptChain.Hyperbolic.density k y := by
  rw [oddDensity_eq_coefficient_mul]
  have hc : oddCoefficient k ≠ 0 := ne_of_gt (oddCoefficient_pos k)
  field_simp

/-- The actual real-s weight is bounded by a positive linear combination
of the explicitly constructed odd-integer weights 1 and 2*k+1. -/
theorem realWeight_le_oddWeights (s : ℝ) (k : ℕ) (hs : 1 < s)
    (hsk : s - 1 ≤ ((2 * k : ℕ) : ℝ)) {y : ℝ} (hy : 0 < y) :
    realWeight s y ≤
      (realCoefficient s / oddCoefficient 0) *
        ManuscriptChain.Hyperbolic.density 0 y +
      (realCoefficient s / oddCoefficient k) *
        ManuscriptChain.Hyperbolic.density k y := by
  have hr := raw_realWeight_le_oddShapes s k hs hsk hy
  have hc : 0 ≤ realCoefficient s := (realCoefficient_pos s hs).le
  have h := mul_le_mul_of_nonneg_left hr hc
  have hzero :
      y * (∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm 0 n y) =
        (oddCoefficient 0)⁻¹ * ManuscriptChain.Hyperbolic.density 0 y := by
    simpa only [mul_zero, zero_add, pow_one] using
      (rawOdd_eq_coefficient_inv_mul 0 y)
  rw [hzero, rawOdd_eq_coefficient_inv_mul k y] at h
  simpa only [realWeight, realCoefficient, div_eq_mul_inv,
    mul_add, mul_assoc, mul_left_comm, mul_comm] using h

end PaperChronology.Proposition3_2.Envelope

#print axioms PaperChronology.Proposition3_2.Envelope.rpow_le_one_add_pow
#print axioms PaperChronology.Proposition3_2.Envelope.raw_realWeight_le_oddShapes
#print axioms PaperChronology.Proposition3_2.Envelope.realWeight_le_oddWeights
