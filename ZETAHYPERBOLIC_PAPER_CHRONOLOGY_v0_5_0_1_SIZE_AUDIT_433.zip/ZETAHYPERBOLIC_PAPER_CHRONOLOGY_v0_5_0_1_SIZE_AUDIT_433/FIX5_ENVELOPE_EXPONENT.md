# v0.3.7.1 — Envelope exponent patch

- User result: `CHECK_FAIL=Proposition_3_2_Real_s_Weight_Envelope`, line 77, unsolved goals.
- Repair: replace a broad `rw [show s = (s - 1) + 1 ...]` by `hs` and a `calc` chain to rewrite only the left exponent.
- Actual formula unchanged: `y ^ s = y ^ (s - 1) * y` under `hy : 0 < y`.
- Only one Lean file modified. The chronology's other 74 Lean files remain byte-identical.
- The persistent PASS-ONCE cache is reused by the same `run.cmd`, with automatic dependency invalidation.
- No `sorry`, `admit`, or axioms introduced. No local Lean compilation performed.

Compiler target: `CHECK_PASS=Proposition_3_2_Real_s_Weight_Envelope` then `CHECK_PASS=Proposition_3_2_Real_s_Moment_Integrability`, followed by Section 3 and chronology.
