import Theorem_3_3_Discrete_Total_Positivity_Samples
import Mathlib.Tactic

/-!
# PDF Theorem 3.3 — shifted two- and three-atomic Gram minors

This file proves complete formulas for every natural-index translation of
finite two- and three-atom Hankel blocks, plus their strict positivity on
strictly positive, pairwise distinct nodes with positive masses.
The finite-atomic results do not imply total positivity of the exact
continuous measure without a separate integral/limit bridge.
-/

noncomputable section
namespace PaperChronology.Theorem3_3.ShiftedAtomic

open PaperChronology.Theorem3_3.DiscreteSamples

/-- Absorb the index shift into the two positive atomic masses. -/
theorem twoMoment_shift (a b u v : ℝ) (n j : ℕ) :
    twoMoment a b u v (n + j) =
      twoMoment (a * u ^ n) (b * v ^ n) u v j := by
  simp only [twoMoment, pow_add]
  ring

/-- Every translated two-atom Hankel determinant factorizes exactly. -/
theorem two_atom_shifted_det (a b u v : ℝ) (n : ℕ) :
    twoMoment a b u v (n + 0) * twoMoment a b u v (n + 2) -
      twoMoment a b u v (n + 1) * twoMoment a b u v (n + 1) =
        a * b * (u * v) ^ n * (u - v) ^ 2 := by
  rw [twoMoment_shift a b u v n 0,
      twoMoment_shift a b u v n 2,
      twoMoment_shift a b u v n 1]
  rw [two_atom_hankel_det]
  simp only [mul_pow]
  ring

/-- Every translated order-two Hankel block is positive for two distinct
positive nodes and positive masses. -/
theorem two_atom_shifted_det_pos
    (a b u v : ℝ) (n : ℕ)
    (ha : 0 < a) (hb : 0 < b)
    (hu : 0 < u) (hv : 0 < v) (huv : u ≠ v) :
    0 < twoMoment a b u v (n + 0) * twoMoment a b u v (n + 2) -
      twoMoment a b u v (n + 1) * twoMoment a b u v (n + 1) := by
  rw [two_atom_shifted_det]
  have hp : 0 < (u * v) ^ n := pow_pos (mul_pos hu hv) n
  have hd : 0 < (u - v) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huv)
  exact mul_pos (mul_pos (mul_pos ha hb) hp) hd

/-- Absorb the index shift into three atomic masses. -/
theorem threeMoment_shift (a b c u v w : ℝ) (n j : ℕ) :
    threeMoment a b c u v w (n + j) =
      threeMoment (a * u ^ n) (b * v ^ n) (c * w ^ n) u v w j := by
  simp only [threeMoment, pow_add]
  ring

/-- Exact determinant formula for every natural-index translate of a
three-atom order-three Hankel block. -/
theorem three_atom_shifted_det (a b c u v w : ℝ) (n : ℕ) :
    hankelDet3
      (threeMoment a b c u v w (n + 0))
      (threeMoment a b c u v w (n + 1))
      (threeMoment a b c u v w (n + 2))
      (threeMoment a b c u v w (n + 3))
      (threeMoment a b c u v w (n + 4)) =
      a * b * c * (u * v * w) ^ n *
        (u - v) ^ 2 * (u - w) ^ 2 * (v - w) ^ 2 := by
  rw [threeMoment_shift a b c u v w n 0,
      threeMoment_shift a b c u v w n 1,
      threeMoment_shift a b c u v w n 2,
      threeMoment_shift a b c u v w n 3,
      threeMoment_shift a b c u v w n 4]
  rw [three_atom_hankel_det]
  simp only [mul_pow]
  ring

/-- The translated order-three determinant is positive for distinct
positive nodes and positive masses, at every natural shift. -/
theorem three_atom_shifted_det_pos
    (a b c u v w : ℝ) (n : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hu : 0 < u) (hv : 0 < v) (hw : 0 < w)
    (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
    0 < hankelDet3
      (threeMoment a b c u v w (n + 0))
      (threeMoment a b c u v w (n + 1))
      (threeMoment a b c u v w (n + 2))
      (threeMoment a b c u v w (n + 3))
      (threeMoment a b c u v w (n + 4)) := by
  rw [three_atom_shifted_det]
  have hp : 0 < (u * v * w) ^ n :=
    pow_pos (mul_pos (mul_pos hu hv) hw) n
  have hUV : 0 < (u - v) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huv)
  have hUW : 0 < (u - w) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huw)
  have hVW : 0 < (v - w) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr hvw)
  exact mul_pos (mul_pos (mul_pos (mul_pos (mul_pos (mul_pos ha hb) hc)
    hp) hUV) hUW) hVW

end PaperChronology.Theorem3_3.ShiftedAtomic

#print axioms PaperChronology.Theorem3_3.ShiftedAtomic.two_atom_shifted_det_pos
#print axioms PaperChronology.Theorem3_3.ShiftedAtomic.three_atom_shifted_det_pos
