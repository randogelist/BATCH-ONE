# v0.4.7.0 — Actual pole-diagonal sign counts

Verified baseline: user native Windows Lean 4.33.0 reports 103/103 frozen modules PASS, zero newly compiled and FINAL_AXIOMS=NO_FORBIDDEN_AXIOMS_DETECTED. These 103 source files remain unchanged.

New source: `Theorem_3_3_Actual_Diagonal_Sign_Counts.lean` composes the actual-slope sign equivalence, finite-index parity, and odd-prefix count to compute the positive and negative diagonal inertia-coordinate counts for **every** parameter interval N <= K and the exact weight-five K=30n, N=3n specialization.

New entry point: `PAPER_CHRONOLOGICAL_EXTENSION_8.lean` exposes the theorem-level conjunction and absence of zero diagonal directions.

Not claimed: Sylvester transfer to the numbers of actual spectral eigenvalues, or nonprincipal strict total positivity. Neither is hidden as a premise or `sorry`.

The two new modules are uncompiled candidate source; only the user's compiler can freeze them. Run `run.cmd` from the archive folder to reuse all 103 cached successful modules.
