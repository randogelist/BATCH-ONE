import Theorem_3_3_Actual_Diagonal_Inertia_Signs
import Theorem_3_3_Pole_Signature_Counts
import Mathlib.Tactic

/-!
# Theorem 3.3(3): exact positive and negative coordinate counts (v0.4.7.2 bridge)

The earlier certified source proves that the ACTUAL pole-congruence slope
has alternating nonzero diagonal entries. We now COUNT those signs over
its entire indexed pole lattice, and specialize to the PDF family
`N = 3*n`, `K = 30*n`, `h = 27*n`.

This computes the positive/negative inertia of the diagonal quadratic
form (the congruence coordinate certificate). Identifying these numbers
with spectral-eigenvalue multiplicities of the normalized real pencil
still requires the separate Sylvester inertia bridge: this file does
not assert or assume that remaining theorem.

No external arithmetic Witness is required for this theorem.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_3.ActualSignCounts

open ManuscriptChain.PoleDiagonalization
open PaperChronology.Theorem3_3.ActualDiagonalSigns
open PaperChronology.Theorem3_3.PoleCounts

/-- Number of strictly positive entries in the ACTUAL diagonalized slope,
counted with multiplicities (one per pole index). -/
def positiveMass (p : ManuscriptChain.Real.Parameters) : ℕ :=
  ∑ i : Fin p.h, if 0 < diagonalSlope p i then 1 else 0

/-- Corresponding exact count of strictly negative diagonal entries. -/
def negativeMass (p : ManuscriptChain.Real.Parameters) : ℕ :=
  ∑ i : Fin p.h, if diagonalSlope p i < 0 then 1 else 0

/-- Positive actual residues correspond precisely to ODD pole indices. -/
private theorem diagonal_positive_iff_pole_odd
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m)
    (i : Fin p.h) :
    (0 < diagonalSlope p i) ↔ (p.N + 1 + i.val) % 2 = 1 := by
  have hindex : poleIndex p i - 1 = p.N + i.val := by
    simp only [poleIndex]
    omega
  rw [diagonalSlope_pos_iff_even p hm i, hindex]
  constructor
  · rintro ⟨t, ht⟩
    omega
  · intro h
    exact ⟨(p.N + i.val) / 2, by omega⟩

/-- Additive decomposition of the paper's odd-prefix count into its
first `N+1` indices and the next `h` pole indices. -/
private theorem odd_prefix_shift (N h : ℕ) :
    (∑ i : Fin h,
      if (N + 1 + i.val) % 2 = 1 then (1 : ℕ) else 0) =
      oddPrefix (N + 1 + h) - oddPrefix (N + 1) := by
  have hfin :
      (∑ i : Fin h,
        if (N + 1 + i.val) % 2 = 1 then (1 : ℕ) else 0) =
      ∑ a ∈ Finset.range h,
        if (N + 1 + a) % 2 = 1 then (1 : ℕ) else 0 := by
    exact Fin.sum_univ_eq_sum_range
      (fun a : ℕ => if (N + 1 + a) % 2 = 1 then (1 : ℕ) else 0) h
  have hsplit :
      oddPrefix (N + 1 + h) = oddPrefix (N + 1) +
        (∑ a ∈ Finset.range h,
          if (N + 1 + a) % 2 = 1 then (1 : ℕ) else 0) := by
    simpa only [oddPrefix] using
      (Finset.sum_range_add
        (fun a : ℕ => if a % 2 = 1 then (1 : ℕ) else 0)
        (N + 1) h)
  rw [hfin]
  omega

/-- Exact, unconditional count of positive diagonal directions for the
paper's actual rational slope, at EVERY admissible pole interval. -/
theorem positiveMass_eq_oddPoleCount
    (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (hNK : p.N ≤ p.K) :
    positiveMass p = oddPoleCount p.N p.K := by
  have hK : p.N + 1 + p.h = p.K + 1 := by
    dsimp [ManuscriptChain.Real.Parameters.h]
    omega
  calc
    positiveMass p =
        ∑ i : Fin p.h,
          if (p.N + 1 + i.val) % 2 = 1 then (1 : ℕ) else 0 := by
      unfold positiveMass
      apply Finset.sum_congr rfl
      intro i _
      by_cases hpos : 0 < diagonalSlope p i
      · have hodd : (p.N + 1 + i.val) % 2 = 1 :=
          (diagonal_positive_iff_pole_odd p hm i).mp hpos
        simp [hpos, hodd]
      · have hnotodd : ¬ ((p.N + 1 + i.val) % 2 = 1) := by
          intro hodd
          exact hpos ((diagonal_positive_iff_pole_odd p hm i).mpr hodd)
        simp [hpos, hnotodd]
    _ = oddPrefix (p.N + 1 + p.h) - oddPrefix (p.N + 1) :=
      odd_prefix_shift p.N p.h
    _ = oddPoleCount p.N p.K := by
      rw [hK]
      rfl

/-- The actual diagonal slope has no zero direction: at every coordinate
exactly one of the two sign indicators contributes one. -/
private theorem positive_add_negative_indicator
    (p : ManuscriptChain.Real.Parameters) (i : Fin p.h) :
    (if 0 < diagonalSlope p i then (1 : ℕ) else 0) +
      (if diagonalSlope p i < 0 then (1 : ℕ) else 0) = 1 := by
  rcases lt_trichotomy (diagonalSlope p i) 0 with hn | hz | hp
  · have hnotpos : ¬ 0 < diagonalSlope p i := by linarith
    simp [hnotpos, hn]
  · exact (diagonalSlope_ne_zero p i hz).elim
  · have hnotneg : ¬ diagonalSlope p i < 0 := by linarith
    simp [hp, hnotneg]

/-- A genuine no-zero-inertia statement on the full actual pole lattice. -/
theorem positiveMass_add_negativeMass
    (p : ManuscriptChain.Real.Parameters) :
    positiveMass p + negativeMass p = p.h := by
  classical
  unfold positiveMass negativeMass
  rw [← Finset.sum_add_distrib]
  simp [positive_add_negative_indicator]

/-- Number of negative actual pole directions equals the complementary
EVEN-index count. This is not a statement about a free model matrix. -/
theorem negativeMass_eq_evenPoleCount
    (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (hNK : p.N ≤ p.K) :
    negativeMass p = evenPoleCount p.N p.K := by
  have hsplit := positiveMass_add_negativeMass p
  have hpositive := positiveMass_eq_oddPoleCount p hm hNK
  have hodd := oddPoleCount_le p.N p.K hNK
  rw [hpositive] at hsplit
  unfold evenPoleCount
  dsimp [ManuscriptChain.Real.Parameters.h] at hsplit
  omega

/-- Exact diagonal-coordinate inertia counts for the manuscript's
weight-five specialization. In the paper these are the two sides of the
spectral root split AFTER Sylvester's law of inertia is invoked. -/
theorem weightFive_actual_diagonal_sign_counts
    (n : ℕ) (p : ManuscriptChain.Real.Parameters)
    (hm : 0 < p.m) (hN : p.N = 3 * n) (hK : p.K = 30 * n) :
    positiveMass p = (27 * n) / 2 ∧
    negativeMass p = (27 * n + 1) / 2 := by
  have hNK : p.N ≤ p.K := by omega
  constructor
  · calc
      positiveMass p = oddPoleCount p.N p.K :=
        positiveMass_eq_oddPoleCount p hm hNK
      _ = (27 * n) / 2 := by
        simpa [hN, hK] using weightFive_odd_count n
  · calc
      negativeMass p = evenPoleCount p.N p.K :=
        negativeMass_eq_evenPoleCount p hm hNK
      _ = (27 * n + 1) / 2 := by
        simpa [hN, hK] using weightFive_even_count n

end PaperChronology.Theorem3_3.ActualSignCounts

#print axioms PaperChronology.Theorem3_3.ActualSignCounts.positiveMass_eq_oddPoleCount
#print axioms PaperChronology.Theorem3_3.ActualSignCounts.negativeMass_eq_evenPoleCount
#print axioms PaperChronology.Theorem3_3.ActualSignCounts.weightFive_actual_diagonal_sign_counts
