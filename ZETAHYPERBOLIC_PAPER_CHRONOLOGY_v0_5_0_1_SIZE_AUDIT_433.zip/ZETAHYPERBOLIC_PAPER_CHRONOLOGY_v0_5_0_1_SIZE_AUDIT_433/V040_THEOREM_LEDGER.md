# Chronological increment v0.4.0 — awaiting USER compiler

Last verified baseline: 83/83 modules PASS (user Windows Lean 4.33). 83 original Lean
source files in this ZIP are **byte identical** to the v0.3.9.16 sources.

New candidate modules (NOT locally compiled):

1. PDF Theorem 3.3 (finite model only): exact 2-atom and 3-atom Hankel
   determinant / Vandermonde-square identities with strict positivity under
   positive weights and distinct real nodes.  Not the full infinite-dimensional
   total-positivity theorem, nor its Carleman uniqueness statement.
2. PDF Theorem 3.4(2), dimension 3: the two 3x3 Dodgson identities for the
   symbolic Hankel moments m0,...,m4, sign at a root of the 2x2 leading
   principal minor, and strict sign if the complementary minor is nonzero.
   General dimension and eigenvalue interlacing still open.
3. New PAPER_CHRONOLOGICAL_EXTENSION: lean theorem-level entry point importing
   the preserved chain + new finite determinants; no arithmetic witness.

Compiler source is kept offline and solely the user's native Windows 4.33.
Only these three missing .olean files need to be compiled on an otherwise
unchanged verified 83-module cache.  No extra axioms, sorry, admit, or
placeholder statements are introduced.

## v0.4.2.0 additional finite-model work
- Three-atom arbitrary-index 2×2 Hankel minors and strict positivity: new, awaiting compiler.
- Universal n-shifted order-3 and order-4 Dodgson and strict sign: new, awaiting compiler.
- Exact continuous integral all-minors and arbitrary-order Jacobi remain not formalized.
