# v0.3.3.3 — Chronological chain & diagnostic repair

Your log shows all five displayed theorem-axiom reports are standard only.
It does not show the first compiler `error:` line and therefore does not identify
the exact source of `RESULT=FAIL`.

## Changes
1. `PAPER_CHRONOLOGICAL_CHAIN.lean`: changed from nonessential `#check` assertions
   into a compositional theorem importing the actual Section 2 and 3 modules.
   Only already available theorems are used. No new arithmetic or analytic assumption.
2. `run.cmd`: prints concise `error:` diagnostics on failure; full errors remain on
   the user's machine in the indicated log file.
3. `run.cmd`: change flags now survive failed/interrupted runs so invalidated
   dependents are still rebuilt on the subsequent rerun. Flags clear after success.
4. No source changes to Proposition 3.2, Theorem 3.3, Section 2, or other mathematical
   proof files. Existing passed modules remain frozen.

## Verification
- ZIP/static checks only.
- No local Lean compile was run; your native Lean 4.33.0 is authoritative.
- The analytic real-s moment bridge and full inertia theorem remain open.
