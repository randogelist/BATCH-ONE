import PAPER_SECTION_02
import PAPER_SECTION_03
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion
import PAPER_WITNESS_ONLY
import PAPER_COUNTEREXAMPLES
import Theorem_3_3_Actual_Leading_Coefficient_Sign

/-!
# Manuscript chronology: Sections 2 -> 3, with later sections retained as imports

This file is a real Lean theorem endpoint rather than an array of `#check`
diagnostics.  The preceding files establish Section 2's concrete algebra,
Section 3's general odd-weight hyperbolicity, and the finite real-s derivative
part of Proposition 3.2.  A positive real-s integral realization (the rest of
PDF Proposition 3.2) and the exact inertia of PDF Theorem 3.3 are NOT claimed
here.  The named arithmetic witness for later Section 4 remains isolated in
`PAPER_WITNESS_ONLY.lean`.

The manuscript's printed Corollaries 3.5 and 3.6 need correction: their
counterexamples are independently compiled in `PAPER_COUNTEREXAMPLES.lean`.
-/

open scoped BigOperators

noncomputable section
namespace PaperChronology

/-- Cumulative proved core in PDF order:
  - Section 2 establishes the actual moment/pole polynomial construction;
  - Theorem 3.1 establishes unconditional odd-weight hyperbolicity;
  - Proposition 3.2: the real-s derivative of the prescribed finite pencil is
    invertible, before completing the infinite-weight moment representation.
No arithmetic witness is needed for this portion. -/
theorem paper_section_2_through_3_spectral_core
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    (s : ℝ) :
    ManuscriptChain.General.GeneralStatement p ∧
      (Proposition3_2.derivativeMatrix s p).det ≠ 0 := by
  exact ⟨Section3.theorem_3_1_unconditional p hp,
    Section3.proposition_3_2_derivative_invertible s p⟩

/-- The unconditionally established Section-3 analytic layer combines
with the Section-2 and Theorem-3.1 spectral results without an arithmetic witness.
The real-s Gram integrability proof now supplies the unconditional
Proposition 3.2 spectral endpoint; it still awaits the user compiler. -/
theorem paper_through_real_s_density
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    (s y : ℝ) (hs : 1 < s) (hy : 0 < y) :
    ManuscriptChain.General.GeneralStatement p ∧
      (Proposition3_2.derivativeMatrix s p).det ≠ 0 ∧
      0 < Proposition3_2.Analytic.realWeight s y := by
  exact ⟨Section3.theorem_3_1_unconditional p hp,
    Section3.proposition_3_2_derivative_invertible s p,
    Section3.proposition_3_2_infinite_weight_positive hs hy⟩

/-- The analytic measure and derivative are now constructed without
an arithmetic witness for EVERY s>1. The final integrability estimate remains
the open mathematical frontier for the full real-s spectral result. -/
theorem paper_through_real_s_measure
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    (s : ℝ) (hs : 1 < s) :
    ManuscriptChain.General.GeneralStatement p ∧
      (Proposition3_2.derivativeMatrix s p).det ≠ 0 ∧
      Proposition3_2.Gram.momentMeasure s p ≠ 0 := by
  exact ⟨Section3.theorem_3_1_unconditional p hp,
    Section3.proposition_3_2_derivative_invertible s p,
    Section3.proposition_3_2_actual_moment_measure_nonzero s p hs⟩

/-- Unconditional Section 2 -> Proposition 3.2 spectral endpoint.
The odd-weight general statement is combined with the ACTUAL real-s Gram,
its determinant degree, and real-rootedness, with NO arithmetic witness. -/
theorem paper_through_real_s_unconditional_spectral
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    (s : ℝ) (hs : 1 < s) :
    ManuscriptChain.General.GeneralStatement p ∧
      (Proposition3_2.Gram.gram s p).PosDef ∧
      (Proposition3_2.Gram.actualPencil s p).detPolynomial.natDegree = p.h ∧
      (∀ z : ℂ, Polynomial.eval₂ (algebraMap ℝ ℂ) z
        (Proposition3_2.Gram.actualPencil s p).detPolynomial = 0 → z.im = 0) := by
  exact ⟨Section3.theorem_3_1_unconditional p hp,
    Proposition3_2.Integrability.actualGram_posDef s p hs,
    Proposition3_2.Integrability.actualPencil_exact_degree s p hs,
    fun z hz => Proposition3_2.Integrability.actualPencil_root_real s p hs z hz⟩

/-- Theorem 3.3's exact arithmetic pole counts are appended in the same
chronology as the real-s proposition; this does not claim full inertia yet. -/
theorem paper_theorem_3_3_pole_counts (n : ℕ) :
    Theorem3_3.PoleCounts.oddPoleCount (3 * n) (30 * n) = (27 * n) / 2 ∧
    Theorem3_3.PoleCounts.evenPoleCount (3 * n) (30 * n) = (27 * n + 1) / 2 :=
  Section3.theorem_3_3_weight_five_pole_counts n

/-- Theorem 3.3(2), exact rational determinant: the canonical signed
leading coefficient is strictly positive for the actual polynomial pencil.
This theorem is independent of the Section 4 arithmetic witness. -/
theorem paper_theorem_3_3_actual_signed_leading_coefficient
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m) :
    0 < (∏ i : Fin p.h,
      (-1 : ℚ) ^ (ManuscriptChain.PoleDiagonalization.poleIndex p i - 1)) *
      (ManuscriptChain.Real.delta p).leadingCoeff :=
  Theorem3_3.ActualLeadingSign.actual_leadingCoeff_signed_positive p hm

end PaperChronology

#print axioms PaperChronology.paper_section_2_through_3_spectral_core
