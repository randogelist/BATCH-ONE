# FIX13 — Explicit Nat.card_Icc and package identity

The reported unknown identifier `Finset.card_Icc` belongs to the previous source revision. The source in this package uses the Lean/Mathlib declaration `Nat.card_Icc` with an explicit intermediate equality and a final `omega` discharge. The build launcher displays `PATCH=FIX13_EXPLICIT_NAT_CARD_ICC` and checks for the new identifier before running Lean, to distinguish the package from older extracts.

No original theorem statement was changed. The only changed Lean file is `Theorem_3_3_Signed_Pole_Products.lean`. The Windows-native Lean compiler remains the sole authority; this package was NOT compiled locally.
