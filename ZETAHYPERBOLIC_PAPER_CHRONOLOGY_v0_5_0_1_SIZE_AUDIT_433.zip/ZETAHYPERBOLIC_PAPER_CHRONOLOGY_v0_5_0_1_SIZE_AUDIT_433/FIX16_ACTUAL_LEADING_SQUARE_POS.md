# FIX16 — actual leading coefficient sign

The native compiler passed `Theorem_3_3_Pole_Weight_Signs` and stopped at line 51 of `Theorem_3_3_Actual_Leading_Coefficient_Sign.lean`.

The proof incorrectly expected `nlinarith` to derive strict square positivity from nonnegativity plus disequality. It now uses `sq_pos_of_ne_zero`, a lemma already employed elsewhere in this same package.

Exactly one Lean source has changed. Existing successful modules remain unchanged and eligible for persistent freeze-on-PASS cache reuse. The new source awaits the user's native Lean 4.33.0 compiler. No assistant Lean compilation.
