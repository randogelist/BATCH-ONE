# v0.4.7.2 — pole-sign cardinality bridge (compiler pending)

This release repairs only the `odd_prefix_shift` auxiliary proof by separating
`Fin`-indexed summation, range summation, and the `Finset.sum_range_add` identity.
The positivity and negativity count proof uses pointwise `by_cases` rather
than rewriting propositions inside `ite`, and the zero-direction sum uses
`simp [positive_add_negative_indicator]`.

Previously user-certified files are unchanged. No local Lean compilation was
performed. The only compilation authority is the user's native Lean 4.33.0.
The runner checks for a distinctive v0.4.7.2 source patch marker before
starting its persistent pass-once incremental build.
