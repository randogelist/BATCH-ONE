# v0.4.3.0: chronological Theorem 3.3 finite-model extension

Compiler authority: **user Windows native Lean 4.33.0 only**. No assistant
compilation. Last user-reported clean checkpoint: 92/92 Lean modules, with
`BUILD_COMPILED=3`, `BUILD_FROZEN_REUSED=89`, and `FINAL_AXIOMS=NO_FORBIDDEN_AXIOMS_DETECTED`.

The 92 original Lean sources are byte-identical to the compiler-passed v0.4.2.1
archive. Only three new Lean modules are appended:

1. `Theorem_3_3_Four_Atom_General_Minors`: exact six-pair formula for every
   2-by-2 Hankel minor of a four-point moment sequence with independent row and
   column gaps, plus strict positivity under positive masses and strictly
   ordered positive nodes.
2. `Theorem_3_3_Four_Atom_Three_By_Three`: exact four-term Vandermonde-square
   expansion and strict positivity for every translated 3-by-3 principal minor
   of the four-point moment sequence.
3. `PAPER_CHRONOLOGICAL_EXTENSION_4`: imports and re-exports the new finite
   statements downstream of the previously proved chronological chain.

These results do **not** formalize strict total positivity for every minor of
an arbitrary-size Hankel matrix or prove that this four-atomic model is the
paper's continuous moment functional. Those are separate analytic targets.
No new `Witness` field, parameterized `Hypothesis`, `sorry`, `admit`, custom
`axiom`, or local compiler pass is used. The full paper remains unfinished.
