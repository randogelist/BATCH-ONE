# FIX15 — rational square-sign cases

The user compiler log reported `nlinarith` failing to derive `0 < x^2` from `x ≠ 0`. The exact failure corresponds to the older v0.3.9.7 source, not the case-analysis v0.3.9.8 source. This increment makes the case-analysis proof more explicit with `hprod : 0 < x*x` and `hprod : 0 < y*y`, transporting via `pow_two`.

Only `Theorem_3_3_Pole_Weight_Signs.lean` changes among the Lean source files. All successfully verified modules are reused by the existing persistent FASTCORE cache. The `run.cmd` announces this package and checks that the sign-splitting source has actually been extracted. No local Lean compilation or proof certification has been performed.
