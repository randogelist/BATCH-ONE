import Mathlib

/-!
# Two finite algebraic obstructions in the printed paper

Corollary 3.6 says all Hankel determinants of a finite h-atomic power-sum
sequence are strictly positive. At h=2 the order-three determinant is zero.
The general reason is rank(H_r) <= h, so det(H_r) = 0 for r > h.

Corollary 3.5, equation (3.6), omits Gram and spectral-pencil scaling.
Already for h=1, a positive Gram mass G and negative slope M yield
1 / G > 0 at the center, whereas the displayed J-fraction equals
1 / (M/G) < 0. For the actual paper's N=1, K=2, m=1, s=5,
M = 2^4 * (1^2 - 2^2) = -48.

These are algebraic checks, not a proof of the paper's full claims.
-/

namespace PaperAudit

/-- Moments of a measure supported on two atoms of unit mass. -/
def twoAtomMoment (u v : ℝ) (n : ℕ) : ℝ := u ^ n + v ^ n

/-- The order-three Hankel determinant always vanishes for two atoms,
even if their locations are positive and distinct. -/
theorem two_atom_hankel3_zero (u v : ℝ) :
    twoAtomMoment u v 0 *
        (twoAtomMoment u v 2 * twoAtomMoment u v 4 -
          twoAtomMoment u v 3 * twoAtomMoment u v 3) -
      twoAtomMoment u v 1 *
        (twoAtomMoment u v 1 * twoAtomMoment u v 4 -
          twoAtomMoment u v 2 * twoAtomMoment u v 3) +
      twoAtomMoment u v 2 *
        (twoAtomMoment u v 1 * twoAtomMoment u v 3 -
          twoAtomMoment u v 2 * twoAtomMoment u v 2) = 0 := by
  dsimp [twoAtomMoment]
  ring

/-- The scalar special case of the printed J-fraction cannot hold when the
Gram entry is positive and the pencil's linear coefficient is negative. -/
theorem j_fraction_h1_sign_obstruction
    (G M : ℝ) (hG : 0 < G) (hM : M < 0) :
    1 / G ≠ 1 / (M / G) := by
  have hl : (0 : ℝ) < 1 / G := by positivity
  have hMG : M / G < 0 := div_neg_of_neg_of_pos hM hG
  have hr : 1 / (M / G) < 0 :=
    div_neg_of_pos_of_neg (by norm_num : (0 : ℝ) < 1) hMG
  exact ne_of_gt (lt_trans hr hl)

/-- Slope M for the actual h=1 pencil at (s,K,N,m)=(5,2,1,1). -/
theorem paper_h1_slope : (2 : ℚ) ^ 4 * ((1 : ℚ) ^ 2 - (2 : ℚ) ^ 2) = -48 := by
  norm_num

end PaperAudit

#print axioms PaperAudit.two_atom_hankel3_zero
#print axioms PaperAudit.j_fraction_h1_sign_obstruction
#print axioms PaperAudit.paper_h1_slope
