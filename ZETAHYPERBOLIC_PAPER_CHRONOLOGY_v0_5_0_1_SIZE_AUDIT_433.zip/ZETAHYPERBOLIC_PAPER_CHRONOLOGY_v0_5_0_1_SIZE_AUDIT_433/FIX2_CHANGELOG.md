# v0.3.3.2 — Proposition 3.2 compiler repair (FIX2)

## Confirmed user-compiler failure

- `Proposition_3_2_Continuous_Real_Weight_Pencil.lean:76`: `simpa only [vandermonde, Rat.cast_det]` rewrote to a lambda cast function while the declaration uses `Rat.castHom`.
- `Proposition_3_2_Continuous_Real_Weight_Pencil.lean:90`: `simp only [Matrix.transpose_apply]` made no progress. The preceding blanket `Matrix.mul_apply` expansion also prevented use of the specialized `Matrix.mul_diagonal` rewrite.

## Exact changes

1. Replaced the cast simplifier with the explicit `RingHom.map_det (Rat.castHom ℝ)` identity. This matches the declaration's exact ring homomorphism.
2. Proved the Gram entry formula with the successful pattern already used in `Theorem_2_5_Lagrange_Pole_Diagonalization.lean`: first `rw [Matrix.mul_apply]` for the **outer** product, then `simp only [Matrix.mul_diagonal, Matrix.transpose_apply]`. Symmetry follows by `Finset.sum_congr` and `ring`.
3. Changed only the Lean source `Proposition_3_2_Continuous_Real_Weight_Pencil.lean`. Other `.lean` files remain byte-for-byte identical to FIX1.

## Verification protocol

- No Lean compilation on the assistant's machine.
- Preserve `PASS_ONCE / FREEZE` native Lean 4.33.0 persistent compilation cache.
- The one `run.cmd` will recompile this changed module and its invalidated dependents, skip unchanged modules already marked as passed, and produce the user-compiler status.
- **Not yet compiler certified:** all new FIX2 edits need a Windows Lean 4.33.0 run.

## Scope of the mathematics

This repairs the *finite algebraic and spectral reduction* of Proposition 3.2. The paper's exact positive real-`s` infinite-series moment matrix still requires a separate analytic construction; Proposition 3.2 as printed is not yet fully formalized.
