import Mathlib.Tactic

/-!
# PDF Theorem 3.3(2): algebraic parity reduction

For K=30n,N=3n,h=27n and 2m=6, the sign of the derivative determinant
is computed from `(-1)^(h(h-1)/2 + 5Nh)`. Expanding this integer exponent
produces a term `756n² + 13n(n-1) + n(n-1)/2`. The two first summands are
even. Using the canonical binomial coefficient `n.choose 2` avoids a
spurious division or a restriction to even n.

This file proves the parity calculation. Connecting it to the actual
slope determinant is handled separately by Theorem 2.5's exact determinant
factorization and the pole-sign file.
-/

noncomputable section
namespace PaperChronology.Theorem3_3.LeadingParity

/-- Canonical integer expansion of the manuscript's sign exponent. -/
def expandedExponent (n : ℕ) : ℕ :=
  756 * n * n + 26 * n.choose 2 + n.choose 2

/-- The even terms in the exponent contribute sign `+1`. -/
theorem even_offset_sign (n : ℕ) :
    (-1 : ℚ) ^ (756 * n * n + 26 * n.choose 2) = 1 := by
  have h756 : (-1 : ℚ) ^ 756 = 1 := by norm_num
  have h26 : (-1 : ℚ) ^ 26 = 1 := by norm_num
  simp only [pow_add, pow_mul, h756, h26, one_pow, mul_one]

/-- Only the `choose n 2` parity survives the even terms. -/
theorem expandedExponent_sign (n : ℕ) :
    (-1 : ℚ) ^ expandedExponent n = (-1 : ℚ) ^ n.choose 2 := by
  rw [expandedExponent, pow_add, even_offset_sign, one_mul]

end PaperChronology.Theorem3_3.LeadingParity

#print axioms PaperChronology.Theorem3_3.LeadingParity.expandedExponent_sign
