import PAPER_SECTION_02
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk

/-!
# Proposition 3.2 — continuous-real-weight spectral algebra

The manuscript takes s > 1, extends the positive weight from odd integer s
into a continuum, and retains the same Lagrange pole nodes. This module
proves the entire *finite spectral reduction* for a real exponent: the
explicit rescaled weights are nonzero, their Vandermonde-congruent slope
matrix is invertible, and ANY positive-definite base Gram matrix yields
an exact-degree real-rooted polynomial with a nonvanishing center.

Unfinished analytical bridge (NOT an axiom, and NOT exported as proved):
prove that the paper's exact infinite-series real-s density defines an
integrable moment matrix A(s) and that it is positive definite. Without
that bridge, this file is NOT the entire PDF Proposition 3.2.
-/

noncomputable section
open scoped BigOperators
open ManuscriptChain

namespace PaperChronology.Proposition3_2

/-- Multiplying the integer odd-weight coefficient by this positive factor
replaces the old pole power a^(2k) by a^(s-1) for any real s. -/
def poleRescaling (s : ℝ) (p : Real.Parameters) (a : Fin p.h) : ℝ :=
  (PoleDiagonalization.poleIndex p a : ℝ) ^ (s - 1) /
    (PoleDiagonalization.poleIndex p a : ℝ) ^ (2 * p.k)

/-- The real-s coefficient γ_a(s) in the Lagrange-pole derivative matrix. -/
def poleWeight (s : ℝ) (p : Real.Parameters) (a : Fin p.h) : ℝ :=
  (PoleDiagonalization.poleWeight p a : ℝ) * poleRescaling s p a

private theorem poleIndex_real_pos (p : Real.Parameters) (a : Fin p.h) :
    0 < (PoleDiagonalization.poleIndex p a : ℝ) := by
  exact_mod_cast PoleDiagonalization.poleIndex_pos p a

theorem poleRescaling_pos (s : ℝ) (p : Real.Parameters) (a : Fin p.h) :
    0 < poleRescaling s p a := by
  unfold poleRescaling
  exact div_pos (Real.rpow_pos_of_pos (poleIndex_real_pos p a) _)
    (pow_pos (poleIndex_real_pos p a) _)

theorem poleWeight_ne_zero (s : ℝ) (p : Real.Parameters) (a : Fin p.h) :
    poleWeight s p a ≠ 0 := by
  unfold poleWeight
  have h : (PoleDiagonalization.poleWeight p a : ℝ) ≠ 0 := by
    exact_mod_cast PoleDiagonalization.poleWeight_ne_zero p a
  exact mul_ne_zero h (ne_of_gt (poleRescaling_pos s p a))

/-- At s=2k+1 this is exactly the already proved odd-weight coefficient;
there is no unrelated auxiliary pencil. -/
theorem poleWeight_at_odd (p : Real.Parameters) (a : Fin p.h) :
    poleWeight (p.weight : ℝ) p a =
      (PoleDiagonalization.poleWeight p a : ℝ) := by
  have hpow : (p.weight : ℝ) - 1 = (2 * p.k : ℕ) := by
    dsimp [Real.Parameters.weight]
    push_cast
    ring
  have hnz : (PoleDiagonalization.poleIndex p a : ℝ) ^ (2 * p.k) ≠ 0 :=
    pow_ne_zero _ (ne_of_gt (poleIndex_real_pos p a))
  simp only [poleWeight, poleRescaling, hpow, Real.rpow_natCast,
    div_self hnz, mul_one]

/-- The Vandermonde matrix, with its *same* negative-square rational poles,
considered over ℝ for real values of the exponent. -/
def vandermonde (p : Real.Parameters) : Matrix (Fin p.h) (Fin p.h) ℝ :=
  (PoleDiagonalization.poleVandermonde p).map (Rat.castHom ℝ)

theorem vandermonde_det_ne_zero (p : Real.Parameters) :
    (vandermonde p).det ≠ 0 := by
  have h : ((PoleDiagonalization.poleVandermonde p).det : ℝ) ≠ 0 := by
    exact_mod_cast PoleDiagonalization.poleVandermonde_det_ne_zero p
  have hdet : (vandermonde p).det =
      ((PoleDiagonalization.poleVandermonde p).det : ℝ) := by
    change ((PoleDiagonalization.poleVandermonde p).map (Rat.castHom ℝ)).det =
      (Rat.castHom ℝ) (PoleDiagonalization.poleVandermonde p).det
    exact (RingHom.map_det (Rat.castHom ℝ)
      (PoleDiagonalization.poleVandermonde p)).symm
  exact hdet.symm ▸ h

/-- Exact full-rank real-s derivative matrix M(s)=V diag(γ_a(s)) Vᵀ. -/
def derivativeMatrix (s : ℝ) (p : Real.Parameters) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  vandermonde p * Matrix.diagonal (poleWeight s p) * (vandermonde p).transpose

theorem derivativeMatrix_symmetric (s : ℝ) (p : Real.Parameters) :
    (derivativeMatrix s p).IsSymm := by
  have hentry (i j : Fin p.h) :
      derivativeMatrix s p i j =
        ∑ a : Fin p.h, vandermonde p i a * poleWeight s p a *
          vandermonde p j a := by
    unfold derivativeMatrix
    rw [Matrix.mul_apply]
    simp only [Matrix.mul_diagonal, Matrix.transpose_apply]
  ext i j
  change derivativeMatrix s p j i = derivativeMatrix s p i j
  rw [hentry j i, hentry i j]
  apply Finset.sum_congr rfl
  intro a _
  ring

theorem derivativeMatrix_det (s : ℝ) (p : Real.Parameters) :
    (derivativeMatrix s p).det =
      (vandermonde p).det ^ 2 * ∏ a : Fin p.h, poleWeight s p a := by
  unfold derivativeMatrix
  rw [Matrix.det_mul, Matrix.det_mul, Matrix.det_diagonal,
    Matrix.det_transpose]
  ring

theorem derivativeMatrix_det_ne_zero (s : ℝ) (p : Real.Parameters) :
    (derivativeMatrix s p).det ≠ 0 := by
  rw [derivativeMatrix_det]
  apply mul_ne_zero
  · exact pow_ne_zero _ (vandermonde_det_ne_zero p)
  · exact Finset.prod_ne_zero_iff.mpr (fun a _ => poleWeight_ne_zero s p a)

/-- A real-s pencil centered at the paper's ζ(s), with the manuscript's
exact real-s derivative. `A` is the analytic moment matrix to be constructed
from equation (3.1), not a claim that it has been constructed here. -/
def pencil (s : ℝ) (p : Real.Parameters)
    (A : Matrix (Fin p.h) (Fin p.h) ℝ) (hA : A.IsSymm) :
    Spectral.SymmetricAffinePencil p.h where
  center := (riemannZeta (s : ℂ)).re
  base := A
  direction := derivativeMatrix s p
  base_symmetric := hA
  direction_symmetric := derivativeMatrix_symmetric s p

/-- All finite spectral conclusions of PDF Proposition 3.2, derived by the
SAME positive-definite-pencil theorem used for PDF Theorem 3.1. -/
noncomputable def spectralFactors (s : ℝ) (p : Real.Parameters)
    (A : Matrix (Fin p.h) (Fin p.h) ℝ) (hA : A.IsSymm)
    (hpos : A.PosDef) : Spectral.RootFactorization (pencil s p A hA) :=
  Spectral.rootFactorizationOfPosDef (pencil s p A hA) hpos
    (derivativeMatrix_det_ne_zero s p)

theorem exact_degree (s : ℝ) (p : Real.Parameters)
    (A : Matrix (Fin p.h) (Fin p.h) ℝ) (hA : A.IsSymm)
    (hpos : A.PosDef) :
    ((pencil s p A hA).detPolynomial).natDegree = p.h :=
  (spectralFactors s p A hA hpos).natDegree_eq

theorem root_is_real (s : ℝ) (p : Real.Parameters)
    (A : Matrix (Fin p.h) (Fin p.h) ℝ) (hA : A.IsSymm)
    (hpos : A.PosDef) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      ((pencil s p A hA).detPolynomial) = 0) : z.im = 0 :=
  (spectralFactors s p A hA hpos).complex_root_im_zero z hz

theorem center_is_not_a_root (s : ℝ) (p : Real.Parameters)
    (A : Matrix (Fin p.h) (Fin p.h) ℝ) (hA : A.IsSymm)
    (hpos : A.PosDef) :
    ((pencil s p A hA).detPolynomial).eval ((riemannZeta (s : ℂ)).re) ≠ 0 :=
  (spectralFactors s p A hA hpos).center_nonvanishing

/-- The spectrum determines an exact positive radius whenever h>0;
all the nonzero-eigenvalue and root identities are inherited from
`spectralFactors` rather than taken as external data. -/
theorem nonzero_spectral_eigenvalues (s : ℝ) (p : Real.Parameters)
    (A : Matrix (Fin p.h) (Fin p.h) ℝ) (hA : A.IsSymm)
    (hpos : A.PosDef) :
    ∀ a : Fin p.h, (spectralFactors s p A hA hpos).beta a ≠ 0 :=
  (spectralFactors s p A hA hpos).beta_ne_zero

end PaperChronology.Proposition3_2

#print axioms PaperChronology.Proposition3_2.derivativeMatrix_det_ne_zero
#print axioms PaperChronology.Proposition3_2.exact_degree
#print axioms PaperChronology.Proposition3_2.root_is_real
