import Proposition_3_2_Continuous_Real_Weight_Pencil

/-!
# Theorem 3.3 — spectral sign-to-root correspondence

A finite, fully general ingredient of the printed bilateral root-signature
statement. The actual alternating-sign formula for the γ_a and the precise
numbers of positive/negative eigenvalues must still be proved from the pole
residues. No such formula is assumed by these theorems.
-/

noncomputable section
namespace PaperChronology.Theorem3_3
open ManuscriptChain.Spectral

variable {n : ℕ} {p : SymmetricAffinePencil n}

/-- A positive eigenvalue produces a root strictly below the center. -/
theorem root_below_of_beta_pos (c : RootFactorization p) (i : Fin n)
    (h : 0 < c.beta i) : c.root i < p.center := by
  have hi : 0 < (c.beta i)⁻¹ := inv_pos.mpr h
  change p.center - (c.beta i)⁻¹ < p.center
  linarith

/-- Conversely, every root strictly below the center corresponds to a
positive (and never zero) eigenvalue. -/
theorem beta_pos_of_root_below (c : RootFactorization p) (i : Fin n)
    (h : c.root i < p.center) : 0 < c.beta i := by
  have hi : 0 < (c.beta i)⁻¹ := by
    change p.center - (c.beta i)⁻¹ < p.center at h
    linarith
  exact inv_pos.mp hi

/-- Exact correspondence used for Theorem 3.3's left-hand root count. -/
theorem root_below_iff_beta_pos (c : RootFactorization p) (i : Fin n) :
    c.root i < p.center ↔ 0 < c.beta i :=
  ⟨beta_pos_of_root_below c i, root_below_of_beta_pos c i⟩

/-- Every nonzero eigenvalue not positive is strictly negative. -/
theorem beta_lt_zero_of_not_pos (c : RootFactorization p) (i : Fin n)
    (h : ¬ 0 < c.beta i) : c.beta i < 0 := by
  have hle : c.beta i ≤ 0 := le_of_not_gt h
  exact lt_of_le_of_ne hle (c.beta_ne_zero i)

/-- The right-hand root count is controlled by negative eigenvalues. -/
theorem root_above_iff_beta_neg (c : RootFactorization p) (i : Fin n) :
    p.center < c.root i ↔ c.beta i < 0 := by
  constructor
  · intro h
    by_contra hn
    have hb0 : 0 ≤ c.beta i := le_of_not_gt (by
      intro hneg
      exact hn hneg)
    have hb : 0 < c.beta i := lt_of_le_of_ne hb0 (Ne.symm (c.beta_ne_zero i))
    exact (not_lt_of_ge (root_below_of_beta_pos c i hb).le) h
  · intro hb
    by_contra hnot
    have hle : c.root i ≤ p.center := le_of_not_gt hnot
    have hne : c.root i ≠ p.center := c.root_ne_center i
    have hlt : c.root i < p.center := lt_of_le_of_ne hle hne
    have hp : 0 < c.beta i := beta_pos_of_root_below c i hlt
    exact (not_lt_of_ge (le_of_lt hb)) hp

end PaperChronology.Theorem3_3

#print axioms PaperChronology.Theorem3_3.root_below_iff_beta_pos
#print axioms PaperChronology.Theorem3_3.root_above_iff_beta_neg
