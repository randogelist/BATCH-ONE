# Current Lean Coverage — 24 October 2026

## Executive estimate (entire 52-page uploaded paper)

- **Approximately 20–25% of the paper's mathematical proof work is represented by Lean theorems**, when partial mathematical results receive fractional credit.
- **Approximately 12–16% of its 51 numbered/registered manuscript items are covered at close to their full printed theorem level.** This is an estimated 6–8 genuinely close-to-complete manuscript items, not 51 or 95 complete theorem statements.
- **Approximately 75–80% remains**, including much of the analytic asymptotics, general all-order determinant theory, Dirichlet/Beukers analytic bridges, and p-adic valuation estimates.

These ranges are *judgmental proof coverage estimates*, not percentages emitted by Lean, and not an assessment that the entire PDF's arguments are correct. The 51-item paper ledger includes a definition, lemmas, remarks and a conjecture; different statements have very different mathematical workloads. A module's name, total source-module count, or proof of a finite model is not counted as a complete proof of the identically numbered PDF theorem.

## Compiler authority and package status

- Latest confirmed successful *user Windows Lean 4.33* checkpoint: **92 source modules passing**, consisting of 3 new modules compiled and 89 frozen modules reused (`RESULT=PASS`, `FINAL_AXIOMS=NO_FORBIDDEN_AXIOMS_DETECTED`).
- The v0.4.3.0 FOUR_ATOM_HANKEL source collection has **95 ordered modules**. Its 3 new modules (`Theorem_3_3_Four_Atom_General_Minors`, `Theorem_3_3_Four_Atom_Three_By_Three`, `PAPER_CHRONOLOGICAL_EXTENSION_4`) have **not yet been confirmed by a user compiler log**. They are excluded from certified coverage.
- This v0.4.3.1 edition adds only this audit and adjusts the launcher package banner. No existing `.lean` mathematical source or theorem statement was modified. No local Lean compilation was performed. Keep the persistent PASS-ONCE frozen build cache.

## By PDF sector

| Section | Coverage judgment | Evidence and principal gaps |
|---|---|---|
| §2, Definition 2.1 through Theorem 2.5 | **High, roughly 70–85%** | Generator-level functional, pullback/reflection/difference identities, basis invariance, Lagrange diagonalization. Direct `RatFunc` syntax/evaluation bridge may still need auditing. |
| §3, Theorems 3.1–3.9 | **Moderate, roughly 25–35%** | Theorem 3.1 unconditional odd-weight spectral core, Proposition 3.2 real-`s` integrability/Gram realization, pole-weight signs and special leading coefficient, selected finite-atomic minors, low-order Dodgson. Arbitrary-order strict total positivity, full inertia transfer, interlacing and corrected J-fraction remain. |
| §4, Diophantine asymptotics | **Low, roughly 10–15%** | Abstract integer-polynomial transfer and witness-only endpoint are implemented. Effective 25687 estimate and quadratic normalization/prime sums are *not* proved unconditionally. |
| §5, weight-seven and double-pole | **Low, roughly 5–10%** | Even-pole cancellation and some finite pencils/identities; most integral, β-value, prime-sum, and q-adic claims are open. |
| §6, generalized constructions | **Very low, roughly 3–8%** | Isolated exact finite identities and interfaces; the full analytic/arithmetic theorem conclusions are largely open. |

The section ranges are coarse independent estimates; averaging them is **not** a defensible overall measure because the sections differ in length and difficulty. The overarching 20–25% estimate gives conservative fractional credit for substantive partial work only.

## Representative completed or substantially completed PDF-level work

- §2: rational moment algebra, canonical change-of-basis invariance (2.4), and Lagrange pole diagonalization (2.5); pullback/reflection/difference are present on finite decomposition/generator domains (2.2–2.3).
- §3: unconditional odd-weight spectral theorem (3.1); real-`s` series positivity and the actual integrable Gram measure yielding degree and real-rootedness (3.2).
- §5: cancellation on the actual simple even-pole pair, matching equation (5.5).
- §4: a conditional transfer **theorem**, not a proof that its required arithmetic family/quantitative estimates exist.

## Partials that must NOT be promoted to a completed manuscript theorem

- Theorem 3.3: weight-five leading sign and some finite-atomic strict minors, **not** full strict total positivity for every minor of the manuscript's continuous Hankel matrix or the full universal signature.
- Theorem 3.4: low-order and shifted Dodgson identities, **not** the general Cauchy-interlacing assertion for all relevant principal blocks.
- Corollary 3.5: the printed J-fraction formula needs correction and proof, and is not certified as printed.
- Corollary 3.6: a corrected finite-atomic moment result is proved; the printed all-order strict Hankel positivity is false beyond the support rank, so it does not count as a literal PDF proof.
- Theorem 4.4: `PaperWitness.EffectiveWitness` includes essential arithmetic **and** spectral estimates. It is a conditional implication, not the unconditional claimed irrationality measure.
- Theorems 5.1–5.2 and most of 6.1–6.18: structure or partial source modules do not amount to complete analytic/p-adic proofs.

## Next high-value target

Keep the 92 user-certified modules frozen. Have the user's compiler check only the three new finite four-atom modules from v0.4.3, then work on **the full continuous-measure arbitrary-order strict total positivity of Theorem 3.3**, followed by the complete spectral signature and Theorem 3.4's general interlacing/Dodgson conclusions. This closes substantial manuscript-level gaps rather than merely growing the count of model calculations.

No `sorry`, `admit`, hidden oracle, or additional mathematical axiom is introduced by this audit.
