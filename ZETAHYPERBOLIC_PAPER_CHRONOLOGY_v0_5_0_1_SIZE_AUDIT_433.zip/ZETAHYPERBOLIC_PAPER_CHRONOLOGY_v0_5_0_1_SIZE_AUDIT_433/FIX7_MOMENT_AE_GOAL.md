# Fix7 — Explicit almost-everywhere domination

User-native Lean compiler report:

```text
CHECK_PASS=Proposition_3_2_Real_s_Weight_Envelope
CHECK=Proposition_3_2_Real_s_Moment_Integrability
CHECK_FAIL=Proposition_3_2_Real_s_Moment_Integrability
Proposition_3_2_Real_s_Moment_Integrability.lean:55:17: error: unsolved goals
```

Unlike the preceding `dsimp` error, line 55 points to an unclosed goal at
*the theorem proof level*. The new source names `hmeas` for measurability and
`hdom` for the full almost-everywhere majorization. The final line is an
`exact hsum.mono' hmeas hdom` term, ensuring the theorem has no tacit goals
left by a partially applied tactic. No theorem statement or hypothesis changes.

The CMD launcher now includes `FULL_ERROR_DETAILS_BEGIN`/`END` on failures
so the native Lean goal state appears in the pasted output. The successful
build remains concise. No assistant-side Lean compilation occurred.
