# Incremental proof delta — v0.3.8

The user's compiler most recently certified v0.3.6 (73 modules), and later the
v0.3.7.1 envelope lemma. v0.3.7.4 moment-integrability FIX4 has NOT been
confirmed and remains a candidate proof.

## New finite arithmetic and spectral count results

- `Theorem_3_3_Pole_Signature_Counts.lean`: finite sum proof of the count of odd
  integers under a cutoff; exact positive/negative pole-index counts for
  N=3n, K=30n; finite cardinality transfer from spectral eigenvalue signs to
  real-root locations.
- `PAPER_SECTION_03.lean` and `PAPER_CHRONOLOGICAL_CHAIN.lean`: the new
  arithmetic endpoint is appended, without claiming that Theorem 3.3 is closed.

## Still unproved

- FIX4's `Integrable.mono'` closure pending the user's Lean 4.33 compiler.
- PDF Theorem 3.3: sign of the ACTUAL rational residue weights, congruence /
  inertia transfer to the eigenvalue signs, strict total positivity of all
  minors, and Carleman determinate moment result. None is axiomatized.

## Workflow

Exactly one `run.cmd` in a single ZIP. Prior frozen Lean files byte-identical.
New theorem module is before the pending moment module in FASTCORE_ORDER so it
can be checked independently even if the moment proof fails.
No local compilation performed.
