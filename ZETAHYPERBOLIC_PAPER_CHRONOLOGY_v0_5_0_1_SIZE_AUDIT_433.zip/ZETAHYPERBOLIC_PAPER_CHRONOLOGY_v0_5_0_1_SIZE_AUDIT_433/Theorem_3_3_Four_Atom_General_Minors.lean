import Theorem_3_3_General_Three_Atom_Minors
import Mathlib.Tactic

/-!
# PDF Theorem 3.3 — four-atom arbitrary-index 2×2 Hankel minors

An unconditional finite-atomic extension of the verified three-atom model.
For a positive measure with four strictly ordered positive atoms, every
2×2 Hankel minor with increasing row and column indices is strictly positive.
The exact six-pair formula is a finite discrete Cauchy–Binet identity.

This does NOT identify finite-atomic moments with the paper's continuous
integral moment functional. No witness, custom axiom, or sorry is used.
-/

noncomputable section
namespace PaperChronology.Theorem3_3.FourAtomic

/-- Moments of a positive four-point measure (the masses need not be positive
for the defining expression). -/
def fourMoment (a b c d u v w z : ℝ) (j : ℕ) : ℝ :=
  a * u ^ j + b * v ^ j + c * w ^ j + d * z ^ j

/-- Shift the moment index by rescaling each atomic mass. -/
theorem fourMoment_shift (a b c d u v w z : ℝ) (n j : ℕ) :
    fourMoment a b c d u v w z (n + j) =
      fourMoment (a * u ^ n) (b * v ^ n) (c * w ^ n)
        (d * z ^ n) u v w z j := by
  simp only [fourMoment, pow_add]
  ring

/-- The exact six-pair Cauchy–Binet expression for an arbitrarily shifted,
arbitrarily gapped order-two Hankel minor. -/
theorem four_atom_general_minor_factor
    (a b c d u v w z : ℝ) (n i j : ℕ) :
    fourMoment a b c d u v w z (n + 0) *
        fourMoment a b c d u v w z (n + (i + j)) -
      fourMoment a b c d u v w z (n + i) *
        fourMoment a b c d u v w z (n + j) =
      a * b * (u * v) ^ n * ((u ^ i - v ^ i) * (u ^ j - v ^ j)) +
      a * c * (u * w) ^ n * ((u ^ i - w ^ i) * (u ^ j - w ^ j)) +
      a * d * (u * z) ^ n * ((u ^ i - z ^ i) * (u ^ j - z ^ j)) +
      b * c * (v * w) ^ n * ((v ^ i - w ^ i) * (v ^ j - w ^ j)) +
      b * d * (v * z) ^ n * ((v ^ i - z ^ i) * (v ^ j - z ^ j)) +
      c * d * (w * z) ^ n * ((w ^ i - z ^ i) * (w ^ j - z ^ j)) := by
  rw [fourMoment_shift a b c d u v w z n 0,
      fourMoment_shift a b c d u v w z n (i + j),
      fourMoment_shift a b c d u v w z n i,
      fourMoment_shift a b c d u v w z n j]
  simp only [fourMoment, pow_add, pow_zero, mul_pow, mul_one]
  ring

/-- A positive ordered pair contributes strictly positively to every
translated minor having positive row and column gaps. -/
private theorem pairTerm_pos
    (a b u v : ℝ) (n i j : ℕ)
    (ha : 0 < a) (hb : 0 < b)
    (hu : 0 < u) (huv : u < v)
    (hi : 0 < i) (hj : 0 < j) :
    0 < a * b * (u * v) ^ n *
      ((u ^ i - v ^ i) * (u ^ j - v ^ j)) := by
  have hv : 0 < v := lt_trans hu huv
  have hi0 : i ≠ 0 := Nat.ne_of_gt hi
  have hj0 : j ≠ 0 := Nat.ne_of_gt hj
  have hli : u ^ i < v ^ i := pow_lt_pow_left₀ huv hu.le hi0
  have hlj : u ^ j < v ^ j := pow_lt_pow_left₀ huv hu.le hj0
  have hpair : 0 < (u ^ i - v ^ i) * (u ^ j - v ^ j) :=
    mul_pos_of_neg_of_neg (sub_neg.mpr hli) (sub_neg.mpr hlj)
  exact mul_pos (mul_pos (mul_pos ha hb)
    (pow_pos (mul_pos hu hv) n)) hpair

/-- Strict positivity for every translated 2×2 Hankel minor of the
four-point positive measure. Independent index gaps are permitted. -/
theorem four_atom_general_minor_pos
    (a b c d u v w z : ℝ) (n i j : ℕ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d)
    (hu : 0 < u) (huv : u < v) (hvw : v < w) (hwz : w < z)
    (hi : 0 < i) (hj : 0 < j) :
    0 < fourMoment a b c d u v w z (n + 0) *
          fourMoment a b c d u v w z (n + (i + j)) -
        fourMoment a b c d u v w z (n + i) *
          fourMoment a b c d u v w z (n + j) := by
  rw [four_atom_general_minor_factor]
  have hv : 0 < v := lt_trans hu huv
  have hw : 0 < w := lt_trans hv hvw
  have huw : u < w := lt_trans huv hvw
  have huz : u < z := lt_trans huw hwz
  have hvz : v < z := lt_trans hvw hwz
  have h1 := pairTerm_pos a b u v n i j ha hb hu huv hi hj
  have h2 := pairTerm_pos a c u w n i j ha hc hu huw hi hj
  have h3 := pairTerm_pos a d u z n i j ha hd hu huz hi hj
  have h4 := pairTerm_pos b c v w n i j hb hc hv hvw hi hj
  have h5 := pairTerm_pos b d v z n i j hb hd hv hvz hi hj
  have h6 := pairTerm_pos c d w z n i j hc hd hw hwz hi hj
  exact add_pos (add_pos (add_pos (add_pos (add_pos h1 h2) h3) h4) h5) h6

end PaperChronology.Theorem3_3.FourAtomic

#print axioms PaperChronology.Theorem3_3.FourAtomic.four_atom_general_minor_factor
#print axioms PaperChronology.Theorem3_3.FourAtomic.four_atom_general_minor_pos
