# ZETAHYPERBOLIC v0.4.3.0 — Four-atom Hankel extensions

One archive, one root-level `run.cmd`, 95 ordered Lean modules. Run only from
Windows CMD using your preinstalled native Lean 4.33.0 + pinned Mathlib cache.

Last user-reported pass: v0.4.2.1, 92/92 modules, 3 compiled and 89 reused.
All 92 verified source files are unchanged. New proof targets: Theorem_3_3_Four_Atom_General_Minors, Theorem_3_3_Four_Atom_Three_By_Three, PAPER_CHRONOLOGICAL_EXTENSION_4.
The incremental launcher verifies these source files appear in FASTCORE_ORDER,
reuses previously compiled unchanged modules and checks all three new modules.
It prints `V043_CERTIFIED` lines and `RESULT=PASS` only after successful
compilation on the user's machine. `run.cmd full` forces a manual rebuild.

No Lean compilation was performed by the assistant. This release is **compiler
pending**. It is still only a finite-atomic part of Section 3 of the paper.

## v0.4.4.0 update (compiler pending)
Added three all-order algebraic Gram modules; earlier passed Lean sources
are byte-identical. One root `run.cmd` runs native Windows Lean 4.33.0,
reusing the pass-once frozen module cache and compiling the 3 new targets.
No local assistant compilation. See `V0440_MATHEMATICAL_DELTA.md`.


## v0.4.6.0
New theorem-level diagonal sign classification for the actual pole slope and chronological extension 7. Run the single `run.cmd` on the user native Lean 4.33.0 installation. No local Lean compilation was performed.

## v0.4.7.0 — exact actual diagonal sign-count theorem
New proof targets: `Theorem_3_3_Actual_Diagonal_Sign_Counts.lean` and `PAPER_CHRONOLOGICAL_EXTENSION_8.lean`. Previously verified 103 source modules are identical. One root `run.cmd`, native Windows Lean 4.33.0. See `V0470_MATHEMATICAL_DELTA.md`. No assistant-side Lean compilation.

## v0.4.7.2 source proof bridge
Corrected finite-index/range-sum bridge for actual diagonal sign counts; compiler pending.
User-certified unchanged modules reuse persistent cache. One run.cmd; no assistant Lean compilation.


## v0.5.0 direct theorem jump
105 previously certified modules frozen, 8 new modules. Read `V050_THEOREM_JUMP.md`. Run root `run.cmd`.


See PROJECT_SIZE_AUDIT_v0_5_0_1.md for measured source/module sizes.
