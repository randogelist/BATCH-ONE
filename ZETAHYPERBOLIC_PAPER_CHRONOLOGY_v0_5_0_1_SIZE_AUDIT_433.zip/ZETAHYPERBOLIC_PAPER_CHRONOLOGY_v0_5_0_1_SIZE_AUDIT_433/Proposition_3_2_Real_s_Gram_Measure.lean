import Proposition_3_2_Real_s_Weight_Infinite_Series
import Theorem_3_1_Concrete_Moment_Realization
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

/-!
# PDF Proposition 3.2 — canonical real-s moment measure

The prescribed infinite real-s density is already constructed and pointwise
positive. This file applies EXACTLY the manuscript's D_N(y²)^(2m)/D_K(y²)
weight, then pushes forward along y ↦ y², giving the exact candidate Gram
measure for all real s>1.

Unconditional: positive weighted density, measurability, a nonzero atomless
measure, and the integral and integrability transport identities.

The precise unresolved analytic target is the integrability of all moments.
Once that is proved, positive definiteness and the real-rooted spectral
factorization follow by existing theorems. There is no axiom, opaque witness,
or assumption of the desired positive definiteness in the constructions.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory Set Polynomial

namespace PaperChronology.Proposition3_2.Gram

/-- The actual denominator ratio and actual infinite weight in the PDF. -/
def weightedDensity (s : ℝ) (p : ManuscriptChain.Real.Parameters)
    (y : ℝ) : ℝ :=
  (Zetahyperbolic.D_real p.N (y ^ 2)) ^ (2 * p.m) /
    Zetahyperbolic.D_real p.K (y ^ 2) *
      PaperChronology.Proposition3_2.Analytic.realWeight s y

theorem weightedDensity_pos (s : ℝ) (p : ManuscriptChain.Real.Parameters)
    (hs : 1 < s) {y : ℝ} (hy : 0 < y) :
    0 < weightedDensity s p y :=
  mul_pos (Zetahyperbolic.D_real_ratio_pos p.N p.K p.m hy)
    (PaperChronology.Proposition3_2.Analytic.realWeight_pos hs hy)

theorem measurable_weightedDensity (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) :
    Measurable (weightedDensity s p) := by
  unfold weightedDensity Zetahyperbolic.D_real
  apply Measurable.mul _
    (PaperChronology.Proposition3_2.Analytic.measurable_realWeight s)
  fun_prop

/-- An explicitly constructed density-weighted measure on y>0. -/
def weightedMeasure (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    Measure ℝ :=
  (volume.restrict (Ioi 0)).withDensity
    (fun y => ENNReal.ofReal (weightedDensity s p y))

instance weightedMeasure_nullSingleton (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) :
    NullSingletonClass (weightedMeasure s p) := by
  unfold weightedMeasure
  infer_instance

theorem weightedMeasure_nonzero (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    weightedMeasure s p ≠ 0 := by
  have hac : volume.restrict (Ioi (0 : ℝ)) ≪ weightedMeasure s p := by
    apply withDensity_absolutelyContinuous'
      (measurable_weightedDensity s p).ennreal_ofReal.aemeasurable
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
    exact ne_of_gt (ENNReal.ofReal_pos.mpr (weightedDensity_pos s p hs hy))
  intro hzero
  rw [hzero] at hac
  have h := Measure.absolutelyContinuous_zero_iff.mp hac
  have hu := congrArg (fun μ : Measure ℝ => μ Set.univ) h
  simp at hu

/-- Pushforward by t = y², exactly as in the manuscript. -/
def momentMeasure (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    Measure ℝ :=
  (weightedMeasure s p).map (fun y : ℝ => y ^ 2)

theorem momentMeasure_nonzero (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) :
    momentMeasure s p ≠ 0 := by
  exact (Measure.map_ne_zero_iff (by fun_prop)).2
    (weightedMeasure_nonzero s p hs)

instance momentMeasure_nullSingleton (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) :
    NullSingletonClass (momentMeasure s p) := by
  constructor
  intro t
  rw [momentMeasure, Measure.map_apply (by fun_prop) (measurableSet_singleton t)]
  have hq : (X ^ 2 - C t : ℝ[X]) ≠ 0 := by
    intro h
    have hcoeff := congrArg (fun q : ℝ[X] => q.coeff 2) h
    norm_num at hcoeff
  have hz :=
    (Polynomial.finite_setOfPred_isRoot hq).measure_zero (weightedMeasure s p)
  have hs : (fun y : ℝ => y ^ 2) ⁻¹' {t} =
      {y | Polynomial.IsRoot (X ^ 2 - C t : ℝ[X]) y} := by
    ext y
    simp [Polynomial.IsRoot, sub_eq_zero]
  rw [hs]
  exact hz

/-- The exact entry integral, in the original positive-half-line variable y. -/
theorem integral_momentMeasure (s : ℝ) (p : ManuscriptChain.Real.Parameters)
    (hs : 1 < s) (e : ℕ) :
    (∫ t, t ^ e ∂momentMeasure s p) =
      ∫ y in Ioi (0 : ℝ), y ^ (2 * e) * weightedDensity s p y := by
  rw [momentMeasure, integral_map (by fun_prop) (by fun_prop), weightedMeasure,
    integral_withDensity_eq_integral_toReal_smul
      (measurable_weightedDensity s p).ennreal_ofReal (by simp)]
  apply integral_congr_ae
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
  rw [ENNReal.toReal_ofReal (weightedDensity_pos s p hs hy).le]
  simp only [smul_eq_mul]
  rw [← pow_mul]
  ring

/-- This is the exact integrability bridge still to be proved unconditionally. -/
theorem integrable_momentMeasure_iff (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) (e : ℕ) :
    Integrable (fun t : ℝ => t ^ e) (momentMeasure s p) ↔
      IntegrableOn (fun y : ℝ => y ^ (2 * e) * weightedDensity s p y)
        (Ioi 0) := by
  rw [momentMeasure, integrable_map_measure (by fun_prop) (by fun_prop),
    weightedMeasure, integrable_withDensity_iff_integrable_smul'
      (measurable_weightedDensity s p).ennreal_ofReal (by simp)]
  apply integrable_congr
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
  rw [ENNReal.toReal_ofReal (weightedDensity_pos s p hs hy).le]
  simp only [Function.comp_def, smul_eq_mul]
  rw [← pow_mul]
  ring

/-- The PDF's actual real-s Gram matrix, defined by its exact measure. -/
def gram (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  ManuscriptChain.Moments.momentMatrix (momentMeasure s p) p.h

theorem gram_symmetric (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) :
    (gram s p).IsSymm := by
  ext i j
  change (∫ t, t ^ (j.val + i.val) ∂momentMeasure s p) =
    (∫ t, t ^ (i.val + j.val) ∂momentMeasure s p)
  simp only [Nat.add_comm]

/-- No Gram-positive assumption: actual measure positivity implies it,
provided the still-open weighted-moment integrability estimate holds. -/
theorem gram_posDef_of_integrable (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (hm : ∀ i j : Fin p.h,
      Integrable (fun t : ℝ => t ^ (i.val + j.val)) (momentMeasure s p)) :
    (gram s p).PosDef := by
  unfold gram
  exact ManuscriptChain.Moments.momentMatrix_posDef
    (momentMeasure_nonzero s p hs) hm

/-- The exact manuscript pencil with its constructed Gram, rather than
an arbitrary positive-definite matrix parameter. -/
def actualPencil (s : ℝ) (p : ManuscriptChain.Real.Parameters) :
    ManuscriptChain.Spectral.SymmetricAffinePencil p.h :=
  PaperChronology.Proposition3_2.pencil s p (gram s p) (gram_symmetric s p)

theorem actualPencil_degree_of_integrable (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (hm : ∀ i j : Fin p.h,
      Integrable (fun t : ℝ => t ^ (i.val + j.val)) (momentMeasure s p)) :
    (actualPencil s p).detPolynomial.natDegree = p.h := by
  exact PaperChronology.Proposition3_2.exact_degree s p (gram s p)
    (gram_symmetric s p) (gram_posDef_of_integrable s p hs hm)

theorem actualPencil_root_real_of_integrable (s : ℝ)
    (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    (hm : ∀ i j : Fin p.h,
      Integrable (fun t : ℝ => t ^ (i.val + j.val)) (momentMeasure s p))
    (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (actualPencil s p).detPolynomial = 0) : z.im = 0 :=
  PaperChronology.Proposition3_2.root_is_real s p (gram s p)
    (gram_symmetric s p) (gram_posDef_of_integrable s p hs hm) z hz

end PaperChronology.Proposition3_2.Gram

#print axioms PaperChronology.Proposition3_2.Gram.weightedMeasure_nonzero
#print axioms PaperChronology.Proposition3_2.Gram.momentMeasure_nullSingleton
#print axioms PaperChronology.Proposition3_2.Gram.integrable_momentMeasure_iff
#print axioms PaperChronology.Proposition3_2.Gram.gram_posDef_of_integrable
#print axioms PaperChronology.Proposition3_2.Gram.actualPencil_degree_of_integrable
