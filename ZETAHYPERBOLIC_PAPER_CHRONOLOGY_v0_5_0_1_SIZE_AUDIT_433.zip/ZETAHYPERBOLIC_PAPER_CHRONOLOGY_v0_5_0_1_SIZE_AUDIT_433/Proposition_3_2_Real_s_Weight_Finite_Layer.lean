import Proposition_3_2_Continuous_Real_Weight_Pencil
import Theorem_3_1_Hyperbolic_Weight
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# Proposition 3.2 — the exact real-s exponential series, finite layer

The analytic weight from the manuscript contains the series
  ∑_{n≥1} n^(s-1) * exp(-2π n y).
Here we construct EVERY nonempty finite truncation of exactly that series,
prove strict positivity for y>0, monotone growth as more terms are added,
and prove termwise identity with the established odd-weight exponential terms
at s=2k+1.

This file neither assumes convergence of the infinite real-s series nor
claims that its integral moments have been constructed.  The complete
infinite-sum/integrability bridge remains the next step of Proposition 3.2.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Proposition3_2.Analytic

/-- The l=n+1 summand of the paper's real-s density, with l≥1. -/
def exponentialTerm (s : ℝ) (n : ℕ) (y : ℝ) : ℝ :=
  ((n + 1 : ℕ) : ℝ) ^ (s - 1) *
    Real.exp (-(2 * Real.pi * y) * ((n + 1 : ℕ) : ℝ))

theorem exponentialTerm_pos (s : ℝ) (n : ℕ) {y : ℝ} (hy : 0 < y) :
    0 < exponentialTerm s n y := by
  unfold exponentialTerm
  have hn : 0 < ((n + 1 : ℕ) : ℝ) := by positivity
  exact mul_pos (Real.rpow_pos_of_pos hn _) (Real.exp_pos _)

/-- First N+1 summands (always nonempty). -/
def partialSeries (s : ℝ) (N : ℕ) (y : ℝ) : ℝ :=
  ∑ n ∈ Finset.range (N + 1), exponentialTerm s n y

theorem partialSeries_pos (s : ℝ) (N : ℕ) {y : ℝ} (hy : 0 < y) :
    0 < partialSeries s N y := by
  unfold partialSeries
  rw [Finset.sum_range_succ]
  exact add_pos_of_nonneg_of_pos
    (Finset.sum_nonneg (fun n _ => (exponentialTerm_pos s n hy).le))
    (exponentialTerm_pos s N hy)

theorem partialSeries_succ (s y : ℝ) (N : ℕ) :
    partialSeries s (N + 1) y =
      partialSeries s N y + exponentialTerm s (N + 1) y := by
  simp only [partialSeries]
  simpa only [Nat.add_assoc] using
    (Finset.sum_range_succ (fun n => exponentialTerm s n y) (N + 1))

theorem partialSeries_mono_succ (s : ℝ) (N : ℕ) {y : ℝ} (hy : 0 < y) :
    partialSeries s N y ≤ partialSeries s (N + 1) y := by
  rw [partialSeries_succ]
  exact le_add_of_nonneg_right (exponentialTerm_pos s (N + 1) hy).le

/-- The y^s factor from the manuscript's (unnormalized) real-s weight. -/
def shapeDensity (s : ℝ) (N : ℕ) (y : ℝ) : ℝ :=
  y ^ s * partialSeries s N y

theorem shapeDensity_pos (s : ℝ) (N : ℕ) {y : ℝ} (hy : 0 < y) :
    0 < shapeDensity s N y := by
  unfold shapeDensity
  exact mul_pos (Real.rpow_pos_of_pos hy _) (partialSeries_pos s N hy)

theorem shapeDensity_mono_succ (s : ℝ) (N : ℕ) {y : ℝ} (hy : 0 < y) :
    shapeDensity s N y ≤ shapeDensity s (N + 1) y := by
  unfold shapeDensity
  exact mul_le_mul_of_nonneg_left
    (partialSeries_mono_succ s N hy) (Real.rpow_pos_of_pos hy _).le

/-- Real-s summands coincide with the *existing* odd-weight summands
without any extra normalization or change of family. -/
theorem exponentialTerm_at_odd (p : ManuscriptChain.Real.Parameters)
    (n : ℕ) (y : ℝ) :
    exponentialTerm (p.weight : ℝ) n y =
      ManuscriptChain.Hyperbolic.exponentialTerm p.k n y := by
  have hpow : (p.weight : ℝ) - 1 = (2 * p.k : ℕ) := by
    dsimp [ManuscriptChain.Real.Parameters.weight]
    push_cast
    ring
  simp only [exponentialTerm, ManuscriptChain.Hyperbolic.exponentialTerm,
    hpow, Real.rpow_natCast]

theorem partialSeries_at_odd (p : ManuscriptChain.Real.Parameters)
    (N : ℕ) (y : ℝ) :
    partialSeries (p.weight : ℝ) N y =
      ∑ n ∈ Finset.range (N + 1),
        ManuscriptChain.Hyperbolic.exponentialTerm p.k n y := by
  simp only [partialSeries, exponentialTerm_at_odd]

/-- Term-by-term agreement of the real-s finite weight with the odd-weight
finite weight, omitting their common positive gamma normalization. -/
theorem shapeDensity_at_odd (p : ManuscriptChain.Real.Parameters)
    (N : ℕ) (y : ℝ) :
    shapeDensity (p.weight : ℝ) N y =
      y ^ p.weight *
        (∑ n ∈ Finset.range (N + 1),
          ManuscriptChain.Hyperbolic.exponentialTerm p.k n y) := by
  rw [shapeDensity, partialSeries_at_odd]
  rw [Real.rpow_natCast]

end PaperChronology.Proposition3_2.Analytic

#print axioms PaperChronology.Proposition3_2.Analytic.partialSeries_pos
#print axioms PaperChronology.Proposition3_2.Analytic.shapeDensity_mono_succ
#print axioms PaperChronology.Proposition3_2.Analytic.shapeDensity_at_odd
