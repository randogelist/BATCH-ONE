# v0.4.5.0 — Direct PDF theorem construction (compiler pending)

All **98 earlier sources** are preserved byte-identically.

## Theorem 3.3(1) — actual continuous principal minors

- Unconditionally, for every s>1 and every injection `Fin r → Fin p.h`, the
  principal submatrix of the **actual constructed** continuous moment matrix
  is positive definite and has strictly positive determinant.
- The same is proved for the genuine odd-integer zeta Hankel Gram.
- No arbitrary externally-supplied Gram-positive premise, auxiliary finite-atom
  family, or arithmetic Witness appears in the results.

## Theorem 3.4(1) — all principal-minor roots real

- New *singular-direction* spectral factorization of an arbitrary symmetric
  affine pencil with a positive-definite base. No invertibility of the slope.
- Applies to **every** real-s and odd-zeta principal subpencil of the actual
  continuous Hankel determinant.
- Every complex root lies on the real axis and each principal polynomial is
  strictly positive at the distinguished zeta center.
- The printed Cauchy interlacing claim is not yet claimed by these files.

## Still open

Theorem 3.3 strict nonprincipal minor total positivity (Andreief and
generalized Chebyshev), determinacy; Theorem 3.3 full inertia, Theorem 3.4
Cauchy interlacing and general-size Jacobi condensation.

NO local Lean compilation. Single root run.cmd and persistent frozen cache.
