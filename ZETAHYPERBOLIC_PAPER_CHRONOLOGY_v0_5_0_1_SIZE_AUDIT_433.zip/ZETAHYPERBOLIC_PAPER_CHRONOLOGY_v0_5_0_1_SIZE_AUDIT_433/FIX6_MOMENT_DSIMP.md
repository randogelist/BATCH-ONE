# Fix6 — Proposition 3.2 real-s moment integrability

Observed native compiler feedback (user):

```text
CHECK_PASS=Proposition_3_2_Real_s_Weight_Envelope
CHECK=Proposition_3_2_Real_s_Moment_Integrability
CHECK_FAIL=Proposition_3_2_Real_s_Moment_Integrability
Proposition_3_2_Real_s_Moment_Integrability.lean:97:2: error: `dsimp` made no progress
```

`hbound` is the pointwise bound produced directly by
`mul_le_mul_of_nonneg_left`. Its right side already contains the full
expressions `realCoefficient s / oddCoefficient 0` and
`realCoefficient s / oddCoefficient k`; the local names `c0` and `ck`
appear only in the target inequality below. Therefore `dsimp only
[c0, ck] at hbound` has no occurrence to rewrite and fails. The
following `simpa only [c0, ck, mul_add, mul_assoc, mul_left_comm,
mul_comm] using hbound` performs the necessary comparison.

Only that redundant tactic is deleted (replaced by a comment).
No mathematical assumptions changed. Pending user compiler.
