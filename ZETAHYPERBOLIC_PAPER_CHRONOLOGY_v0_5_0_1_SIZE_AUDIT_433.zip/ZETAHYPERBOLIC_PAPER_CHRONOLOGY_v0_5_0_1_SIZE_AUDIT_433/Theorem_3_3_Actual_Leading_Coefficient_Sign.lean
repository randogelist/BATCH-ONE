import Theorem_3_3_Pole_Weight_Signs
import Mathlib.Tactic

/-!
# Theorem 3.3(2) — actual determinant leading-coefficient sign certificate

For the manuscript's *actual rational Hankel polynomial*, not a free matrix
pencil, the coefficient of the highest power of X is det(M). Theorem 2.5
provides the exact factorization

  det(M) = det(V)^2 * ∏ₐ γₐ.

The exact sign of each γₐ is now the result of the preceding pole-product
proofs. This file composes those results to give an unconditional strictly
positive signed leading coefficient. The determinant and diagonal congruence
are the actual objects defined in the earlier Section 2 development.

No witness, no extra analytical hypothesis, no sorry, admit, or custom axiom.
This new source is *not* certified until run on the user's Lean 4.33 compiler.
This does not assert the remaining inertia/all-minor positivity statements.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_3.ActualLeadingSign

open ManuscriptChain.PoleDiagonalization

/-- The prescribed alternating sign applied to each pole residue gives a
strictly positive product over the complete pole lattice. -/
theorem poleWeights_signed_product_positive
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m) :
    0 < ∏ i : Fin p.h,
      ((-1 : ℚ) ^ (poleIndex p i - 1) * poleWeight p i) := by
  classical
  apply Finset.prod_pos
  intro i _
  exact PaperChronology.Theorem3_3.PoleWeightSigns.actual_poleWeight_signed_positive p hm i

/-- The actual derivative determinant and its leading coefficient have the
same exact sign, encoded without a chosen ordering of eigenvalues. -/
theorem actual_leadingCoeff_signed_positive
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m) :
    0 < (∏ i : Fin p.h, (-1 : ℚ) ^ (poleIndex p i - 1)) *
      (ManuscriptChain.Real.delta p).leadingCoeff := by
  have hV : 0 < (poleVandermonde p).det ^ 2 := by
    exact sq_pos_of_ne_zero (poleVandermonde_det_ne_zero p)
  have hprod := poleWeights_signed_product_positive p hm
  calc
    (∏ i : Fin p.h, (-1 : ℚ) ^ (poleIndex p i - 1)) *
        (ManuscriptChain.Real.delta p).leadingCoeff =
      ((poleVandermonde p).det ^ 2) *
        (∏ i : Fin p.h,
          ((-1 : ℚ) ^ (poleIndex p i - 1) * poleWeight p i)) := by
      rw [delta_leadingCoeff, rationalDerivativeMatrix_det,
        Finset.prod_mul_distrib]
      ring
    _ > 0 := mul_pos hV hprod

/-- The diagonalized *actual* rational derivative matrix has the alternating
pole-index signs on its diagonal, without postulating a spectral signature. -/
theorem actual_diagonalized_slope_signed_positive
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m)
    (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (poleIndex p i - 1) *
      ((poleVandermonde p)⁻¹ * rationalDerivativeMatrix p *
        ((poleVandermonde p)⁻¹).transpose) i i := by
  rw [pole_slope_diagonal]
  simpa using
    (PaperChronology.Theorem3_3.PoleWeightSigns.actual_poleWeight_signed_positive p hm i)

end PaperChronology.Theorem3_3.ActualLeadingSign

#print axioms PaperChronology.Theorem3_3.ActualLeadingSign.actual_leadingCoeff_signed_positive
#print axioms PaperChronology.Theorem3_3.ActualLeadingSign.actual_diagonalized_slope_signed_positive
