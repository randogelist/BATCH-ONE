# v0.4.4.0 — Arbitrary-order pole Gram algebra (compiler pending)

New sources:

1. `Theorem_3_3_Arbitrary_Order_Gram_Determinant.lean`: exact determinant,
   strict positive determinant, nonsingularity, and vanishing for a zero mass,
   for *every* finite dimension and any ordered field.
2. `Theorem_3_3_Actual_Sign_Corrected_Pole_Gram.lean`: discharges
   Vandermonde nondegeneracy and positive corrected-residue weights for the
   manuscript's *actual* pole lattice, at arbitrary size.
3. `PAPER_CHRONOLOGICAL_EXTENSION_5.lean`: unconditional chronological
   endpoint for the true pole index structure.

All 95 modules in last user's `BUILD_COMPILED=0 BUILD_FROZEN_REUSED=95 RESULT=PASS`
are preserved unmodified. Exactly 3 new modules are placed after them.

This is **not** the paper's continuous-measure strict total positivity
at every minor; a separate integral/Andreief and Chebyshev-system proof
is still required. It does not assert a complete proof of the entire PDF.

The assistant did not invoke any Lean compiler. The source and module order
await the user's native Windows Lean 4.33.0 FASTCORE build.
