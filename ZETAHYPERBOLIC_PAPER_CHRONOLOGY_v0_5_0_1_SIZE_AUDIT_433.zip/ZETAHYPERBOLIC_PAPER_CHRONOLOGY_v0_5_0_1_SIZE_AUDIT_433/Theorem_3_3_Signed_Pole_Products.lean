import Theorem_2_5_Lagrange_Pole_Diagonalization
import Mathlib.Tactic

/-!
# PDF Theorem 3.3: signed products for the actual negative-square poles

For each N < a ≤ K, the polynomial D_N(-a²) has N strictly
negative factors, while D_tail'(-a²) has a-N-1 strictly negative
factors and all other factors strictly positive.  These are exact
rational-polynomial identities, independent of any analytic witness.

This revision spells out each finite product, interval partition,
and square-difference inequality to avoid unfinished simplifier goals.
It does not assert the downstream inertia theorem until that bridge is
proved.  The user's Windows Lean 4.33.0 compiler is the only authority.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology.Theorem3_3.SignedPoleProducts

/-- All factors negative: after multiplication by (-1) to the
number of factors, the finite product is strictly positive. -/
theorem negative_product_signed_positive (s : Finset ℕ) (f : ℕ → ℚ)
    (hf : ∀ b ∈ s, f b < 0) :
    0 < (-1 : ℚ) ^ s.card * (∏ b ∈ s, f b) := by
  classical
  have hpositive : 0 < (∏ b ∈ s, -(f b)) := by
    apply Finset.prod_pos
    intro b hb
    exact neg_pos.mpr (hf b hb)
  have hsign : (∏ b ∈ s, -(f b)) =
      (-1 : ℚ) ^ s.card * (∏ b ∈ s, f b) := by
    calc
      (∏ b ∈ s, -(f b)) =
          (∏ b ∈ s, (-1 : ℚ) * f b) := by
            apply Finset.prod_congr rfl
            intro b hb
            ring
      _ = (∏ _b ∈ s, (-1 : ℚ)) * (∏ b ∈ s, f b) := by
            exact Finset.prod_mul_distrib
      _ = _ := by
            simp only [Finset.prod_const]
  rw [← hsign]
  exact hpositive

/-- Difference of squares is negative when the nonnegative first
argument is strictly smaller than the second. -/
private theorem square_sub_square_neg {u v : ℚ}
    (hu : 0 ≤ u) (huv : u < v) : u ^ 2 - v ^ 2 < 0 := by
  have hneg : u - v < 0 := sub_neg.mpr huv
  have hpos : 0 < u + v := by linarith
  have hprod : (u - v) * (u + v) < 0 :=
    mul_neg_of_neg_of_pos hneg hpos
  nlinarith

/-- Difference of squares is positive in the opposite direction. -/
private theorem square_sub_square_pos {u v : ℚ}
    (hu : 0 ≤ u) (huv : u < v) : 0 < v ^ 2 - u ^ 2 := by
  have h := square_sub_square_neg hu huv
  linarith

/-- The exact numerator of the Lagrange residue has sign (-1)^N. -/
theorem D_eval_negative_square_signed_positive (N a : ℕ)
    (hNa : N < a) :
    0 < (-1 : ℚ) ^ N *
      (ManuscriptChain.Real.D N).eval (-(a : ℚ) ^ 2) := by
  have hEval :
      (ManuscriptChain.Real.D N).eval (-(a : ℚ) ^ 2) =
        ∏ j ∈ Finset.range N,
          ((((j + 1 : ℕ) : ℚ) ^ 2) - (a : ℚ) ^ 2) := by
    simp only [ManuscriptChain.Real.D, Polynomial.eval_prod]
    apply Finset.prod_congr rfl
    intro j hj
    simp only [Polynomial.eval_add, Polynomial.eval_X, Polynomial.eval_C]
    ring
  have hneg : ∀ j ∈ Finset.range N,
      ((((j + 1 : ℕ) : ℚ) ^ 2) - (a : ℚ) ^ 2) < 0 := by
    intro j hj
    have hjN : j < N := Finset.mem_range.mp hj
    have hjlt : j + 1 < a := by omega
    have hjQ : ((j + 1 : ℕ) : ℚ) < (a : ℚ) := by
      exact_mod_cast hjlt
    exact square_sub_square_neg (by positivity) hjQ
  rw [hEval]
  simpa only [Finset.card_range] using
    (negative_product_signed_positive (Finset.range N)
      (fun j : ℕ => ((((j + 1 : ℕ) : ℚ) ^ 2) - (a : ℚ) ^ 2)) hneg)

/-- The exact denominator derivative at the pole -a² has
exactly (a-N-1) negative factors. -/
theorem tail_derivative_negative_square_signed_positive
    (p : ManuscriptChain.Real.Parameters) (a : ℕ)
    (ha : a ∈ Finset.Icc (p.N + 1) p.K) :
    0 < (-1 : ℚ) ^ (a - p.N - 1) *
      (derivative (ManuscriptChain.Real.tailD p)).eval (-(a : ℚ) ^ 2) := by
  classical
  let F : Finset ℕ := Finset.Icc (p.N + 1) p.K
  let L : Finset ℕ := F.filter (fun b => b < a)
  let U : Finset ℕ := F.filter (fun b => a < b)
  have hsplit : F.erase a = L ∪ U := by
    ext b
    simp only [L, U, Finset.mem_erase, Finset.mem_union,
      Finset.mem_filter]
    constructor
    · rintro ⟨hne, hb⟩
      by_cases hlt : b < a
      · exact Or.inl ⟨hb, hlt⟩
      · exact Or.inr ⟨hb, by omega⟩
    · intro hb
      rcases hb with hb | hb
      · exact ⟨by omega, hb.1⟩
      · exact ⟨by omega, hb.1⟩
  have hdis : Disjoint L U := by
    apply Finset.disjoint_left.mpr
    intro b hbL hbU
    have hbl : b < a := (Finset.mem_filter.mp hbL).2
    have hbu : a < b := (Finset.mem_filter.mp hbU).2
    omega
  have haN : p.N + 1 ≤ a := (Finset.mem_Icc.mp ha).1
  have haK : a ≤ p.K := (Finset.mem_Icc.mp ha).2
  have hL : L = Finset.Icc (p.N + 1) (a - 1) := by
    ext b
    simp only [L, F, Finset.mem_filter, Finset.mem_Icc]
    constructor
    · rintro ⟨⟨hNB, _⟩, hBA⟩
      constructor <;> omega
    · rintro ⟨hNB, hBA⟩
      refine ⟨⟨hNB, ?_⟩, ?_⟩ <;> omega
  have hcount : L.card = a - p.N - 1 := by
    rw [hL]
    have hcard :
        (Finset.Icc (p.N + 1) (a - 1)).card =
          (a - 1) + 1 - (p.N + 1) :=
      Nat.card_Icc (p.N + 1) (a - 1)
    rw [hcard]
    omega
  have hbelow :
      0 < (-1 : ℚ) ^ L.card *
        (∏ b ∈ L, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) := by
    apply negative_product_signed_positive
    intro b hb
    have hbA : b < a := (Finset.mem_filter.mp hb).2
    have hbQ : (b : ℚ) < (a : ℚ) := by exact_mod_cast hbA
    exact square_sub_square_neg (by positivity) hbQ
  have habove :
      0 < (∏ b ∈ U, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) := by
    apply Finset.prod_pos
    intro b hb
    have haB : a < b := (Finset.mem_filter.mp hb).2
    have haBQ : (a : ℚ) < (b : ℚ) := by exact_mod_cast haB
    exact square_sub_square_pos (by positivity) haBQ
  have hprodEq :
      (derivative (ManuscriptChain.Real.tailD p)).eval
        (-(a : ℚ) ^ 2) =
      (∏ b ∈ L, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) *
      (∏ b ∈ U, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) := by
    rw [ManuscriptChain.PoleDiagonalization.tailD_derivative_eval p a ha,
      hsplit, Finset.prod_union hdis]
  calc
    (-1 : ℚ) ^ (a - p.N - 1) *
        (derivative (ManuscriptChain.Real.tailD p)).eval
          (-(a : ℚ) ^ 2) =
      ((-1 : ℚ) ^ L.card *
        (∏ b ∈ L, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2))) *
        (∏ b ∈ U, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) := by
          rw [hprodEq, hcount]
          ring
    _ > 0 := mul_pos hbelow habove

/-- Both signs hold for the manuscript's actual Lagrange pole index. -/
theorem actual_signed_factor_pair (p : ManuscriptChain.Real.Parameters)
    (i : Fin p.h) :
    0 < (-1 : ℚ) ^ p.N *
      (ManuscriptChain.Real.D p.N).eval
        (ManuscriptChain.PoleDiagonalization.poleNode p i) ∧
    0 < (-1 : ℚ) ^
        (ManuscriptChain.PoleDiagonalization.poleIndex p i - p.N - 1) *
      (derivative (ManuscriptChain.Real.tailD p)).eval
        (ManuscriptChain.PoleDiagonalization.poleNode p i) := by
  have hi := ManuscriptChain.PoleDiagonalization.poleIndex_mem p i
  have hNi : p.N < ManuscriptChain.PoleDiagonalization.poleIndex p i := by
    have h := (Finset.mem_Icc.mp hi).1
    omega
  constructor
  · simpa only [ManuscriptChain.PoleDiagonalization.poleNode] using
      (D_eval_negative_square_signed_positive p.N _ hNi)
  · simpa only [ManuscriptChain.PoleDiagonalization.poleNode] using
      (tail_derivative_negative_square_signed_positive p _ hi)

end PaperChronology.Theorem3_3.SignedPoleProducts

#print axioms PaperChronology.Theorem3_3.SignedPoleProducts.D_eval_negative_square_signed_positive
#print axioms PaperChronology.Theorem3_3.SignedPoleProducts.tail_derivative_negative_square_signed_positive
#print axioms PaperChronology.Theorem3_3.SignedPoleProducts.actual_signed_factor_pair
