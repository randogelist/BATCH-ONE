# Formal chain with precisely named witness boundaries

Source: Prince Anand, *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values* (2026-10-21), uploaded 52-page PDF. Pinned Lean 4.33.0/Mathlib from upstream archive.

## Verdict

**Yes**, the **central weight-five irrationality spine** can be stated in native Lean with one mathematical premise named `PaperWitness.Witness`: the actual normalized determinant family with the paper's eventual quadratic bound. All of the other ingredients used in that particular irrationality implication (identity of the polynomial, positive Gram representation, degree, nonvanishing, and the denominator contradiction) are either fields verifying the witness is the *specified* polynomial or unconditional theorems in the imported modules.

**Not yet** for a literal formalization of **the entire PDF** using only this witness: independent claims in Sections 3, 5 and 6 require further proofs, and some are incorrect as printed. A mathematical witness for section 4 does not repair false claims.

## Source-faithful witness

Paper equations (4.2)--(4.3), with K=30*n, N=3*n, h=27*n, specify

    S_K > 0, F_K(X) = S_K * Delta_K(X),
    Q_K(X) = m_(K,M) * F_K(X) in Z[X], m_(K,M)>0,
    0 < Q_K(zeta(5)) <= exp(-K^2 / 2500), eventually.

`MainChain.MainNormalization` certifies the exact algebraic identity, integrality, positive multiplier, and a positive onset. `PaperWitness.Witness.normalized_value_upper` is the **only additional eventual decay premise**. The positivity `0 < Q_K(zeta(5))` follows from the actual positive moment representation and the positive multiplier; it is not taken as a separate hypothesis.

Lean endpoint:

    PaperWitness.ZETA5_IRRATIONAL_OF_WITNESS
       (w : PaperWitness.Witness) : Irrational (riemannZeta (5 : C)).re

An even leaner endpoint uses the already constructed positive primitive normalized family:

    PaperWitness.ZETA5_IRRATIONAL_OF_PRIMITIVE_WITNESS
       (w : PaperWitness.PrimitiveWitness) : Irrational (riemannZeta (5 : C)).re

An adapter `witness_of_paper_bounds` reconstructs the witness from the paper's claimed uniform multiplier and archimedean estimates (they remain premises, not proved by the adapter).

## Why the effective measure needs more than the arithmetic witness

Corollary of Theorem 3.1 gives an exact *positive* zero-free radius but not the uniform value exp(-11.411*K). The paper's Theorem 4.4 uses:

    max_i |beta_(K,i)| <= exp(11.411*K), eventually.

`PaperWitness.EffectiveWitness` packages `PaperWitness.Witness` plus `MainChain.MainSpectralData` for this growth estimate. Its endpoint is:

    PaperWitness.MEASURE_25687_OF_WITNESS
       (w : PaperWitness.EffectiveWitness) :
       RealTransfer.RationalMeasure zeta5 25687 (indexDenominatorThreshold ...)

The effective transfer itself, including the comparison radius and denominator index, is an already-written Lean proof. **The quantitative norm bound is not shown to follow from the arithmetic witness**. A one-argument `EffectiveWitness` is only a packaging of two independent estimates; it should never be described as proof that all but one underlying mathematical lemma have been discharged.

## General odd-weight endpoint

Theorem 3.1's general odd-weight hyperbolicity is unconditional in the imported `MAIN_CHAIN_ASSEMBLED` proof. Its universal irrationality analogue needs the strictly stronger family-level premise:

    forall k>=1, exists admissible sequence of actual primitive Hankel P_(k,n)
      with K_(k,n) unbounded and
      0 < P_(k,n)(zeta(2k+1)) <= exp(-c_k K_(k,n)^2) eventually.

`PaperWitness.AllOddWitness` states exactly that; it is **not** supplied by the paper's one weight-five certificate.

## The parts that cannot literally be closed by this witness

* Corollary 3.5: printed J-fraction scaling is false at h=1. Requires rewriting the identity, then proving the corrected statement.
* Corollary 3.6: order r>h finite-atomic Hankel determinants vanish, contradicting the printed universal strict positivity; the comparison inequality direction is also reversed.
* Theorem 5.2(3): positive/negative Krein spaces require the full infinite-tail bound absent in the printed finite truncation argument.
* Theorems 4.5, 4.6--4.8 and 5.3--6.18: their paper-level integral identities, asymptotic bounds, prime valuation estimates and/or functional bridges are not all in the compiled manuscript chain. In particular a zeta5 witness says nothing on its own about simultaneous zeta7-beta constructions.
* Conjecture 4.11 is openly conjectural, and need not be proved to close the manuscript's main conditional theorem.

## Rebuild / trust

The source-only distribution adds exactly `PAPER_WITNESS_ONLY.lean` and `PAPER_CHRONOLOGICAL_CHAIN.lean` to the prior auditable archive. No new `axiom`, `sorry`, `admit`, or `native_decide` is used. Lean 4.33.0 + pinned Mathlib compiled artifacts are not installed in the current execution environment, **so the new Lean files have not been compiled**. Use `run.cmd` on the user's Windows native environment with the matching Mathlib tree already present.

Inspect `#check` of theorem TYPES to see what is conditional; `#print axioms` can list only `propext`, `Classical.choice`, `Quot.sound` even when the theorem has an explicit witness parameter.
