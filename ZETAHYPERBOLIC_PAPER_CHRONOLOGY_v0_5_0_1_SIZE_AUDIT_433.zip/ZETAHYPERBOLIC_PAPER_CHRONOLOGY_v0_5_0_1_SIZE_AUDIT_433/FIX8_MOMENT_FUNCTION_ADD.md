# FIX8 — Theorem-level integrability majorant application

Module: `Proposition_3_2_Real_s_Moment_Integrability.lean`.

The user's Lean 4.33.0 log shows the final `Integrable.mono' hsum hmeas hdom`
application fails: the integrable majorant produced by `(h0.const_mul c0).add
(hk.const_mul ck)` retains pointwise addition of functions, whereas `hdom`
is phrased using an explicit pointwise sum. The new proof uses
`apply hsum.mono' hmeas`, extracts the a.e. bound with `filter_upwards`,
and normalizes `Pi.add_apply`. The fallback normalizes scalar/associative
multiplication as well. No mathematical hypotheses, statements, or other
Lean modules have changed.

Status: UNCOMPILED. This is a candidate repair to be checked only by the
user's native Windows Lean 4.33.0 compiler.
