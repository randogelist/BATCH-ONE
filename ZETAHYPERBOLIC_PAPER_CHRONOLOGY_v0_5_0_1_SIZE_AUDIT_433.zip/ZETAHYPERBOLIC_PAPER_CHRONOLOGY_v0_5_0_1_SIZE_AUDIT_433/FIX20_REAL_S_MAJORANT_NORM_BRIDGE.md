# FIX20 — Real-s moment majorant norm bridge

This candidate repair leaves all prior compiler-certified Lean source files unchanged.

In `Proposition_3_2_Real_s_Moment_Integrability.lean`, an explicit almost-everywhere bound `‖f‖ ≤ ‖g‖` is derived from the already established stronger bound `‖f‖ ≤ g`, using `g ≤ |g| = ‖g‖`.

`Integrable.mono'` is applied to the norm-bound proposition rather than passing the raw non-norm estimate directly. No new assumptions, `sorry`, `admit`, or axioms are introduced.

This is a source-only repair awaiting compilation by the user's Windows Lean 4.33.0 compiler. No assistant-side Lean compilation has occurred.
