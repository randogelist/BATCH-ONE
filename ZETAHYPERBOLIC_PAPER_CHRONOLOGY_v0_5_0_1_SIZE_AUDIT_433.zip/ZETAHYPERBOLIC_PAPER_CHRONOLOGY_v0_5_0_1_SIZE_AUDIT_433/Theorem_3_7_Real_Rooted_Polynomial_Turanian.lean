import Theorem_3_7_All_Order_Turanian_Jets
import Mathlib.Analysis.Calculus.Deriv.Basic
import Mathlib.Tactic

/-!
# Theorem 3.7: finite real-root product, ACTUAL analytic derivatives

We prove that the all-order jets really are the first and second
ordinary derivatives of the polynomial product. This converts the
certified algebraic SOS recurrence into the manuscript's Turanian
`P'(x)^2 - P(x) P''(x) >= 0`, FOR EVERY REAL-ROOTED PRODUCT DEGREE.

This is the m=1 Wronskian portion of Theorem 3.7. Higher-derivative
Turanian statements additionally require a real-rooted-derivative bridge.
-/

noncomputable section
namespace PaperChronology.Theorem3_7.ActualTuranian
open PaperChronology.Theorem3_7.TuranJets

private theorem rootJet_two_derivatives (roots : List ℝ) (x : ℝ) :
    HasDerivAt (fun y : ℝ => (rootJet y roots).value)
      (rootJet x roots).first x ∧
    HasDerivAt (fun y : ℝ => (rootJet y roots).first)
      (rootJet x roots).second x := by
  induction roots with
  | nil =>
      constructor
      · simpa [rootJet, initialJet] using (hasDerivAt_const x (1 : ℝ))
      · simpa [rootJet, initialJet] using (hasDerivAt_const x (0 : ℝ))
  | cons a tail ih =>
      obtain ⟨hv, hd⟩ := ih
      have hlin : HasDerivAt (fun y : ℝ => y - a) 1 x := by
        simpa using (hasDerivAt_id x).sub_const a
      have hval : HasDerivAt
          (fun y : ℝ => (y - a) * (rootJet y tail).value)
          ((rootJet x tail).value + (x - a) * (rootJet x tail).first) x := by
        convert hlin.mul hv using 1 <;> ring
      have hder : HasDerivAt
          (fun y : ℝ => (rootJet y tail).value +
            (y - a) * (rootJet y tail).first)
          (2 * (rootJet x tail).first +
            (x - a) * (rootJet x tail).second) x := by
        convert hv.add (hlin.mul hd) using 1 <;> ring
      constructor
      · simpa only [rootJet, factorStep] using hval
      · simpa only [rootJet, factorStep] using hder

/-- The genuine first derivative of ANY finite real root product. -/
theorem rootProduct_deriv (roots : List ℝ) (x : ℝ) :
    deriv (rootProduct roots) x = (rootJet x roots).first := by
  have hfun : rootProduct roots =
      (fun y : ℝ => (rootJet y roots).value) := by
    funext y
    exact (rootJet_value_eq_rootProduct y roots).symm
  rw [hfun]
  exact (rootJet_two_derivatives roots x).1.deriv

/-- The genuine second derivative of ANY finite real root product. -/
theorem rootProduct_second_deriv (roots : List ℝ) (x : ℝ) :
    deriv (fun y : ℝ => deriv (rootProduct roots) y) x =
      (rootJet x roots).second := by
  have hfun : (fun y : ℝ => deriv (rootProduct roots) y) =
      (fun y : ℝ => (rootJet y roots).first) := by
    funext y
    exact rootProduct_deriv roots y
  rw [hfun]
  exact (rootJet_two_derivatives roots x).2.deriv

/-- All-degree, mathematically exact m=1 Turanian for real-rooted
polynomials. It is nonnegative at EVERY real x, including repeated roots. -/
theorem real_root_product_turanian (roots : List ℝ) (x : ℝ) :
    0 ≤ (deriv (rootProduct roots) x) ^ 2 -
      rootProduct roots x *
        deriv (fun y : ℝ => deriv (rootProduct roots) y) x := by
  rw [rootProduct_deriv roots x, rootProduct_second_deriv roots x,
    ← rootJet_value_eq_rootProduct x roots]
  exact rootJet_turanian_nonneg x roots

end PaperChronology.Theorem3_7.ActualTuranian

#print axioms PaperChronology.Theorem3_7.ActualTuranian.real_root_product_turanian
