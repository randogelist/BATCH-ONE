import PAPER_CHRONOLOGICAL_EXTENSION_8
import Theorem_3_4_Actual_Principal_Spectral_Gap
import Corollary_3_5_Corrected_Schur_Fraction
import Corollary_3_6_Reciprocal_Root_Moment_Bounds
import Theorem_3_7_All_Order_Turanian_Jets
import Theorem_3_7_Real_Rooted_Polynomial_Turanian
import Theorem_3_8_Actual_Christoffel_Darboux_Kernel
import Theorem_4_1_Witness_Free_Principal_Separation

/-!
# Large chronological jump: Theorems 3.4–3.8 and Theorem 4.1

The individual source modules contain genuine proof statements, not empty
`#check` registries. This module records a direct unconditional chain:
3.4 actual principal spectral gaps; 3.5 correct 2x2 fraction; 3.6 finite
root moment bounds; 3.7 universal Turan m=1 theorem in ordinary analytic
derivatives; 3.8 actual Gram/pole kernel and normalized determinant; and
4.1 witness-free local root exclusion.

Still OPEN AS PRINTED: 3.3 nonprincipal total positivity and Sylvester
spectral inertia bridge; 3.4 full Cauchy interlacing; 3.5 length-h Lanczos
J-fraction with correct coefficients and cyclicity; 3.7 all m derivatives;
3.8 full Christoffel-Darboux eigenvalue identification; the quantitative
exp(-rho*K) uniform spectral gap and arithmetic witness in Section 4.
No assumptions other than the paper's ordinary parameter ranges.
-/

noncomputable section
namespace PaperChronology

/-- Theorem 3.4: all actual real-s principal pencils have a finite
unconditional spectral radius separating their zeros from zeta(s). -/
theorem paper_theorem_3_4_uniform_within_each_principal_pencil
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) :
    ∃ B : ℝ, 0 < B ∧ ∀ x : ℝ,
      |x - (riemannZeta (s : ℂ)).re| < 1 / B →
      0 < (Theorem3_4.ActualPrincipal.realSPrincipalPencil
         s p choose).detPolynomial.eval x :=
  Theorem3_4.ActualSpectralGap.real_s_principal_zero_free s p hs choose hinj

/-- Corollary 3.5: corrected h=2 exact Schur fraction, not the false
unscaled printed J-fraction. -/
theorem paper_corollary_3_5_corrected_two_by_two (a b c : ℝ)
    (ha : a ≠ 0) (hd : Corollary3_5.CorrectedSchur.det2 a b c ≠ 0) :
    a / Corollary3_5.CorrectedSchur.det2 a b c =
      1 / (c - b ^ 2 / a) :=
  Corollary3_5.CorrectedSchur.ratio2_corrected a b c ha hd

/-- Theorem 3.7, all-degree m=1 Turan inequality for real-root products. -/
theorem paper_theorem_3_7_all_degree_first_turanian
    (roots : List ℝ) (x : ℝ) :
    0 ≤ (deriv (Theorem3_7.TuranJets.rootProduct roots) x) ^ 2 -
      Theorem3_7.TuranJets.rootProduct roots x *
        deriv (fun y : ℝ => deriv (Theorem3_7.TuranJets.rootProduct roots) y) x :=
  Theorem3_7.ActualTuranian.real_root_product_turanian roots x

/-- Theorem 3.8: exact normalized determinant for the original real-s
moment Gram, without introducing spectral/arithmetic assumptions. -/
theorem paper_theorem_3_8_actual_relative_determinant
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s) (t : ℝ) :
    (Proposition3_2.Gram.gram s p +
      t • Proposition3_2.derivativeMatrix s p).det =
    (Proposition3_2.Gram.gram s p).det *
      (1 + t • ((Proposition3_2.Gram.gram s p)⁻¹ *
        Proposition3_2.derivativeMatrix s p)).det :=
  Theorem3_8.ActualKernel.actual_relative_det s p hs t

end PaperChronology

#print axioms PaperChronology.paper_theorem_3_4_uniform_within_each_principal_pencil
#print axioms PaperChronology.paper_corollary_3_5_corrected_two_by_two
#print axioms PaperChronology.paper_theorem_3_7_all_degree_first_turanian
#print axioms PaperChronology.paper_theorem_3_8_actual_relative_determinant
