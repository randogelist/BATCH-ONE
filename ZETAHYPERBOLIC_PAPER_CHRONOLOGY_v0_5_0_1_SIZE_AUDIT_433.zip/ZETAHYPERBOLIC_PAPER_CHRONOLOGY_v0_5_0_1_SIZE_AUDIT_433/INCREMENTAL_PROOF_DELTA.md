# v0.3.7 incremental theorem proof delta

**User-certified source baseline:** 73 modules of v0.3.6, PASS (3 compiled / 70 reused, no forbidden axioms).

Two NEW Lean modules, no changes to those 73 module definitions:
1. `Proposition_3_2_Real_s_Weight_Envelope.lean`: exact two-odd-weight pointwise envelope of the real-s infinite density.
2. `Proposition_3_2_Real_s_Moment_Integrability.lean`: polynomial moment integrability via the already checked odd-weight integrability, plus actual Gram PosDef, degree, real roots, and excluded center.

Two *aggregate* files amended:
- `PAPER_SECTION_03.lean`: named unconditional endpoints in PDF order.
- `PAPER_CHRONOLOGICAL_CHAIN.lean`: chronological composition theorem.

The 73 modules of the previous baseline were preserved byte-for-byte. No Lean compilation performed in this environment; the user compiler determines validity of all new statements.

## v0.3.7.2 moment-integrability FIX2

- Frozen: the compiler-approved real-s envelope and preceding modules.
- Repaired: `Proposition_3_2_Real_s_Moment_Integrability.lean` only.
- Edit: deleted the no-op `dsimp only [c0, ck] at hbound`.
- Pending native compiler: moment integrability + Section 3 + chronological chain.
- No assistant-side Lean compilation.

## v0.3.7.3 — Explicit AE domination repair

- Frozen: all previously compiler-passed proof modules.
- Changed: one failed moment-integrability Lean module.
- Added explicit a.e. inequality and measurability proof; final `exact` closure.
- Native verification pending; no assistant-side Lean compilation.
