# Necessary mathematical corrections to the printed manuscript

## Corollary 3.5, PDF p. 10: the J-fraction scaling

Let `t = X - ξ`, `G = L Lᵀ` positive definite and `M` the real-symmetric pencil slope. Write `B = L⁻¹ M L⁻ᵀ`. Let `G_r` and `B_r` be compatible leading principal blocks. Then

\[
\frac{\Delta_{h-1}(X)}{\Delta_h(X)} =
\frac{\det G_{h-1}}{\det G_h}
\frac{\det(I_{h-1}+tB_{h-1})}{\det(I_h+tB_h)}
= \frac{1}{L_{hh}^2}\big((I+tB)^{-1}\big)_{hh}.
\]

After a valid Lanczos tridiagonalization starting at `e_h` (accounting for basis orientation), if `T=tridiag(a_i,b_i)` is the tridiagonalized *B*, the continued fraction must have diagonal terms `1 + t*a_i` and subtractions `t^2*b_i^2`, multiplied by `1/L_hh^2`. This is different from printed formula (3.6), whose denominator is `a_i + t - b_i^2/(...)` and whose Gram prefactor is missing. Without a cyclic starting vector Lanczos may break down (`b_i=0`), so strict `b_i>0` does not follow from symmetry alone.

**Exact h=1 contradiction in the paper's admitted parameter family:** set `K=2,N=1,m=1,s=5`. The slope is `M=2^4(1^2-2^2)=-48`, while `G=Δ_1(ξ)>0` by the paper's moment measure. At `X=ξ`, the left side of (3.6) is `1/G>0`, while the right side is `1/(M/G)=G/M<0`. Both cannot be equal. `PAPER_COUNTEREXAMPLES.lean` proves the general scalar sign incompatibility.

This does **not** invalidate the valid spectral theorem 3.1. It prevents literal proof of Corollary 3.5 and of any downstream theorem that uses the uncorrected formula.

## Corollary 3.6, PDF p. 11: finite atomic rank

The claimed Stieltjes moments are

\[
S_{2r}(q_0)=\sum_{j=1}^{h} u_j^r,\qquad
u=\sum_{j=1}^h\delta_{u_j},\qquad
u\ge 0,\quad u_j=(r_j-q_0)^{-2}>0.
\]

Their order-`r` Hankel matrix factors as `V_r V_rᵀ`, where `V_r[i,j]=u_j^i`. Its rank is at most the number `d` of distinct support locations `u_j` (at most `h`). Therefore

- all Hankel determinants are **nonnegative**;
- they are **strictly positive** only through order `r<=d`;
- they are **zero for every order `r>d`**.

Moreover, because the transformation `r_j -> (r_j-q_0)^{-2}` loses the sign, `d` can be smaller than the number of distinct roots when two roots are equally distant from `q_0`.

The correct quantitative limit is

\[
  h^{-1/(2r)}d_{\min} \le S_{2r}(q_0)^{-1/(2r)} \le d_{\min},
\]

not `1 <= S_{2r}(q_0)^{-1/(2r)}/d_min` as printed. For `h=2`, the order-three determinant vanishes identically, proved as `PaperAudit.two_atom_hankel3_zero`.

## Section 5, dual Krein cones: tail control

The proof of Theorem 5.2(3) builds trial functions orthogonal to finitely many negative modes, but the exact Krein form also includes infinitely many untruncated negative modes. The line that writes the full quadratic form as only an `m<=M` positive sum drops the infinite signed tail. Controlling that tail is required for definiteness. The existing Lean `WeightSevenTailBound` interface acknowledges exactly this missing condition; naming a finite positive certificate is not a proof of the full inequality.
