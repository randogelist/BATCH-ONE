import Theorem_3_3_Spectral_Root_Sign_Correspondence
import Mathlib.Tactic

/-!
# PDF Theorem 3.3 — exact arithmetic counts and spectral root-count transfer

Two unconditional, finite components of the manuscript's theorem:

* Counts of odd and even indices in the negative-square pole interval
  `N < a ≤ K`, with an explicit arithmetic specialization `N=3n, K=30n`.
* Cardinality equality between eigenvalues of each sign and the roots of a
  positive Gram pencil on the corresponding side of its center.

The **actual residue sign formula** `sign γ_a = (-1)^(a-1)` and the use of
Sylvester's law of inertia to identify eigenvalue counts with these pole
counts are separate unfinished steps. They are NOT assumed in any exported
unconditional theorem here. The PDF's all-minors total-positivity and Carleman
claims likewise remain separate.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_3.PoleCounts

/-- The exact number of odd natural numbers strictly below `n`, computed as a
finite sum rather than postulated as a formula. -/
def oddPrefix (n : ℕ) : ℕ :=
  ∑ a ∈ Finset.range n, if a % 2 = 1 then (1 : ℕ) else 0

lemma oddPrefix_succ (n : ℕ) :
    oddPrefix (n + 1) =
      oddPrefix n + (if n % 2 = 1 then (1 : ℕ) else 0) := by
  simp only [oddPrefix, Finset.sum_range_succ]

/-- Counting the odd indices in `[0, n)` uses just a finite parity split. -/
theorem oddPrefix_eq_div_two (n : ℕ) : oddPrefix n = n / 2 := by
  induction n with
  | zero => simp [oddPrefix]
  | succ n ih =>
      change oddPrefix (n + 1) = (n + 1) / 2
      rw [oddPrefix_succ, ih]
      split_ifs with h <;> omega

/-- The pole nodes in the paper are `N+1, ..., K`. The following is their
odd-index count, expressed as a difference of two explicitly finite counts. -/
def oddPoleCount (N K : ℕ) : ℕ := oddPrefix (K + 1) - oddPrefix (N + 1)

/-- Complementary even-index count in the same interval. -/
def evenPoleCount (N K : ℕ) : ℕ := (K - N) - oddPoleCount N K

theorem oddPoleCount_formula (N K : ℕ) :
    oddPoleCount N K = (K + 1) / 2 - (N + 1) / 2 := by
  simp only [oddPoleCount, oddPrefix_eq_div_two]

theorem oddPoleCount_le (N K : ℕ) (hNK : N ≤ K) :
    oddPoleCount N K ≤ K - N := by
  rw [oddPoleCount_formula]
  omega

theorem evenPoleCount_formula (N K : ℕ) (hNK : N ≤ K) :
    evenPoleCount N K = K / 2 - N / 2 := by
  rw [evenPoleCount, oddPoleCount_formula]
  omega

theorem poleCounts_add (N K : ℕ) (hNK : N ≤ K) :
    oddPoleCount N K + evenPoleCount N K = K - N := by
  have hOddBound : oddPoleCount N K ≤ K - N :=
    oddPoleCount_le N K hNK
  unfold evenPoleCount
  omega

/-- The positive-index count specified by the residue-sign computation for
`N=3n, K=30n`, independently of any analytic or arithmetic witness. -/
theorem weightFive_odd_count (n : ℕ) :
    oddPoleCount (3 * n) (30 * n) = (27 * n) / 2 := by
  rw [oddPoleCount_formula]
  omega

/-- The negative-index count for the same weight-five pole family. -/
theorem weightFive_even_count (n : ℕ) :
    evenPoleCount (3 * n) (30 * n) = (27 * n + 1) / 2 := by
  rw [evenPoleCount_formula (3 * n) (30 * n) (by omega)]
  omega

/-- The exact pair of integer counts appearing in PDF Theorem 3.3(3).
The spectral identification with these counts is not claimed here. -/
theorem weightFive_pole_counts (n : ℕ) :
    oddPoleCount (3 * n) (30 * n) = (27 * n) / 2 ∧
    evenPoleCount (3 * n) (30 * n) = (27 * n + 1) / 2 :=
  ⟨weightFive_odd_count n, weightFive_even_count n⟩

open ManuscriptChain.Spectral

variable {h : ℕ} {p : SymmetricAffinePencil h}

/-- Number of roots below the center equals number of positive nonzero
spectral eigenvalues, including multiplicities. No choice of ordering is
needed beyond the preexisting finite `RootFactorization`. -/
theorem rootCount_below_eq_beta_pos (c : RootFactorization p) :
    (Finset.univ.filter (fun i : Fin h => c.root i < p.center)).card =
      (Finset.univ.filter (fun i : Fin h => 0 < c.beta i)).card := by
  classical
  have heq :
      Finset.univ.filter (fun i : Fin h => c.root i < p.center) =
        Finset.univ.filter (fun i : Fin h => 0 < c.beta i) := by
    ext i
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    exact PaperChronology.Theorem3_3.root_below_iff_beta_pos c i
  exact congrArg Finset.card heq

/-- Number of roots above the center equals number of negative nonzero
spectral eigenvalues. -/
theorem rootCount_above_eq_beta_neg (c : RootFactorization p) :
    (Finset.univ.filter (fun i : Fin h => p.center < c.root i)).card =
      (Finset.univ.filter (fun i : Fin h => c.beta i < 0)).card := by
  classical
  have heq :
      Finset.univ.filter (fun i : Fin h => p.center < c.root i) =
        Finset.univ.filter (fun i : Fin h => c.beta i < 0) := by
    ext i
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    exact PaperChronology.Theorem3_3.root_above_iff_beta_neg c i
  exact congrArg Finset.card heq

end PaperChronology.Theorem3_3.PoleCounts

#print axioms PaperChronology.Theorem3_3.PoleCounts.oddPrefix_eq_div_two
#print axioms PaperChronology.Theorem3_3.PoleCounts.weightFive_pole_counts
#print axioms PaperChronology.Theorem3_3.PoleCounts.rootCount_below_eq_beta_pos
#print axioms PaperChronology.Theorem3_3.PoleCounts.rootCount_above_eq_beta_neg
