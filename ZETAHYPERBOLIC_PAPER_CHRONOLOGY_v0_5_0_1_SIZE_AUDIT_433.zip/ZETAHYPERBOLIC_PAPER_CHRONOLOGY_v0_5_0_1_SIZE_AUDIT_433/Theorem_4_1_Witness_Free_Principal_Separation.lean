import Theorem_3_4_Actual_Principal_Spectral_Gap
import Theorem_3_8_Actual_Christoffel_Darboux_Kernel
import Mathlib.Tactic

/-!
# Theorem 4.1 preliminary: witness-free, actual algebraic root separation

The arithmetic smallness bound is the ONE allowed Witness in the wider
project, but local spectral separation itself is NOT conditional on that
Witness. Compose the full real-s moment proof with the positive-base
factorization to give an explicit (finite, spectrum-dependent) disk for
all actual principal determinant polynomials. This is not a claim of
the paper's UNIFORM exponential K-bound, which needs additional proof.
-/

noncomputable section
namespace PaperChronology.Theorem4_1.PrincipalSeparation

/-- The spectral part of the Diophantine transfer can be separated from
the arithmetic Witness for every actual real-s principal determinant. -/
theorem real_s_principal_has_root_free_interval
    (s : ℝ) (p : ManuscriptChain.Real.Parameters) (hs : 1 < s)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) :
    ∃ B : ℝ, 0 < B ∧ ∀ x : ℝ,
      |x - (riemannZeta (s : ℂ)).re| < 1 / B →
      (PaperChronology.Theorem3_4.ActualPrincipal.realSPrincipalPencil
         s p choose).detPolynomial.eval x ≠ 0 := by
  obtain ⟨B, hB, hpos⟩ :=
    PaperChronology.Theorem3_4.ActualSpectralGap.real_s_principal_zero_free
      s p hs choose hinj
  exact ⟨B, hB, fun x hx => ne_of_gt (hpos x hx)⟩

/-- Original odd-weight zeta analogue of the same *unconditional* finite
gap. This is independent of the prime-sum/denominator witness. -/
theorem odd_principal_has_root_free_interval
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p)
    {r : ℕ} (choose : Fin r → Fin p.h)
    (hinj : Function.Injective choose) :
    ∃ B : ℝ, 0 < B ∧ ∀ x : ℝ,
      |x - ManuscriptChain.Real.zeta p.weight| < 1 / B →
      (PaperChronology.Theorem3_4.ActualPrincipal.oddPrincipalPencil
         p choose).detPolynomial.eval x ≠ 0 := by
  obtain ⟨B, hB, hpos⟩ :=
    PaperChronology.Theorem3_4.ActualSpectralGap.odd_principal_zero_free
      p hp choose hinj
  exact ⟨B, hB, fun x hx => ne_of_gt (hpos x hx)⟩

end PaperChronology.Theorem4_1.PrincipalSeparation

#print axioms PaperChronology.Theorem4_1.PrincipalSeparation.real_s_principal_has_root_free_interval
#print axioms PaperChronology.Theorem4_1.PrincipalSeparation.odd_principal_has_root_free_interval
