import Theorem_3_3_Actual_Leading_Coefficient_Sign
import Mathlib.Tactic

/-!
# PDF Theorem 3.3(1) — finite atomic Gram determinants

These are exact finite, positive-mass moment identities underlying the
Vandermonde/Andreief mechanism. The two- and three-atom determinants are
proved with no additional hypotheses except positivity and distinctness.
They are NOT claimed to establish strict total positivity of the paper's
continuous infinite moment measure; that remains a separate theorem.

No sorry, admit, or custom axiom is introduced.
-/

noncomputable section
namespace PaperChronology.Theorem3_3.DiscreteSamples

/-- Two-atom weighted moments. -/
def twoMoment (a b u v : ℝ) (j : ℕ) : ℝ :=
  a * u ^ j + b * v ^ j

/-- The exact order-two weighted Vandermonde Gram determinant. -/
theorem two_atom_hankel_det (a b u v : ℝ) :
    twoMoment a b u v 0 * twoMoment a b u v 2 -
      twoMoment a b u v 1 * twoMoment a b u v 1 =
        a * b * (u - v) ^ 2 := by
  simp only [twoMoment, pow_zero, pow_one]
  ring

/-- Distinct nodes and positive masses force a positive order-two determinant. -/
theorem two_atom_hankel_det_pos
    (a b u v : ℝ) (ha : 0 < a) (hb : 0 < b) (huv : u ≠ v) :
    0 < twoMoment a b u v 0 * twoMoment a b u v 2 -
      twoMoment a b u v 1 * twoMoment a b u v 1 := by
  rw [two_atom_hankel_det]
  exact mul_pos (mul_pos ha hb)
    (sq_pos_of_ne_zero (sub_ne_zero.mpr huv))

/-- Three-atom weighted moments. -/
def threeMoment (a b c u v w : ℝ) (j : ℕ) : ℝ :=
  a * u ^ j + b * v ^ j + c * w ^ j

/-- The explicit determinant of a symmetric order-three Hankel matrix. -/
def hankelDet3 (m0 m1 m2 m3 m4 : ℝ) : ℝ :=
  m0 * (m2 * m4 - m3 * m3) -
    m1 * (m1 * m4 - m2 * m3) +
    m2 * (m1 * m3 - m2 * m2)

/-- The exact order-three determinant factorization for three atoms.
This is a finite form of the Andreief/Vandermonde mechanism. -/
theorem three_atom_hankel_det (a b c u v w : ℝ) :
    hankelDet3
        (threeMoment a b c u v w 0)
        (threeMoment a b c u v w 1)
        (threeMoment a b c u v w 2)
        (threeMoment a b c u v w 3)
        (threeMoment a b c u v w 4) =
      a * b * c * (u - v) ^ 2 * (u - w) ^ 2 * (v - w) ^ 2 := by
  simp only [hankelDet3, threeMoment, pow_zero, pow_one]
  ring

/-- Strict positivity of the order-three Hankel determinant for exactly
three distinct nodes with positive masses. -/
theorem three_atom_hankel_det_pos
    (a b c u v w : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (huv : u ≠ v) (huw : u ≠ w) (hvw : v ≠ w) :
    0 < hankelDet3
        (threeMoment a b c u v w 0)
        (threeMoment a b c u v w 1)
        (threeMoment a b c u v w 2)
        (threeMoment a b c u v w 3)
        (threeMoment a b c u v w 4) := by
  rw [three_atom_hankel_det]
  have hUV : 0 < (u - v) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huv)
  have hUW : 0 < (u - w) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr huw)
  have hVW : 0 < (v - w) ^ 2 :=
    sq_pos_of_ne_zero (sub_ne_zero.mpr hvw)
  exact mul_pos (mul_pos (mul_pos (mul_pos (mul_pos ha hb) hc) hUV) hUW) hVW

end PaperChronology.Theorem3_3.DiscreteSamples

#print axioms PaperChronology.Theorem3_3.DiscreteSamples.two_atom_hankel_det_pos
#print axioms PaperChronology.Theorem3_3.DiscreteSamples.three_atom_hankel_det
#print axioms PaperChronology.Theorem3_3.DiscreteSamples.three_atom_hankel_det_pos
