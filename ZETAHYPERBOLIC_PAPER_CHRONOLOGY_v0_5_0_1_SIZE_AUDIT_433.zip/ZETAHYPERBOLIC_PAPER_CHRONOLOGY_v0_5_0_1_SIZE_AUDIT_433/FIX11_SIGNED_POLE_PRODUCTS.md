# FIX11 — actual negative-square pole signed products

User-native Lean reported `sorryAx` in the D_N(-a^2), D_tail'(-a^2), and actual factor-pair results. The full first compiler-error goal was not present in the pasted excerpt, so the repair reconstructs the three proofs explicitly rather than assuming a specific failure line.

The only mathematical Lean source changed is `Theorem_3_3_Signed_Pole_Products.lean`. The replacement supplies explicit finite-product sign normalization, a difference-of-squares inequality, an exact negative-square D_N evaluation, a disjoint lower/upper derivative-factor decomposition, and source-level specialization at the actual pole nodes. There is no axiom, sorry, admit, extra witness, or new conditional argument.

Preserve passing sources under the PASS-ONCE frozen artifact policy. Run `run.cmd` on the user's native Windows Lean 4.33.0 compiler. No Lean compilation was attempted during packaging.

Compiler outcome: PENDING USER CHECK.
