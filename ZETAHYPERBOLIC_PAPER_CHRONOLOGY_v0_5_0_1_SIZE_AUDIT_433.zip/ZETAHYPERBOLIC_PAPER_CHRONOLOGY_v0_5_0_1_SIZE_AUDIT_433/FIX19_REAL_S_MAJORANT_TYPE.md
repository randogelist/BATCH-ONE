# FIX19: Real-s moment integrability majorant type

The user compiler reported a type mismatch in the application of `Integrable.mono'` to `hsum_explicit` and `hdom`.

The comparison lemma expects an a.e. inequality of the form `‖f y‖ ≤ g y`, with the real-valued nonnegative majorant `g`, **not** `‖f y‖ ≤ ‖g y‖`. The existing `weightedDensity_le_oddWeighted` provides precisely the un-normed RHS. The fix changes only `hdom` to use that direct RHS and removes the no-longer-necessary equality with its norm.

Mathematical content and all other Lean modules are unchanged. The previously passed frozen modules must not be recompiled unless invalidated. This package has not been Lean-compiled locally; only the user's native Windows Lean compiler is the certification authority.
