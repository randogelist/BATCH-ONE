import Theorem_3_3_Signed_Pole_Products
import Mathlib.Tactic

/-!
# PDF Theorem 3.3 — actual residue-sign bridge

The pole weights are defined by the existing rational Lagrange diagonalization:
  γ_a = D_N(-a²)^(2m-1) / D_tail'(-a²) * a^(2k).

The previous module proves the signs of the *actual* factors, with no free
sign assumptions.  Here we combine them for `m ≥ 1` to show that the pole
weights alternate by pole index.  The spectral inertia and all-minors strict
total-positivity portions of the paper are not asserted by this file.

This module contains no `sorry`, `admit`, or custom axioms.  It has NOT been
compiled on the assistant's machine.  Only the user's Lean 4.33.0 run is
an authoritative check.
-/

noncomputable section
open ManuscriptChain

namespace PaperChronology.Theorem3_3.PoleWeightSigns

/-- Raising a signed nonzero rational number to a positive odd exponent
preserves the same prescribed sign. -/
theorem signed_odd_power_pos (x : ℚ) (n m : ℕ) (hm : 0 < m)
    (hx : 0 < (-1 : ℚ) ^ n * x) :
    0 < (-1 : ℚ) ^ n * x ^ (2 * m - 1) := by
  have hxne : x ≠ 0 := by
    intro h
    rw [h] at hx
    norm_num at hx
  have hsquare : 0 < x ^ 2 := by
    rcases lt_trichotomy x 0 with hneg | hzero | hpos
    · have hprod : 0 < x * x := mul_pos_of_neg_of_neg hneg hneg
      simpa only [pow_two] using hprod
    · exact (hxne hzero).elim
    · have hprod : 0 < x * x := mul_pos hpos hpos
      simpa only [pow_two] using hprod
  have hexp : 2 * m - 1 = 2 * (m - 1) + 1 := by omega
  calc
    (-1 : ℚ) ^ n * x ^ (2 * m - 1) =
        ((-1 : ℚ) ^ n * x) * (x ^ 2) ^ (m - 1) := by
      rw [hexp, pow_add, pow_one, pow_mul]
      ring
    _ > 0 := mul_pos hx (pow_pos hsquare _)

/-- The exact rational pole weights of Theorem 2.5 have the sign claimed
in PDF Theorem 3.3.  The sole parameter condition `0<m` is already part
of the manuscript's usual admissibility constraints. -/
theorem actual_poleWeight_signed_positive
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m)
    (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (ManuscriptChain.PoleDiagonalization.poleIndex p i - 1) *
      ManuscriptChain.PoleDiagonalization.poleWeight p i := by
  let a := ManuscriptChain.PoleDiagonalization.poleIndex p i
  let x := (ManuscriptChain.Real.D p.N).eval
    (ManuscriptChain.PoleDiagonalization.poleNode p i)
  let y := (Polynomial.derivative (ManuscriptChain.Real.tailD p)).eval
    (ManuscriptChain.PoleDiagonalization.poleNode p i)
  let q := a - p.N - 1
  have ha : p.N + 1 ≤ a :=
    (Finset.mem_Icc.mp (ManuscriptChain.PoleDiagonalization.poleIndex_mem p i)).1
  have hsum : p.N + q = a - 1 := by
    dsimp [q]
    omega
  have hpair :=
    PaperChronology.Theorem3_3.SignedPoleProducts.actual_signed_factor_pair p i
  have hx : 0 < (-1 : ℚ) ^ p.N * x := hpair.1
  have hy : 0 < (-1 : ℚ) ^ q * y := hpair.2
  have hxpow : 0 < (-1 : ℚ) ^ p.N * x ^ (2 * p.m - 1) :=
    signed_odd_power_pos x p.N p.m hm hx
  have hcore :
      0 < (-1 : ℚ) ^ (p.N + q) * x ^ (2 * p.m - 1) * y := by
    calc
      (-1 : ℚ) ^ (p.N + q) * x ^ (2 * p.m - 1) * y =
          ((-1 : ℚ) ^ p.N * x ^ (2 * p.m - 1)) *
            ((-1 : ℚ) ^ q * y) := by
        rw [pow_add]
        ring
      _ > 0 := mul_pos hxpow hy
  have hyne : y ≠ 0 := by
    intro h
    rw [h] at hy
    norm_num at hy
  have hySq : 0 < y ^ 2 := by
    rcases lt_trichotomy y 0 with hneg | hzero | hpos
    · have hprod : 0 < y * y := mul_pos_of_neg_of_neg hneg hneg
      simpa only [pow_two] using hprod
    · exact (hyne hzero).elim
    · have hprod : 0 < y * y := mul_pos hpos hpos
      simpa only [pow_two] using hprod
  have hdiv :
      0 < ((-1 : ℚ) ^ (p.N + q) * x ^ (2 * p.m - 1)) / y := by
    have h := div_pos hcore hySq
    have heq :
        ((-1 : ℚ) ^ (p.N + q) * x ^ (2 * p.m - 1) * y) / y ^ 2 =
          ((-1 : ℚ) ^ (p.N + q) * x ^ (2 * p.m - 1)) / y := by
      field_simp [hyne]
    rwa [heq] at h
  have haPos : 0 < (a : ℚ) := by
    exact_mod_cast (ManuscriptChain.PoleDiagonalization.poleIndex_pos p i)
  have haPow : 0 < (a : ℚ) ^ (2 * p.k) := pow_pos haPos _
  change 0 < (-1 : ℚ) ^ (a - 1) *
    (x ^ (2 * p.m - 1) / y * (a : ℚ) ^ (2 * p.k))
  calc
    (-1 : ℚ) ^ (a - 1) *
        (x ^ (2 * p.m - 1) / y * (a : ℚ) ^ (2 * p.k)) =
        (((-1 : ℚ) ^ (p.N + q) * x ^ (2 * p.m - 1)) / y) *
          (a : ℚ) ^ (2 * p.k) := by
      rw [← hsum]
      ring
    _ > 0 := mul_pos hdiv haPow

end PaperChronology.Theorem3_3.PoleWeightSigns

#print axioms PaperChronology.Theorem3_3.PoleWeightSigns.signed_odd_power_pos
#print axioms PaperChronology.Theorem3_3.PoleWeightSigns.actual_poleWeight_signed_positive
