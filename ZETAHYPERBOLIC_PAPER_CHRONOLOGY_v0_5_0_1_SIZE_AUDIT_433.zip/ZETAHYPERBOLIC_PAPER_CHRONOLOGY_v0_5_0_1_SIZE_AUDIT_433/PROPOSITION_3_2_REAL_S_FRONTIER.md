# Proposition 3.2 — v0.3.7 attempted analytic closure

Previously kernel-checked by user: finite positive weight; infinite series convergence, positivity and odd specialization; nonzero atomless real-s measure; derivative invertible and generic spectral reduction.

New candidate proof (NOT YET compiled): for any s>1, choose k with 2k>=s-1. For every t>0, t^(s-1)<=1+t^(2k). With t=(n+1)y, y>0 and termwise summation, the exact real-s density w_s is bounded above by positive multiples of the two already formalized odd-index densities w_1 and w_(2k+1). The two same-denominator weighted odd measures have all polynomial moments finite. Therefore the exact real-s weighted Gram has all its moments finite, is positive definite, and yields real-rooted exact-degree determinant without any extra hypothesis. It must be verified by the user's Lean 4.33 compiler.

No arithmetic witness appears in Proposition 3.2.

**v0.3.8:** The prior real-s moment integrability fix is still pending your
compiler; added a separate Theorem 3.3 finite pole-count layer independently.
