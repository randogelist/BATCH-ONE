import Theorem_3_4_Dodgson_Four_By_Four
import Mathlib.Tactic

/-!
# PDF Theorem 3.4(2) — translated symbolic Jacobi/Dodgson identities

Unconditional size-three and size-four formulas, now quantified over every
moment sequence `μ : ℕ → ℝ` and every integer shift `n`. These formulas can
be instantiated on the manuscript's moments once the exact determinant
identification has been supplied; we make no such unproved identification.
-/

noncomputable section
namespace PaperChronology.Theorem3_4.ShiftedDodgson

open PaperChronology.Theorem3_4.Dodgson3
open PaperChronology.Theorem3_4.Dodgson4

/-- General translated size-three contiguous Hankel Jacobi identity. -/
theorem jacobi_three_all_shifts (μ : ℕ → ℝ) (n : ℕ) :
    det3 (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3)) (μ (n + 4)) *
      μ (n + 2) =
      (μ n * μ (n + 2) - (μ (n + 1)) ^ 2) *
        (μ (n + 2) * μ (n + 4) - (μ (n + 3)) ^ 2) -
      (μ (n + 1) * μ (n + 3) - (μ (n + 2)) ^ 2) ^ 2 :=
  condensation_center (μ n) (μ (n + 1)) (μ (n + 2))
    (μ (n + 3)) (μ (n + 4))

/-- General translated size-four contiguous Hankel Jacobi identity. -/
theorem jacobi_four_all_shifts (μ : ℕ → ℝ) (n : ℕ) :
    hankelDet4 (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3))
        (μ (n + 4)) (μ (n + 5)) (μ (n + 6)) *
      (μ (n + 2) * μ (n + 4) - (μ (n + 3)) ^ 2) =
      det3 (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3)) (μ (n + 4)) *
        det3 (μ (n + 2)) (μ (n + 3)) (μ (n + 4))
          (μ (n + 5)) (μ (n + 6)) -
      (det3 (μ (n + 1)) (μ (n + 2)) (μ (n + 3))
        (μ (n + 4)) (μ (n + 5))) ^ 2 :=
  condensation_four (μ n) (μ (n + 1)) (μ (n + 2))
    (μ (n + 3)) (μ (n + 4)) (μ (n + 5)) (μ (n + 6))

/-- Arbitrary-shift order-three sign at a zero of the leading
order-two Hankel determinant. -/
theorem jacobi_three_nonpositive_at_root (μ : ℕ → ℝ) (n : ℕ)
    (hpivot : 0 < μ n)
    (hroot : μ n * μ (n + 2) - (μ (n + 1)) ^ 2 = 0) :
    det3 (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3)) (μ (n + 4)) ≤ 0 := by
  apply det3_nonpos_at_minor_root (μ n) (μ (n + 1))
    (μ (n + 2)) (μ (n + 3)) (μ (n + 4)) hpivot
  simpa only [pow_two] using hroot

/-- Arbitrary-shift order-four sign at a zero of the leading
order-three Hankel determinant. -/
theorem jacobi_four_nonpositive_at_root (μ : ℕ → ℝ) (n : ℕ)
    (hpivot : 0 < μ (n + 2) * μ (n + 4) - (μ (n + 3)) ^ 2)
    (hroot : det3 (μ n) (μ (n + 1)) (μ (n + 2))
        (μ (n + 3)) (μ (n + 4)) = 0) :
    hankelDet4 (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3))
        (μ (n + 4)) (μ (n + 5)) (μ (n + 6)) ≤ 0 :=
  det4_nonpos_at_minor_root (μ n) (μ (n + 1)) (μ (n + 2))
    (μ (n + 3)) (μ (n + 4)) (μ (n + 5)) (μ (n + 6)) hpivot hroot

/-- Strict size-four sign if its off-diagonal complementary minor
is nonzero. -/
theorem jacobi_four_negative_at_root (μ : ℕ → ℝ) (n : ℕ)
    (hpivot : 0 < μ (n + 2) * μ (n + 4) - (μ (n + 3)) ^ 2)
    (hroot : det3 (μ n) (μ (n + 1)) (μ (n + 2))
        (μ (n + 3)) (μ (n + 4)) = 0)
    (hoff : det3 (μ (n + 1)) (μ (n + 2)) (μ (n + 3))
        (μ (n + 4)) (μ (n + 5)) ≠ 0) :
    hankelDet4 (μ n) (μ (n + 1)) (μ (n + 2)) (μ (n + 3))
        (μ (n + 4)) (μ (n + 5)) (μ (n + 6)) < 0 :=
  det4_neg_at_minor_root (μ n) (μ (n + 1)) (μ (n + 2))
    (μ (n + 3)) (μ (n + 4)) (μ (n + 5)) (μ (n + 6)) hpivot hroot hoff

end PaperChronology.Theorem3_4.ShiftedDodgson

#print axioms PaperChronology.Theorem3_4.ShiftedDodgson.jacobi_three_all_shifts
#print axioms PaperChronology.Theorem3_4.ShiftedDodgson.jacobi_four_all_shifts
#print axioms PaperChronology.Theorem3_4.ShiftedDodgson.jacobi_four_negative_at_root
