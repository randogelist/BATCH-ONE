# Project size audit — 24 October 2026

## Exact snapshot counts

- Project: ZETAHYPERBOLIC_PAPER_CHRONOLOGY_v0_5_0_1_SIZE_AUDIT_433
- Ordered Lean proof modules: **113** (`FASTCORE_ORDER.txt`; excludes build configuration `lakefile.lean`).
- Total `.lean` files including `lakefile.lean`: **114**.
- Source lines of proof modules: **13,929** (12,092 nonblank).
- Proof module `.lean` source bytes: **600,916**.
- Original v0.5.0 package compressed: **362,321 bytes**.
- Original v0.5.0 package total uncompressed file sizes: **980,738 bytes approximately**, includes documentation, metadata and launch script.
- Source `.lean` modules newly prepared in v0.5.0: **8**. These **are not user-compiler-certified** by the latest log.
- Last user-compiler-certified checkpoint: **105 frozen modules**, `BUILD_COMPILED=0`, `BUILD_FROZEN_REUSED=105`, `RESULT=PASS` for the preceding v0.4.7.2 baseline.

## Scope distinction

Number of modules and lines does **not** measure percentage of the PDF proved. Existing approximate paper-level mathematical coverage assessment was 20–25% including partial work, and must be re-audited after actual theorem endpoints compile.

## Verification limits

Only ZIP checks and source hash comparisons were performed in this audit. No Lean compilation locally. Previously passing source modules are byte-for-byte unchanged. The host's native Lean 4.33.0 compiler remains the sole proof authority.
