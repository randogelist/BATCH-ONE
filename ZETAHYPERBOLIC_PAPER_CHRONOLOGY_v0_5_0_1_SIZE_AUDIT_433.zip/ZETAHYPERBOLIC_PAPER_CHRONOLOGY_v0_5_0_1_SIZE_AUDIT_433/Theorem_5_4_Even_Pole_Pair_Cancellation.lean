import Lemma_2_3_Reflection_And_Difference_Identities
import Mathlib.Tactic

/-!
# Theorem 5.4: exact cancellation on simple even pole pairs

For s=2k+1, k≥1, and j≥1, the auxiliary functional τ_X maps
E_j=(x-j)⁻¹-(x+j)⁻¹ to the rational constant j⁻ˢ.
This is established on the actual `tauPolePoly` representation of
Definition 2.1, rather than postulated as a property of a new functional.
The theorem does NOT assert a higher-order-pole extension.
-/

noncomputable section
open Polynomial
namespace PaperChronology.Theorem5_4
open Zetahyperbolic

/-- The τ-image of the paper's x-even simple-pole pair E_j. -/
def evenPolePairValue (k j : ℕ) : ℚ[X] :=
  tauPolePoly k (j : ℤ) - tauPolePoly k (-(j : ℤ))

/-- Cancellation of X and all higher zeta terms: exactly equation (5.5). -/
theorem evenPolePairValue_eq (k j : ℕ) (hj : 1 ≤ j) :
    evenPolePairValue k j =
      C (((j : ℚ) ^ (2 * k + 1))⁻¹) := by
  have hpos : dIndex (j : ℤ) = j := by
    simp [dIndex, Int.toNat_of_nonneg (by omega : (0 : ℤ) ≤ (j : ℤ))]
  have hneg : dIndex (-(j : ℤ)) = j - 1 := by
    have hh : ¬ (0 : ℤ) ≤ -(j : ℤ) := by omega
    unfold dIndex
    rw [if_neg hh]
    have hcast : -(-(j : ℤ)) - 1 = ((j - 1 : ℕ) : ℤ) := by omega
    rw [hcast]
    simp
  have hrec : harmonicWeight (2 * k + 1) j =
      harmonicWeight (2 * k + 1) (j - 1) +
        (((j : ℚ) ^ (2 * k + 1))⁻¹) := by
    have hjj : j - 1 + 1 = j := by omega
    have h := harmonicWeight_succ (2 * k + 1) (j - 1)
    rw [hjj] at h
    exact h
  unfold evenPolePairValue tauPolePoly
  rw [hpos, hneg]
  calc
    (C (harmonicWeight (2 * k + 1) j) - X) -
        (C (harmonicWeight (2 * k + 1) (j - 1)) - X) =
        C (harmonicWeight (2 * k + 1) j -
           harmonicWeight (2 * k + 1) (j - 1)) := by
      rw [Polynomial.C_sub]
      ring
    _ = C (((j : ℚ) ^ (2 * k + 1))⁻¹) := by
      rw [hrec]
      ring

end PaperChronology.Theorem5_4

#print axioms PaperChronology.Theorem5_4.evenPolePairValue_eq
