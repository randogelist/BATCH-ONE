# V0.4.1.0 mathematical delta

Native Lean 4.33.0, PASS-ONCE incremental, **not locally compiled**.

The frozen user-compiler checkpoint preceding this package is 86/86 modules
(83 frozen reused, 3 newly compiled), with no forbidden axioms detected.

- New finite-atomic §3.3 lemma: shifted two-atomic and three-atomic Gram/Hankel
  determinant factorizations with strictly positive masses and nodes.
- New §3.4 lemma: algebraic first-row expansion of the 4x4 Hankel determinant,
  the exact order-four Jacobi/Dodgson identity, and the nonpositive/negative
  sign law at a root of the leading order-three minor.
- New aggregation theorem: imports the verified chronology plus both new proof
  modules, with no additional witness or analytic assumptions.

**Scope limitations:** The two/three-atomic formulas are not the paper's full
continuous all-minor strict total positivity theorem; and the order-four
cofactor polynomial remains to be connected to the manuscript matrix's
`Matrix.det`. The full arbitrary-order Jacobi identity and root interlacing
remain pending. They are not postulated as axioms.

Only the new modules and their dependency edges were added; all 86 previously
verified `.lean` source files retain their original bytes. The launcher runs
all 89 modules in dependency order and recompiles only changed/invalidated
sources, using the verified native Windows persistent cache.
