import Theorem_3_3_Arbitrary_Order_Gram_Determinant
import Theorem_3_3_Pole_Weight_Signs
import Mathlib.Tactic

/-!
# PDF Theorem 3.3: actual-pole all-order sign-adjusted Gram certificate

Apply arbitrary-order positive determinant algebra directly to the
paper's rational Vandermonde at the actual negative-square poles.
The signed residues have already been proved strictly positive when
multiplied by (-1)^(a-1); the pole Vandermonde determinant is nonzero
from Theorem 2.5. Hence the associated sign-corrected full Gram
determinant is strictly positive for every admissible matrix size.

This is a certificate on the actual pole lattice, not an identification
of the sign-corrected Gram matrix with the paper's positive continuous
moment Hankel matrix. The Sylvester inertia transfer remains distinct.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Theorem3_3.ActualPoleGram

open ManuscriptChain.PoleDiagonalization
open PaperChronology.Theorem3_3.ArbitraryGram

/-- Positive sign-adjusted residue for the manuscript's actual pole index. -/
def correctedPoleWeight (p : ManuscriptChain.Real.Parameters)
    (i : Fin p.h) : ℚ :=
  (-1 : ℚ) ^ (poleIndex p i - 1) * poleWeight p i

/-- All actual-pole weights become strictly positive after their
explicit alternating sign correction. -/
theorem correctedPoleWeight_pos
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m)
    (i : Fin p.h) : 0 < correctedPoleWeight p i := by
  exact PaperChronology.Theorem3_3.PoleWeightSigns.actual_poleWeight_signed_positive p hm i

/-- Exact determinant at every matrix size for the actual pole lattice. -/
theorem correctedPoleGram_det
    (p : ManuscriptChain.Real.Parameters) :
    (weightedGram (poleVandermonde p) (correctedPoleWeight p)).det =
      (poleVandermonde p).det ^ 2 *
        ∏ i : Fin p.h, correctedPoleWeight p i := by
  exact weightedGram_det (poleVandermonde p) (correctedPoleWeight p)

/-- Unconditional, all-order strictly positive determinant for the
sign-corrected pole Gram matrix of the *actual* manuscript parameters. -/
theorem correctedPoleGram_det_pos
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m) :
    0 < (weightedGram (poleVandermonde p)
      (correctedPoleWeight p)).det := by
  apply weightedGram_det_pos
  · exact poleVandermonde_det_ne_zero p
  · intro i
    exact correctedPoleWeight_pos p hm i

/-- Actual pole weights and the Vandermonde yield a nonsingular positive
sign-corrected Gram determinant, with no external arithmetic hypothesis. -/
theorem correctedPoleGram_det_ne_zero
    (p : ManuscriptChain.Real.Parameters) (hm : 0 < p.m) :
    (weightedGram (poleVandermonde p) (correctedPoleWeight p)).det ≠ 0 :=
  ne_of_gt (correctedPoleGram_det_pos p hm)

end PaperChronology.Theorem3_3.ActualPoleGram

#print axioms PaperChronology.Theorem3_3.ActualPoleGram.correctedPoleWeight_pos
#print axioms PaperChronology.Theorem3_3.ActualPoleGram.correctedPoleGram_det_pos
#print axioms PaperChronology.Theorem3_3.ActualPoleGram.correctedPoleGram_det_ne_zero
