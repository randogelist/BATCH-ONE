# v0.5.0 — larger chronological paper-theorem increment

This package starts from the user-verified **105/105 PASS** v0.4.7.2 snapshot.
All 105 old `.lean` files are byte-identical. It provides eight new modules,
including a chronological integration theorem. No assistant compilation.

## Actual newly developed mathematics (subject to user Lean verification)

1. **Theorem 3.4:** for each actual principal real-s or odd-zeta affine pencil,
   use the finite real spectrum to CONSTRUCT its own positive radius B and
   prove positivity on |x−center|<1/B. No spectral bound hypothesis.
2. **Corollary 3.5 (corrected):** exact 2x2 Schur complement/J-fraction for
   (G+tM), including the missing Gram normalization. Not the false (3.6).
3. **Corollary 3.6 (corrected):** all-order reciprocal-root atomic moments,
   individual lower bounds, cardinal upper bounds, and exact Gram factor.
4. **Theorem 3.7:** ALL-degree real-rooted Turan m=1 formula, starting from
   the recursive SOS identity and connecting to actual first/second derivatives.
5. **Theorem 3.8:** actual pole Christoffel-Darboux kernel VᵀG⁻¹V,
   its all-index sum expression, and det(G+tM)=det(G)det(I+tG⁻¹M).
6. **Theorem 4.1 (local spectral part):** witness-free finite root separation
   for all actual principal pencils; uniform exponential bound remains open.

## Still not certified as complete printed theorems

3.3 all nonprincipal minors and Sylvester inertia/eigenvalue count; 3.4
Cauchy interlacing; 3.5 global length-h Lanczos J-fraction; 3.6 infinite
strict Hankel determinants (false as printed); 3.7 m>1 Wronskians; 3.8
eigenvalue equality with weighted pole kernel; 4.1 uniform exponential
spectral estimates and the arithmetic normalization witness.

## Verification

One ZIP, one root-level `run.cmd`, native Lean 4.33.0, 16 threads, offline,
pass-once frozen 105 sources. The user's compiler decides whether eight
new modules pass; final certificate checks .olean and source stamps of each.
