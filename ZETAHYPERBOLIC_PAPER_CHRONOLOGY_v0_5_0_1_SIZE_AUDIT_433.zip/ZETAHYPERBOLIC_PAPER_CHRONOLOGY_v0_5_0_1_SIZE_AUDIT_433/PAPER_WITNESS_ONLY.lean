import PAPER_MAIN_CHAIN
import ZETA5_DIRECT_IRRATIONALITY
import MAIN_CHAIN_IRRATIONALITY

/-!
# The paper's weight-five Diophantine spine: a single witness input

This module preserves the manuscript's *actual* K=30*n, N=3*n, h=27*n
pencil and its canonical zeta(5) center. It neither postulates a polynomial
unrelated to the manuscript nor assumes the final irrationality conclusion.

`Witness` is ONE named conditional input. It consists of:
  * a positive rational normalization into integer polynomials, verified
    to be an exact multiple of the manuscript's rational determinant, and
  * the manuscript's eventual quadratic upper bound for the normalized
    value at zeta(5).

The normalized polynomial's positivity and nonvanishing are PROVED from
its identity and the unconditional positive Gram moment representation.
No quantitative spectral estimate is needed for plain irrationality.

For the manuscript's *effective measure* 25687, `EffectiveWitness` adds the
separate quantitative spectral growth bound. The spectral factorization
itself is already available from the Gram theorem. These are two independent
mathematical estimates, even though the end theorem has one formal argument.
No unproved estimate is hidden in a local `have`, and no custom axiom occurs.

STATUS: source-only interface; run Lean 4.33.0 with the pinned Mathlib cache.
-/

noncomputable section

namespace PaperWitness
open ManuscriptChain

/-- Manuscript Theorem 4.4, equation (4.3), with its *actual* integral
normalization. A proof of this one structure is the conditional paper witness.

`normalization` certifies `Q_n in Z[X]`, a strictly positive multiplier, and
`Q_n = multiplier_n * S_n * Delta_n` for the specified n-family.
`normalized_value_upper` is the one asymptotic arithmetic bound that the
source paper attributes to its prime-sum / potential calculation. -/
structure Witness where
  normalization : MainChain.MainNormalization
  normalized_value_upper :
    forall n : ℕ, normalization.onset ≤ n →
      |RealTransfer.evalReal (normalization.Q n) MainChain.zeta5| ≤
        MainChain.decayBudget n

/-- All ingredients of the abstract integer-polynomial decay criterion
follow from the ONE witness. Nonzero evaluation is proved independently
from the unconditional concrete moment realization. -/
theorem decay_from_witness (w : Witness) :
    RealTransfer.Decay w.normalization.Q MainChain.zeta5
      MainChain.decayBudget w.normalization.onset := by
  have pos : MainChain.BaseValuePositive w.normalization.onset :=
    MainChain.main_baseValuePositive w.normalization.onset
      w.normalization.onset_ge_one
  constructor
  · intro n hn
    exact ne_of_gt
      (MainChain.normalized_value_pos w.normalization pos n hn)
  · intro n hn
    exact w.normalized_value_upper n hn

/-- The only user-supplied mathematical input is `w`. The polynomial,
its degree, zeta-center positivity, and denominator squeeze are constructed
by the imported manuscript modules. -/
theorem ZETA5_IRRATIONAL_OF_WITNESS (w : Witness) :
    Irrational (riemannZeta (5 : ℂ)).re :=
  ManuscriptChain.zeta5_irrational_of_normalized_decay
    w.normalization (decay_from_witness w)

/-- Source-faithful adapter: the separate multiplier and Archimedean
estimates claimed in Section 4 jointly provide the arithmetic witness.
The theorem is not evidence that either uniform estimate has been proved. -/
def witness_of_paper_bounds (A : MainChain.MainNormalization)
    (multiplier : MainChain.MultiplierUpper A)
    (archimedean : MainChain.ArchimedeanUpper A.onset) : Witness where
  normalization := A
  normalized_value_upper :=
    (MainChain.main_decay A
      (MainChain.main_baseValuePositive A.onset A.onset_ge_one)
      multiplier archimedean).upper

/-- Canonical primitive integer family: its construction, degree and
positivity are unconditional. Only its exponential value estimate is input. -/
structure PrimitiveWitness where
  start : ℕ
  value_bound : ∀ n : ℕ, start + 1 ≤ n →
    |RealTransfer.evalReal
        ((MainChain.primitiveMainNormalization start).Q n)
        MainChain.zeta5| ≤ MainChain.decayBudget n

def PrimitiveWitness.toWitness (w : PrimitiveWitness) : Witness where
  normalization := MainChain.primitiveMainNormalization w.start
  normalized_value_upper := w.value_bound

theorem ZETA5_IRRATIONAL_OF_PRIMITIVE_WITNESS (w : PrimitiveWitness) :
    Irrational (riemannZeta (5 : ℂ)).re :=
  ZETA5_IRRATIONAL_OF_WITNESS w.toWitness

/-- To obtain Theorem 4.4's *effective* irrationality measure, the norm
bound e^(11.411 K) must ALSO be supplied. The real-rooted factorization and
its nonzero eigenvalues are established unconditionally upstream. -/
structure EffectiveWitness where
  arithmetic : Witness
  spectral : MainChain.MainSpectralData arithmetic.normalization.onset

/-- Full conditional transfer for the *same* normalized polynomial family:
Theorem 4.1's comparison and denominator-index choice are proved upstream. -/
theorem MEASURE_25687_OF_WITNESS (w : EffectiveWitness) :
    RealTransfer.RationalMeasure MainChain.zeta5 25687
      (MainChain.indexDenominatorThreshold
        w.arithmetic.normalization.onset) :=
  RealTransfer.conditional_measure
    (MainChain.main_localComparison
      w.arithmetic.normalization w.spectral)
    (decay_from_witness w.arithmetic)
    (MainChain.main_indexBudget w.arithmetic.normalization)

/-- The paper's effective inequality stated literally with Mathlib's
`riemannZeta`, for the actual normalized determinant Q_K. -/
theorem THEOREM_4_4_MEASURE_25687 (w : EffectiveWitness) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b →
      MainChain.indexDenominatorThreshold
        w.arithmetic.normalization.onset ≤ b →
      1 / (b : ℝ) ^ 25687 <
        |(riemannZeta (5 : ℂ)).re - (a : ℝ) / (b : ℝ)| := by
  intro a b hb hlarge
  have h := MEASURE_25687_OF_WITNESS w a b hb hlarge
  simpa only [MainChain.zeta5, Real.zeta_five_eq_riemannZeta_re] using h

/-- The numbered paper endpoint as a single-argument conditional theorem.
`MEASURE_25687_OF_WITNESS` has the actual manuscript Q-family, not a toy one. -/
theorem THEOREM_4_4_IRRATIONALITY (w : EffectiveWitness) :
    Irrational (riemannZeta (5 : ℂ)).re :=
  ZETA5_IRRATIONAL_OF_WITNESS w.arithmetic

/-- One-assumption proof of the central manuscript chain:
  Section 2 finite algebra -> Section 3 actual integral/Gram/spectrum ->
  Section 4 polynomial measure.
This does NOT claim that every theorem in Sections 3-6 has been formalized. -/
theorem PAPER_CENTRAL_SPINE (w : EffectiveWitness) :
    (∀ p : Real.Parameters, Real.Admissible p →
      General.GeneralStatement p) ∧
    RealTransfer.RationalMeasure MainChain.zeta5 25687
      (MainChain.indexDenominatorThreshold
        w.arithmetic.normalization.onset) := by
  constructor
  · intro p hp
    exact ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp
  · exact MEASURE_25687_OF_WITNESS w

/-- A different, substantially stronger universal input would be needed
to prove irrationality for *every* odd zeta value. The paper does not
provide this universal witness. It is exposed, not silently assumed. -/
def AllOddWitness : Prop :=
  ∀ k : ℕ, 0 < k →
    GeneralIrrationality.OddWeightDecayHypothesis k

theorem ALL_ODD_IRRATIONAL_OF_WITNESS (w : AllOddWitness) :
    ∀ k : ℕ, 0 < k →
      Irrational (riemannZeta ((2 * k + 1 : ℕ) : ℂ)).re :=
  GeneralIrrationality.all_odd_zeta_irrational w

end PaperWitness

#print axioms PaperWitness.decay_from_witness
#print axioms PaperWitness.ZETA5_IRRATIONAL_OF_WITNESS
#print axioms PaperWitness.MEASURE_25687_OF_WITNESS
#print axioms PaperWitness.THEOREM_4_4_MEASURE_25687
#print axioms PaperWitness.PAPER_CENTRAL_SPINE
#print axioms PaperWitness.ALL_ODD_IRRATIONAL_OF_WITNESS
