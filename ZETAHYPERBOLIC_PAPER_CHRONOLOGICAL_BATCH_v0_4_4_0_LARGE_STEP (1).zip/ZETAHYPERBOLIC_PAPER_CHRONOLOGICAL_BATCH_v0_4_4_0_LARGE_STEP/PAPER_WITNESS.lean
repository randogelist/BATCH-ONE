import ZETA5_DIRECT_IRRATIONALITY
import MAIN_CHAIN_IRRATIONALITY

/-!
# Paper's weight-five arithmetic witness, one conditional input

The PDF's Section 4, equation (4.3), asserts existence of integer polynomials
Q_K = m_{K,M} S_K Delta_K, M=100000, with a positive rational multiplier and
quadratic smallness at zeta(5). We do NOT assume the paper's norm estimate,
the irrationality result, or any additional analytic lemma here.

`RawWitness` is exactly the existence of a per-index integer-polynomial
normalization of this manuscript's real family and a uniform eventual
quadratic bound. There is no assumption of nonzero evaluation, determinant
degree, positive Gram matrix, nor any root bound: all are already theorems in
the imported project, and the direct irrationality endpoint does not require
the last of these.

`Witness` is the equivalent sufficient assertion reduced to the internally
constructed positive primitive integer polynomials. The map from raw to
primitive form is PROVED, not an additional input.

No `sorry`, `admit`, or custom `axiom` is introduced in this file.
-/

noncomputable section
open Polynomial

namespace PaperReconstruction
open ManuscriptChain
open ManuscriptChain.MainChain
open ManuscriptChain.RealTransfer

/-- Single missing numerical/arithmetic assertion after canonical primitive
normalization. The onset accommodates the PDF's "sufficiently large K". -/
def Witness : Prop :=
  ∃ start : ℕ, ∀ n : ℕ, start + 1 ≤ n →
    |evalReal ((primitiveMainNormalization start).Q n) zeta5| ≤ decayBudget n

/-- The PDF's own kind of witness: an integer polynomial at every sufficiently
large n, identified with a POSITIVE rational multiple of the paper's F_K,
with (4.3) on exactly the same normalization/family.

This is an unproved `Prop`, NOT an instantiated existence claim. -/
def RawWitness : Prop :=
  ∃ start : ℕ, ∀ n : ℕ, start + 1 ≤ n →
    ∃ (g : ℤ[X]) (a : ℚ),
      0 < a ∧
      g.map (Int.castRingHom ℚ) = C a * ManuscriptChain.Real.mainF n ∧
      |evalReal g zeta5| ≤ decayBudget n

/-- One paper-style witness implies the decay input on the REAL primitive
normalized Hankel polynomials, by minimality of primitive normalization. -/
theorem WITNESS_FROM_PAPER_RAW (h : RawWitness) : Witness := by
  obtain ⟨start, hw⟩ := h
  refine ⟨start, ?_⟩
  intro n hn
  obtain ⟨g, a, ha, hg, hsmall⟩ := hw n hn
  have hprim :
      |evalReal ((primitiveMainNormalization start).Q n) zeta5| ≤
        |evalReal g zeta5| := by
    simpa only [evalReal, primitiveMainNormalization, algebraMap_int_eq] using
      BasisInvariance.primitiveNormalization_abs_eval_int_le
        (primitiveMainPolynomialNormalization n) ha hg zeta5
  exact hprim.trans hsmall

/-- The determinant of the actual source pencil has full degree, all roots
real and off zeta(s), and an exact positive zero-free radius. NO witness. -/
theorem THEOREM_3_1_WITHOUT_WITNESS
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- The nonzero-evaluation input is a theorem, not part of the Witness. -/
theorem PRIMITIVE_VALUE_POSITIVE (start n : ℕ) (hn : start + 1 ≤ n) :
    0 < evalReal ((primitiveMainNormalization start).Q n) zeta5 := by
  let A := primitiveMainNormalization start
  have hpos : BaseValuePositive A.onset :=
    main_baseValuePositive A.onset A.onset_ge_one
  exact normalized_value_pos A hpos n hn

/-- Main theorem: the paper's weight-five IRRATIONALITY endpoint needs ONE
conditional proposition. No quantitative spectral bound is needed. -/
theorem THEOREM_4_4_IRRATIONAL_FROM_WITNESS
    (h : Witness) : Irrational (riemannZeta 5).re := by
  obtain ⟨start, hw⟩ := h
  exact ManuscriptChain.ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY start hw

/-- The exact paper-style normalization witness (4.3) also suffices. -/
theorem THEOREM_4_4_IRRATIONAL_FROM_RAW
    (h : RawWitness) : Irrational (riemannZeta 5).re :=
  THEOREM_4_4_IRRATIONAL_FROM_WITNESS (WITNESS_FROM_PAPER_RAW h)

end PaperReconstruction

#check PaperReconstruction.RawWitness
#check PaperReconstruction.Witness
#check PaperReconstruction.THEOREM_3_1_WITHOUT_WITNESS
#check PaperReconstruction.THEOREM_4_4_IRRATIONAL_FROM_WITNESS
#check PaperReconstruction.THEOREM_4_4_IRRATIONAL_FROM_RAW
#print axioms PaperReconstruction.WITNESS_FROM_PAPER_RAW
#print axioms PaperReconstruction.THEOREM_3_1_WITHOUT_WITNESS
#print axioms PaperReconstruction.PRIMITIVE_VALUE_POSITIVE
#print axioms PaperReconstruction.THEOREM_4_4_IRRATIONAL_FROM_WITNESS
#print axioms PaperReconstruction.THEOREM_4_4_IRRATIONAL_FROM_RAW
