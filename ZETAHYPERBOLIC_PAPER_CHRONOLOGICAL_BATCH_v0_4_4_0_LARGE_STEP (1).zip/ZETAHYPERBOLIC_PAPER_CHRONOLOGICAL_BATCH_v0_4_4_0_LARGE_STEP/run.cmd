@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 exit /b 1
set "PACKAGE=ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_BATCH_v0_4_4_0_LARGE_STEP"
set "MODE=PERSISTENT_VERIFIED_INCREMENTAL"
if /i "%~1"=="full" set "MODE=FORCE_CLEAN_REBUILD"
if not defined LEAN_JOBS set "LEAN_JOBS=16"
set "LEAN_NUM_THREADS=%LEAN_JOBS%"
if not exist "compile-order.txt" goto FAIL_MANIFEST
if not exist "_logs" mkdir "_logs"
if not exist "_logs" goto FAIL_LOGS
>"_logs\BUILD_SUMMARY.txt" echo BUILD=RUNNING
>>"_logs\BUILD_SUMMARY.txt" echo PACKAGE=%PACKAGE%
>>"_logs\BUILD_SUMMARY.txt" echo MODE=%MODE%
echo RUNNER=NATIVE_WINDOWS_LEAN_433_PRINCIPAL_ENDPOINT_INCREMENTAL
echo MODE=%MODE%
echo NETWORK=NOT_USED
echo LAKE=NOT_USED
echo POWERSHELL=NOT_USED
echo PYTHON=NOT_USED
echo WSL=NOT_USED
echo LEAN_THREADS=%LEAN_JOBS%
echo COMPILER=USER_MACHINE_ONLY

rem Existing native Windows Lean 4.33.0 compiler; no installation or download.
if not defined LEAN_EXE set "LEAN_EXE=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0\bin\lean.exe"
if not exist "%LEAN_EXE%" goto FAIL_LEAN
for %%E in ("%LEAN_EXE%") do set "LEAN_STDLIB=%%~dpE..\lib\lean"
if not exist "%LEAN_STDLIB%\Init.olean" goto FAIL_STDLIB
"%LEAN_EXE%" --version >"_logs\lean-version.log" 2>&1
if errorlevel 1 goto FAIL_LEAN
findstr /C:"version 4.33.0," "_logs\lean-version.log" >nul
if errorlevel 1 goto FAIL_VERSION

rem The established offline .olean package roots.
if not defined CACHE_ROOT set "CACHE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
if not defined MATHLIB_LIB if defined MATHLIB_DIR if exist "%MATHLIB_DIR%\Mathlib.olean" set "MATHLIB_LIB=%MATHLIB_DIR%"
if not defined MATHLIB_LIB if defined MATHLIB_DIR if exist "%MATHLIB_DIR%\.lake\build\lib\lean\Mathlib.olean" set "MATHLIB_LIB=%MATHLIB_DIR%\.lake\build\lib\lean"
if not defined MATHLIB_LIB if exist "%CACHE_ROOT%\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean" set "MATHLIB_LIB=%CACHE_ROOT%\.lake\packages\mathlib\.lake\build\lib\lean"
if not defined MATHLIB_LIB if exist "%CD%\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean" set "MATHLIB_LIB=%CD%\.lake\packages\mathlib\.lake\build\lib\lean"
if not defined MATHLIB_LIB goto FAIL_MATHLIB
if not exist "%MATHLIB_LIB%\Mathlib.olean" goto FAIL_MATHLIB

rem Shared across ZIP versions: unchanged successful modules are not rerun.
if not defined PAPER_VERIFIED_CACHE set "PAPER_VERIFIED_CACHE=%USERPROFILE%\lean-native\zetahyperbolic-paper-verified-lean433"
set "OBJECTS=%PAPER_VERIFIED_CACHE%\lean"
set "SNAPSHOTS=%PAPER_VERIFIED_CACHE%\src"
set "DIRTY_FLAGS=%PAPER_VERIFIED_CACHE%\dirty-this-run"
set "LEAN_PATH=%OBJECTS%;%LEAN_STDLIB%"
set /a CACHE_ROOTS=0
call :addRoot "%CACHE_ROOT%\.lake\build\lib\lean"
for /d %%P in ("%CACHE_ROOT%\.lake\packages\*") do call :addRoot "%%~fP\.lake\build\lib\lean"
for /d %%P in ("%CD%\.lake\packages\*") do call :addRoot "%%~fP\.lake\build\lib\lean"
call :addRoot "%MATHLIB_LIB%"
echo MATHLIB_CACHE=READY
echo NATIVE_LEAN_PATH=READY
echo VERIFIED_CACHE=%PAPER_VERIFIED_CACHE%
echo CACHE_ROOTS=%CACHE_ROOTS%
>>"_logs\BUILD_SUMMARY.txt" echo VERIFIED_CACHE=%PAPER_VERIFIED_CACHE%
>>"_logs\BUILD_SUMMARY.txt" echo MATHLIB_CACHE=READY

rem Preserve the v0.3.2 config format for safe one-time object seeding.
>"_logs\fastcore-config.current" echo LEAN_EXE=%LEAN_EXE%
>>"_logs\fastcore-config.current" echo LEAN_STDLIB=%LEAN_STDLIB%
>>"_logs\fastcore-config.current" echo MATHLIB_LIB=%MATHLIB_LIB%
>>"_logs\fastcore-config.current" echo CACHE_ROOT=%CACHE_ROOT%
>>"_logs\fastcore-config.current" echo FLAGS=relaxedAutoImplicit_false_maxSynthPendingDepth_3_mathlibStandardSet_false
rem Invalidate if the actual Mathlib root artifact is replaced in place.
>"_logs\mathlib-stamp.current" echo LEAN_VERSION=4.33.0
for %%F in ("%MATHLIB_LIB%\Mathlib.olean") do (
  >>"_logs\mathlib-stamp.current" echo MATHLIB_SIZE=%%~zF
  >>"_logs\mathlib-stamp.current" echo MATHLIB_MODIFIED=%%~tF
)

if not exist "%PAPER_VERIFIED_CACHE%" mkdir "%PAPER_VERIFIED_CACHE%"
if not exist "%PAPER_VERIFIED_CACHE%" goto FAIL_CACHE
set "INVALIDATE=0"
if /i "%~1"=="full" set "INVALIDATE=1"
if not exist "%PAPER_VERIFIED_CACHE%\fastcore-config.txt" set "INVALIDATE=1"
if not exist "%PAPER_VERIFIED_CACHE%\mathlib-stamp.txt" set "INVALIDATE=1"
if exist "%PAPER_VERIFIED_CACHE%\mathlib-stamp.txt" (
  fc /b "%PAPER_VERIFIED_CACHE%\mathlib-stamp.txt" "_logs\mathlib-stamp.current" >nul 2>&1
  if errorlevel 1 set "INVALIDATE=1"
)
if exist "%PAPER_VERIFIED_CACHE%\fastcore-config.txt" (
  fc /b "%PAPER_VERIFIED_CACHE%\fastcore-config.txt" "_logs\fastcore-config.current" >nul 2>&1
  if errorlevel 1 set "INVALIDATE=1"
)
if "%INVALIDATE%"=="1" (
  if exist "%OBJECTS%" rmdir /s /q "%OBJECTS%"
  if exist "%SNAPSHOTS%" rmdir /s /q "%SNAPSHOTS%"
)
if not exist "%OBJECTS%" mkdir "%OBJECTS%"
if not exist "%SNAPSHOTS%" mkdir "%SNAPSHOTS%"
if exist "%DIRTY_FLAGS%" rmdir /s /q "%DIRTY_FLAGS%"
mkdir "%DIRTY_FLAGS%"
if not exist "%OBJECTS%" goto FAIL_CACHE
if not exist "%SNAPSHOTS%" goto FAIL_CACHE
if not exist "%DIRTY_FLAGS%" goto FAIL_CACHE

rem On the first shared-cache run, seed from successfully compiled v0.3.2
rem objects ONLY IF their recorded environment matches ours. The current
rem source and dependency graph are validated below, module by module.
set "CACHE_SEED=NOT_USED"
if /i not "%~1"=="full" if "%INVALIDATE%"=="1" call :seedPrior "%USERPROFILE%\Downloads\ZETAHYPERBOLIC_PAPER_CHRONOLOGICAL_NATIVE_v0_3_2_FASTSTART"
copy /y "_logs\fastcore-config.current" "%PAPER_VERIFIED_CACHE%\fastcore-config.txt" >nul
if errorlevel 1 goto FAIL_CACHE
copy /y "_logs\mathlib-stamp.current" "%PAPER_VERIFIED_CACHE%\mathlib-stamp.txt" >nul
if errorlevel 1 goto FAIL_CACHE
echo CACHE_SEED=%CACHE_SEED%
>>"_logs\BUILD_SUMMARY.txt" echo CACHE_SEED=%CACHE_SEED%

set /a COMPILED=0
set /a REUSED=0
for /f "usebackq delims=" %%M in ("compile-order.txt") do (
  call :compile "%%M"
  if errorlevel 1 goto FAIL_COMPILE
)
>>"_logs\BUILD_SUMMARY.txt" echo MODULES_COMPILED=%COMPILED%
>>"_logs\BUILD_SUMMARY.txt" echo MODULES_REUSED=%REUSED%
>>"_logs\BUILD_SUMMARY.txt" echo CHRONOLOGY_ENTRIES=51
>>"_logs\BUILD_SUMMARY.txt" echo PAPER_RESULTS_FULLY_PROVED=NO
>>"_logs\BUILD_SUMMARY.txt" echo BUILD=PASS
echo MODULES_COMPILED=%COMPILED%
echo MODULES_REUSED=%REUSED%
echo CHRONOLOGY_ENTRIES=51
echo PAPER_RESULTS_FULLY_PROVED=NO
echo BUILD=PASS
exit /b 0

:addRoot
if not exist "%~1" exit /b 0
set "LEAN_PATH=%LEAN_PATH%;%~1"
set /a CACHE_ROOTS+=1 >nul
exit /b 0

:seedPrior
set "OLDROOT=%~1"
if not exist "%OLDROOT%\_logs\BUILD_SUMMARY.txt" exit /b 0
findstr /B /C:"BUILD=PASS" "%OLDROOT%\_logs\BUILD_SUMMARY.txt" >nul 2>&1
if errorlevel 1 exit /b 0
if not exist "%OLDROOT%\.build\fastcore-config.txt" exit /b 0
fc /b "%OLDROOT%\.build\fastcore-config.txt" "_logs\fastcore-config.current" >nul 2>&1
if errorlevel 1 exit /b 0
if not exist "%OLDROOT%\.build\lean" exit /b 0
if not exist "%OLDROOT%\.build\src" exit /b 0
xcopy "%OLDROOT%\.build\lean\*" "%OBJECTS%\" /E /I /Q /Y >nul
if errorlevel 1 exit /b 0
xcopy "%OLDROOT%\.build\src\*" "%SNAPSHOTS%\" /E /I /Q /Y >nul
if errorlevel 1 exit /b 0
set "CACHE_SEED=VERIFIED_V032_SNAPSHOT"
exit /b 0

:snapshot
set "MOD_SNAPSHOT=%~1"
set "FILE_SNAPSHOT=%MOD_SNAPSHOT:.=\%"
for %%D in ("%SNAPSHOTS%\%FILE_SNAPSHOT%.lean") do if not exist "%%~dpD" mkdir "%%~dpD"
copy /y "%FILE_SNAPSHOT%.lean" "%SNAPSHOTS%\%FILE_SNAPSHOT%.lean" >nul
if errorlevel 1 exit /b 1
exit /b 0

:checkDirtyImport
if exist "%DIRTY_FLAGS%\%~1.flag" set "REBUILD=1"
exit /b 0

:compile
set "MODULE=%~1"
set "SOURCE=%MODULE:.=\%"
set "REBUILD=0"
if not exist "%SOURCE%.lean" (
  echo SOURCE_NOT_FOUND=%SOURCE%.lean
  set "FAILED_MODULE=%MODULE%"
  exit /b 1
)
if not exist "%OBJECTS%\%SOURCE%.olean" set "REBUILD=1"
if not exist "%SNAPSHOTS%\%SOURCE%.lean" set "REBUILD=1"
if "%REBUILD%"=="0" (
  fc /b "%SOURCE%.lean" "%SNAPSHOTS%\%SOURCE%.lean" >nul 2>&1
  if errorlevel 1 set "REBUILD=1"
)
rem Only source-unchanged modules with unchanged transitive inputs are reused.
if "%REBUILD%"=="0" for /f "tokens=1,2" %%A in ('findstr /B /C:"import " "%SOURCE%.lean"') do if /i "%%A"=="import" call :checkDirtyImport "%%B"
if "%REBUILD%"=="0" (
  set /a REUSED+=1 >nul
  echo CHECK_REUSE=%MODULE%
  >>"_logs\BUILD_SUMMARY.txt" echo CHECK_REUSE=%MODULE%
  exit /b 0
)
for %%D in ("%OBJECTS%\%SOURCE%.olean") do if not exist "%%~dpD" mkdir "%%~dpD"
if exist "%OBJECTS%\%SOURCE%.olean" del /q "%OBJECTS%\%SOURCE%.olean" >nul
set "FAILED_MODULE=%MODULE%"
echo CHECK=%MODULE%
"%LEAN_EXE%" -j %LEAN_JOBS% -DrelaxedAutoImplicit=false -DmaxSynthPendingDepth=3 -Dweak.linter.mathlibStandardSet=false -o "%OBJECTS%\%SOURCE%.olean" "%SOURCE%.lean" >"_logs\%MODULE%.log" 2>&1
if errorlevel 1 (
  echo CHECK_FAIL=%MODULE%
  >>"_logs\BUILD_SUMMARY.txt" echo CHECK_FAIL=%MODULE%
  type "_logs\%MODULE%.log"
  exit /b 1
)
rem Axiom audit: reject any newly compiled theorem depending on Lean's sorryAx.
findstr /C:"sorryAx" "_logs\%MODULE%.log" >nul 2>&1
if not errorlevel 1 (
  echo CHECK_FAIL_SORRYAX=%MODULE%
  >>"_logs\BUILD_SUMMARY.txt" echo CHECK_FAIL_SORRYAX=%MODULE%
  exit /b 1
)
call :snapshot "%MODULE%"
if errorlevel 1 exit /b 1
>"%DIRTY_FLAGS%\%MODULE%.flag" echo CHANGED
set /a COMPILED+=1 >nul
echo CHECK_PASS=%MODULE%
>>"_logs\BUILD_SUMMARY.txt" echo CHECK_PASS=%MODULE%
exit /b 0

:FAIL_COMPILE
echo FAILED_MODULE=%FAILED_MODULE%
>>"_logs\BUILD_SUMMARY.txt" echo FAILED_MODULE=%FAILED_MODULE%
>>"_logs\BUILD_SUMMARY.txt" echo BUILD=FAIL
echo BUILD=FAIL
exit /b 5
:FAIL_MANIFEST
echo BUILD=FAIL missing compile-order.txt
exit /b 1
:FAIL_LOGS
echo BUILD=FAIL cannot initialize logs
exit /b 1
:FAIL_LEAN
echo BUILD=FAIL missing native Lean 4.33.0
>>"_logs\BUILD_SUMMARY.txt" echo BUILD=FAIL missing lean.exe
exit /b 2
:FAIL_STDLIB
echo BUILD=FAIL native Lean .olean stdlib missing
>>"_logs\BUILD_SUMMARY.txt" echo BUILD=FAIL missing stdlib
exit /b 2
:FAIL_VERSION
type "_logs\lean-version.log"
echo BUILD=FAIL expected Lean 4.33.0
>>"_logs\BUILD_SUMMARY.txt" echo BUILD=FAIL wrong Lean version
exit /b 3
:FAIL_MATHLIB
echo BUILD=FAIL matching prebuilt Mathlib cache not found
echo CACHE_ROOT=%CACHE_ROOT%
>>"_logs\BUILD_SUMMARY.txt" echo BUILD=FAIL missing Mathlib
exit /b 4
:FAIL_CACHE
echo BUILD=FAIL cannot use verified object cache
>>"_logs\BUILD_SUMMARY.txt" echo BUILD=FAIL cache error
exit /b 6
