# Paper coverage audit — 2026-10-24

## Current best estimate

**Approximately 10–15% of the manuscript's mathematical proof content has been formalized, including partial proof components.** This is a subjective, proof-depth-weighted estimate, **not** a compiler-certified percentage.

**Fully formalized numbered substantive results according to the source register: 3/46 = 6.52%.** These are **Theorem 2.4, Theorem 2.5, and Theorem 3.1**.

| Category | Results |
|---|---:|
| Numbered checkpoints, including remarks/conjecture | 51 |
| Substantive definitions/lemmas/theorems/propositions/corollaries | 46 |
| Listed as fully proved | 3 |
| Have a construction, generator result, or partial proof | 20 |
| Not yet substantively formalized | 20 |
| Printed statement requires correction before complete proof | 3 |
| Remarks + conjecture, excluded from full-theorem percentage | 5 |

The proportion of *substantive results with some attempted implementation* is 50.0%, but this is **not** proof coverage: partial proofs often omit the principal assertion. The registered full-proof percentage measures completed theorem statements, not lines of Lean code or imported theorems.

## Completeness and validation boundaries

- `Theorem 2.4`: primitive basis invariance.
- `Theorem 2.5`: pole matrix factorization and determinant degree; the exact Lagrange-polynomial functional interpretation is more extensive than current Lean.
- `Theorem 3.1`: unconditional general odd-weight Gram/hyperbolicity endpoint, as listed in `MAIN_CHAIN_ASSEMBLED.lean`.
- `Theorem 3.3`: finite residue signs and Gram-energy pieces exist, but full continuous total positivity and complete inertia transfer are not yet formalized.
- `Theorems 3.4`, `Corollaries 3.5` and `3.6`: printed statements require mathematical repairs.
- `Theorem 4.4`: claimed constant 25687 remains outside the established unconditional Lean chain; some weaker/conditional transfers are available.
- `Sections 5–6`: many finite arithmetic/linear algebra identities exist, but complete integral/p-adic/analytic bridges remain outstanding.

## Compiler status caveat

User-supplied logs confirm the frozen v0.3.6 124-module checkpoint and subsequent incremental compilation successes, but **v0.3.19** still reports `sorryAx` in `Theorem_3_3_Finite_Determinant_Sign`. Separately, the v0.4.2.x Section 5 dual-arithmetic additions have had `sorryAx` failures. A `CHECK_REUSE` line means the corresponding module was reused unchanged; it does **not** certify that the full PDF result corresponding to its filename is proved. We have not compiled locally.

This ZIP preserves the last available full chronological source snapshot (`v0.4.2.3`) and adds this report without changing any `.lean` file. Its `run.cmd` retains the existing persistent native Windows Lean 4.33.0 fast-cache workflow. Since pending sources remain unverified, a new run is not predicted to pass. Avoid counting any theorem that still depends on `sorryAx` as proved.

## Coverage improvement priorities

1. Close the precise finite determinant sign proof in 3.3 with no `sorryAx`.
2. Complete the actual matrix congruence/inertia theorem, then real-weight moment positivity and total-positivity proof.
3. Repair 3.4–3.6 statements and prove the corrected ones.
4. Extend Section 4 transfers without importing arithmetic witnesses other than the explicit designated witness, when the specific theorem calls for it.
5. Close Section 5–6 integrations and p-adic congruence/valuation claims chronologically.

Source: `THEOREM_REGISTER.csv` and associated Lean files, with verification boundaries from user compiler logs. This document does not claim a compiler pass for these additions.
