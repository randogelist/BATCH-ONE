import Mathlib

/-!
Paper audit for pp. 9--11: exact arithmetic witnesses against literal
versions of three printed claims. This module contains no admitted proofs.
The mathematical identification with the paper's pencil is supplied by
Theorem 2.5, equation (2.11); the four gammas below are its N=1,K=5,
k=1,m=1 specialization. There is no claim to prove the false printed theorems.
-/

namespace PaperCorrections

/-- Residue coefficient gamma_2 in (2.11), N=1, K=5, k=m=1. -/
private def gamma2 : ℚ :=
  (2 : ℚ)^2 * ((1 : ℚ) - 2^2) /
    (((3 : ℚ)^2 - 2^2) * ((4 : ℚ)^2 - 2^2) * ((5 : ℚ)^2 - 2^2))

private def gamma3 : ℚ :=
  (3 : ℚ)^2 * ((1 : ℚ) - 3^2) /
    (((2 : ℚ)^2 - 3^2) * ((4 : ℚ)^2 - 3^2) * ((5 : ℚ)^2 - 3^2))

private def gamma4 : ℚ :=
  (4 : ℚ)^2 * ((1 : ℚ) - 4^2) /
    (((2 : ℚ)^2 - 4^2) * ((3 : ℚ)^2 - 4^2) * ((5 : ℚ)^2 - 4^2))

private def gamma5 : ℚ :=
  (5 : ℚ)^2 * ((1 : ℚ) - 5^2) /
    (((2 : ℚ)^2 - 5^2) * ((3 : ℚ)^2 - 5^2) * ((4 : ℚ)^2 - 5^2))

theorem gamma_values :
    gamma2 = -1/105 ∧ gamma3 = 9/70 ∧
      gamma4 = -20/63 ∧ gamma5 = 25/126 := by
  constructor
  · norm_num [gamma2]
  constructor
  · norm_num [gamma3]
  constructor
  · norm_num [gamma4]
  · norm_num [gamma5]

/-- In the manuscript's notation: [X] Delta_{K,1}(X) = 0 for
    s=3, N=1, K=5, 2m=2, by formula (2.11).
    Therefore Delta_{K,1} is a nonzero CONSTANT, not degree one.
    This contradicts the blanket principal-minor root claim in 3.4. -/
theorem first_principal_coefficient_zero :
    gamma2 + gamma3 + gamma4 + gamma5 = 0 := by
  norm_num [gamma2, gamma3, gamma4, gamma5]

/-- The computed X-coefficient forces the entire affine first minor
    to be constant, whatever its positive Gram constant is. -/
theorem first_principal_minor_constant (g x y : ℚ) :
    g + x * (gamma2 + gamma3 + gamma4 + gamma5) =
      g + y * (gamma2 + gamma3 + gamma4 + gamma5) := by
  rw [first_principal_coefficient_zero]
  ring

/-- Equation (2.11) for the h=1 pencil, N=1, K=2, s=3, m=1.
    Its derivative coefficient is NEGATIVE, while G(xi) is positive. -/
theorem singleton_derivative_negative :
    (2 : ℚ)^2 * ((1 : ℚ) - 2^2) = -12 := by
  norm_num

/-- For a positive one-dimensional Gram value g and slope -12,
    the printed continued-fraction RHS at X=xi has the wrong sign
    relative to Delta_0/Delta_1 = 1/g. -/
theorem printed_fraction_sign_conflict (g : ℝ) (hg : 0 < g) :
    (1 : ℝ) / g ≠ 1 / ((-12 : ℝ) / g) := by
  have hleft : 0 < (1 : ℝ) / g := by positivity
  have hden : ((-12 : ℝ) / g) < 0 :=
    div_neg_of_neg_of_pos (by norm_num) hg
  have hright : (1 : ℝ) / ((-12 : ℝ) / g) < 0 :=
    div_neg_of_pos_of_neg (by norm_num) hden
  exact ne_of_gt (lt_trans hright hleft)

/-- A one-atom Stieltjes moment sequence has a zero 2x2 Hankel
    determinant; the paper's "strictly positive all orders" in 3.6
    is false already when h=1. -/
theorem single_atom_hankel_determinant_zero (u : ℝ) :
    (1 : ℝ) * u^2 - u*u = 0 := by ring

end PaperCorrections

#print axioms PaperCorrections.first_principal_coefficient_zero
#print axioms PaperCorrections.printed_fraction_sign_conflict
#print axioms PaperCorrections.single_atom_hankel_determinant_zero
