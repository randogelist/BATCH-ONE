import PAPER_COROLLARY_3_6_FINITE_SUPPORT
import PaperChronology.Section3FiniteSupportSharp

/-!
# Corollary 3.6, corrected finite-support theorem — chronology endpoint

When h nodes are distinct and the weights are positive, finite Stieltjes
Hankel energy is strictly positive for nonzero polynomial test functions of
degree below h. Nonetheless it has a nontrivial kernel on the space of ALL
polynomials, as shown by the monic annihilator in the frozen v0.4.3.1 proof.

This package does not infer irrationality or any unproved analytic statement.
-/

#check PaperChronology.Section3FiniteSupportSharp.sharp_finite_atomic_positive_form
#check PaperChronology.Section3FiniteSupportSharp.energy_zero_iff_all_evaluations_zero
#check PaperChronology.Section3FiniteSupportSharp.energy_pos_iff_exists_nonzero_evaluation
#check PaperChronology.Section3FiniteSupportSharp.energy_strict_below_support_card
#check PaperChronology.Section3FiniteSupportSharp.root_polynomial_degree_at_least_card
#check PaperReconstruction.PRINCIPAL_THEOREM
#check PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
