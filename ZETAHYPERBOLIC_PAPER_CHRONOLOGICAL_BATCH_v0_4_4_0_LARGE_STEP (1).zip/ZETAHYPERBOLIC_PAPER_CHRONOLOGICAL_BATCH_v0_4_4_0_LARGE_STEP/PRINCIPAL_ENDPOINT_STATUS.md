# Principal manuscript theorem: native Lean entrypoint

## One-input principal endpoint

`PaperReconstruction.PRINCIPAL_THEOREM (w : RawWitness) : PrincipalEndpoint`

The `PrincipalEndpoint` comprises all three unconditional families from the
actual paper pencil plus irrationality of the real part of `riemannZeta 5`.
`RawWitness` is the paper Section 4 integer normalization and eventual
quadratic evaluation bound. It is NOT declared as an axiom and no construction
of a finite, terminating witness checker is claimed.

## Separate endpoints, without conflating premises

- `UNCONDITIONAL_CORE`: exact-degree / real-root / positive zero-free disk,
  plus primitive polynomial degree and positivity, with only structural
  admissibility of `(k,m,N,K)`.
- `PRINCIPAL_THEOREM_FROM_PRIMITIVE`: same conclusion using previously
  proved canonical normalization of the raw arithmetic witness.
- `PRINCIPAL_ALL_ODD_THEOREM`: every odd zeta value irrational, conditional
  on **a witness at each odd weight** (`AllOddWitness`), not implied by zeta(5).
- `QUANTITATIVE_FROM_FULL_WITNESS`: the paper's effective exponent 25687,
  conditional on `FullMeasureWitness`. That condition contains TWO independent
  mathematical obligations: normalized quadratic decay and sharp spectral
  comparison. The latter remains unproved unconditionally. This is NOT
  `PRINCIPAL_THEOREM` from only `RawWitness`.

## What has NOT been established

This package does not certify the full 52-page manuscript, its remaining
Section 3--6 analytic or p-adic claims, the printed minor/interlacing
statements known to require correction, or a finite verifier for RawWitness.
An import/`#check` of a numbered theorem module is not counted as its proof.

## Compiler and trusted cache

- Lean: user's own native Windows 4.33.0 with offline Mathlib; no compilation
  performed when producing this package.
- `run.cmd` uses the shared verified `.olean` cache and rebuilds only
  missing/changed modules and dependency-invalidated modules, never all 51
  paper checkpoints by default.
- `run.cmd full` explicitly performs clean rebuild of the required
  **principal import closure**, not every open PDF checkpoint.
- `PAPER_PRINCIPAL_AXIOMS` uses `#print axioms` on every new theorem.
- The runner rejects `sorryAx` in compiled proof reports.

New source files: `PAPER_PRINCIPAL_ENDPOINT.lean`, `PAPER_PRINCIPAL_AXIOMS.lean`.
All other Lean source files were copied unchanged from the v0.4.2.4 branch.
