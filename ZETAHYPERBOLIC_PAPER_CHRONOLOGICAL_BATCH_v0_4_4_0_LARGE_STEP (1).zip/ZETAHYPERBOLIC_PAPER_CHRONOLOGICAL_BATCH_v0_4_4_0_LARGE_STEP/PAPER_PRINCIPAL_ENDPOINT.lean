import PAPER_UNCONDITIONAL_CHAIN
import PAPER_ODD_WEIGHT_WITNESS
import PAPER_MEASURE_BOUNDARY

/-!
# Principal theorem endpoint of the manuscript, source-faithful and axiom audited

This module makes the main implication syntactically explicit. It does NOT
assert the arithmetic witness, nor assert that all 51 PDF checkpoints are proved.

* UnconditionalCore is proved for all admissible odd-weight Hankel parameters:
  positive Gram / hyperbolic determinant, exact root-free radius,
  integer primitive-polynomial degree and nonzero center evaluation.
* PRINCIPAL_THEOREM needs only RawWitness, the positive integral multiplier
  and eventual quadratic smallness of the ACTUAL weight-five determinant
  family in Equation (4.3) of the PDF. It proves zeta(5) irrational.
* PRINCIPAL_ALL_ODD_THEOREM is a distinct, stronger implication whose
  AllOddWitness quantifies over EVERY odd-weight arithmetic family. The
  weight-five witness alone does not establish this.
* QUANTITATIVE_FROM_FULL_WITNESS has a stronger FullMeasureWitness
  containing TWO independent requirements: the decay estimate AND the
  sharp spectral bound. This bound has NOT been proved unconditionally.

Full paper theorem coverage is NOT asserted: corrected manuscript claims in
Theorem 3.4 and Corollaries 3.5/3.6, Section 3--6 analytic and p-adic claims,
and the actual finite construction of RawWitness remain open.

No `sorry`, `admit`, synthetic axioms, or unproved theorems are used here.
The user's Windows native Lean 4.33.0 is the only compilation authority.
-/

noncomputable section

namespace PaperReconstruction

/-- The unconditional mathematical core common to the odd-weight pencils.
    These are the paper's source-specific matrices, not abstract substitutes. -/
def UnconditionalCore : Prop :=
  (∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      ManuscriptChain.General.GeneralStatement p) ∧
  (∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      ∃ radius : ℝ, 0 < radius ∧
        (∀ z : ℂ,
          ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ < radius →
            ¬ ManuscriptChain.General.ComplexRoot p z) ∧
        (∃ z : ℂ, ManuscriptChain.General.ComplexRoot p z ∧
          ‖z - (ManuscriptChain.Real.zeta p.weight : ℂ)‖ = radius)) ∧
  (∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      (ManuscriptChain.GeneralIrrationality.primitivePolynomial p).natDegree = p.h ∧
      0 < ManuscriptChain.RealTransfer.evalReal
        (ManuscriptChain.GeneralIrrationality.primitivePolynomial p)
        (ManuscriptChain.Real.zeta p.weight))

/-- The source-specific structural core is unconditional. -/
theorem UNCONDITIONAL_CORE : UnconditionalCore := by
  refine ⟨?_, ?_, ?_⟩
  · exact ManuscriptChain.PAPER_ALL_ODD_SPECTRAL
  · intro p hp
    exact ManuscriptChain.PAPER_EXACT_DISK p hp
  · intro p hp
    exact ⟨ManuscriptChain.GeneralIrrationality.primitivePolynomial_natDegree p,
      ManuscriptChain.GeneralIrrationality.primitivePolynomial_eval_pos p hp⟩

/-- Principal endpoint: the universal unconditional core AND irrationality of
    zeta(5). RawWitness is defined from the actual manuscript determinant. -/
def PrincipalEndpoint : Prop :=
  UnconditionalCore ∧ Irrational (riemannZeta 5).re

/-- PRINCIPAL THEOREM: only a single explicit arithmetic witness is assumed.
    No normalized spectral bound is needed for mere irrationality. -/
theorem PRINCIPAL_THEOREM (w : RawWitness) : PrincipalEndpoint := by
  exact ⟨UNCONDITIONAL_CORE, THEOREM_4_4_IRRATIONAL_FROM_RAW w⟩

/-- Equivalent endpoint from the canonical primitive-normalization witness. -/
theorem PRINCIPAL_THEOREM_FROM_PRIMITIVE
    (w : Witness) : PrincipalEndpoint := by
  exact ⟨UNCONDITIONAL_CORE, THEOREM_4_4_IRRATIONAL_FROM_WITNESS w⟩

/-- General odd-weight endpoint. This requires an all-weights arithmetic
    input, not just the manuscript's weight-five witness. -/
theorem PRINCIPAL_ALL_ODD_THEOREM (w : AllOddWitness) :
    UnconditionalCore ∧
      (∀ k : ℕ, 0 < k →
        Irrational (riemannZeta ((2 * k + 1 : ℕ) : ℂ)).re) := by
  exact ⟨UNCONDITIONAL_CORE, ALL_ODD_IRRATIONAL_FROM_WITNESS w⟩

/-- Quantitative endpoint with the manuscript's exponent 25687. The
    required FullMeasureWitness includes BOTH decay and spectral growth;
    unlike RawWitness it is not currently one independent estimate. -/
def QuantitativeEndpoint : Prop :=
  UnconditionalCore ∧
  Irrational (riemannZeta 5).re ∧
  (∃ b₀ : ℕ, ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
    1 / (b : ℝ) ^ 25687 <
      |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)|)

/-- Published quantitative conclusion from the explicitly stronger witness. -/
theorem QUANTITATIVE_FROM_FULL_WITNESS
    (w : FullMeasureWitness) : QuantitativeEndpoint := by
  exact ⟨UNCONDITIONAL_CORE,
    THEOREM_4_4_IRRATIONAL_FROM_FULL_WITNESS w,
    THEOREM_4_4_MEASURE_FROM_FULL_WITNESS w⟩

end PaperReconstruction

#check PaperReconstruction.RawWitness
#check PaperReconstruction.AllOddWitness
#check PaperReconstruction.FullMeasureWitness
#check PaperReconstruction.PRINCIPAL_THEOREM
#check PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
#check PaperReconstruction.QUANTITATIVE_FROM_FULL_WITNESS
#print axioms PaperReconstruction.UNCONDITIONAL_CORE
#print axioms PaperReconstruction.PRINCIPAL_THEOREM
#print axioms PaperReconstruction.PRINCIPAL_THEOREM_FROM_PRIMITIVE
#print axioms PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
#print axioms PaperReconstruction.QUANTITATIVE_FROM_FULL_WITNESS
