# v0.4.2 — finite spectral sharpness

Added:
- `PaperChronology.Section3ThreeAtomSharp` (two/three atom Hankel
  determinant, Vandermonde positivity, cubic recurrence, cubic null vector)
- `PaperChronology.Section3TuranQuadratic` (degree-two Turan expression)
- `PaperChronology.Section4FiniteRootGap` (finite root separation)

Edited only the two main-chain source/checker files, manifest,
runner package label and accompanying metadata. No local Lean execution.
The sole conditional irrationality input remains the explicit `AllOddWitness`
parameter at the final arithmetic endpoint. Other PDF analytic work is open.
