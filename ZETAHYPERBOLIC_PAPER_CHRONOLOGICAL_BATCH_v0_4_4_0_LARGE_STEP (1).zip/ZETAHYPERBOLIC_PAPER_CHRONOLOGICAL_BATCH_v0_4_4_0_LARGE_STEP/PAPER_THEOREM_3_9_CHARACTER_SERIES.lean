import PAPER_THEOREM_3_9_FEKETE_POSITIVITY_AXIOMS
import PaperChronology.Section3CharacterSeries

/-! Theorem 3.9: exact finite and infinite period-block identities.
Only the geometric-block/character-numerator bridge is proved here;
the full Dirichlet L and Hurwitz pencil theorem remains open. -/

#check PaperChronology.Section3CharacterSeries.geometricBlocks_telescoping
#check PaperChronology.Section3CharacterSeries.finiteBlocks_quotient
#check PaperChronology.Section3CharacterSeries.geometricBlocks_tsum
#check PaperChronology.Section3CharacterSeries.kernelNeg3_series
#check PaperChronology.Section3CharacterSeries.kernelNeg4_series
#check PaperChronology.Section3CharacterSeries.kernel5_series
#check PaperChronology.Section3CharacterSeries.kernel8_series
#check PaperChronology.Section3CharacterSeries.kernelNeg8_series
#check PaperChronology.Section3CharacterSeries.allFivePeriodicSeries_pos
