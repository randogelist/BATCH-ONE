# v0.4.2.2 finite dual arithmetic repair

Only `PaperChronology/Section5DualArithmetic.lean` has new proof source.

- `dualConstant_seven_symmetric`: reduces the off-diagonal entry of
  the actual dual moment matrix to the already-proved rational divided
  difference symmetry, with the diagonal case handled separately.
- `coefficientEnergy_pos_at`: replaces an incompatible `Finset.sum_pos`
  invocation with `Finset.single_le_sum`, following the already-successful
  finite Gram proof in `Section3FiniteGram`.
- `coefficientEnergy_pos_of_injective`: statement and proof unchanged.

The 51 PDF checkpoints and all previously verified module source files are
unchanged. The persistent local cache remains enabled; the user's native
Lean 4.33.0 compiler is the sole compilation authority.

Theoretical correctness is not equivalent to an actual Lean compilation.
No Lean compiler was invoked in producing this package.
