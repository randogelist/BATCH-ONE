import PAPER_COROLLARY_3_6_FINITE_SUPPORT

/-! Inspect the actual finite-support theorem and the source-specific
    already-verified witness implications.  No additional assumption has
    been attached to the corrected finite-support conclusion. -/
#print axioms PaperChronology.Section3FiniteSupport.rootPolynomial_monic
#print axioms PaperChronology.Section3FiniteSupport.rootPolynomial_eval_at_atom
#print axioms PaperChronology.Section3FiniteSupport.polynomialEnergy_annihilator_zero
#print axioms PaperChronology.Section3FiniteSupport.finite_support_not_strictly_positive_definite
#print axioms PaperReconstruction.PRINCIPAL_THEOREM
#print axioms PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
