import PaperChronology.Section4FiniteSpectralBall

/-! Source-specific executable theorem checks. Full PDF claim is not asserted. -/
#check PaperChronology.Section4FiniteSpectralBall.factor_strict_pos
#check PaperChronology.Section4FiniteSpectralBall.determinant_ne_zero
#check PaperChronology.Section4FiniteSpectralBall.root_distance_lower_bound
