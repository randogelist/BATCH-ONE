import PAPER_WITNESS
import MAIN_CHAIN_IRRATIONALITY

/-!
# General odd-weight one-witness criterion -- NOT claimed by the PDF

For each fixed k>=1, the unproved normalized quadratic decay on a FIXED
admissible affine family is one arithmetic assertion. The rest of the chain,
including existence of the family and positive Gram evaluations, is proved.

This is a conditional all-odd statement, not an unconditional corollary of
weight-five data. A single weight-five witness cannot imply this interface.
-/

noncomputable section
namespace PaperReconstruction

/-- Uniform family of all odd-weight arithmetic decay conditions. This is
logically a single Prop but quantifies over every odd weight. -/
def AllOddWitness : Prop :=
  ∀ k : ℕ, 0 < k → ManuscriptChain.GeneralIrrationality.AffineFamilyDecay k

/-- The all-odd implication with exactly one visible conditional input. -/
theorem ALL_ODD_IRRATIONAL_FROM_WITNESS (h : AllOddWitness) :
    ∀ k : ℕ, 0 < k →
      Irrational (riemannZeta ((2 * k + 1 : ℕ) : ℂ)).re :=
  ManuscriptChain.GeneralIrrationality.all_odd_zeta_irrational_of_affineFamilyDecay h

end PaperReconstruction

#check PaperReconstruction.AllOddWitness
#check PaperReconstruction.ALL_ODD_IRRATIONAL_FROM_WITNESS
#print axioms PaperReconstruction.ALL_ODD_IRRATIONAL_FROM_WITNESS
