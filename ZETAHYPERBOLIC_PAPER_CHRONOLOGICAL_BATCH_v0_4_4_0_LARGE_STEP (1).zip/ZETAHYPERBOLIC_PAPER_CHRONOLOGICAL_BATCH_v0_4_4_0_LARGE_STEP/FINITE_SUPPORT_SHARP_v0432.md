# v0.4.3.2 — exact finite-support strict positivity threshold

User-verified prior checkpoint: 50 modules reused, 0 compiled, BUILD=PASS.

New: Section3FiniteSupportSharp (nine source-specific finite proofs), chronological
wrapper, axiom report. The finite atom quadratic form is strictly positive
on all nonzero polynomials of degree < h when h atom locations are distinct
and masses are positive; the verified annihilator from v0.4.3.1 makes
strictness on unrestricted polynomial space false.

This is NOT a proof of the full paper's Corollary 3.6, which needs a
source-specific root/atom bridge, nor a proof of the full PDF.

No source module from v0.4.3.1 is modified. Persistent verified cache remains
unchanged. Only the user's compiler can verify the new Lean proof candidates.

One ZIP, one root-level Windows CRLF run.cmd, no Lean compilation here.
