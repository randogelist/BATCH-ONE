import PaperChronology.Section4SpectralTransfer

/-! Source-specific executable theorem checks. Full PDF claim is not asserted. -/
#check PaperChronology.Section4SpectralTransfer.rational_measure_from_pencils
#check PaperChronology.Section4SpectralTransfer.irrational_from_pencils
