# Exact arithmetic preflight (Python Fraction, NOT Lean)

All 11 affine table integrals of Theorem 5.6(1) were independently
calculated using rational primitives. They agree with their printed
entries and their total is exactly 453803/288000.

The leading Theorem 6.1(3) rational local block is:

    [ 0    1/6 ]
    [ 1/6  -1   ]

and has determinant -1/36. This calculation does NOT prove that this
matrix is the leading p-adic pole block of the actual determinant.

The Section 5 dual off-diagonal divided-difference formula is symmetric,
and its adjacent case reduces to 1/(6(m+1)^6), by the harmonic increment.

These are mathematical validations and static source checks, not a substitute
for native Lean compilation.
