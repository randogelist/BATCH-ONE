# Necessary printed-paper corrections before proof completion

1. Proposition 3.2: The PDF continuous-s weight `(2*pi)^s/(2*Gamma(s))` does not specialize to the odd-weight `(2*(2*pi)^(s-1)/Gamma(s))`; at odd s it differs by factor pi/2. Correct the prefactor before attempting source-identification.
2. Theorem 3.4: N=1,K=5,k=m=1: gamma_2 + gamma_3 + gamma_4 + gamma_5=0. The first principal minor is constant; generalized eigenvalue 0 and degree deficiencies must be admitted. Check `PAPER_CORRECTIONS.lean`.
3. Corollary 3.5: The printed J-fraction is missing the normalization factor and terms `1 + (X-xi)*a_j` and squared `(X-xi)` off-diagonal factors; the Lanczos cyclicity required for all positive b_j also is not given. Check `PAPER_CORRECTIONS.lean`.
4. Corollary 3.6: Discrete measure with finitely many atoms has zero Hankel determinants above its rank; cannot be strictly totally positive in all sizes.
5. Theorem 5.2: Formal negative/positive Krein cones cannot discard the infinite tail outside the chosen finite modes; the imported module keeps it as explicit tail control, not a claimed theorem.
6. Various late Section 6 results depend on open local valuations, comparisons or source corrections. Inspect `THEOREM_REGISTER.md` and inherited `REPAIR_NOTES` references in source comments.

No theorem whose source statement is known false is exported as unconditional.
