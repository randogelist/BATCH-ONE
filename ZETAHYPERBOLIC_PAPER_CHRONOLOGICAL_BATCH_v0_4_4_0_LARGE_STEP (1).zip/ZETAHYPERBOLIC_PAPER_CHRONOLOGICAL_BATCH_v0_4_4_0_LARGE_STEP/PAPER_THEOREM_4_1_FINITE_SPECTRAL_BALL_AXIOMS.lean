import PAPER_THEOREM_4_1_FINITE_SPECTRAL_BALL

/-! The native runner rejects sorryAx in this certificate output. -/
#print axioms PaperChronology.Section4FiniteSpectralBall.factor_strict_pos
#print axioms PaperChronology.Section4FiniteSpectralBall.determinant_ne_zero
#print axioms PaperChronology.Section4FiniteSpectralBall.root_distance_lower_bound
