# v0.4.3.5 — Theorem 3.8 finite pole-kernel algebra

Source reference: the PDF Theorem 3.8(1), Christoffel–Darboux kernel
at the negative-square poles.

Given matrices H,V and nonzero pole coefficients gamma, define

  K = Vᵀ H V,
  B_coeff = (V diag(gamma) Vᵀ) H,
  B_poles = diag(gamma) K.

New Lean theorem candidates show:

  Kᵀ=K whenever Hᵀ=H.
  B_coeff V = V B_poles.
  det B_coeff = det B_poles = det(H) det(V)^2 product gamma.

For the paper, H will be the inverse positive-definite Gram matrix and
V the invertible negative-square Vandermonde evaluation matrix.
For invertible V, the intertwining identity gives similarity of the
coefficient-space and pole-space operators, which is the finite algebra
behind their common eigenvalues. A separate Lean module must still
connect the concrete inverse Gram matrix and verify the actual
orthogonal-polynomial Christoffel-Darboux representation.

Proof status: new theorem candidates, not compiled here.
Previously verified 59 source modules are untouched. New modules appended
without editing the runner or the cache. Run on native Windows Lean 4.33.0.
PDF Theorem 3.8 is not yet fully formalized (analytic derivative identity
and orthogonal-basis identification remain open).
