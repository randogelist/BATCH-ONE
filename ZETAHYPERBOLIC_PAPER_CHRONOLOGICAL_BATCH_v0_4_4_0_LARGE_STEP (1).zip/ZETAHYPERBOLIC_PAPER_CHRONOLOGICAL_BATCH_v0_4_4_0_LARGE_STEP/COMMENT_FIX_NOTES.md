# v0.3.5.1 -- Lean nested-comment repair

The original `PaperChronology/Section3Signature.lean` had a doc comment
containing the text `+1/-1`. Lean parses the `/` followed by `-` as the
opening of a nested block comment `/-`, so the closing `-/` on the next
line only closes the nested comment and the surrounding doc comment
remains unterminated at end of file.

Change: only that documentation text, now `alternating positive and negative
unit signs`. No Lean theorem statements, proof terms, or imports changed.

Previously verified source files remain identical and eligible for reuse.
Run `run.cmd` without the `full` argument. No local compilation was performed
while preparing this ZIP. The `BUILD=PASS` line is exclusively provided by
your native Windows Lean compiler after successfully checking all targets.
