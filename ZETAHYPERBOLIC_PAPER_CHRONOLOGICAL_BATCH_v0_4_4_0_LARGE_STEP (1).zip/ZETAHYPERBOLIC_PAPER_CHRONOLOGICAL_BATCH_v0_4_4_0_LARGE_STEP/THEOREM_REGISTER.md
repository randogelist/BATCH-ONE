# Theorem register: source-exact open/proved boundaries

| Number | Kind | Status | Verified scope / outstanding |
|---|---|---|---|
| 2.1 | Definition | CONSTRUCTED | Constructions of rational moments, the pencil and determinant. |
| 2.2 | Lemma | REPRESENTATION_PROVED | Pullback proved for arbitrary finite canonical polynomial/simple-square-pole decompositions using exact generator formulas. RatFunc interpretation/uniqueness bridge remains. |
| 2.3 | Lemma | REPRESENTATION_PROVED | Reflection proved for all finite Q-linear combinations of integer poles and monomials; difference for every allowed integer pole. Independent RatFunc semantic bridge pending. |
| 2.4 | Theorem | PROVED | The basis-matrix determinant scaling and primitive normalization are proved. |
| 2.5 | Theorem | PROVED | Matrix derivative factorization and pole basis identities are proved. |
| 3.1 | Theorem | PROVED | The general odd-weight Gram realization and spectral root/disk endpoint are proved. |
| 3.2 | Proposition | CORRECTION_AND_SPECTRAL_CORE_PROVED | Odd normalization mismatch identity; all-real-exponent finite Laplace sums strictly positive; generic real-s pencil exact degree and real-root theorem from Gram positivity and nonsingular slope. Full real-s integral/moment and specialization bridges remain open. |
| 3.3 | Theorem | PARTIAL_FINITE_DIAGONAL_ENERGY | Closed pole-residue signed-energy positivity plus official derivative-defined gamma sign bridge added; Sylvester inertia transfer and continuum strict total positivity not yet proved. |
| 3.4 | Theorem | CORRECTION_REQUIRED | Printed interlacing fails when a leading pencil has zero derivative eigenvalue. |
| 3.5 | Corollary | CORRECTION_REQUIRED | Printed continued fraction is incorrectly scaled; cyclicity not established. |
| 3.6 | Corollary | CORRECTION_REQUIRED | A finite-support moment sequence cannot be strictly positive Hankel of all orders. |
| 3.7 | Theorem | Turanian non-negativity and Newton log-concavity | PARTIAL (m=1, all finite real-split degrees) | `PaperChronology.Section3TuranProduct` | General product identity and universal first-Turan positivity; derivatives m>=2 and Newton inequalities remain open |
| 3.8 | Theorem | OPEN | Requires Christoffel-Darboux identification and differentiability under the integral. |
| 3.9 | Theorem | OPEN | General spectral argument known; specific Hurwitz/Dirichlet analytic realization not proved. |
| 3.10 | Remark | REMARK_REVIEW | Favard/Lanczos non-classicality argument needs revision before formal statement. |
| 4.1 | Theorem | PARTIAL | General transfer with explicit index and comparison inputs is proved; asymptotic criterion not fully assembled. |
| 4.2 | Proposition | OPEN | Resultant-height argument and all quantitative limits not formalized. |
| 4.3 | Proposition | OPEN | P-adic polynomial local constancy not yet formalized. |
| 4.4 | Theorem | PARTIAL | Irrationality follows from one raw arithmetic witness; 11.411 spectral bound and 25687 measure open. |
| 4.5 | Theorem | OPEN | Mixed-weight integrality, positive cone, and quantitative estimates remain open. |
| 4.6 | Theorem | OPEN | Asymptotic Euler-Maclaurin/Jensen input and height bounds remain open. |
| 4.7 | Theorem | OPEN | Depends on unformalized 4.4 and 4.6 quantitative bounds. |
| 4.8 | Proposition | OPEN | Depends on 4.4 measure and precise height control. |
| 4.9 | Remark | REMARK_REVIEW | Records conjectural variational growth; not a theorem. |
| 4.10 | Remark | REMARK_REVIEW | Limit existence and claimed first-order transition are not established. |
| 4.11 | Conjecture | CONJECTURE | Conjecture remains conjectural; deliberately not imported as axiom. |
| 5.1 | Theorem | PARTIAL_FINITE_MOMENT_ARITHMETIC | Off-diagonal divided-difference symmetry and finite Gram-energy nonnegativity; full Beukers double-integral identification remains open. |
| 5.2 | Theorem | PARTIAL | Finite sign/tail comparison proved conditionally; infinite-tail cone construction not proved. |
| 5.3 | Proposition | OPEN | Analytic integral and full beta pencil pending. |
| 5.4 | Theorem | GENERATOR_PROVED | Exact rational cancellation for every positive simple-pole pair, re-exported by the completed Section 2 finite-span module. |
| 5.5 | Remark | REMARK_REVIEW | States domain restriction; recorded after 5.4. |
| 5.6 | Theorem | PARTIAL_TABLE_ARITHMETIC_EXACT | All 11 affine Table 1 interval primitives and exact sum 453803/288000; equality to floor/min prime-sum integrand not proved, other parts remain open. |
| 5.7 | Theorem | OPEN | Hermite interpolation and q-adic determinant valuation pending. |
| 6.1 | Theorem | PARTIAL_EXACT_LOCAL_BLOCK | Exact nonzero determinant -1/36 and rational kernel triviality of leading 2x2 block; full p-adic valuation identification open. |
| 6.2 | Theorem | PARTIAL_ADJACENT_RATIONAL_MOMENT | The rational adjacent divided difference 1/(6(m+1)^6) is proved; required double integral and denominator clearance remain open. |
| 6.3 | Theorem | PARTIAL | Finite certificates are available under tail bounds; no full claimed positive-cone existence. |
| 6.4 | Theorem | PARTIAL | Only replacement moment consistency lemmas; printed beta analytic realization unresolved. |
| 6.5 | Theorem | OPEN | Prime-index local matrix reduction and arithmetic degree proof pending. |
| 6.6 | Theorem | OPEN | General differential-shift plus full analytic comparison not proved. |
| 6.7 | Theorem | OPEN | General two-variable kernel and positive/negative cone existence remain open. |
| 6.8 | Corollary | OPEN | Needs independently formalized mixed-weight Theorem 4.5. |
| 6.9 | Theorem | PARTIAL | Finite corrected Hermite algebra, not full q-adic nonvanishing. |
| 6.10 | Theorem | PARTIAL | Finite determinant identity proved, asymptotic variational identity not. |
| 6.11 | Theorem | OPEN | General prime valuation asymptotic and 2-adic obstruction not formalized. |
| 6.12 | Theorem | OPEN | Targeted pole sign-flip construction and valuation argument pending. |
| 6.13 | Theorem | OPEN | Differential identity and analytic shift closure pending. |
| 6.14 | Theorem | OPEN | Moment and spectral analytic bridges missing. |
| 6.15 | Theorem | OPEN | Exact algebraic and analytic statements not formalized. |
| 6.16 | Theorem | PARTIAL | Bounded-ratio comparison only under stated analytic inputs. |
| 6.17 | Theorem | PARTIAL | Corrected parity/window finite facts, not complete stated theorem. |
| 6.18 | Theorem | PARTIAL | Finite quotient/degree facts proved; global height and irrationality remain open. |


## v0.4.3.7 — Theorem 3.9 periodic character series (candidate)

The five finite Fekete block quotient identities are extended to exact convergent q-period geometric-block sums. Analytic Dirichlet character grouping and full Hankel hyperbolicity remain open. User native compiler verification pending.
