# v0.3.4.1 Windows CMD launcher repair

The v0.3.4 `run.cmd` was mistakenly delivered with Unix LF line endings.
The native Windows CMD interpreter reported:
`Das Sprungziel - snapshot wurde nicht gefunden.`

This patch restores the exact CRLF line format and label-handling script of
v0.3.3 (previously successful on the user machine) with only the package tag
changed. The 121 module compile manifest and all `.lean` source bytes are
identical to v0.3.4. No local Lean compilation was performed.

Run `run.cmd` (not `run.cmd full`) to reuse your existing verified global cache
at `%USERPROFILE%\lean-native\zetahyperbolic-paper-verified-lean433`.
The earlier v0.3.4 failure may have left the first new `.olean` in the cache
without its source snapshot; this runner safely recompiles that incomplete
module, followed by any changed dependents. Previously verified unchanged
modules are reused.

If it fails again, send `_logs\PaperChronology.Section3Continuous.log` and
`_logs\BUILD_SUMMARY.txt`. Any subsequent Lean errors are separate from this
batch-label failure.
