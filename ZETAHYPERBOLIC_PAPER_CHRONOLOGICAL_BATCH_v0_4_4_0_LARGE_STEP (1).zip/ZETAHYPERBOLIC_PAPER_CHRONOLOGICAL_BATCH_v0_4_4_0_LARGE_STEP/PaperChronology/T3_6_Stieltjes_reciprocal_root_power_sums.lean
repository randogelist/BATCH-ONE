import PaperChronology.T3_5_Stieltjes_J_fraction_from_interlacing_roots
import PAPER_CORRECTIONS

/-!
# Corollary 3.6 — Stieltjes reciprocal-root power sums

SOURCE: Zetahyperbolic PDF; Section 3.
STATUS: CORRECTION_REQUIRED
SOURCE MODULE: PAPER_CORRECTIONS
SCOPE: A finite-support moment sequence cannot be strictly positive Hankel of all orders.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check PaperCorrections.single_atom_hankel_determinant_zero
