import PaperChronology.Section3FeketeCharacter

/-!
# Theorem 3.9: character-period geometric blocks

Source-faithful next step after the five Fekete numerator positivity proofs.
The algebraic block identity is valid for every period q.  For 0 < z < 1,
all five periodic character-block series converge to the five positive
Fekete quotients already defined in Section3FeketeCharacter.

This proves the geometric-block generating-function bridge; it does NOT
identify the resulting kernels with full analytic Dirichlet L moments or
establish the Hurwitz/Dirichlet Hankel hyperbolicity theorem.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3CharacterSeries

open PaperChronology.Section3FeketeCharacter

/-- The first `blocks` complete q-period geometric blocks. -/
def geometricBlocks (q blocks : ℕ) (z : ℝ) : ℝ :=
  ∑ j ∈ Finset.range blocks, z ^ (q * j)

/-- Exact finite block recurrence, including the empty sum. -/
theorem geometricBlocks_succ (q blocks : ℕ) (z : ℝ) :
    geometricBlocks q (blocks + 1) z =
      geometricBlocks q blocks z + z ^ (q * blocks) := by
  simp only [geometricBlocks, Finset.sum_range_succ]

/-- Finite geometric-series identity without convergence assumptions. -/
theorem geometricBlocks_telescoping (q blocks : ℕ) (z : ℝ) :
    (1 - z ^ q) * geometricBlocks q blocks z =
      1 - z ^ (q * blocks) := by
  induction blocks with
  | zero =>
      simp [geometricBlocks]
  | succ blocks ih =>
      calc
        (1 - z ^ q) * geometricBlocks q (blocks + 1) z =
            (1 - z ^ q) * (geometricBlocks q blocks z + z ^ (q * blocks)) := by
              rw [geometricBlocks_succ]
        _ = 1 - z ^ (q * blocks) + (1 - z ^ q) * z ^ (q * blocks) := by
              rw [mul_add, ih]
        _ = 1 - z ^ (q * (blocks + 1)) := by
              rw [Nat.mul_succ, pow_add]
              ring

/-- Every nonempty positive-base block sum is strictly positive. -/
theorem geometricBlocks_pos (q blocks : ℕ) (z : ℝ)
    (hz : 0 < z) (hb : 0 < blocks) :
    0 < geometricBlocks q blocks z := by
  unfold geometricBlocks
  apply Finset.sum_pos
  · intro j _
    exact pow_pos hz _
  · exact ⟨0, Finset.mem_range.mpr hb⟩

/-- A q-block Fekete numerator admits an exact finite rational quotient. -/
theorem finiteBlocks_quotient (q blocks : ℕ) (z f : ℝ)
    (hd : 1 - z ^ q ≠ 0) :
    f * geometricBlocks q blocks z =
      (f / (1 - z ^ q)) * (1 - z ^ (q * blocks)) := by
  have htel := geometricBlocks_telescoping q blocks z
  calc
    f * geometricBlocks q blocks z =
        (f * (1 - z ^ (q * blocks))) / (1 - z ^ q) := by
      apply (eq_div_iff hd).2
      calc
        (f * geometricBlocks q blocks z) * (1 - z ^ q) =
            f * ((1 - z ^ q) * geometricBlocks q blocks z) := by ring
        _ = f * (1 - z ^ (q * blocks)) := by rw [htel]
    _ = (f / (1 - z ^ q)) * (1 - z ^ (q * blocks)) := by ring

/-- A geometric q-block series converges in norm when the q-th power
has norm below one.  This is the analytic input needed for period blocks. -/
theorem geometricBlocks_tsum (q : ℕ) (z : ℝ)
    (hz : ‖z ^ q‖ < 1) :
    (∑' blocks : ℕ, z ^ (q * blocks)) = 1 / (1 - z ^ q) := by
  have hp (blocks : ℕ) : z ^ (q * blocks) = (z ^ q) ^ blocks := by
    rw [pow_mul]
  simp_rw [hp]
  calc
    (∑' blocks : ℕ, (z ^ q) ^ blocks) = (1 - z ^ q)⁻¹ :=
      tsum_geometric_of_norm_lt_one hz
    _ = 1 / (1 - z ^ q) := by rw [one_div]

/-- Every periodic block sum equals its rational generating function. -/
theorem weightedBlocks_tsum (q : ℕ) (z f : ℝ)
    (hz : ‖z ^ q‖ < 1) :
    (∑' blocks : ℕ, f * z ^ (q * blocks)) = f / (1 - z ^ q) := by
  rw [tsum_mul_left, geometricBlocks_tsum q z hz]
  ring

/-- Positivity of `1-z^q` implies the geometric-series norm bound
whenever `z` itself is positive. -/
theorem norm_pow_lt_one (q : ℕ) (z : ℝ)
    (hz : 0 < z) (hsub : 0 < 1 - z ^ q) :
    ‖z ^ q‖ < 1 := by
  rw [Real.norm_eq_abs, abs_of_pos (pow_pos hz q)]
  linarith

/-- Character -3: complete periodic-block generating function. -/
theorem kernelNeg3_series (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    (∑' blocks : ℕ, fNeg3 z * z ^ (3 * blocks)) = kernelNeg3 z := by
  unfold kernelNeg3
  exact weightedBlocks_tsum 3 z (fNeg3 z)
    (norm_pow_lt_one 3 z hz (oneSubPowThree_pos z hz hlt))

/-- Character -4: complete periodic-block generating function. -/
theorem kernelNeg4_series (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    (∑' blocks : ℕ, fNeg4 z * z ^ (4 * blocks)) = kernelNeg4 z := by
  unfold kernelNeg4
  exact weightedBlocks_tsum 4 z (fNeg4 z)
    (norm_pow_lt_one 4 z hz (oneSubPowFour_pos z hz hlt))

/-- Character 5: complete periodic-block generating function. -/
theorem kernel5_series (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    (∑' blocks : ℕ, f5 z * z ^ (5 * blocks)) = kernel5 z := by
  unfold kernel5
  exact weightedBlocks_tsum 5 z (f5 z)
    (norm_pow_lt_one 5 z hz (oneSubPowFive_pos z hz hlt))

/-- Character 8: complete periodic-block generating function. -/
theorem kernel8_series (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    (∑' blocks : ℕ, f8 z * z ^ (8 * blocks)) = kernel8 z := by
  unfold kernel8
  exact weightedBlocks_tsum 8 z (f8 z)
    (norm_pow_lt_one 8 z hz (oneSubPowEight_pos z hz hlt))

/-- Character -8: complete periodic-block generating function. -/
theorem kernelNeg8_series (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    (∑' blocks : ℕ, fNeg8 z * z ^ (8 * blocks)) = kernelNeg8 z := by
  unfold kernelNeg8
  exact weightedBlocks_tsum 8 z (fNeg8 z)
    (norm_pow_lt_one 8 z hz (oneSubPowEight_pos z hz hlt))

/-- All five series are strictly positive on the open interval. -/
theorem allFivePeriodicSeries_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < (∑' blocks : ℕ, fNeg3 z * z ^ (3 * blocks)) ∧
    0 < (∑' blocks : ℕ, fNeg4 z * z ^ (4 * blocks)) ∧
    0 < (∑' blocks : ℕ, f5 z * z ^ (5 * blocks)) ∧
    0 < (∑' blocks : ℕ, f8 z * z ^ (8 * blocks)) ∧
    0 < (∑' blocks : ℕ, fNeg8 z * z ^ (8 * blocks)) := by
  rw [kernelNeg3_series z hz hlt, kernelNeg4_series z hz hlt,
    kernel5_series z hz hlt, kernel8_series z hz hlt,
    kernelNeg8_series z hz hlt]
  exact allFiveKernels_pos z hz hlt

end PaperChronology.Section3CharacterSeries
