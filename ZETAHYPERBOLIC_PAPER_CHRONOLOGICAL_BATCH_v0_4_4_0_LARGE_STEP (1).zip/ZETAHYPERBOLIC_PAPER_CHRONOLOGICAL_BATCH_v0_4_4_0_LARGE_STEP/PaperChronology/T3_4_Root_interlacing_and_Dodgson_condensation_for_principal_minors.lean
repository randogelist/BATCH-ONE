import PaperChronology.T3_3_Total_positivity_leading_sign_and_universal_signature
import PAPER_CORRECTIONS

/-!
# Theorem 3.4 — Root interlacing and Dodgson condensation for principal minors

SOURCE: Zetahyperbolic PDF; Section 3.
STATUS: CORRECTION_REQUIRED
SOURCE MODULE: PAPER_CORRECTIONS
SCOPE: Printed interlacing fails when a leading pencil has zero derivative eigenvalue.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check PaperCorrections.first_principal_coefficient_zero
