import PaperChronology.Section5PrimeSumCertificate
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

/-!
# Theorem 6.1(3): exact rational leading local block

The 2x2 leading q-adic pole matrix of the manuscript has rational
entries 0, 1/6, 1/6, -1.  Its determinant is -1/36, so it is
nondegenerate over Q.  That is the arithmetic core of the p-adic
obstruction, NOT a proof of the claimed p-adic valuation law.
-/

noncomputable section
namespace PaperChronology.Section6PoleBlock

/-- The leading coefficient of the 2x2 block in equation (6.1). -/
def localBlock : Matrix (Fin 2) (Fin 2) ℚ :=
  fun i j =>
    if i.val = 0 then
      if j.val = 0 then 0 else 1/6
    else
      if j.val = 0 then 1/6 else -1

/-- Exact arithmetic determinant, independent of any p-adic approximations. -/
theorem localBlock_det : localBlock.det = -(1/36 : ℚ) := by
  norm_num [localBlock, Matrix.det_fin_two]

/-- The rational block is invertible. -/
theorem localBlock_det_ne_zero : localBlock.det ≠ 0 := by
  rw [localBlock_det]
  norm_num

/-- A zero vector is the ONLY rational vector annihilated by the local
leading pole block; the corresponding reduction over F_p requires p>=11. -/
theorem localBlock_kernel_trivial (x y : ℚ)
    (h0 : localBlock 0 0 * x + localBlock 0 1 * y = 0)
    (h1 : localBlock 1 0 * x + localBlock 1 1 * y = 0) :
    x = 0 ∧ y = 0 := by
  change (0 : ℚ) * x + (1/6 : ℚ) * y = 0 at h0
  change (1/6 : ℚ) * x + (-1 : ℚ) * y = 0 at h1
  constructor <;> linarith

end PaperChronology.Section6PoleBlock

#print axioms PaperChronology.Section6PoleBlock.localBlock_det
#print axioms PaperChronology.Section6PoleBlock.localBlock_det_ne_zero
#print axioms PaperChronology.Section6PoleBlock.localBlock_kernel_trivial
