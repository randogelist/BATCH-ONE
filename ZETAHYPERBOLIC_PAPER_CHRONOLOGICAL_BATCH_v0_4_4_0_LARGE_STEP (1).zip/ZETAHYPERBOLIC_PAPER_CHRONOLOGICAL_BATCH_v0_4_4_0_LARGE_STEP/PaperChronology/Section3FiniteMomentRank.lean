import PaperChronology.Section3FiniteGram

/-!
# Corollary 3.6 (corrected): finite-support moment Hankel forms

The source's statement of strict Hankel positivity for ALL orders cannot hold
for a finite spectral measure. This file gives a mathematically unconditional
and finite-dimensional correction:

1. All finite discrete moment quadratic forms with nonnegative weights are
   positive semidefinite.
2. A two-point support has an explicitly nonzero degree-two annihilator,
   independent of positive weights.
3. The 3 by 3 moment-Hankel determinant for two atoms vanishes identically.

These exact algebraic statements do not assert existence of a continuous
positive zeta measure, real-rootedness of the source determinant, or an
unproved spectral-to-arithmetic transfer.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3FiniteMomentRank

/-- Quadratic energy of a polynomial evaluated on a finite atomic measure. -/
def atomicPolynomialEnergy {h d : ℕ} (w x : Fin h → ℚ)
    (c : Fin d → ℚ) : ℚ :=
  PaperChronology.Section3FiniteGram.energy w
    (fun a => ∑ i : Fin d, c i * (x a) ^ i.val)

/-- Positivity of the finite moment quadratic form holds at EVERY order. -/
theorem atomicPolynomialEnergy_nonneg {h d : ℕ}
    (w x : Fin h → ℚ) (c : Fin d → ℚ)
    (hw : ∀ a, 0 ≤ w a) :
    0 ≤ atomicPolynomialEnergy w x c := by
  exact PaperChronology.Section3FiniteGram.energy_nonneg w _ hw

/-- Positive finite mass plus an observable nonzero polynomial value
implies strict positivity for this one coefficient vector. -/
theorem atomicPolynomialEnergy_pos_at {h d : ℕ}
    (w x : Fin h → ℚ) (c : Fin d → ℚ)
    (hw : ∀ a, 0 < w a) (a : Fin h)
    (ha : (∑ i : Fin d, c i * (x a) ^ i.val) ≠ 0) :
    0 < atomicPolynomialEnergy w x c := by
  exact PaperChronology.Section3FiniteGram.energy_pos_at w _ hw a ha

/-- The moments of a measure with two (possibly coincident) atoms. -/
def twoAtomMoment (w₁ w₂ x y : ℚ) (n : ℕ) : ℚ :=
  w₁ * x ^ n + w₂ * y ^ n

/-- The monic quadratic with roots x,y vanishes at both support nodes. -/
theorem two_atom_annihilator_at_x (x y : ℚ) :
    x ^ 2 - (x + y) * x + x * y = 0 := by ring

theorem two_atom_annihilator_at_y (x y : ℚ) :
    y ^ 2 - (x + y) * y + x * y = 0 := by ring

/-- A nonzero polynomial lies in the null space of every two-atom
quadratic moment form of degree at least two. Its leading coefficient is 1. -/
def twoAtomQuadraticEnergy (w₁ w₂ x y c₀ c₁ c₂ : ℚ) : ℚ :=
  w₁ * (c₀ + c₁ * x + c₂ * x ^ 2) ^ 2 +
  w₂ * (c₀ + c₁ * y + c₂ * y ^ 2) ^ 2

/-- Nonnegativity is unconditional for nonnegative masses. -/
theorem two_atom_quadratic_nonneg (w₁ w₂ x y c₀ c₁ c₂ : ℚ)
    (hw₁ : 0 ≤ w₁) (hw₂ : 0 ≤ w₂) :
    0 ≤ twoAtomQuadraticEnergy w₁ w₂ x y c₀ c₁ c₂ := by
  unfold twoAtomQuadraticEnergy
  exact add_nonneg
    (mul_nonneg hw₁ (sq_nonneg _))
    (mul_nonneg hw₂ (sq_nonneg _))

/-- The explicit coefficient vector (xy, -(x+y), 1) is nonzero and
annihilates both points, so positivity is never strict at order 3. -/
theorem two_atom_quadratic_kernel (w₁ w₂ x y : ℚ) :
    twoAtomQuadraticEnergy w₁ w₂ x y (x * y) (-(x + y)) 1 = 0 := by
  unfold twoAtomQuadraticEnergy
  ring

/-- Equivalently the shifted two-atom moments have the universal
second-order recurrence from the annihilating polynomial. -/
theorem two_atom_moment_recurrence (w₁ w₂ x y : ℚ) (n : ℕ) :
    twoAtomMoment w₁ w₂ x y (n + 2) -
      (x + y) * twoAtomMoment w₁ w₂ x y (n + 1) +
        x * y * twoAtomMoment w₁ w₂ x y n = 0 := by
  simp only [twoAtomMoment, pow_add, pow_one, pow_two]
  ring

/-- The 3 by 3 Hankel determinant vanishes for any two-atom moment
sequence, independent of the two masses. This is a concrete corrected
finite-rank endpoint for the printed Corollary 3.6. -/
theorem two_atom_hankel_three_det_zero (w₁ w₂ x y : ℚ) :
    twoAtomMoment w₁ w₂ x y 0 *
        (twoAtomMoment w₁ w₂ x y 2 * twoAtomMoment w₁ w₂ x y 4 -
          (twoAtomMoment w₁ w₂ x y 3) ^ 2) -
      twoAtomMoment w₁ w₂ x y 1 *
        (twoAtomMoment w₁ w₂ x y 1 * twoAtomMoment w₁ w₂ x y 4 -
          twoAtomMoment w₁ w₂ x y 2 * twoAtomMoment w₁ w₂ x y 3) +
      twoAtomMoment w₁ w₂ x y 2 *
        (twoAtomMoment w₁ w₂ x y 1 * twoAtomMoment w₁ w₂ x y 3 -
          (twoAtomMoment w₁ w₂ x y 2) ^ 2) = 0 := by
  simp only [twoAtomMoment, pow_zero, pow_one]
  ring

end PaperChronology.Section3FiniteMomentRank

#print axioms PaperChronology.Section3FiniteMomentRank.atomicPolynomialEnergy_nonneg
#print axioms PaperChronology.Section3FiniteMomentRank.atomicPolynomialEnergy_pos_at
#print axioms PaperChronology.Section3FiniteMomentRank.two_atom_quadratic_nonneg
#print axioms PaperChronology.Section3FiniteMomentRank.two_atom_quadratic_kernel
#print axioms PaperChronology.Section3FiniteMomentRank.two_atom_moment_recurrence
#print axioms PaperChronology.Section3FiniteMomentRank.two_atom_hankel_three_det_zero
