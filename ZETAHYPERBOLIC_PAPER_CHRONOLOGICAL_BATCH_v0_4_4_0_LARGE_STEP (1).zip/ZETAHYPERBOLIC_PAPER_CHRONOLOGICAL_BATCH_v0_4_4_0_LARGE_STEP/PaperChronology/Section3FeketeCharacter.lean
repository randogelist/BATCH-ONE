import Zetahyperbolic.CoreLinearAlgebra

/-!
# Theorem 3.9 — finite Fekete-character positivity

This file isolates the elementary Fekete polynomial factorizations used in
Theorem 3.9(2) of the manuscript. It proves the five numerators are strictly
positive on the open unit interval, as are the corresponding geometric-block
quotients. No unproved zeta/L-value identity, analytic continuation, or
irrationality claim is used.

The infinite character generating series and the Hankel Gram realization are
separate, not yet established in this module.
-/

noncomputable section
namespace PaperChronology.Section3FeketeCharacter

/-- The five finite Fekete numerators for real primitive characters
of conductors 3, 4, 5, and 8. The two last entries are the two
real primitive characters of conductor 8. -/
def fNeg3 (z : ℝ) : ℝ := z - z ^ 2
def fNeg4 (z : ℝ) : ℝ := z - z ^ 3
def f5 (z : ℝ) : ℝ := z - z ^ 2 - z ^ 3 + z ^ 4
def f8 (z : ℝ) : ℝ := z - z ^ 3 - z ^ 5 + z ^ 7
def fNeg8 (z : ℝ) : ℝ := z + z ^ 3 - z ^ 5 - z ^ 7

/-- Each factorization is an exact polynomial identity, with no sign premise. -/
theorem fNeg3_factor (z : ℝ) : fNeg3 z = z * (1 - z) := by
  unfold fNeg3
  ring

theorem fNeg4_factor (z : ℝ) : fNeg4 z = z * (1 - z ^ 2) := by
  unfold fNeg4
  ring

theorem f5_factor (z : ℝ) :
    f5 z = z * (1 - z) ^ 2 * (1 + z) := by
  unfold f5
  ring

theorem f8_factor (z : ℝ) :
    f8 z = z * (1 - z ^ 2) * (1 - z ^ 4) := by
  unfold f8
  ring

theorem fNeg8_factor (z : ℝ) :
    fNeg8 z = z * (1 + z ^ 2) * (1 - z ^ 4) := by
  unfold fNeg8
  ring

/- The denominator inequalities use only finite difference-of-powers
identities. In particular they do not depend on real-power library lemmas. -/
theorem oneSubPowTwo_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < 1 - z ^ 2 := by
  have ha : 0 < 1 - z := sub_pos.mpr hlt
  have hb : 0 < 1 + z := by positivity
  calc
    0 < (1 - z) * (1 + z) := mul_pos ha hb
    _ = 1 - z ^ 2 := by ring

theorem oneSubPowThree_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < 1 - z ^ 3 := by
  have ha : 0 < 1 - z := sub_pos.mpr hlt
  have hb : 0 < 1 + z + z ^ 2 := by positivity
  calc
    0 < (1 - z) * (1 + z + z ^ 2) := mul_pos ha hb
    _ = 1 - z ^ 3 := by ring

theorem oneSubPowFour_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < 1 - z ^ 4 := by
  have ha : 0 < 1 - z ^ 2 := oneSubPowTwo_pos z hz hlt
  have hb : 0 < 1 + z ^ 2 := by positivity
  calc
    0 < (1 - z ^ 2) * (1 + z ^ 2) := mul_pos ha hb
    _ = 1 - z ^ 4 := by ring

theorem oneSubPowFive_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < 1 - z ^ 5 := by
  have ha : 0 < 1 - z := sub_pos.mpr hlt
  have hb : 0 < 1 + z + z ^ 2 + z ^ 3 + z ^ 4 := by positivity
  calc
    0 < (1 - z) * (1 + z + z ^ 2 + z ^ 3 + z ^ 4) := mul_pos ha hb
    _ = 1 - z ^ 5 := by ring

theorem oneSubPowEight_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < 1 - z ^ 8 := by
  have ha : 0 < 1 - z ^ 4 := oneSubPowFour_pos z hz hlt
  have hb : 0 < 1 + z ^ 4 := by positivity
  calc
    0 < (1 - z ^ 4) * (1 + z ^ 4) := mul_pos ha hb
    _ = 1 - z ^ 8 := by ring

/-- All five character numerators are strictly positive for 0 < z < 1. -/
theorem fNeg3_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < fNeg3 z := by
  rw [fNeg3_factor]
  exact mul_pos hz (sub_pos.mpr hlt)

theorem fNeg4_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < fNeg4 z := by
  rw [fNeg4_factor]
  exact mul_pos hz (oneSubPowTwo_pos z hz hlt)

theorem f5_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < f5 z := by
  rw [f5_factor]
  have ha : 0 < 1 - z := sub_pos.mpr hlt
  have hb : 0 < 1 + z := by positivity
  exact mul_pos (mul_pos hz (pow_pos ha 2)) hb

theorem f8_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < f8 z := by
  rw [f8_factor]
  exact mul_pos
    (mul_pos hz (oneSubPowTwo_pos z hz hlt))
    (oneSubPowFour_pos z hz hlt)

theorem fNeg8_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < fNeg8 z := by
  rw [fNeg8_factor]
  have ha : 0 < 1 + z ^ 2 := by positivity
  exact mul_pos (mul_pos hz ha) (oneSubPowFour_pos z hz hlt)

/-- Geometric-block quotients, to be identified analytically with the
respective Dirichlet-character generating kernels. -/
def kernelNeg3 (z : ℝ) : ℝ := fNeg3 z / (1 - z ^ 3)
def kernelNeg4 (z : ℝ) : ℝ := fNeg4 z / (1 - z ^ 4)
def kernel5 (z : ℝ) : ℝ := f5 z / (1 - z ^ 5)
def kernel8 (z : ℝ) : ℝ := f8 z / (1 - z ^ 8)
def kernelNeg8 (z : ℝ) : ℝ := fNeg8 z / (1 - z ^ 8)

theorem kernelNeg3_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < kernelNeg3 z := by
  unfold kernelNeg3
  exact div_pos (fNeg3_pos z hz hlt) (oneSubPowThree_pos z hz hlt)

theorem kernelNeg4_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < kernelNeg4 z := by
  unfold kernelNeg4
  exact div_pos (fNeg4_pos z hz hlt) (oneSubPowFour_pos z hz hlt)

theorem kernel5_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < kernel5 z := by
  unfold kernel5
  exact div_pos (f5_pos z hz hlt) (oneSubPowFive_pos z hz hlt)

theorem kernel8_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < kernel8 z := by
  unfold kernel8
  exact div_pos (f8_pos z hz hlt) (oneSubPowEight_pos z hz hlt)

theorem kernelNeg8_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < kernelNeg8 z := by
  unfold kernelNeg8
  exact div_pos (fNeg8_pos z hz hlt) (oneSubPowEight_pos z hz hlt)

/-- Complete simultaneous finite-character positivity certificate. -/
theorem allFiveKernels_pos (z : ℝ) (hz : 0 < z) (hlt : z < 1) :
    0 < kernelNeg3 z ∧ 0 < kernelNeg4 z ∧ 0 < kernel5 z ∧
    0 < kernel8 z ∧ 0 < kernelNeg8 z := by
  exact ⟨kernelNeg3_pos z hz hlt,
    kernelNeg4_pos z hz hlt,
    kernel5_pos z hz hlt,
    kernel8_pos z hz hlt,
    kernelNeg8_pos z hz hlt⟩

end PaperChronology.Section3FeketeCharacter
