import PaperChronology.T2_5_Lagrange_pole_diagonalization
import MAIN_CHAIN_ASSEMBLED

/-!
# Theorem 3.1 — Universal hyperbolicity and zero-free disk

SOURCE: Zetahyperbolic PDF; Section 3.
STATUS: PROVED
SOURCE MODULE: MAIN_CHAIN_ASSEMBLED
SCOPE: The general odd-weight Gram realization and spectral root/disk endpoint are proved.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
#check ManuscriptChain.EXACT_ZERO_FREE_DISK
