import Definition_2_1_Order_s_Rational_Moment_Functional

/-!
# Definition 2.1 — Order-s rational moment functional

SOURCE: Zetahyperbolic PDF; Section 2.
STATUS: CONSTRUCTED
SOURCE MODULE: Definition_2_1_Order_s_Rational_Moment_Functional
SCOPE: Constructions of rational moments, the pencil and determinant.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check ManuscriptChain.Real.pencil
#check ManuscriptChain.Real.delta
#check ManuscriptChain.Real.zeta_eq_riemannZeta_re
