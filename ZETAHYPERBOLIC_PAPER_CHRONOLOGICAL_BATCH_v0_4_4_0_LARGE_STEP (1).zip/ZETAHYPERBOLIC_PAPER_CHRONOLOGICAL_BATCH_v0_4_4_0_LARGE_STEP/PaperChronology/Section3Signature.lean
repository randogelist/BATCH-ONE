import PaperChronology.Section3Continuous

/-!
# Theorem 3.3: finite alternating-sign signature certificate

The manuscript proves the Lagrange residue sign pattern
`sgn(γ_a) = (-1)^(a-1)`.  This module proves, without the Omega,
Linarith or NormNum imports, the exact signed imbalance of an alternating
finite list.  Consequently a diagonal slope with alternating nonzero signs
has equally many positive and negative entries when its size is even, and
one additional entry of the sign of its first entry when the size is odd.

This proves the **finite signed-mass calculation**, not the identification of
the actual `poleWeight` with this pattern, nor the matrix congruence/inertia
bridge, nor the full Theorem 3.3 total-positivity/Carleman assertion.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3Signature

/-- The difference of counts of alternating positive and negative unit signs, encoded directly
as a rational sum to avoid a hidden finite-cardinality hypothesis. -/
def signedRow (start length : ℕ) : ℚ :=
  ∑ j ∈ Finset.range length, (-1 : ℚ) ^ (start + j)

/-- Every adjacent two signs sum to zero. -/
theorem signedRow_pair (start length : ℕ) :
    signedRow start (length + 2) = signedRow start length := by
  unfold signedRow
  change (∑ j ∈ Finset.range ((length + 1) + 1),
    (-1 : ℚ) ^ (start + j)) =
      (∑ j ∈ Finset.range length, (-1 : ℚ) ^ (start + j))
  rw [Finset.sum_range_succ, Finset.sum_range_succ]
  have hstep : (-1 : ℚ) ^ (start + (length + 1)) =
      -((-1 : ℚ) ^ (start + length)) := by
    calc
      (-1 : ℚ) ^ (start + (length + 1)) =
          (-1 : ℚ) ^ ((start + length) + 1) := by simp [Nat.add_assoc]
      _ = (-1 : ℚ) ^ (start + length) * (-1 : ℚ) := by rw [pow_succ]
      _ = -((-1 : ℚ) ^ (start + length)) := by ring
  rw [hstep]
  ring

/-- In an even-length alternating diagonal the signed imbalance is zero. -/
theorem signedRow_even (start n : ℕ) :
    signedRow start (2 * n) = 0 := by
  induction n with
  | zero => simp [signedRow]
  | succ n ih =>
      have h : 2 * (n + 1) = 2 * n + 2 := by ring
      rw [h, signedRow_pair, ih]

/-- In an odd-length alternating diagonal the surplus sign is the first sign. -/
theorem signedRow_odd (start n : ℕ) :
    signedRow start (2 * n + 1) = (-1 : ℚ) ^ start := by
  calc
    signedRow start (2 * n + 1) =
        signedRow start (2 * n) + (-1 : ℚ) ^ (start + 2 * n) := by
          unfold signedRow
          rw [Finset.sum_range_succ]
    _ = (-1 : ℚ) ^ (start + 2 * n) := by
          rw [signedRow_even]
          ring
    _ = (-1 : ℚ) ^ start := by simp [pow_add, pow_mul]

end PaperChronology.Section3Signature

#print axioms PaperChronology.Section3Signature.signedRow_pair
#print axioms PaperChronology.Section3Signature.signedRow_even
#print axioms PaperChronology.Section3Signature.signedRow_odd
