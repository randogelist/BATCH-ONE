import PaperChronology.Section3LeadingSign

/-!
# Theorem 3.3: rational closed-product pole-weight sign

For the source's negative-square nodes a = N+1+i, separate the tail
pole derivative into factors from lower nodes and factors from upper
nodes.  Their positive unsigned products determine the sign of the
closed residue formula.  This module proves positivity of those factors
and alternation of the exact closed-form rational coefficient, without
importing Mathlib.Tactic.Omega or Theorem_2_5 directly.

FRONTIER: the identity between `closedPoleWeight` and the *actual*
`PoleDiagonalization.poleWeight` requires proving that the derivative of
`Real.tailD` at the pole equals `(-1)^i * positiveTailGap`.  The later
matrix inertia transfer also remains to be proved.  No custom axioms.
-/

noncomputable section
open scoped BigOperators

namespace PaperChronology.Section3PoleResidue

private theorem square_gap_pos (u v : ℚ) (hu : 0 ≤ u) (huv : u < v) :
    0 < v ^ 2 - u ^ 2 := by
  have hv : 0 < v := lt_of_le_of_lt hu huv
  have hdiff : 0 < v - u := sub_pos.mpr huv
  have hsum : 0 < v + u := add_pos_of_pos_of_nonneg hv hu
  calc
    0 < (v - u) * (v + u) := mul_pos hdiff hsum
    _ = v ^ 2 - u ^ 2 := by ring

/-- Strictly positive factors from all pole nodes preceding N+1+i. -/
def lowerGap (N i : ℕ) : ℚ :=
  ∏ j ∈ Finset.range i,
    ((((N + 1 + i : ℕ) : ℚ)) ^ 2 - (((N + 1 + j : ℕ) : ℚ)) ^ 2)

/-- Strictly positive factors from all pole nodes following N+1+i. -/
def upperGap (N h i : ℕ) : ℚ :=
  ∏ j ∈ Finset.Ico (i + 1) h,
    ((((N + 1 + j : ℕ) : ℚ)) ^ 2 - (((N + 1 + i : ℕ) : ℚ)) ^ 2)

def positiveTailGap (N h i : ℕ) : ℚ := lowerGap N i * upperGap N h i

theorem lowerGap_pos (N i : ℕ) : 0 < lowerGap N i := by
  unfold lowerGap
  apply Finset.prod_pos
  intro j hj
  have hjlt : j < i := Finset.mem_range.mp hj
  have hij : N + 1 + j < N + 1 + i := by
    exact Nat.add_lt_add_left hjlt (N + 1)
  have hcast : ((N + 1 + j : ℕ) : ℚ) < ((N + 1 + i : ℕ) : ℚ) := by
    exact_mod_cast hij
  exact square_gap_pos _ _ (Nat.cast_nonneg _) hcast

theorem upperGap_pos (N h i : ℕ) : 0 < upperGap N h i := by
  unfold upperGap
  apply Finset.prod_pos
  intro j hj
  have hij : i < j := by
    have h := (Finset.mem_Ico.mp hj).1
    exact lt_of_lt_of_le (Nat.lt_succ_self i) h
  have hindex : N + 1 + i < N + 1 + j :=
    Nat.add_lt_add_left hij (N + 1)
  have hcast : ((N + 1 + i : ℕ) : ℚ) < ((N + 1 + j : ℕ) : ℚ) := by
    exact_mod_cast hindex
  exact square_gap_pos _ _ (Nat.cast_nonneg _) hcast

theorem positiveTailGap_pos (N h i : ℕ) : 0 < positiveTailGap N h i := by
  exact mul_pos (lowerGap_pos N i) (upperGap_pos N h i)

private theorem neg_one_square (n : ℕ) :
    (-1 : ℚ) ^ n * (-1 : ℚ) ^ n = 1 := by
  simpa using (mul_pow (-1 : ℚ) (-1 : ℚ) n).symm

/-- Odd positive powers preserve the sign of an arbitrary power of negative one. -/
theorem neg_one_pow_odd (N m : ℕ) (hm : 0 < m) :
    (-1 : ℚ) ^ (N * (2 * m - 1)) = (-1 : ℚ) ^ N := by
  have hmge : 1 ≤ m := Nat.succ_le_of_lt hm
  have hodd : 2 * m - 1 = 2 * (m - 1) + 1 := by
    have hcancel : m - 1 + 1 = m := Nat.sub_add_cancel hmge
    have hmul : 2 * m = (2 * (m - 1) + 1) + 1 := by
      calc
        2 * m = 2 * (m - 1 + 1) := by rw [hcancel]
        _ = (2 * (m - 1) + 1) + 1 := by ring
    calc
      2 * m - 1 = ((2 * (m - 1) + 1) + 1) - 1 := by rw [hmul]
      _ = 2 * (m - 1) + 1 := by simp
  have hsquare : ((-1 : ℚ) ^ N) ^ 2 = 1 := by
    simpa [pow_two] using neg_one_square N
  calc
    (-1 : ℚ) ^ (N * (2 * m - 1)) =
        (-1 : ℚ) ^ (N * (2 * (m - 1) + 1)) := by rw [hodd]
    _ = ((-1 : ℚ) ^ N) ^ (2 * (m - 1) + 1) := by rw [pow_mul]
    _ = (((-1 : ℚ) ^ N) ^ 2) ^ (m - 1) * ((-1 : ℚ) ^ N) := by
          simp only [pow_add, pow_mul, pow_one]
    _ = (-1 : ℚ) ^ N := by rw [hsquare]; simp

/-- The pole coefficient in the PDF after elementary derivative-product expansion.
Its numerator is the paper's D_N evaluation raised to the odd power 2m-1;
the denominator is the signed product of squared-node differences. -/
def closedPoleWeight (N h i m k : ℕ) : ℚ :=
  let a : ℕ := N + 1 + i
  ((a : ℚ) ^ (2 * k) *
    ((ManuscriptChain.Real.D N).eval (-(a : ℚ) ^ 2)) ^ (2 * m - 1)) /
      ((-1 : ℚ) ^ i * positiveTailGap N h i)

/-- All factors in the closed formula give precisely (-1)^(N+i).
This is the full finite product *sign computation*, not yet an identity
with the separately formalized derivative-evaluation poleWeight. -/
theorem closedPoleWeight_alternating_sign (N h i m k : ℕ)
    (hm : 0 < m) :
    0 < (-1 : ℚ) ^ (N + i) * closedPoleWeight N h i m k := by
  let a : ℕ := N + 1 + i
  let d : ℚ := (ManuscriptChain.Real.D N).eval (-(a : ℚ) ^ 2)
  let sN : ℚ := (-1 : ℚ) ^ N
  let sI : ℚ := (-1 : ℚ) ^ i
  let P : ℚ := positiveTailGap N h i
  have hNa : N < a := by
    change N < N + 1 + i
    exact lt_of_lt_of_le (Nat.lt_succ_self N) (Nat.le_add_right (N + 1) i)
  have hd : 0 < sN * d := by
    exact PaperChronology.Section3LeadingSign.D_evaluation_sign N a hNa
  have hp : 0 < P := positiveTailGap_pos N h i
  have ha : 0 < (a : ℚ) ^ (2 * k) := by
    have ha0 : 0 < (a : ℚ) := by
      exact_mod_cast (lt_of_lt_of_le (Nat.zero_lt_succ N) (Nat.le_add_right (N + 1) i))
    exact pow_pos ha0 _
  have hspow : sN * d ^ (2 * m - 1) = (sN * d) ^ (2 * m - 1) := by
    rw [mul_pow]
    have hN : sN ^ (2 * m - 1) = sN := by
      dsimp [sN]
      rw [← pow_mul]
      exact neg_one_pow_odd N m hm
    rw [hN]
  have hnum : 0 < sN * ((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) := by
    calc
      sN * ((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) =
          (a : ℚ) ^ (2 * k) * (sN * d ^ (2 * m - 1)) := by ring
      _ = (a : ℚ) ^ (2 * k) * (sN * d) ^ (2 * m - 1) := by rw [hspow]
      _ > 0 := mul_pos ha (pow_pos hd _)
  have hsi : sI ≠ 0 := by
    dsimp [sI]
    exact pow_ne_zero _ (by simp : (-1 : ℚ) ≠ 0)
  have hcancel : sI * (sI * P)⁻¹ = P⁻¹ := by
    rw [mul_inv_rev]
    calc
      sI * (P⁻¹ * sI⁻¹) = (sI * sI⁻¹) * P⁻¹ := by ring
      _ = P⁻¹ := by rw [mul_inv_cancel₀ hsi, one_mul]
  have hratio : sN * sI *
      (((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) / (sI * P)) =
      (sN * ((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1))) / P := by
    calc
      sN * sI *
          (((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) / (sI * P)) =
          sN * ((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) *
            (sI * (sI * P)⁻¹) := by rw [div_eq_mul_inv]; ring
      _ = sN * ((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) * P⁻¹ := by
        rw [hcancel]
      _ = (sN * ((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1))) / P := by
        rw [div_eq_mul_inv]
  change 0 < (-1 : ℚ) ^ (N + i) *
    (((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) / (sI * P))
  rw [pow_add]
  change 0 < (sN * sI) *
    (((a : ℚ) ^ (2 * k) * d ^ (2 * m - 1)) / (sI * P))
  rw [hratio]
  exact div_pos hnum hp

end PaperChronology.Section3PoleResidue

#print axioms PaperChronology.Section3PoleResidue.lowerGap_pos
#print axioms PaperChronology.Section3PoleResidue.upperGap_pos
#print axioms PaperChronology.Section3PoleResidue.neg_one_pow_odd
#print axioms PaperChronology.Section3PoleResidue.closedPoleWeight_alternating_sign
