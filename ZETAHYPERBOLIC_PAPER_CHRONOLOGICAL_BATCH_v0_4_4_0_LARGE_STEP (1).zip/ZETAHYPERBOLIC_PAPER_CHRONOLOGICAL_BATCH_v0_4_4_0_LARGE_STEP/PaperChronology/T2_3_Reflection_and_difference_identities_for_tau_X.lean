import PaperChronology.T2_2_Pullback_identity
import PaperChronology.PoleGenerators

/-!
# Lemma 2.3 — Reflection and difference identities for tau_X

SOURCE: Zetahyperbolic PDF; Section 2.
STATUS: PARTIAL
SOURCE MODULE: PaperChronology.PoleGenerators
SCOPE: Simple-pole reflection and difference proved; monomial reflection/general-span closure pending.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check PaperChronology.even_pole_pair_generator
#check PaperChronology.reflected_pole_index
#check PaperChronology.shifted_positive_pole
