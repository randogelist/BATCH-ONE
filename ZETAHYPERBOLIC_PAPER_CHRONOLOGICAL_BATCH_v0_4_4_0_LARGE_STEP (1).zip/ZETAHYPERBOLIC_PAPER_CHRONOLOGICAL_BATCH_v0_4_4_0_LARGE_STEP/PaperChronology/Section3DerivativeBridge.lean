import PaperChronology.Section3ClosedSignature

/-!
# Theorem 3.3 -- derivative at an arbitrary negative-square pole

Unlike the earlier closed rational formula, this file works with the
*polynomial derivative* of the finite pole product.  It proves the
signed product formula directly by differentiating the factorization
at the selected pole.  It then identifies that finite polynomial with
the paper's `Real.tailD` and the associated rational pole weights.

No integral positivity or inertia law is claimed by these identities.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology.Section3DerivativeBridge

open PaperChronology.Section3PoleResidue

/-- The K-N tail polynomial in zero-based pole coordinates. -/
def localTailD (N h : ℕ) : ℚ[X] :=
  ∏ j ∈ Finset.range h,
    (X + C (((N + 1 + j : ℕ) : ℚ) ^ 2))

/-- Polynomial differentiation at a simple pole leaves the product
of all the other linear factors. -/
theorem localTailD_derivative_eval (N h i : ℕ) (hi : i < h) :
    (derivative (localTailD N h)).eval (-(((N + 1 + i : ℕ) : ℚ) ^ 2)) =
      ∏ j ∈ (Finset.range h).erase i,
        (((N + 1 + j : ℕ) : ℚ) ^ 2 -
          (((N + 1 + i : ℕ) : ℚ) ^ 2)) := by
  have hfactor : localTailD N h =
      (X + C (((N + 1 + i : ℕ) : ℚ) ^ 2)) *
        ∏ j ∈ (Finset.range h).erase i,
          (X + C (((N + 1 + j : ℕ) : ℚ) ^ 2)) := by
    exact (Finset.mul_prod_erase (Finset.range h)
      (fun j => (X + C (((N + 1 + j : ℕ) : ℚ) ^ 2) : ℚ[X]))
      (Finset.mem_range.mpr hi)).symm
  rw [hfactor, derivative_mul, derivative_add, derivative_X, derivative_C]
  simp [Polynomial.eval_prod, sub_eq_add_neg, add_comm]

private theorem range_erase_split (h i : ℕ) (hi : i < h) :
    (Finset.range h).erase i =
      Finset.range i ∪ Finset.Ico (i + 1) h := by
  ext j
  simp only [Finset.mem_erase, Finset.mem_range,
    Finset.mem_union, Finset.mem_Ico]
  constructor
  · rintro ⟨hne, hjh⟩
    rcases lt_trichotomy j i with hji | heq | hij
    · exact Or.inl hji
    · exact False.elim (hne heq)
    · exact Or.inr ⟨Nat.succ_le_of_lt hij, hjh⟩
  · intro hj
    rcases hj with hji | ⟨hij, hjh⟩
    · exact ⟨ne_of_lt hji, lt_trans hji hi⟩
    · have hlt : i < j := lt_of_lt_of_le (Nat.lt_succ_self i) hij
      exact ⟨(ne_of_lt hlt).symm, hjh⟩

private theorem range_ico_disjoint (h i : ℕ) :
    Disjoint (Finset.range i) (Finset.Ico (i + 1) h) := by
  apply Finset.disjoint_left.mpr
  intro j hj hupper
  have hjlt : j < i + 1 :=
    lt_trans (Finset.mem_range.mp hj) (Nat.lt_succ_self i)
  have hjge : i + 1 ≤ j := (Finset.mem_Ico.mp hupper).1
  exact (Nat.not_le_of_gt hjlt) hjge

/-- The derivative is the product of the positive lower and upper gaps,
with sign precisely (-1)^i. This is the finite analytic-free derivative
identity missing between Equation (2.11) and the closed product. -/
theorem localTailD_derivative_closed (N h i : ℕ) (hi : i < h) :
    (derivative (localTailD N h)).eval (-(((N + 1 + i : ℕ) : ℚ) ^ 2)) =
      (-1 : ℚ) ^ i * positiveTailGap N h i := by
  rw [localTailD_derivative_eval N h i hi,
    range_erase_split h i hi, Finset.prod_union (range_ico_disjoint h i)]
  have hlow :
      (∏ j ∈ Finset.range i,
        (((N + 1 + j : ℕ) : ℚ) ^ 2 -
          (((N + 1 + i : ℕ) : ℚ) ^ 2))) =
      (-1 : ℚ) ^ i * lowerGap N i := by
    calc
      (∏ j ∈ Finset.range i,
        (((N + 1 + j : ℕ) : ℚ) ^ 2 -
          (((N + 1 + i : ℕ) : ℚ) ^ 2))) =
          ∏ j ∈ Finset.range i,
            (-1 : ℚ) *
              ((((N + 1 + i : ℕ) : ℚ) ^ 2) -
                (((N + 1 + j : ℕ) : ℚ) ^ 2)) := by
              apply Finset.prod_congr rfl
              intro j hj
              ring
      _ = (-1 : ℚ) ^ i * lowerGap N i := by
            rw [Finset.prod_mul_distrib]
            simp [lowerGap]
  rw [hlow]
  unfold positiveTailGap upperGap
  ring

/-- A derivative-defined rational pole weight for the reindexed finite tail. -/
def localPoleWeight (N h i m k : ℕ) : ℚ :=
  let a : ℕ := N + 1 + i
  ((a : ℚ) ^ (2 * k) *
    ((ManuscriptChain.Real.D N).eval (-(a : ℚ) ^ 2)) ^ (2 * m - 1)) /
    (derivative (localTailD N h)).eval (-(a : ℚ) ^ 2)

/-- The derivative-defined local coefficient equals the previously
verified closed-rational coefficient, without assumptions on zeta. -/
theorem localPoleWeight_eq_closed (N h i m k : ℕ) (hi : i < h) :
    localPoleWeight N h i m k = closedPoleWeight N h i m k := by
  -- Congruence acts ONLY on the fraction denominator, leaving both
  -- definitionally identical numerators untouched. No `simp` step.
  exact congrArg
    (fun d : ℚ =>
      ((((N + 1 + i : ℕ) : ℚ) ^ (2 * k)) *
        ((ManuscriptChain.Real.D N).eval
          (-(((N + 1 + i : ℕ) : ℚ) ^ 2))) ^ (2 * m - 1)) / d)
    (localTailD_derivative_closed N h i hi)

/-- The PDF's interval product is exactly the reindexed finite product,
provided the endpoint order agrees with the paper's K >= N convention. -/
theorem tailD_eq_local (p : ManuscriptChain.Real.Parameters)
    (hNK : p.N ≤ p.K) :
    ManuscriptChain.Real.tailD p = localTailD p.N p.h := by
  have hK : p.K = p.N + p.h := by
    unfold ManuscriptChain.Real.Parameters.h
    simpa only [Nat.add_comm] using (Nat.sub_add_cancel hNK).symm
  unfold ManuscriptChain.Real.tailD localTailD
  rw [hK]
  have hIco : Finset.Icc (p.N + 1) (p.N + p.h) =
      Finset.Ico (p.N + 1) (p.N + p.h + 1) := by
    ext b
    simp only [Finset.mem_Icc, Finset.mem_Ico]
    constructor
    · rintro ⟨hlo, hhi⟩
      exact ⟨hlo, Nat.lt_succ_of_le hhi⟩
    · rintro ⟨hlo, hhi⟩
      exact ⟨hlo, Nat.lt_succ_iff.mp hhi⟩
  rw [hIco, Finset.prod_Ico_eq_prod_range]
  have hcnt : p.N + p.h + 1 - (p.N + 1) = p.h := by
    have hassoc : p.N + p.h + 1 = p.h + (p.N + 1) := by ac_rfl
    rw [hassoc]
    simp
  rw [hcnt]

/-- The *source formula* of the Theorem 2.5 pole weight, reconstructed
using only Definition 2.1 objects. This is definitionally the same formula
as `ManuscriptChain.PoleDiagonalization.poleWeight`, but importing its module
here would reintroduce the unavailable Mathlib.Omega transitive dependency.
The official namespace equality is therefore checked in `PAPER_MAIN_CHAIN`,
which already imports the earlier theorem in its manuscript-order spine. -/
def paperPoleWeight (p : ManuscriptChain.Real.Parameters) (i : Fin p.h) : ℚ :=
  let a : ℕ := p.N + 1 + i.val
  (ManuscriptChain.Real.D p.N).eval (-(a : ℚ) ^ 2) ^ (2 * p.m - 1) /
      (derivative (ManuscriptChain.Real.tailD p)).eval (-(a : ℚ) ^ 2) *
      (a : ℚ) ^ (2 * p.k)

/-- The source derivative formula agrees with the local tail derivative. -/
theorem paperPoleWeight_eq_local (p : ManuscriptChain.Real.Parameters)
    (hNK : p.N ≤ p.K) (i : Fin p.h) :
    paperPoleWeight p i = localPoleWeight p.N p.h i.val p.m p.k := by
  unfold paperPoleWeight localPoleWeight
  rw [tailD_eq_local p hNK] <;> ring

/-- The source pole-weight expression equals the closed signed product.
This is the unconditioned rational identity, without any zeta assumptions. -/
theorem paper_poleWeight_eq_closed (p : ManuscriptChain.Real.Parameters)
    (hNK : p.N ≤ p.K) (i : Fin p.h) :
    paperPoleWeight p i =
      closedPoleWeight p.N p.h i.val p.m p.k := by
  exact (paperPoleWeight_eq_local p hNK i).trans
    (localPoleWeight_eq_closed p.N p.h i.val p.m p.k i.isLt)

/-- Sign of the derivative-defined source pole weight. -/
theorem paper_poleWeight_alternating_sign (p : ManuscriptChain.Real.Parameters)
    (hNK : p.N ≤ p.K) (hm : 0 < p.m) (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (p.N + i.val) * paperPoleWeight p i := by
  rw [paper_poleWeight_eq_closed p hNK i]
  exact closedPoleWeight_alternating_sign p.N p.h i.val p.m p.k hm

end PaperChronology.Section3DerivativeBridge

#print axioms PaperChronology.Section3DerivativeBridge.localTailD_derivative_eval
#print axioms PaperChronology.Section3DerivativeBridge.localTailD_derivative_closed
#print axioms PaperChronology.Section3DerivativeBridge.localPoleWeight_eq_closed
#print axioms PaperChronology.Section3DerivativeBridge.tailD_eq_local
#print axioms PaperChronology.Section3DerivativeBridge.paperPoleWeight_eq_local
#print axioms PaperChronology.Section3DerivativeBridge.paper_poleWeight_eq_closed
#print axioms PaperChronology.Section3DerivativeBridge.paper_poleWeight_alternating_sign
