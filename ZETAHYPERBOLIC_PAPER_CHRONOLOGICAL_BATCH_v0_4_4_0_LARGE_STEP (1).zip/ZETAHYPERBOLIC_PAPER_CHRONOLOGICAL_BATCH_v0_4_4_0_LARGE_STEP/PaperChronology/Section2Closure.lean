import Zetahyperbolic.Section2Checked
import PaperChronology.PoleGenerators

/-!
# Lemma 2.2 and Lemma 2.3: finite-span closure

Source: *Spectral Theory and Diophantine Bounds for Hankel Determinants
of Odd Zeta Values*, Section 2, equations (2.2)--(2.7).

Unlike the old chronological wrappers, the theorems below quantify over
*arbitrary* finite polynomial and simple-pole combinations. They use the
previously developed, explicit Bernoulli and harmonic generator proofs in
`Zetahyperbolic.Section2Checked`.  They DO NOT postulate any analytic
identification with the zeta integral, nor the existence of a Diophantine
witness.

`RatMomentElem` is the source's polynomial-division + finite partial-fraction
representation of rational functions with permitted simple square poles.
`TauSpan` is an inductively generated finite Q-linear span of monomials
and integer simple poles. These are representations of the named domains;
we do not assert a new, unproved `RatFunc` representation theorem here.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PaperChronology

/-- The tau-side of formula (2.5), evaluated on an arbitrary finite
polynomial-plus-simple-square-poles decomposition of R(t).  Each term is
the tau evaluation of the explicitly substituted monomial or of the pole
pair in the partial fraction identity displayed in the paper. -/
def tauOfPulledBackDecomposition (k : ℕ)
    (R : Zetahyperbolic.RatMomentElem) : ℚ[X] :=
  (∑ e ∈ Finset.range (R.polyPart.natDegree + 1),
    C (R.polyPart.coeff e *
      ((-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1)))) +
  ∑ j ∈ Finset.Icc 1 R.maxPole,
    C (R.poleRes j) *
      (C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        C (((j : ℚ) ^ (2 * k)) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
            Zetahyperbolic.tauPolePoly k (-(j : ℤ))))

/-- Lemma 2.2: the pullback identity for the ENTIRE canonical domain
of finite rational moment decompositions, not only individual generators.
The RHS explicitly applies the tau formula on the substituted generators.
-/
theorem LEMMA_2_2_FULL_DECOMPOSED_PULLBACK
    (k : ℕ) (hk : 1 ≤ k) (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k R =
      tauOfPulledBackDecomposition k R := by
  unfold Zetahyperbolic.muFunctionalPoly tauOfPulledBackDecomposition
  congr 1
  · apply Finset.sum_congr rfl
    intro e he
    rw [Zetahyperbolic.pullback_identity_monomial k e hk]
  · apply Finset.sum_congr rfl
    intro j hj
    rw [Zetahyperbolic.pullback_identity_pole k j hk
      (Finset.mem_Icc.mp hj).1]

/-- The finite Q-linear span of exactly the two types of generators
specified for tau in Lemmas 2.2 and 2.3. -/
inductive TauSpan where
  | monomial : ℕ → TauSpan
  | pole : ℤ → TauSpan
  | add : TauSpan → TauSpan → TauSpan
  | scale : ℚ → TauSpan → TauSpan

/-- tau value on a finite linear combination of polynomial monomials
and integer simple poles, calculated from (2.4) and the pole values. -/
def tauSpanEval (k : ℕ) : TauSpan → ℚ[X]
  | .monomial d => C (Zetahyperbolic.tauMonomial k d)
  | .pole r => Zetahyperbolic.tauPolePoly k r
  | .add f g => tauSpanEval k f + tauSpanEval k g
  | .scale a f => C a * tauSpanEval k f

/-- tau on the reflected generators under x -> -1-x, extended linearly.
On x^d this uses the *actual binomial coefficients* of (-1-x)^d;
on the integer pole (x-r)^-1 the index becomes -1-r and the sign flips. -/
def tauSpanReflectedEval (k : ℕ) : TauSpan → ℚ[X]
  | .monomial d =>
      C ((-1 : ℚ) ^ d *
        (∑ i ∈ Finset.range (d + 1),
          (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i))
  | .pole r => -(Zetahyperbolic.tauPolePoly k (-1 - r))
  | .add f g => tauSpanReflectedEval k f + tauSpanReflectedEval k g
  | .scale a f => C a * tauSpanReflectedEval k f

/-- Lemma 2.3(1): the reflection identity on EVERY finite Q-linear
combination of the stated monomial and integer simple-pole generators. -/
theorem LEMMA_2_3_REFLECTION_FULL_FINITE_SPAN
    (k : ℕ) (hk : 1 ≤ k) (f : TauSpan) :
    tauSpanReflectedEval k f = -tauSpanEval k f := by
  induction f with
  | monomial d =>
      simpa only [tauSpanReflectedEval, tauSpanEval, Polynomial.C_neg] using
        congrArg (Polynomial.C : ℚ → ℚ[X])
          (Zetahyperbolic.tau_reflection_monomial k d hk)
  | pole r =>
      simpa only [tauSpanReflectedEval, tauSpanEval] using
        Zetahyperbolic.tau_reflection_pole k r
  | add f g hf hg =>
      change tauSpanReflectedEval k f + tauSpanReflectedEval k g =
        -(tauSpanEval k f + tauSpanEval k g)
      rw [hf, hg]
      ring
  | scale a f hf =>
      change C a * tauSpanReflectedEval k f = -(C a * tauSpanEval k f)
      rw [hf]
      ring

/-- Lemma 2.3(2): exact difference law, including positive and
negative integer poles, with the paper's exceptional indices 0,1. -/
theorem LEMMA_2_3_DIFFERENCE_ALL_ALLOWED_POLES
    (k : ℕ) (r : ℤ) (hr0 : r ≠ 0) (hr1 : r ≠ 1) :
    Zetahyperbolic.tauPolePoly k (r - 1) -
        Zetahyperbolic.tauPolePoly k r =
      C (-((r : ℚ) ^ (2 * k + 1))⁻¹) := by
  exact Zetahyperbolic.tau_difference_pole k r hr0 hr1

/-- The paper's even-pair cancellation has no zeta or witness input. -/
theorem THEOREM_5_4_SIMPLE_POLE_CANCELLATION
    (k j : ℕ) (hj : 1 ≤ j) (X : ℚ) :
    tauPolePositive k (j - 1) X - tauPoleNegative k (j - 1) X =
      1 / ((j : ℚ) ^ (2 * k + 1)) := by
  exact even_pole_pair_for_positive_j k j hj X

end PaperChronology

#print axioms PaperChronology.LEMMA_2_2_FULL_DECOMPOSED_PULLBACK
#print axioms PaperChronology.LEMMA_2_3_REFLECTION_FULL_FINITE_SPAN
#print axioms PaperChronology.LEMMA_2_3_DIFFERENCE_ALL_ALLOWED_POLES
