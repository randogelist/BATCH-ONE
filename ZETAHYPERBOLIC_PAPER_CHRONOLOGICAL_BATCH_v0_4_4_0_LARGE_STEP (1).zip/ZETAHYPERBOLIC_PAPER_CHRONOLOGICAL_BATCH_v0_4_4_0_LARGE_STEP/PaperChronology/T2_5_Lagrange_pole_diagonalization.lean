import PaperChronology.T2_4_Canonical_basis_invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Theorem 2.5 — Lagrange pole diagonalization

SOURCE: Zetahyperbolic PDF; Section 2.
STATUS: PROVED
SOURCE MODULE: Theorem_2_5_Lagrange_Pole_Diagonalization
SCOPE: Matrix derivative factorization and pole basis identities are proved.

Only source-exact proved statements are checked below. For open results,
this file is a chronological checkpoint and NOT a proof or hypothesis.
-/

#check ManuscriptChain.PoleDiagonalization.theorem_2_5_lagrange_pole_diagonalization
