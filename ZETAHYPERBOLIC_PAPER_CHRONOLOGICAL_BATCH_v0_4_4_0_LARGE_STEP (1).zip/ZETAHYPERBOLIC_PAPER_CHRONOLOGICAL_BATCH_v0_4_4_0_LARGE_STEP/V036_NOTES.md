# v0.3.6 — Theorem 3.3 finite pole-residue sign

Native Lean 4.33.0 only. No local Lean compilation was performed.

New `PaperChronology/Section3PoleResidue.lean` states and proves finite algebraic candidate lemmas for the strictly positive lower and upper pole-node gap factors and the resulting sign of the closed rational pole-residue product in the paper.

The *identity of this expanded product* with `ManuscriptChain.PoleDiagonalization.poleWeight`, the full real Gram integral, and the Sylvester inertia theorem are **not** claimed. Those remain in chronological Theorem 3.3 frontier.

Only this new module and the root `PAPER_MAIN_CHAIN.lean` are changed/new targets. All 123 previously verified module sources remain byte-identical. The persistent cache should rebuild the new module and the root main chain and axiom audit if they are affected by source changes. Do not use `run.cmd full`.
