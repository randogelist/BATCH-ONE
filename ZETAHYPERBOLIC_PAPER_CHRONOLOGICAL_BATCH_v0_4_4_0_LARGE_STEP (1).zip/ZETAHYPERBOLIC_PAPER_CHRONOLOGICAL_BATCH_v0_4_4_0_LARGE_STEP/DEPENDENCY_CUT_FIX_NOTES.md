# v0.3.4.4: dependency-isolation repair

**User-reported failure:** `PaperChronology.Section3LeadingSign.lean:1:0: object file ... Mathlib/Tactic/Omega.olean ... does not exist`.

v0.3.4.3 removed the textual `import Mathlib.Tactic.Omega`, but the failing module still imported the cached theorem 2.5 module and `Mathlib.Tactic.Linarith`, which expose different, previously untested precompiled import closures. v0.3.4.4 entirely removes those import paths **from the newly compiled sign module**. Its only import is `PaperChronology.Section3Continuous`, which the user's compiler explicitly reports as `CHECK_PASS`.

The same exact sign lemmas remain; their internal proofs now use elementary Nat arithmetic, `ring`, `simp`, product positivity, and finite polynomial evaluation instead of `omega`, `linarith`, `nlinarith` and `norm_num` tactics. No source file other than `Section3LeadingSign.lean` has changed. The project runner retains the cross-version, source-checked, incremental cache.

## Native verification

No Lean compilation was run during packaging. The next proof module to compile is `PaperChronology.Section3LeadingSign`. The target is a genuine new proof, and the PDF's full Theorem 3.3 remains open.

If the same module has an import failure, inspect `_logs\PaperChronology.Section3LeadingSign.log` and the `PACKAGE=` field at the start of `_logs\BUILD_SUMMARY.txt` to distinguish a cached old package run from a transitive environment problem. If there is a tactic or proof error, report its complete error text; don't rebuild the 116 unchanged modules.
