# v0.4.3.3 — finite Stieltjes shifts (Theorem 3.1 / corrected Corollary 3.6)

The previous 53 compiled targets remain unchanged. Three new targets build
from their verified Lean 4.33.0 artifacts. No Lean was run while packaging.

New statements:
- Atomic Stieltjes moments and shifted polynomial energies for any finite real support.
- Nonnegative weights and nodes imply all shifted energies are nonnegative.
- Positive masses and positive nodes imply the exact common zero-energy kernel.
- Pairwise distinct support nodes give strict shifted positivity for every
  nonzero polynomial of natural degree below the number of atoms.
- A nonzero monic polynomial annihilates all shifts (indeed all its multiples do).
- Two real roots symmetric about a shift have identical reciprocal-square nodes,
  even though the roots are distinct when t != 0. This guards against an
  unjustified strict-rank claim in printed Corollary 3.6.

Status: Lean source candidate, not compiled here; your native Windows compiler
is sole authority. Package does not assert full-paper closure.
