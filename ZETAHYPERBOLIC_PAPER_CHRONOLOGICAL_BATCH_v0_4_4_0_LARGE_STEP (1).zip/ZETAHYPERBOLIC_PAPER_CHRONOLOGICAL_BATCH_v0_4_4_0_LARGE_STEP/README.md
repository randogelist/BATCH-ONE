# Native Lean chronological large batch v0.4.4.0

One ZIP / one root `run.cmd` / native Windows Lean 4.33.0 / offline Mathlib.
The previous 65 already-verified modules are retained unchanged. Additional
modules cover finite character-period series and heights (3.9), finite
spectral balls and measure transfer (4.1), and dual coefficient Gram form
(5.1–5.2). These are **not** full theorem completion.

Use `run.cmd` normally. Shared persistent cache allows previous verified
modules to be reused; only changed modules or invalidated imports rebuild.
The compiler is run only by the user. Full-manuscript closure and the
arithmetic witness remain unproved.

See `LARGE_STEP_v0440.md` for mathematical and verification scope.
