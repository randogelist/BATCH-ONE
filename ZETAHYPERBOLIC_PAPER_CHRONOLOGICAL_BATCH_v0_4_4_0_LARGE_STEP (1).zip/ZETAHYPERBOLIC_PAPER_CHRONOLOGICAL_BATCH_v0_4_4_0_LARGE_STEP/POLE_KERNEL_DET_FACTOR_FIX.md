# Theorem 3.8 finite pole-kernel — determinant factor repair

The paper-aligned finite theorem `PaperChronology.Section3PoleKernel.det_coefficientOperator`
had a Lean-normalization failure at line 71 in v0.4.3.5. The previous proof invoked
`Zetahyperbolic.det_conjugated_diagonal` even though its simp argument was unused.
The resulting goal still contained `(Matrix.diagonal gamma).det` and `V.transpose.det`.

The replacement proof explicitly rewrites both via `Matrix.det_diagonal` and
`Matrix.det_transpose`, then uses `ring` to rearrange commuting scalar products.
It changes no theorem statements, mathematical definitions, or prior Lean modules.
The offline run.cmd reuses cached olean artifacts for source-identical modules.

Verification: static source and ZIP validation only; Lean compilation is performed
exclusively on the user's native Windows Lean 4.33.0 compiler.
