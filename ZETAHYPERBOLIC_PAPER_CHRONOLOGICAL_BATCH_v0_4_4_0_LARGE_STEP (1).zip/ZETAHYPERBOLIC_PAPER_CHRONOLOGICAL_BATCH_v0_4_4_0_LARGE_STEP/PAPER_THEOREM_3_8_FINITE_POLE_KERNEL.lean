import PAPER_THEOREM_3_7_TURAN_PRODUCT_AXIOMS
import PaperChronology.Section3PoleKernel

/-! Source PDF Theorem 3.8: finite algebra of the Christoffel-Darboux
pole-evaluation matrix, independent of the analytic reproducing kernel. -/
#check PaperChronology.Section3PoleKernel.poleKernel_transpose
#check PaperChronology.Section3PoleKernel.coefficient_pole_intertwine
#check PaperChronology.Section3PoleKernel.det_coefficientOperator
#check PaperChronology.Section3PoleKernel.det_poleOperator
#check PaperChronology.Section3PoleKernel.det_coefficient_eq_pole
#check PaperChronology.Section3PoleKernel.det_poleOperator_ne_zero
#check PaperChronology.Section3PoleKernel.det_coefficientOperator_ne_zero
