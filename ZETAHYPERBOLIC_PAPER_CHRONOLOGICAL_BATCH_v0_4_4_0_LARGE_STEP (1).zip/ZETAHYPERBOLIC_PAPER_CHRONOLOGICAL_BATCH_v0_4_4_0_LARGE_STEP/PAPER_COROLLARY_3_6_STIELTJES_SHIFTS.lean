import PAPER_COROLLARY_3_6_FINITE_SUPPORT_SHARP
import PaperChronology.Section3StieltjesShifts

/-! # Corrected Corollary 3.6: all shifted Stieltjes quadratic forms

This is a finite-support consequence, not a claim that the entire PDF
or the real-zero spectral/analytic bridge has been formalized.
-/

#check PaperChronology.Section3StieltjesShifts.atomicMoment_nonneg
#check PaperChronology.Section3StieltjesShifts.shiftedEnergy_zero_iff
#check PaperChronology.Section3StieltjesShifts.shifted_stieltjes_sharp
#check PaperChronology.Section3StieltjesShifts.reciprocalSquare_pos
#check PaperChronology.Section3StieltjesShifts.reciprocalSquare_symmetric
#check PaperReconstruction.PRINCIPAL_THEOREM
#check PaperReconstruction.PRINCIPAL_ALL_ODD_THEOREM
