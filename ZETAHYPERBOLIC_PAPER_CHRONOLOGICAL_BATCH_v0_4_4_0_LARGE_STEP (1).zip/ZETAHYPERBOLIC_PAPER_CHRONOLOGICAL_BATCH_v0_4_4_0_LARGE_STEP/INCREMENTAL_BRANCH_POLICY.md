# Native compiler branch policy

1. **Compile once, reuse unchanged proofs.** A module is frozen only after the user's native Lean compiler successfully emits its `.olean`, which is accompanied by the matching source snapshot.
2. **Across ZIP versions.** Verified objects and source snapshots live in `PAPER_VERIFIED_CACHE` (default under `%USERPROFILE%\lean-native`). Unchanged source files are reused without another `lean.exe` invocation.
3. **Change propagation.** If a module's source bytes change, or an imported local module is rebuilt, the affected module is compiled. Recursive topological ordering takes care of transitive dependencies.
4. **Environment invalidation.** Lean executable, matching stdlib, Mathlib cache path and compiler flags are tracked. When those change, the object cache is invalidated. To force a full replay, run `call run.cmd full`.
5. **Partial failure.** Successful earlier modules remain in the persistent cache even if a later newly compiled module fails; no valid objects are discarded simply because the aggregate build failed.
6. **Audit honesty.** A cache object certifies only the Lean declarations actually checked. A theorem checkpoint that contains only `#check` is not a proof of its paper statement.

The shared cache must not be copied from an unverified or incompatible environment; the only automatic legacy seed requires `BUILD=PASS` and a matching compiler configuration.
