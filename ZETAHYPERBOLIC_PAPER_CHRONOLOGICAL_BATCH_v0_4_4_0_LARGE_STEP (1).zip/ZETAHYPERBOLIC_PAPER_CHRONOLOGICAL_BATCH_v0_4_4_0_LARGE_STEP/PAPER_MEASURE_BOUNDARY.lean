import PAPER_WITNESS

/-!
# Quantitative endpoint boundary -- separate spectral estimate

The printed b^(-25687) measure needs the explicit bound
  ||B_K|| <= exp((11411/1000)*K)
in addition to quadratic decay. Its proof is not discharged by the current
source modules. `FullMeasureWitness` bundles TWO INDEPENDENT mathematical
conditions, not one numerical certificate. We make this visible rather than
hiding the gap in a falsely unconditional theorem.

`MainSpectralData` is a bound for the *actual* manuscript pencil, not a
synthetic abstract set of unrelated roots. Its matrix factorization itself
is constructed from the positive Gram matrix by existing theorems.

No assertions of the PDF's incorrect minor/J-fraction claims are made.
-/

noncomputable section
namespace PaperReconstruction
open ManuscriptChain
open ManuscriptChain.MainChain
open ManuscriptChain.RealTransfer

/-- Two independent quantitative premises, grouped only for interface use:
(1) the printed arithmetic smallness witness;
(2) an eventually uniform sharp spectral factor bound.
`MainSpectralData` is NOT currently supplied by an unconditional theorem. -/
def FullMeasureWitness : Prop :=
  ∃ start : ℕ, ∃ spectral : MainSpectralData (start + 1),
    ∀ n : ℕ, start + 1 ≤ n →
      |evalReal ((primitiveMainNormalization start).Q n) zeta5| ≤ decayBudget n

/-- The exact printed irrationality measure, conditional on BOTH necessary
quantitative estimates. The index selection, positivity, and integrality are
proved internally. The threshold is explicitly from the existing module. -/
theorem THEOREM_4_4_MEASURE_FROM_FULL_WITNESS
    (h : FullMeasureWitness) :
    ∃ b₀ : ℕ, ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
      1 / (b : ℝ) ^ 25687 < |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| := by
  obtain ⟨start, hspectral, hsmall⟩ := h
  let A := primitiveMainNormalization start
  have hbase : BaseValuePositive A.onset :=
    main_baseValuePositive A.onset A.onset_ge_one
  have hdecay : Decay A.Q zeta5 decayBudget A.onset := by
    refine ⟨?_, ?_⟩
    · intro n hn
      exact ne_of_gt (normalized_value_pos A hbase n hn)
    · intro n hn
      exact hsmall n hn
  have hcomparison : LocalComparison A.Q zeta5 mainSpectralRadius A.onset :=
    main_localComparison A hspectral
  refine ⟨indexDenominatorThreshold A.onset, ?_⟩
  intro a b hb hbb
  have hmeasure : RationalMeasure zeta5 25687
      (indexDenominatorThreshold A.onset) :=
    conditional_measure hcomparison hdecay (main_indexBudget A)
  simpa [zeta5, ManuscriptChain.Real.zeta_five_eq_riemannZeta_re] using
    hmeasure a b hb hbb

/-- Even the full quantitative interface gives irrationality directly. -/
theorem THEOREM_4_4_IRRATIONAL_FROM_FULL_WITNESS
    (h : FullMeasureWitness) : Irrational (riemannZeta 5).re := by
  obtain ⟨start, _, hsmall⟩ := h
  exact THEOREM_4_4_IRRATIONAL_FROM_WITNESS ⟨start, hsmall⟩

end PaperReconstruction

#check PaperReconstruction.FullMeasureWitness
#check PaperReconstruction.THEOREM_4_4_MEASURE_FROM_FULL_WITNESS
#print axioms PaperReconstruction.THEOREM_4_4_MEASURE_FROM_FULL_WITNESS
#print axioms PaperReconstruction.THEOREM_4_4_IRRATIONAL_FROM_FULL_WITNESS
