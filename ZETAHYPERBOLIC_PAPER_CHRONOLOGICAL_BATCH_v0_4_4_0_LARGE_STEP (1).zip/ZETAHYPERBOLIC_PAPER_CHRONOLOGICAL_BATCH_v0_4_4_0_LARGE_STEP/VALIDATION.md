# Validation status — v0.3.3

Static import-order and module-existence checks: PASS for 119 manifest modules; the 51 checkpoint names remain in PDF order. All pre-existing mathematical/chronological source modules remain byte-identical except `PAPER_MAIN_CHAIN.lean` and `PAPER_MAIN_CHAIN_AXIOMS.lean`; these two must import and report the new proof file. The unchanged chronological `#check` wrappers are intentionally not recompiled. No compiler or proof kernel was run by the assistant. Your native Lean 4.33.0 logs are the authoritative pass/fail data. Do not count a `#check` wrapper as a proved PDF result.

New source lines explicitly covered: Lemma 2.2 arbitrary finite decomposition; Lemma 2.3 monomial/pole finite span; Theorem 5.4 rational simple-pole cancellation. `RatFunc` semantic/uniqueness is not closed.
