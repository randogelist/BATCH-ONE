# v0.4.1 — finite-support Stieltjes correction

- Added `PaperChronology.Section3FiniteMomentRank` with mathematically
  unconditional finite-sum nonnegativity and exact 2-atom recurrence and
  rank-two obstruction at size three.
- Kept all other finite arithmetic and general odd-zeta packages identical,
  except the main-chain imports, axiom prints, manifest and runner package name.
- Pending native Lean compilation. No Lean executable was invoked locally.
- 51 chronological PDF checkpoints remain represented, not all discharged.
- Exactly one root-level `run.cmd`; cross-version frozen object cache retained.
