import PAPER_THEOREM_3_8_FINITE_POLE_KERNEL_AXIOMS
import PaperChronology.Section3FeketeCharacter

/-! Source PDF Theorem 3.9(2): the five exact finite character-polynomial
factorizations and their positive rational generating kernels on (0,1).
This is a partial finite bridge, not yet the Hurwitz/Dirichlet Gram theorem. -/

#check PaperChronology.Section3FeketeCharacter.fNeg3_factor
#check PaperChronology.Section3FeketeCharacter.fNeg4_factor
#check PaperChronology.Section3FeketeCharacter.f5_factor
#check PaperChronology.Section3FeketeCharacter.f8_factor
#check PaperChronology.Section3FeketeCharacter.fNeg8_factor
#check PaperChronology.Section3FeketeCharacter.allFiveKernels_pos
