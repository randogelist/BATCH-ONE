# v0.3.20 — Signed-product name repair (native compiler only)

The first failing module in v0.3.19, `Theorem_3_3_Signed_Product_Core.lean`, used a no-longer-present Lean/Mathlib identifier `Finset.card_insert_of_not_mem`. This patch changes it to the Mathlib 4 identifier `Finset.card_insert_of_notMem` and bumps the signed-product source marker and release identity.

No theorem statements, definitions, existing certified modules, or mathematical hypotheses were changed. The source proof may still have other errors; only the user's pinned Windows Lean 4.33.0 compiler can establish PASS and absence of `sorryAx`.

The default manifest rebuilds the modified signed-product source and its downstream importers while preserving unrelated previously certified `.olean` artifacts.
