# v0.3.5 — strict source identification and corrected density proof

The previous supplied compiler output corresponded to the v0.3.3-style axiom report: it did not include the two additional `#print axioms` lines added in v0.3.4. That suggests an older extraction/command may have been run; it is not definitive without the full compiler log.

This version:

1. Replaces `continuousDensity_at_odd` by a single explicit `change` plus the three identities `correctedPrefactor_at_odd`, `Real.rpow_natCast`, and the termwise infinite-sum equality.
2. Emits the distinctive line `RELEASE_V035_CONTINUOUS_DENSITY_SOURCE_ACTIVE` when Lean reaches the module's axiom audit.
3. Makes `run.cmd` report `ACTIVE_RELEASE=ZETAHYPERBOLIC_v0_3_5_DEFINITE_RERUN` and abort if the matching source marker is missing.
4. Leaves the persistent FROZEN_PASS cache and all prior Lean modules unchanged; source byte difference triggers rechecking only the repaired frontier and affected imports.
5. The user runs all compilation. The assistant has performed only static archive validation.

**Criteria for closing the fix:** `#print axioms ...continuousDensity_at_odd` must not contain `sorryAx`; `BUILD=PASS` must follow. If it still reports `sorryAx`, return the *first `error:` line* from `CHRONOLOGICAL_BUILD.log`, not just the axiom audit footer.

**Unchanged mathematical frontier:** Full positive definiteness for the paper's actual real-s integral Gram remains unproved; the reference pencil is not substituted for it.
