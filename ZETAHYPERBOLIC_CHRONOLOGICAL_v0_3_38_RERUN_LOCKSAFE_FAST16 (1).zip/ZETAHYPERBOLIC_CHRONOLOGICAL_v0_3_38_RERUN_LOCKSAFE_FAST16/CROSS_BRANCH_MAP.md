# Cross-branch candidate inventory and honest integration boundaries

## Included verbatim as compiled-source baseline

`Zetahyperbolic-general-assembled-lean433 (2).zip` — 60 `.lean` modules,
Lean 4.33.0 pinned, full manuscript-specific analytic moment realization,
Gram positivity, real-rootedness, canonical primitive normalization, and
conditional general irrationality interfaces.

Only this branch forms the import graph of the delivered `PAPER_AUDIT.lean`.

## Other supplied candidates reviewed but not imported

- `ODD_ZETA_3X3_MERGED_v0_3_0.zip` — finite IMPACTG 3x3 matrix identities,
  named eta/zeta readouts and conditional three-weight irrationality
  certificates. Its own README states that certificate existence is open,
  and it explicitly disclaims determinant identification with the
  manuscript's Hankel pencil.
- `IMPACTG_3X3_LEAN_v0_9_2_BINOMIAL_AVERAGE_FIX1.zip` — finite Euler-binomial
  arithmetic and contraction mechanisms, but conditional analytic tail
  profiles. No unconditional zeta(5) or zeta(7) irrationality claim.
- `CHEBYSHEV_MASTERTIER_LEAN_v0_1_56_NATIVE_ZETA7_FAST_FRONTIER.zip` and
  `GP7_UNIFIED_LEAN_BASE_v1_0_1_IMPORT_FIX.zip` — zeta(7) polynomial,
  Chebyshev, eta and finite spectral frameworks; these do not prove the
  primitive determinant decay condition required in the manuscript.
- `ZETA5_NATIVE_WITNESS_SEARCH_v0_1_0.zip` — candidate numerical witness
  generator; the package itself says numerical candidate data are not a
  theorem about the named analytic target.
- `zeta5-spectral-lean (1).zip` — extensive independent weight-five branch;
  its `Zeta5/Axioms.lean` contains a project-owned PNT axiom. This violates
  the requested axiom-free trust standard if imported unchanged.
- `MAIN_CHAIN_LEAN_ONLY (4).zip` — smaller earlier algebraic chain, now
  superseded by the more complete general assembled branch.

The rest of the supplied series/anchor/RH-related ZIPs furnish identities
but no checked theorem establishing the normalized global odd-weight
quadratic decay needed to finish this PDF. No such certificate is assumed.

## Merge design

1. Keep a single version of the manuscript's original moment functional;
   do not identify unrelated 3x3 determinants by similar notation.
2. Admit cross-branch results only through proved equalities relating actual
   values/polynomials and proven uniform bounds, not through arbitrary data.
3. Prefer exact finite certificates for rational combinatorics/p-adic
   valuation computations. Prove their soundness separately.
4. Do not import custom axioms, even if their names suggest familiar
   mathematical theorems. Rely on Mathlib proofs or self-contained proofs.
5. Rebuild entire dependency graph and inspect `#print axioms` for final
   exported endpoints before claiming any unconditional irrationality result.
