# v0.3.32 — single-premise principal endpoint + exact finite sign core

User-verified v0.3.31 principal endpoint was frozen (34 reused, 0 compiled).
The unchanged .olean files and existing principal axiom receipt are preserved.

The only altered mathematical source in this package is
`Theorem_3_3_Finite_Determinant_Sign.lean` (previously FAILED with sorryAx).
Its positivity proof now uses the already established finite product identity
and pointwise-positive product, rather than a separately constructed strict
inequality induction. The generic private helper is similarly made a corollary
of that same product identity. All theorem statements are preserved.

The default runner checks both the independently certified principal endpoint
and this changed determinant-sign module; 16-thread pinned Lean 4.33.0 FASTCORE.
No new axioms or `sorry` are introduced. The failing source has NOT been
compiler-verified by the assistant. A successful kernel `#print axioms` from
the user's compiler is required before freezing the new module. The complete
paper, its witness existence, total positivity, and spectral inertia beyond
proved sub-statements remain open.

`run.cmd endpoint`: principal endpoint-only; `run.cmd all`: broader research
chronology including independently incomplete statements; `run.cmd full`:
forced rebuild of focused modules.
