import Lake
open Lake DSL

package zetahyperbolic where
  -- The audited build order is listed in MODULES_CHECKED.txt.

require mathlib from git
  "https://github.com/leanprover-community/mathlib4" @ "db584cd6d46c92f209a44c0f1c829460d327499d"

@[default_target]
lean_lib Zetahyperbolic where
  -- Register all local namespaces, including theorem-named top-level files.
  roots := #[
    `Zetahyperbolic,
    `Zeta5Merge,
    `Definition_2_1_Order_s_Rational_Moment_Functional,
    `Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7,
    `Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil,
    `Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7,
    `Theorem_2_4_Canonical_Basis_Invariance,
    `Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk,
    `Theorem_2_5_Lagrange_Pole_Diagonalization,
    `Theorem_2_5_Weight_Change,
    `Theorem_4_1_Spectral_Irrationality_Measure_Criterion,
    `Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5,
    `Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4,
    `Theorem_3_1_General_Odd_Weight_Endpoint,
    `Theorem_3_1_Positive_Moment_Realization,
    `MAIN_CHAIN,
    `ZETA5_APPLICATION,
    `APPLICATIONS,
    `AUDITED_REPAIRS,
    `Theorem_3_1_Hyperbolic_Weight,
    `Theorem_3_1_Hyperbolic_Moments,
    `Theorem_3_1_Concrete_Moment_Realization,
    `Theorem_3_1_Rational_Integral_Bridge,
    `ANALYTIC_FRONTIER,
    `Theorem_3_1_Zeta_Tail,
    `Theorem_3_1_Coth_Partial_Fractions,
    `Theorem_3_1_Pole_Scaling,
    `Theorem_3_1_Bose_Tail_Integral,
    `Theorem_3_1_Pole_Integral_Identity,
    `MAIN_CHAIN_ASSEMBLED,
    `Theorem_4_1_General_Odd_Zeta_Application,
    `Theorem_4_1_Integer_Polynomial_Irrationality,
    `Theorem_4_1_Linear_Odd_Zeta_Family,
    `MAIN_CHAIN_ARITHMETIC,
    `Theorem_2_4_Primitive_Normalization_Minimality,
    `Theorem_4_1_Direct_Irrationality_From_Decay,
    `Theorem_4_1_Leading_Coefficient_Gap,
    `MAIN_CHAIN_IRRATIONALITY,
    `ZETA5_DIRECT_IRRATIONALITY,
    `CHECK_AXIOMS,
    `PAPER_CORRECTIONS,
    `Theorem_5_4_Even_Pole_Pair_Cancellation,
    `PAPER_AUDIT,
    `PAPER_WITNESS,
    `MAIN_CHAIN_SINGLE_WITNESS,
    `Lemma_2_2_Pullback_Identity,
    `Lemma_2_3_Reflection_And_Difference,
    `PAPER_CHRONOLOGICAL_MAIN
  ]
  -- Explicit endpoints only: unfinished manuscript files are not globbed.
  -- Lake recursively builds their imports within the registered roots.
  globs := #[.one `Zetahyperbolic, .one `MAIN_CHAIN,
             .one `APPLICATIONS, .one `AUDITED_REPAIRS, .one `ANALYTIC_FRONTIER,
             .one `MAIN_CHAIN_ASSEMBLED, .one `MAIN_CHAIN_ARITHMETIC, .one `MAIN_CHAIN_IRRATIONALITY,
             .one `ZETA5_DIRECT_IRRATIONALITY, .one `CHECK_AXIOMS,
             .one `PAPER_CORRECTIONS, .one `Theorem_5_4_Even_Pole_Pair_Cancellation,
             .one `PAPER_AUDIT, .one `PAPER_WITNESS,
             .one `MAIN_CHAIN_SINGLE_WITNESS,
             .one `Lemma_2_2_Pullback_Identity, .one `Lemma_2_3_Reflection_And_Difference,
             .one `PAPER_CHRONOLOGICAL_MAIN]

-- Source-only distribution: use lake build with the pinned dependencies available.
