# v0.3.26 — Direct finite determinant sign proof (source only)

This revision changes only `Theorem_3_3_Finite_Determinant_Sign.lean`,
its runner release identity, and documentation. Previously compiled, frozen
modules are byte-identical. The patch separates pointwise signed positivity,
its finite product, and the exact sign-exponent identity, combining them only
by explicit equality transport.

All proof compilation and `#print axioms` validation must be performed by the
user's Windows Lean 4.33.0 compiler. No Lean compiler was executed in creating
this archive. The manuscript's analytic total positivity remains separate.
