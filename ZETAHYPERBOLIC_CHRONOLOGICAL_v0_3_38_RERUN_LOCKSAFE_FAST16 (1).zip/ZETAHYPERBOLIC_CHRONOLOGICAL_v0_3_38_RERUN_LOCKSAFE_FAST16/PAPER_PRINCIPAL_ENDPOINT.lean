import MAIN_CHAIN_SINGLE_WITNESS
import MAIN_CHAIN_IRRATIONALITY

/-!
# Principal theorem endpoint of the currently formalized manuscript chain

The endpoint is stated now, before completion of the remaining independent
statements of Sections 3--6.  It is a theorem about the ACTUAL moment-pencil
family, not a tautological wrapper around arbitrary proof certificates.

Exactly one external mathematical premise remains in this file:
`ManuscriptChain.Paper.Witness`, the concrete normalized-decay and spectral-
growth estimates for the PDF's weight-five Hankel polynomials.

The general odd-weight spectral assertion and the uniform odd-weight
DECAY => IRRATIONAL transfer are unconditional Lean theorems.  The latter
DOES NOT assert the still-open universal decay premise.  This module does
NOT claim that the 52-page PDF, or all odd zeta values, are proved.

In particular, neither the unresolved all-pole determinant sign frontier nor
independent later-paper claims are imported here. This keeps the principal
endpoint independently checkable while those are formalized chronologically.
-/

noncomputable section

namespace ManuscriptChronology.Principal

/-- Section 2: full degree and invertible polynomial-pencil derivative,
    for every parameter tuple, without an auxiliary hypothesis. -/
def AlgebraicFoundation : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    (ManuscriptChain.Real.delta p).natDegree = p.h ∧
      (ManuscriptChain.Real.derivativeMatrix p).det ≠ 0

/-- Section 3.1: the actual Gram realization, spectral factorization,
    root reality, nonvanishing, and zero-free disk for every admissible
    odd-weight Hankel pencil. -/
def SpectralFoundation : Prop :=
  ∀ p : ManuscriptChain.Real.Parameters,
    ManuscriptChain.Real.Admissible p →
      ManuscriptChain.General.GeneralStatement p

/-- Section 4: a proved *implication* for any odd weight and the explicit
    admissible affine Hankel family. Decay is not asserted here. -/
def OddWeightTransfer : Prop :=
  ∀ k : ℕ, 0 < k →
    ManuscriptChain.GeneralIrrationality.AffineFamilyDecay k →
      Irrational (riemannZeta ((2 * k + 1 : ℕ) : ℂ)).re

/-- Section 4.4's quantitative endpoint, with the paper's exponent 25687.
    Its witness is NOT folded into this proposition: only the target appears. -/
def WeightFiveMeasure : Prop :=
  Irrational (riemannZeta 5).re ∧
    ∃ b₀ : ℕ, ∀ a : ℤ, ∀ b : ℕ,
      0 < b → b₀ ≤ b →
        1 / (b : ℝ) ^ 25687 <
          |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)|

/-- Principal endpoint of the core manuscript theorem chain. -/
def PrincipalStatement : Prop :=
  AlgebraicFoundation ∧ SpectralFoundation ∧
    OddWeightTransfer ∧ WeightFiveMeasure

/-- The derivative determinant and polynomial degree require no witness. -/
theorem algebraic_foundation : AlgebraicFoundation := by
  intro p
  exact ⟨ManuscriptChain.General.delta_degree p,
    ManuscriptChain.General.derivative_nonsingular p⟩

/-- All odd-weight spectral assertions follow from proved moment positivity. -/
theorem spectral_foundation : SpectralFoundation := by
  intro p hp
  exact ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- For every positive k, decay of the actual primitive determinant on the
    concrete family is sufficient for irrationality at weight 2*k+1. -/
theorem odd_weight_transfer : OddWeightTransfer := by
  intro k hk hdec
  exact ManuscriptChain.GeneralIrrationality.irrational_riemannZeta_of_normalized_decay
    k hk (ManuscriptChain.GeneralIrrationality.affineFamily k)
    (ManuscriptChain.GeneralIrrationality.affineFamily_admissible k hk)
    (ManuscriptChain.GeneralIrrationality.affineFamily_k k)
    (ManuscriptChain.GeneralIrrationality.affineFamily_unbounded k)
    hdec

/-- The *only* input to the effective measure is the actual Hankel witness. -/
theorem weight_five_from_witness (W : ManuscriptChain.Paper.Witness) :
    WeightFiveMeasure :=
  ManuscriptChain.Paper.MAIN_CHAIN W

/-- FINAL: one conditional input, every other conjunct follows from the
    established unconditional algebraic, analytic, and transfer chain. -/
theorem PRINCIPAL_THEOREM (W : ManuscriptChain.Paper.Witness) :
    PrincipalStatement :=
  ⟨algebraic_foundation, spectral_foundation,
    odd_weight_transfer, weight_five_from_witness W⟩

/-- A convenient form that separates the unconditional and conditional parts. -/
theorem PRINCIPAL_THEOREM_IF_WITNESS :
    ManuscriptChain.Paper.Witness → PrincipalStatement :=
  PRINCIPAL_THEOREM

end ManuscriptChronology.Principal

#check ManuscriptChronology.Principal.PrincipalStatement
#check ManuscriptChronology.Principal.PRINCIPAL_THEOREM
#print axioms ManuscriptChronology.Principal.algebraic_foundation
#print axioms ManuscriptChronology.Principal.spectral_foundation
#print axioms ManuscriptChronology.Principal.odd_weight_transfer
#print axioms ManuscriptChronology.Principal.weight_five_from_witness
#print axioms ManuscriptChronology.Principal.PRINCIPAL_THEOREM
#print axioms ManuscriptChronology.Principal.PRINCIPAL_THEOREM_IF_WITNESS
