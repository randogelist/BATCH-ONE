# Manuscript obstruction ledger: exact source statements

Source: **Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values**,
Prince Anand, dated 21 October 2026 (uploaded 52-page PDF).

## Statements that are false as printed

**Proposition 3.2, p. 8.** At an odd integer s=2k+1, the continuous-weight
prefactor `(2*pi)^s/(2*Gamma(s))` equals **pi/2** times the prefactor of
(3.1), `2*(2*pi)^(2k)/(2k)!`. Hence these weights do not coincide exactly as
claimed. The corrected prefactor is `2*(2*pi)^(s-1)/Gamma(s)`.
`PAPER_CORRECTIONS.lean` proves the coefficient identity at k=1.

**Corollary 3.5, pp. 10-11, equation (3.6).** The actual determinant pencil
is `det(G(xi)+(X-xi)*M)`, equivalently `det G(xi)*det(I+(X-xi)*B)`.
A J-fraction derived from B must keep that `I+(X-xi)*B` structure and
normalization. The printed `a_i + (X-xi)` denominators are not correct for
this pencil. Actual family counterexample: k=1, m=1, N=1, K=2, h=1:

```
D1(t)^2/D2(t) = (t+1)/(t+4) = 1 - 3/(t+4)
mu_X(1) = 1/4
mu_X(1/(t+4)) = 4*(X-9/8) + 1/8 - 1/2
Delta(X) = 119/8 - 12*X
```

For h=1 the printed RHS would be `1/(a1+(X-xi))`, whereas the actual LHS
is `1/Delta(X)`. Equality as rational functions would force `Delta(X)`
to have slope +1, contrary to slope -12.
The source-level Lean theorem rules out all choices of a1 and xi in Q.

**Corollary 3.6, p. 11.** A finite measure of at most h atoms has a moment
Hankel matrix of rank at most h. Its determinants of order >h must vanish;
it is false that *all* moment Hankel determinants are strictly positive.
For one atom at u, the 2x2 moment determinant is `1*u^2-u*u=0`.
Additionally, the paper's inequality for `S_(2r)^(-1/(2r))/d_min` is written
with bounds reversed: the proof itself gives `h^(-1/(2r)) <= ratio <= 1`.

## Proved general core (as reported by inherited validation)

- Definition 2.1 / Theorems 2.4, 2.5: actual finite rational functional,
  pole diagonalization, derivative nonsingularity, primitive invariance.
- Theorem 3.1: actual hyperbolic weight, moment integral, Gram positivity,
  exact-degree real-rooted pencil, and zero-free disk for all admissible odd
  integer weights. No quantitative decay statement is part of this theorem.
- Theorem 4.1: abstract spectral Diophantine transfer under its stated
  value-smallness and root-separation *mathematical premises*.
- Additional small results: direct arithmetic irrationality criterion,
  primitive normalization, weight-change factor, exact leading coefficient
  and ratio identity; these imply irrationality only from extra estimates.
- Theorem 5.4: newly added direct rational pole-pair cancellation.

## Endpoints with material gaps (not closed)

- **Theorem 4.4:** normalized integer determinant quadratic decay and
  quantitative relative-matrix norm bound are not discharged by the inherited
  project. The asserted exponent 25687 is not certified by the new module.
- **Theorem 4.5 / Corollary 6.8:** mixed zeta linear forms additionally need
  the arithmetic denominator estimates for the combined functional.
- **Corollary 3.5:** even after correcting the normalization, existence of
  a cyclic Lanczos vector and exact principal-minor identification need proof.
- **Theorem 5.2 / 6.3:** the printed truncation discards the infinite signed
  tail in the Krein form. The inherited modules preserve explicit tail and
  finite-certificate requirements instead of asserting the missing result.
- **Theorems 5.6-5.7 and 6.1-6.18:** many p-adic valuation claims, exact
  potential-theory limits, and global coupled-pencil estimates still need
  source-faithful proofs. The package does not claim their complete coverage.
- **All odd weights:** the bound on primitive-normalized values for
  arbitrarily high odd weights is not implied by matrix real-rootedness,
  the 3x3 finite ratio identities, or the Chebyshev rational approximations.

### Non-negotiable trust boundary

Removing a premise from the *type* of a Lean theorem by renaming it,
redefining `GeneralStatement`, adding a bare `axiom`, or choosing a witness
without proving its required bounds does not solve these mathematical goals.
