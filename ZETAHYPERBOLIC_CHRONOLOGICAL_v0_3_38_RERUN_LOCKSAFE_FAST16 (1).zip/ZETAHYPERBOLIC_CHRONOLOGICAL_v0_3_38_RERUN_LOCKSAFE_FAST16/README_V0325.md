# v0.3.25 — inherited axiom chain rebuild

The previous log gave no source elaboration error in the finite determinant sign
module, but its proof depended on `sorryAx`. This indicates a tainted imported
proof term, not a valid unconditional determinant-sign certificate.

This release forces ONE additional certification of the signed-product core and
the all-pole sign transfer on the user's pinned native compiler. It then
rebuilds the provenance probe, finite determinant sign, and invalidated dependents.

The earlier Proposition 3.2 / Theorem 3.3 first-node finite lemmas are retained
unchanged and cached; they are not rebuilt merely to repeat their checks.

The determinant module itself additionally prints the axiom sets of every
intermediate lemma along the sign chain, so an inherited sorryAx becomes
attributable even when the separate provenance probe is cached.

No Lean compilation has been performed during package preparation.
