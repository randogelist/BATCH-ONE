# v0.3.38 rerun launcher

Same Lean source files and dependency manifests as v0.3.37.
Run the one root `run.cmd` via Windows CMD. Uses Lean 4.33.0 direct 16-thread startup and persistent frozen-pass cache.
Lock acquisition is immediate and safe: if another build owns the cache, the command returns `BUILD=BLOCKED_SHARED_CACHE_WRITER` rather than waiting. No processes are stopped, locks deleted, or verified artifacts invalidated. No Lean was run while preparing this package.
