# Source-specific witness map

Manuscript: *Spectral Theory and Diophantine Bounds for Hankel Determinants of
Odd Zeta Values*, 21 October 2026, 52 pages.

| Manuscript claim | Native Lean module | Assumption status |
|---|---|---|
| Definition 2.1 rational moments, D_N/D_K, Δ_K | `Definition_2_1_...` | Definitions |
| Theorem 2.4 basis invariance | `Theorem_2_4_...` | Existing proved core |
| Theorem 2.5 Lagrange pole diagonalization, det M != 0 | `Theorem_2_5_...` | Existing proved core |
| Eq. (3.2), Theorem 3.1 positivity, spectral reality and radius | `MAIN_CHAIN_ASSEMBLED` and `Theorem_3_1_...` | Existing proved core (reported) |
| Theorem 4.1 transfer and rational denominator budget | `Theorem_4_1_...` + `MainChain.main_indexBudget` | Existing proved transfer |
| Eq. (4.2)/(4.3), weight-five p-adic normalization and decay | `PaperWitness.normalized_decay` | **CONDITIONAL** |
| Eq. (4.4), spectral growth 11.411K | `PaperWitness.spectral_growth` | **CONDITIONAL** |
| Theorem 4.4, measure 25687 and irrationality | `Paper.MAIN_CHAIN` | Derivation from witness |

The paper's `M=100000` cutoff is numerical input in the claimed
normalization analysis, not a proof of a uniform n-indexed estimate.

**Do not equate witnesses from 3x3, Chebyshev or zeta7 branches with
`PaperWitness` without a proved identity to the manuscript's primitive `Qₙ`.
Those branches supply important but distinct finite polynomial structures.**

The one-input endpoint concerns the main application chain, not all
paper claims including the corrupted Corollaries 3.5 and 3.6, nor the full
Sections 5–6. An attempt to force the entire PDF from one witness either
requires repairing mathematical statements and completing those additional
proofs, or would hide logically independent assumptions.
