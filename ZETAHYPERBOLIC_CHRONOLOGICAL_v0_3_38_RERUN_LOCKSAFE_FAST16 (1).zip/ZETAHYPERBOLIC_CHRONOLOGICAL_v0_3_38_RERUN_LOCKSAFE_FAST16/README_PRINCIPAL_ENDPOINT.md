# Principal endpoint — v0.3.31 (compiler pending)

This package adds **PAPER_PRINCIPAL_ENDPOINT.lean**. It defines a single
Lean proposition `ManuscriptChronology.Principal.PrincipalStatement` and
proves `PRINCIPAL_THEOREM (W : ManuscriptChain.Paper.Witness)` using the
existing manuscript code. The statement contains:

1. Unconditional degree and nonsingular derivative matrix for all index tuples.
2. Unconditional spectral theorem and a positive zero-free disk for all
   admissible odd-weight Hankel matrices.
3. General odd-weight implication that decay of the explicit primitive
   affine-family determinant implies irrationality. This is an implication,
   **not** a claim that the universal decay has been proved.
4. Irrationality of zeta(5) and the paper's explicit effective denominator
   exponent 25687, conditional on the **one** `Paper.Witness` whose two fields
   are the normalized determinant decay and quantitative spectral-growth bound.

**Not** proved by this endpoint: full Sections 3.3–6.18, all odd-zeta
irrationality, or existence of the Paper.Witness. The separately developing
Theorem 3.3 determinant-sign branch is not imported by this endpoint because
its most recent compiler report contains `sorryAx`.

## Native build

Windows: run `run.cmd` from the extracted directory. Exactly one `run.cmd`
exists. Default mode uses MODULES_FAST16_ENDPOINT.txt (dependency closure
of this new principal theorem). `run.cmd all` tries the broader historical
chronological chain; that chain has independently unresolved proof steps.
`run.cmd full` forces an endpoint-only rebuild for diagnosis.

No Lean has been run by the assistant. Your pinned Windows Lean 4.33.0 and
precompiled Mathlib cache are the sole verification authority. Compiler
prints `PRINCIPAL_AXIOM_CERTIFICATION=PASS` only when the new theorem and its
immediate unconditional lemmas are free of `sorryAx`. Unchanged previously
verified `.olean` files remain cached with their source-byte snapshots.
