import ZETA5_DIRECT_IRRATIONALITY

/-!
# The unique external input for the zeta(5) part of the manuscript

The actual primitive Hankel polynomial and the positive Gram matrix are
constructed by the imported sources.  The remaining estimates are separated
into TWO MATHEMATICAL FIELDS of ONE explicit witness.

The cutoff M=100000 mentioned in the PDF is a candidate for producing the
normalization estimate, not a checked proof of this structure.

No additional normalization, Gram positivity, nonvanishing, factorization,
or degree hypotheses are assumed.  In particular, the spectral field is an
UNPROVED quantitative estimate, not a consequence of the hyperbolicity theorem.
-/

noncomputable section

namespace ManuscriptChain.Paper

open ManuscriptChain.MainChain

/-- Theorem 3.1's positive Gram matrix, specialized to the actual K=30n family.
    This is a theorem, not a field of the witness. -/
def gramFromGeneral (start : ℕ) :
    ∀ n : ℕ, start + 1 ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef :=
  fun n hn => main_gram_posDef n (by omega)

/-- Precisely two unproved, uniform quantitative estimates.
The first is for the constructed primitive integer polynomial Q_n, not an
unrelated 3×3 determinant.  The second bounds the *actual* Gram-normalized
spectral factors of the manuscript's Hankel matrix pencil. -/
structure PaperWitness where
  start : ℕ
  normalized_decay : ∀ n : ℕ, start + 1 ≤ n →
    |RealTransfer.evalReal ((primitiveMainNormalization start).Q n) zeta5| ≤
      decayBudget n
  spectral_growth : ∀ n (hn : start + 1 ≤ n)
      (i : Fin ((Real.mainParameters n).h)),
    |(mainRootFactorization (start + 1) (gramFromGeneral start) n hn).beta i| ≤
      _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)

/-- The ONLY hypothesis of the final Section 4.4 theorem. -/
def Witness : Prop := Nonempty PaperWitness

/-- The decay-only projection suffices for irrationality; it is not enough for
    the numerical measure claimed by the PDF. -/
theorem valueDecay (w : PaperWitness) :
    ∀ n : ℕ, w.start + 1 ≤ n →
      |RealTransfer.evalReal
        ((primitiveMainNormalization w.start).Q n) zeta5| ≤ decayBudget n :=
  w.normalized_decay

end ManuscriptChain.Paper

#check ManuscriptChain.Paper.PaperWitness
#check ManuscriptChain.Paper.Witness
#print axioms ManuscriptChain.Paper.gramFromGeneral
