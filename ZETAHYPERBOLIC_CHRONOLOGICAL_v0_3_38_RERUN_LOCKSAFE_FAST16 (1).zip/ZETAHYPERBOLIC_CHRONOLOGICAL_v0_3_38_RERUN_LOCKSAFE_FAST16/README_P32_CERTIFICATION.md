# v0.3.6 P32 axiom certificate — targeted frozen-pass repair

The user's reported v0.3.5 output had `COMPILED=0 REUSED=45`, and the earlier
compiler showed `sorryAx` in `continuousDensity_at_odd`. A zero-rebuild run
cannot independently establish that this theorem is now axiom-free.

The new runner forces one actual recompilation of
`Proposition_3_2_Continuous_Hyperbolic_Pencil` if the one-time certificate
for this source/Lean-Mathlib configuration is absent, even when a snapshot and
`.olean` are present. It checks the compiled theorem's `#print axioms`
output for `continuousDensity_at_odd` and `continuousTerm_at_odd`, fails on
`sorryAx`, and writes the certificate only after successful compilation and
snapshot commit. Changed dependents (chronological main) recompile.
Unchanged and previously verified dependencies remain frozen.

A second run with the same source and configuration will normally show zero
compiled modules, now accompanied by `P32_AXIOM_CERTIFICATION=PASS`.

**This does not close Proposition 3.2.** Analytic positivity of the actual
continuous-order integral Gram is still open. Also, cached unrelated modules
were not freshly axiom-inspected by this targeted repair; only previously
verified modules should be trusted as FROZEN_PASS.

No Lean compilation was performed while authoring the ZIP.

Windows CMD:

```
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_6_P32_CERT_FAST16.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_6_P32_CERT_FAST16\run.cmd"
```
