# Zetahyperbolic PDF: native Lean chronological proof architecture (v0.3.16)

This file distinguishes actual proof terms from conjectures, written claims needing correction, and strictly mathematical proof obligations. The number of Lean modules is NOT the number of fully proved paper theorems. Running Windows Lean 4.33.0 with the included single `run.cmd` is the sole kernel certification authority. This release was NOT locally compiled.

## Governing one-Witness interface

- Arithmetic witness: an explicit, concrete collection of quantitative certificates for the **actual** normalized integer Hankel family (e.g. the weight-five family). The existing `PAPER_WITNESS`/`MAIN_CHAIN_SINGLE_WITNESS` imports expose a conditional theorem. They do not prove inhabitance of the witness or the full manuscript.
- Never introduce extra analytic premises or ad hoc `axiom` declarations into claimed unconditional modules. Ordinary `hm : 0 < p.m` is an index-admissibility premise, not an outside arithmetic conjecture. Intermediate implications with hypotheses are legitimate only when upstream source theorems actually prove their hypotheses for the intended concrete objects.
- The paper's final conjecture (4.11) remains explicitly conjectural. Incorrect printed statements must be corrected, not forced into Lean.
- Formalizing §5–6 is independent of proving the weight-five arithmetic endpoint, so a weight-five Witness must not be treated as evidence for their unresolved statements.

## Chronological mathematical dependencies

**2.1–2.5: finite rational foundation (previous frozen checkpoint).** Define `D_m`, polynomial and simple-pole moments, rational functionals, primitive determinants, pullback/reflection/difference laws. Basis invariance and exact pole Lagrange diagonalization yield an actual rational M = V diag(gamma) V^T with nonzero gamma and det M ≠ 0. None of these needs analytic integral representation.

**3.1: hyperbolic Gram proof.** Prove the true analytic identification `mu_{zeta(s)}(R)=∫ R(y²)w_s(y)dy`, w_s > 0, then Gram positivity for any nonzero polynomial q, and use symmetric finite pencil factorization to obtain all real roots distinct from zeta(s), together with the operator-norm zero-free disk. The algebraic transfer already exists; audit actual integral implementation separately.

**3.2: real s > 1.** Density prefactor at odd integer orders corrected in v0.3.6. Entire real-s positive integral Gram and continuous real-order equalities remain distinct analytic proof obligations. The compiler-verified v0.3.6 declaration subset alone does not close Proposition 3.2.

**3.3: total positivity/signature, current frontier.**
1. Previously verified v0.3.10: D_N(-a²) signed positivity, first residue sign, parity identity for K=30n,N=3n, h=27n,m=3.
2. Unverified v0.3.14/v0.3.15 imports: all pole derivative signs gamma_{N+1+i} have sign (-1)^(N+i), and adjacent strict opposition; these require their own compiler certificate.
3. NEW v0.3.16: global sign of `det M` and `delta.leadingCoeff` via `det V² * prod gamma` and the finite sign exponent `∑_i (N+i)`. NEW exact rational congruence `V^{-1} M (V^{-1})^T = diag(gamma)`, concrete bilateral diagonal directions when h>=2.
4. STILL REQUIRED: closed parity count for weight-five sign, Sylvester inertia transport to B = G^(-1/2) M G^(-1/2), exact positive/negative multiplicities, and strict total positivity of every minor of the original analytic moment Gram matrix (Andreief plus strict generalized Vandermonde sign).

**3.4–3.8: spectral minors and coefficient theory.** NEW v0.3.16: exact algebraic reciprocal root distance `|xi-(xi-beta^{-1})| = 1/|beta|` and antitone modulus transfer. Remaining requirements: Cholesky principal-block compatibility; interlacing accounting for zero beta in leading minors; Dodgson/Jacobi determinant condensation; corrected finite J fraction with normalization; finite-support rank correction for the reciprocal-root Stieltjes moment system; Rolle/Turan inequalities; Christoffel-Darboux and differentiating determinants.

**3.9/3.10: L-values and non-classicality.** Positive density/Fekete polynomial identities for each conductor and true Hurwitz/L-value moment realization still need formal proofs. Do not infer non-classicality merely from unproved root fanning-out claims.

**4.1–4.8: transfer and arithmetic.** Theorem 4.1 general quadratic-exponent integer-polynomial transfer has proof modules. Only an actually certified spectral separation and concrete p-adic + potential smallness make its explicit zeta(5) application unconditional. Theorem 4.2 algebraic resultants, 4.3 p-adic Lipschitz, and 4.5–4.8 coupled arithmetic, determinant asymptotics, root collapse and factors all require theorem-specific bridges. Preserve the one explicit Witness at the arithmetic endpoint but do not call other independent gaps 'proved'.

**4.9–4.11: remarks and conjecture.** A finite sequence of real Lee–Yang-type zeros pinching xi does not by itself prove existence of the thermodynamic free-energy limit or a first-order transition. 4.11 is a conjecture in the source, not a closed theorem.

**5.1–5.7: two-variable measure and local arithmetic.** Make the exact Mellin/difference-quotient moment identity for ζ(7); prove rational off-diagonal data. Establish dual CC^T positive and exact Krein expansion with convergence/approximation. Prove cancellation on simple even pole pairs (base lemma already present). The exact piecewise prime integral and local basis valuation theorem, and the simultaneous double-pole q-adic nonvanishing require further proof.

**6.1–6.18: multi-pole, beta, and potential-gap variants.** Preserve and reuse existing finite Hermite algebra and partial beta factorization files, but do not promote q-adic valuations, existence of Gram-positive weights, universal potential-gap asymptotics, or simultaneous irrationality conclusions absent full proofs of their supplied conditions. Several printed statements must be checked against the actual source before formalization.

## Build invariants

- Only one ZIP, one root-level `run.cmd`. FAST16 native direct Lean 4.33.0 using cached Mathlib and shared `.olean` cache.
- The stable source bytes of previously compiler-certified modules must not be changed or rechecked unless invalidated by transitive dependencies, source changes or toolchain changes. One-time axiom certificates are required for historically disputed frontier declarations.
- No `sorry`, `admit`, or `axiom` declarations in delivered theorem modules. Print and inspect `#print axioms` outputs; seeing `sorryAx` means FAIL even if Lean exited 0.
- Do not treat a structure containing an abstract theorem as a terminating finite checker/witness. A genuine finite witness is finite data and an independently terminating acceptance procedure whose accepted data feeds an already-proved downstream theorem chain.

**v0.3.16 second finite module:** Theorem 3.3(2) now has a proposed native proof of the exact signed leading coefficient for the actual weight-five parameters, by evaluating the pole-sign exponent as an arithmetic progression and using the previously certified parity identity. Kernel verification pending user compiler. This is independent of the quantitative ζ(5) irrationality endpoint.
