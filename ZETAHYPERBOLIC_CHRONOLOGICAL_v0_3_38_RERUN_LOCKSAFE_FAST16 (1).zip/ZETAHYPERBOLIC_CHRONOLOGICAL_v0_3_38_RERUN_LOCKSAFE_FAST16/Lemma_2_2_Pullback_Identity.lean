import Zetahyperbolic.Section2Checked

/-!
# Lemma 2.2 — Pullback identity (PDF pp. 4–5)

Native statements for the **original** monomial and simple-pole generators.
These delegate to fully derived identities in `Zetahyperbolic.Section2Checked`.
No new premise is introduced other than the mathematical index restrictions.
The Q-linear extension is represented by the paper's decomposed functional;
this file does not claim an equality of unspecified quotient-field elements.
-/

noncomputable section
open Polynomial

namespace ManuscriptChronology

/-- Lemma 2.2, monomial generator, exactly the Bernoulli/factorial pullback. -/
theorem LEMMA_2_2_MONOMIAL (k e : ℕ) (hk : 1 ≤ k) :
    Zetahyperbolic.muMonomial k e =
      (-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1) :=
  Zetahyperbolic.pullback_identity_monomial k e hk

/-- Lemma 2.2, simple-pole generator, including the rational correction. -/
theorem LEMMA_2_2_POLE (k j : ℕ) (hk : 1 ≤ k) (hj : 1 ≤ j) :
    Zetahyperbolic.muPolePoly k j =
      Polynomial.C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        Polynomial.C ((j : ℚ) ^ (2 * k) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
            Zetahyperbolic.tauPolePoly k (-(j : ℤ))) :=
  Zetahyperbolic.pullback_identity_pole k j hk hj

/-- Both generator cases of the manuscript's Lemma 2.2, as one unconditional
proof object indexed only by the natural parameter `k ≥ 1`. -/
theorem LEMMA_2_2_GENERATORS (k : ℕ) (hk : 1 ≤ k) :
    (∀ e : ℕ, Zetahyperbolic.muMonomial k e =
      (-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1)) ∧
    (∀ j : ℕ, 1 ≤ j → Zetahyperbolic.muPolePoly k j =
      Polynomial.C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        Polynomial.C ((j : ℚ) ^ (2 * k) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
            Zetahyperbolic.tauPolePoly k (-(j : ℤ)))) := by
  exact ⟨fun e => LEMMA_2_2_MONOMIAL k e hk,
    fun j hj => LEMMA_2_2_POLE k j hk hj⟩


/-- Applying `τ` after the algebraic pullback to an arbitrary *decomposed*
rational moment element: a finite polynomial part plus finitely many simple
negative-square poles. This is the precise domain represented by the source's
`RatMomentElem`, not a fabricated total functional on all rational functions. -/
noncomputable def pulledFunctionalPoly (k : ℕ) (R : Zetahyperbolic.RatMomentElem) :
    ℚ[X] :=
  (∑ e ∈ Finset.range (R.polyPart.natDegree + 1),
      Polynomial.C (R.polyPart.coeff e *
        ((-1 : ℚ) ^ e * Zetahyperbolic.tauMonomial k (2 * e + 2 * k + 1)))) +
  ∑ j ∈ Finset.Icc 1 R.maxPole,
    Polynomial.C (R.poleRes j) *
      (Polynomial.C (-Zetahyperbolic.tauMonomial k (2 * k - 1)) -
        Polynomial.C ((j : ℚ) ^ (2 * k) / 2) *
          (Zetahyperbolic.tauPolePoly k (j : ℤ) +
            Zetahyperbolic.tauPolePoly k (-(j : ℤ))))

/-- Full finite-linear extension of Lemma 2.2 for the original source's
explicitly decomposed domain. No analytic premise and no arithmetic witness. -/
theorem LEMMA_2_2_FINITE_LINEAR_EXTENSION
    (k : ℕ) (hk : 1 ≤ k) (R : Zetahyperbolic.RatMomentElem) :
    Zetahyperbolic.muFunctionalPoly k R = pulledFunctionalPoly k R := by
  unfold Zetahyperbolic.muFunctionalPoly pulledFunctionalPoly
  apply congrArg₂ (fun x y : ℚ[X] => x + y)
  · apply Finset.sum_congr rfl
    intro e _
    rw [LEMMA_2_2_MONOMIAL k e hk]
  · apply Finset.sum_congr rfl
    intro j hj
    rw [LEMMA_2_2_POLE k j hk (Finset.mem_Icc.mp hj).1]

end ManuscriptChronology

#print axioms ManuscriptChronology.LEMMA_2_2_GENERATORS
#print axioms ManuscriptChronology.LEMMA_2_2_FINITE_LINEAR_EXTENSION
