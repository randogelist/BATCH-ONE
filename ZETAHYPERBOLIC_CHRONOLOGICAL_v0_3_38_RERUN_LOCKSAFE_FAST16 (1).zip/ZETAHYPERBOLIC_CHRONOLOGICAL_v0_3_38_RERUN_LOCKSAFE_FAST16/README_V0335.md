# v0.3.35 finite product sign repair

The all-pole local positivity (certified), signed-product positivity (certified as
a pure finite statement), and Theorem 2.5 determinant factorization (certified)
are untouched. The unresolved signed-pole aggregate is now expressed through
an independent `negativeOne_pow_sum` and `Finset.prod_mul_distrib` calculation,
with each intermediate declaration separately checked for `sorryAx`.

The prior frozen module bodies are byte-identical. This release does not claim
Theorem 3.3 as proved until your compiler prints the axiom certificate.
No Lean compilation is performed outside your Windows Lean 4.33.0 compiler.
