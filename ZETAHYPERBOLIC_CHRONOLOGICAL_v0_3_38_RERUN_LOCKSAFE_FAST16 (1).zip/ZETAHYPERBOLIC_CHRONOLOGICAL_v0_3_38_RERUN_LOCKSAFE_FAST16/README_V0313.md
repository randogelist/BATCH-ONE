# v0.3.13 — Theorem 3.3 all-pole proof repair and diagnostic certificate

The only edited Lean source in this release is
`Theorem_3_3_All_Pole_Sign_Transfer.lean`.

Theorem declaration names and statements are unchanged. The public `signed_product_positive` and `signed_div_positive`
helpers are now individually axiom-audited, the sign-of-factor cases use explicit
`if_pos`/`if_neg`, and the signed-division identity no longer relies on the
previous fragile `field_simp; all_goals ring` sequence. An explicit cancellation
identity replaces it.

The one `run.cmd` in the package retains Lean 4.33.0, direct `-j 16`, the
persistent verified `.olean` cache, and targeted recompilation of the all-pole
module and its changed descendants. No other modules have been edited. The
all-pole axiom certificate uses new ID V0313 and cannot reuse a V0312 failure.

Required successful report:
`ALLPOLE_AXIOM_CERTIFICATION=PASS`, `BUILD=PASS`,
`RELEASE=ZETAHYPERBOLIC_v0_3_13_T33_ALL_POLES_CERT_FIX_FAST16`.

**No Lean compilation was performed during preparation.** The new proofs are
not verified until the user's compiler passes.

If a failure persists, return the output between `FIRST_LEAN_ERRORS_BEGIN`
and `FIRST_LEAN_ERRORS_END` together with the axiom report. The exact first
error locations identify an incomplete proof or import issue.

This only addresses the finite all-pole sign portion; full Theorem 3.3 still
requires strict total positivity and inertia transfer.
