-- THEOREM34_RECIPROCAL_SPECTRAL_EDGE_V0316_20261024
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Mathlib.Tactic

/-!
# Theorem 3.4: exact reciprocal spectral-edge transfer

Only the rigorous scalar root transformation is formalized here:
    r = center - beta^(-1).

The gap identity and its antitonicity are unconditional real algebra; they
will turn the future verified eigenvalue interlacing inequalities into the
manuscript's root-pinching inequalities. They do NOT assert interlacing of
the actual family until Cauchy interlacing and nonzero principal-minor
coefficients have been discharged in Lean.
-/

noncomputable section

namespace ManuscriptChronology.Theorem3_4_Reciprocal

/-- A transformed spectral root is its center shifted by reciprocal beta. -/
def spectralRoot (center beta : ℝ) : ℝ := center - beta⁻¹

/-- Exact distance from the center, including the convention inverse(0)=0. -/
theorem root_distance (center beta : ℝ) :
    |spectralRoot center beta - center| = 1 / |beta| := by
  have h : spectralRoot center beta - center = -(beta⁻¹) := by
    dsimp [spectralRoot]
    ring
  rw [h, abs_neg, abs_inv]
  rfl

/-- A larger nonzero eigenvalue modulus gives a smaller root-to-center gap. -/
theorem spectral_gap_antitone (center u v : ℝ)
    (hu : 0 < |u|) (huv : |u| ≤ |v|) :
    |spectralRoot center v - center| ≤
      |spectralRoot center u - center| := by
  rw [root_distance, root_distance]
  have hv : 0 < |v| := lt_of_lt_of_le hu huv
  apply (div_le_div_iff₀ hv hu).2
  simpa using huv

/-- Spectral norm bounds transfer into an explicit center-free disk. -/
theorem spectral_gap_lower_bound (center beta R : ℝ)
    (hbeta : beta ≠ 0) (hR : 0 < R) (hbound : |beta| ≤ R) :
    1 / R ≤ |spectralRoot center beta - center| := by
  rw [root_distance]
  have hb : 0 < |beta| := abs_pos.mpr hbeta
  apply (div_le_div_iff₀ hR hb).2
  simpa using hbound

end ManuscriptChronology.Theorem3_4_Reciprocal

#print axioms ManuscriptChronology.Theorem3_4_Reciprocal.root_distance
#print axioms ManuscriptChronology.Theorem3_4_Reciprocal.spectral_gap_antitone
#print axioms ManuscriptChronology.Theorem3_4_Reciprocal.spectral_gap_lower_bound
