import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil

/-!
# Theorem 6.3 (Unconditional q-adic non-vanishing and explicit positive-cone approximations for G_A^(7)(X))

PDF pp. 32-33. Conditional replacement for part (2) only. The printed
positive-cone construction is not accepted as a hypothesis or proved here.
PositiveBasisExistence and an analytic tail bound are explicit inputs to the
replacement implication below. The q-adic and approximation claims are
outside this file. The word "Unconditional" is part of the PDF title only.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Extensions
open ManuscriptChain.Real

def IndependentRows {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) : Prop :=
  ∀ a : Fin h → ℚ, (∀ r, ∑ i, a i * c i r = 0) → a = 0

def PositiveBasisExistence (h : ℕ) : Prop :=
  ∃ K M : ℕ, ∃ c : Fin h → Fin (K + 1) → ℚ,
    IndependentRows c ∧ FinitePositiveCertificate c M

theorem positive_basis_from_explicit_inputs (h : ℕ)
    (analyticTail : ∀ (K M : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
      WeightSevenTailBound c M)
    (existence : PositiveBasisExistence h) :
    ∃ K : ℕ, ∃ c : Fin h → Fin (K + 1) → ℚ,
      IndependentRows c ∧ PositiveQForm (weightSevenGram c) := by
  obtain ⟨K, M, c, independent, certificate⟩ := existence
  exact ⟨K, c, independent,
    weight_seven_positive_from_finite_certificate c (analyticTail K M c) certificate⟩

end ManuscriptChain.Extensions
