# v0.3.11 all-pole Theorem 3.3 sign frontier

The user's v0.3.10 compiler reported `LEAN_BUILD=PASS`, `BUILD=PASS`, `T33_AXIOM_CERTIFICATION=PASS`, 2 compiled and 44 reused. These facts certify only declarations actually present in the previously checked files; no full Theorem 3.3 claim is made.

New file: `Theorem_3_3_All_Pole_Sign_Transfer.lean`; chronological main updated. It aims to establish alternating sign of every true Lagrange residue and parity corollaries, unconditionally. It uses *no witness*.

All previous Lean source files remain byte-identical. The runner reuses frozen modules based on source/config hashes. Only this new module and the chronological main dependent should compile on a matching cache. The new compiler log must print all four new axiom reports and contain no `sorryAx`.

### Run from Downloads

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_11_T33_ALL_POLES_FAST16.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_11_T33_ALL_POLES_FAST16\run.cmd"
```

No assistant-side Lean compilation performed. This is a proposed proof patch, not a kernel-certified result.
