# v0.3.15 — Theorem 3.3 adjacent-sign consequences (Lean 4.33.0)

- `Theorem_3_3_Consecutive_Pole_Signs.lean` is NEW, with actual pole-weight nonvanishing, positivity/position parity equivalence, and a negative product at adjacent poles.
- `Theorem_3_3_All_Pole_Sign_Transfer.lean` is byte-for-byte unchanged from v0.3.14 and must first pass the user's compiler if it has not already done so.
- The new code adds no `Witness` and no custom axioms; its kernel validity remains **unverified** pending Windows Lean.
- Only the new module and affected chronological importer should need rebuilding if v0.3.14 already passed. Otherwise the all-pole module is compiled first.
- This advances the finite sign component, not the all-minors total positivity or analytic Gram signature component of full Theorem 3.3.
- One archive and one root `run.cmd`; direct native FAST16 Lean, persistent frozen-pass cache, no Lake/network.
- No local Lean compilation was performed.
