-- THEOREM33_CONSECUTIVE_SIGNS_V0315_20261024
import Theorem_3_3_All_Pole_Sign_Transfer
import Mathlib.Tactic

/-!
# Theorem 3.3, finite signature layer: exact sign alternation

This is downstream of the *actual* all-pole Lagrange coefficient theorem,
not a statement about a surrogate diagonal matrix. It adds no arithmetic
witness and assumes only the standing exponent constraint `0 < p.m`.

It proves: no coefficient vanishes; positivity is equivalent to even index
parity; consecutive coefficients have strictly negative product.

Neither total positivity of all Gram minors nor the inertia congruence
required for the **full** printed Theorem 3.3 is asserted here.
-/

noncomputable section
open Polynomial

namespace ManuscriptChronology.Theorem3_3_Consecutive

open ManuscriptChain
open ManuscriptChronology.Theorem3_3_AllPoles

/-- Every genuine pole weight is nonzero. -/
theorem poleWeight_ne_zero (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h) :
    PoleDiagonalization.poleWeight p i ≠ 0 := by
  by_cases he : (p.N + i.val) % 2 = 0
  · exact ne_of_gt (poleWeight_pos_of_even p hm i he)
  · have ho : (p.N + i.val) % 2 = 1 := by omega
    exact ne_of_lt (poleWeight_neg_of_odd p hm i ho)

/-- Positive coefficients are exactly the even-parity pole indices. -/
theorem poleWeight_pos_iff_even (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h) :
    0 < PoleDiagonalization.poleWeight p i ↔
      (p.N + i.val) % 2 = 0 := by
  constructor
  · intro hpos
    by_contra hne
    have ho : (p.N + i.val) % 2 = 1 := by omega
    have hneg := poleWeight_neg_of_odd p hm i ho
    linarith
  · intro he
    exact poleWeight_pos_of_even p hm i he

/-- Consecutive pole residues have opposite strict signs (no zero case). -/
theorem consecutive_pole_weights_opposite (p : Real.Parameters)
    (hm : 0 < p.m) (i j : Fin p.h)
    (hij : j.val = i.val + 1) :
    PoleDiagonalization.poleWeight p i *
      PoleDiagonalization.poleWeight p j < 0 := by
  have hpar : (p.N + i.val) % 2 = 0 ∨
      (p.N + i.val) % 2 = 1 := by omega
  rcases hpar with he | ho
  · have hjpar : (p.N + j.val) % 2 = 1 := by omega
    have hi := poleWeight_pos_of_even p hm i he
    have hj := poleWeight_neg_of_odd p hm j hjpar
    have hh : 0 < PoleDiagonalization.poleWeight p i *
        (-PoleDiagonalization.poleWeight p j) :=
      mul_pos hi (neg_pos.mpr hj)
    nlinarith
  · have hjpar : (p.N + j.val) % 2 = 0 := by omega
    have hi := poleWeight_neg_of_odd p hm i ho
    have hj := poleWeight_pos_of_even p hm j hjpar
    have hh : 0 < (-PoleDiagonalization.poleWeight p i) *
        PoleDiagonalization.poleWeight p j :=
      mul_pos (neg_pos.mpr hi) hj
    nlinarith

end ManuscriptChronology.Theorem3_3_Consecutive

#print axioms ManuscriptChronology.Theorem3_3_Consecutive.poleWeight_ne_zero
#print axioms ManuscriptChronology.Theorem3_3_Consecutive.poleWeight_pos_iff_even
#print axioms ManuscriptChronology.Theorem3_3_Consecutive.consecutive_pole_weights_opposite
