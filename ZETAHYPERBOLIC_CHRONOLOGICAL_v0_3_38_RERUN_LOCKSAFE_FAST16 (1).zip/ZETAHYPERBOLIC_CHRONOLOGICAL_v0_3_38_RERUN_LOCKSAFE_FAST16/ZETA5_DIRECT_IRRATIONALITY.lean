import Theorem_4_1_Direct_Irrationality_From_Decay
import Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5
import MAIN_CHAIN_ASSEMBLED

/-!
# Direct zeta(5) irrationality with no quantitative spectral input

The actual primitive integer determinant family has degree 27*n at K=30*n.
The assembled general theorem supplies positive definiteness, and therefore
nonvanishing of its normalized values. Irrationality follows directly from
quadratic value decay. Two separate multiplier and determinant upper estimates
are a sufficient way to supply that one value bound. Neither estimate is
proved in this file, and no unconditional irrationality conclusion is claimed.
-/

noncomputable section

namespace ManuscriptChain.MainChain

/-- The general analytic closure supplies positivity for the actual weight-five family. -/
theorem main_gram_posDef (n : ℕ) (hn : 0 < n) :
    (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef := by
  change General.GramPositive (Real.mainParameters n)
  apply GRAM_POSITIVE
  constructor <;> dsimp [Real.mainParameters] <;> omega

theorem main_baseValuePositive (onset : ℕ) (hone : 1 ≤ onset) :
    BaseValuePositive onset :=
  baseValuePositive_of_gram onset (fun n hn => main_gram_posDef n (by omega))

end ManuscriptChain.MainChain

namespace ManuscriptChain
open MainChain RealTransfer

/-- The already-proved index budget is sufficient for direct irrationality;
its radius clause is unused, and no spectral bound is required. -/
theorem zeta5_irrational_of_normalized_decay
    (normalization : MainNormalization)
    (decay : Decay normalization.Q zeta5 decayBudget normalization.onset) :
    Irrational (riemannZeta 5).re := by
  rw [← Real.zeta_five_eq_riemannZeta_re]
  change Irrational zeta5
  apply irrational_of_decay_and_denominator_budget
    (b₀ := indexDenominatorThreshold normalization.onset) decay
  intro b hb hbb
  obtain ⟨n, hn, _, hsmall⟩ := (main_indexBudget normalization).choose b hb hbb
  refine ⟨n, hn, ?_⟩
  have hnonneg : 0 ≤ (b : ℝ) ^ (normalization.Q n).natDegree * decayBudget n := by
    unfold decayBudget
    positivity
  nlinarith

/-- A single remaining normalized value estimate suffices. Nonvanishing is proved. -/
theorem ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY
    (start : ℕ)
    (upper : ∀ n : ℕ, start + 1 ≤ n →
      |evalReal ((primitiveMainNormalization start).Q n) zeta5| ≤ decayBudget n) :
    Irrational (riemannZeta 5).re := by
  let normalization := primitiveMainNormalization start
  apply zeta5_irrational_of_normalized_decay normalization
  refine ⟨?_, upper⟩
  intro n hn
  exact ne_of_gt (normalized_value_pos normalization
    (main_baseValuePositive normalization.onset normalization.onset_ge_one) n hn)

/-- The two outstanding growth estimates imply irrationality directly.
The quantitative spectral estimate used for the measure 25687 is not an input. -/
theorem ZETA5_IRRATIONALITY_FROM_TWO_ESTIMATES
    (start : ℕ)
    (multiplier : MultiplierUpper (primitiveMainNormalization start))
    (archimedean : ArchimedeanUpper (start + 1)) :
    Irrational (riemannZeta 5).re := by
  let normalization := primitiveMainNormalization start
  exact zeta5_irrational_of_normalized_decay normalization
    (main_decay normalization
      (main_baseValuePositive normalization.onset normalization.onset_ge_one)
      multiplier archimedean)

end ManuscriptChain

#print axioms ManuscriptChain.MainChain.main_gram_posDef
#print axioms ManuscriptChain.MainChain.main_baseValuePositive
#print axioms ManuscriptChain.zeta5_irrational_of_normalized_decay
#print axioms ManuscriptChain.ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY
#print axioms ManuscriptChain.ZETA5_IRRATIONALITY_FROM_TWO_ESTIMATES
