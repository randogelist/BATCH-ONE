-- AXIOM_CHAIN_REBUILD_V0325
-- THEOREM33_FINITE_DETERMINANT_SIGN_V0337_EXPLICIT_EQ_REWRITE_20261024
import Theorem_3_3_Axiom_Provenance_Probe
import Theorem_2_5_Lagrange_Pole_Diagonalization
import Mathlib.Tactic

/-!
# Theorem 3.3: sign of the actual leading determinant coefficient

This is a finite *unconditional* bridge (the standing structural requirement
`0 < p.m` means that the numerator exponent `2*m-1` is a positive odd number).

The derivative matrix is the genuine rational matrix of Definition 2.1 and
Theorem 2.5, not a proxy. Its exact determinant is the Vandermonde determinant
squared times the product of the signed Lagrange pole residues. We transfer
all-pole positivity to the leading coefficient of the original Hankel
polynomial at every odd weight, with no analytic gram-positivity assumption.

This theorem does NOT claim arbitrary-minor total positivity or the complete
Sylvester inertia assertion of Theorem 3.3. The sign is given here by a finite
sum of residue exponents; proving its closed form for each special scaling
family is a separate combinatorial specialization.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChronology.Theorem3_3_DetSign
open ManuscriptChain

/-- Exact sign exponent for the pole lattice, with no asymptotic limits. -/
def signExponent (p : Real.Parameters) : ℕ :=
  ∑ i : Fin p.h, p.N + i.val

/-- Multiplying individually signed factors collects the signs into one
integer power. The proof works for any finite set and any weights over Q. -/
theorem signed_prod_identity {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (e : ι → ℕ) (w : ι → ℚ) :
    (∏ i ∈ s, ((-1 : ℚ) ^ (e i) * w i)) =
      (-1 : ℚ) ^ (∑ i ∈ s, e i) * (∏ i ∈ s, w i) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
      simp
  | @insert a s ha ih =>
      rw [Finset.prod_insert ha, Finset.sum_insert ha,
        Finset.prod_insert ha, pow_add, ih]
      ring

/-- Each actual Lagrange residue has its correct, independently proved sign. -/
theorem signed_pole_factor_positive (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (p.N + i.val) *
      PoleDiagonalization.poleWeight p i := by
  exact ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_alternating p hm i

/-- Product positivity, isolated from the sign-reassociation identity. -/
theorem signed_pole_factors_product_positive (p : Real.Parameters)
    (hm : 0 < p.m) :
    0 < (∏ i : Fin p.h,
      ((-1 : ℚ) ^ (p.N + i.val) *
       PoleDiagonalization.poleWeight p i)) := by
  classical
  apply Finset.prod_pos
  intro i _
  exact signed_pole_factor_positive p hm i

/-- The signed-product positivity lemma is a direct consequence of the
    proved factorwise positivity and the exact finite-product identity.
    No dependent strict-inequality rewriting by induction is required. -/
private theorem signed_prod_positive_by_induction
    {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (e : ι → ℕ) (w : ι → ℚ) :
    (∀ i ∈ s, 0 < (-1 : ℚ) ^ (e i) * w i) →
      0 < (-1 : ℚ) ^ (∑ i ∈ s, e i) * (∏ i ∈ s, w i) := by
  classical
  intro h
  have hpositive :
      0 < (∏ i ∈ s, ((-1 : ℚ) ^ (e i) * w i)) := by
    apply Finset.prod_pos
    intro i hi
    exact h i hi
  rw [signed_prod_identity s e w] at hpositive
  exact hpositive

/-- First isolate the exact specialization of the generic finite-product
identity.  This is a pure equality of rational finite products. -/
private theorem signed_pole_product_eq (p : Real.Parameters) :
    (∏ i : Fin p.h,
      ((-1 : ℚ) ^ (p.N + i.val) *
        PoleDiagonalization.poleWeight p i)) =
      (-1 : ℚ) ^ (signExponent p) *
        (∏ i : Fin p.h, PoleDiagonalization.poleWeight p i) := by
  classical
  change
    (∏ i ∈ (Finset.univ : Finset (Fin p.h)),
      ((-1 : ℚ) ^ (p.N + i.val) *
        PoleDiagonalization.poleWeight p i)) =
      (-1 : ℚ) ^ (∑ i ∈ (Finset.univ : Finset (Fin p.h)), p.N + i.val) *
        (∏ i ∈ (Finset.univ : Finset (Fin p.h)),
          PoleDiagonalization.poleWeight p i)
  exact signed_prod_identity (Finset.univ : Finset (Fin p.h))
    (fun i : Fin p.h => p.N + i.val)
    (fun i : Fin p.h => PoleDiagonalization.poleWeight p i)

/-- Strict positivity now transfers by rewriting one *fully named equality*.
This avoids elaboration through a higher-order conditional proof term. -/
theorem signed_pole_product_positive (p : Real.Parameters) (hm : 0 < p.m) :
    0 < (-1 : ℚ) ^ (signExponent p) *
      (∏ i : Fin p.h, PoleDiagonalization.poleWeight p i) := by
  classical
  rw [← signed_pole_product_eq p]
  exact signed_pole_factors_product_positive p hm

/-- Determinant sign for the original derivative matrix M_K.
This combines the actual Vandermonde factorization with the all-pole signs. -/
theorem derivative_det_signed_positive (p : Real.Parameters) (hm : 0 < p.m) :
    0 < (-1 : ℚ) ^ (signExponent p) *
      (PoleDiagonalization.rationalDerivativeMatrix p).det := by
  have hVne : (PoleDiagonalization.poleVandermonde p).det ≠ 0 :=
    PoleDiagonalization.poleVandermonde_det_ne_zero p
  have hV : (0 : ℚ) < (PoleDiagonalization.poleVandermonde p).det ^ 2 := by
    positivity
  have hweights := signed_pole_product_positive p hm
  calc
    0 < (PoleDiagonalization.poleVandermonde p).det ^ 2 *
      ((-1 : ℚ) ^ (signExponent p) *
       (∏ i : Fin p.h, PoleDiagonalization.poleWeight p i)) :=
         mul_pos hV hweights
    _ = (-1 : ℚ) ^ (signExponent p) *
        (PoleDiagonalization.rationalDerivativeMatrix p).det := by
          rw [PoleDiagonalization.rationalDerivativeMatrix_det]
          ring

/-- Leading coefficient of the exact manuscript polynomial delta_K. -/
theorem delta_leadingCoeff_signed_positive (p : Real.Parameters) (hm : 0 < p.m) :
    0 < (-1 : ℚ) ^ (signExponent p) * (Real.delta p).leadingCoeff := by
  rw [PoleDiagonalization.delta_leadingCoeff]
  exact derivative_det_signed_positive p hm

/-- The actual leading coefficient cannot vanish. -/
theorem delta_leadingCoeff_ne_zero (p : Real.Parameters) (hm : 0 < p.m) :
    (Real.delta p).leadingCoeff ≠ 0 := by
  have hp := delta_leadingCoeff_signed_positive p hm
  intro hz
  rw [hz, mul_zero] at hp
  exact (not_lt_of_ge (le_refl (0 : ℚ))) hp

end ManuscriptChronology.Theorem3_3_DetSign

#print axioms ManuscriptChronology.Theorem3_3_DetSign.signed_prod_identity
#print axioms ManuscriptChronology.Theorem3_3_DetSign.signed_pole_factor_positive
#print axioms ManuscriptChronology.Theorem3_3_DetSign.signed_pole_factors_product_positive
#print axioms ManuscriptChain.PoleDiagonalization.rationalDerivativeMatrix_det
#print axioms ManuscriptChain.PoleDiagonalization.delta_leadingCoeff
#print axioms ManuscriptChronology.Theorem3_3_DetSign.signed_prod_identity
#print axioms ManuscriptChronology.Theorem3_3_DetSign.signed_prod_positive_by_induction
#print axioms ManuscriptChronology.Theorem3_3_DetSign.signed_pole_product_eq
#print axioms ManuscriptChronology.Theorem3_3_DetSign.signed_pole_product_positive
#print axioms ManuscriptChronology.Theorem3_3_DetSign.derivative_det_signed_positive
#print axioms ManuscriptChronology.Theorem3_3_DetSign.delta_leadingCoeff_signed_positive
#print axioms ManuscriptChronology.Theorem3_3_DetSign.delta_leadingCoeff_ne_zero

-- Imported axiom provenance, checked again in this file (not only in the
-- cached separate diagnostic module). No extra assumptions are introduced.
#print axioms ManuscriptChronology.Theorem3_3_SignCore.signed_product_positive
#print axioms ManuscriptChain.PoleDiagonalization.tailD_derivative_eval
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.tail_derivative_signed_positive
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_alternating
