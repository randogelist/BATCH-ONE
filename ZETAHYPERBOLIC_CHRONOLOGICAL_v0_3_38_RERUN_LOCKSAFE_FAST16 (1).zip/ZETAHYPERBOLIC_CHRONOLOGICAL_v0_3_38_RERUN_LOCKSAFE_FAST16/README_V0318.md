# v0.3.18 — all-pole axiom-provenance repair

The user-provided native v0.3.17 compiler reported `sorryAx` at
`tail_derivative_signed_positive`, with no line-numbered Lean elaboration errors.
The all-pole module is **not** frozen or certified.

Changes compared to v0.3.17:
- Derive pole index membership directly from the `Fin` index and parameter arithmetic.
- Derive pole index positivity directly, eliminating reliance on the unchecked imported membership/positivity lemmas.
- Print axiom sets for the two remaining imported proof inputs (`tailD_derivative_eval` and `signed_odd_numerator_pos`), as well as all all-pole targets.
- Print exact axiom-provenance references if `sorryAx` persists.
- Continue the one-time all-pole axiom certificate guard and cached dependency invalidation.

No Lean was compiled locally. v0.3.10 certified sources remain byte-identical.
The mathematical all-pole sign assertion still awaits the user's Lean compiler.
