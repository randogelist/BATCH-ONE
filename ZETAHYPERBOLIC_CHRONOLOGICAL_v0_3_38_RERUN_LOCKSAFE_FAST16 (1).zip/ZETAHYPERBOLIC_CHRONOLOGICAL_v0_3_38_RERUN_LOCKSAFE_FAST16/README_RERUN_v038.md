# Superseded by v0.3.9
The current release fixes the two theorem-3.3 proof gaps shown by the v0.3.8 compiler.
Use README_T33_FIX_v039.md and run.cmd from this release.
