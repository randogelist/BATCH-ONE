# v0.3.9 — Theorem 3.3 proof repair, native compiler only

This release updates exactly one Lean proof module, the Theorem 3.3 finite
sign/parity frontier. The remaining 45 core Lean modules have unchanged source
bytes, and previously certified modules are reused.

Your v0.3.8 compiler reported `sorryAx` in `weightFiveDetExponent_eq` (and hence
`weightFiveDetExponent_sign`) plus an unsolved positivity goal in
`first_pole_slope_signed_pos`. The fix:

1. Proves the division-by-two lemma with *abstract naturals* using `omega`.
   Substitutes the determinant numerator identity by an explicit `calc`, not
   `convert ... <;> ring`.
2. Converts first-pole positivity to multiplication of `div_pos` and `pow_pos`.
   Uses `simpa only [div_eq_mul_inv, mul_assoc]` to align associative product
   expressions without an unclosed inequality tactic.
3. Adds axiom reports for the source numerator identity and consecutive parity.
   All nine finite-sign declarations must be reported before the runner issues
   its dedicated Theorem 3.3 certification receipt.

Theorem 3.3 remains partial in the *mathematical sense*: positivity of arbitrary
Gram minors and full spectral signature have not yet been formalized here.

The launcher includes exactly one `run.cmd`, pinned Lean 4.33.0 with direct
16-thread startup and the persistent previously certified cache. No Lean
compilation, proof checks, or Lean kernel execution was performed by the
assistant. Successful compilation and axiom checks remain to be performed on
**your compiler**.

## Copyable Windows CMD command

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_9_T33_PROOF_FIX_FAST16.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_9_T33_PROOF_FIX_FAST16\run.cmd"
```

Required footer: `T33_AXIOM_CERTIFICATION=PASS`, `LEAN_BUILD=PASS`,
`BUILD=PASS`, `RELEASE=ZETAHYPERBOLIC_v0_3_9_T33_PROOF_FIX_FAST16`.
