# v0.3.21 — exclusive Windows cache writer / signed-core certification

This is an infrastructure-only repair of v0.3.20. Every Lean `.lean` source file is **byte-for-byte unchanged**.

The prior compiler reported the German Windows file-sharing violation while compiling `Theorem_3_3_Signed_Product_Core`, and the shared `_last_module.log` lacked the required axiom lines. This did not establish a Lean proof error: the output stream was unavailable.

- A single root-level `run.cmd` now obtains an **atomic directory lock** around the shared output/cache, including during all source snapshot, `.olean`, certificate and log operations. Other v0.3.21 runners using that shared cache wait. Older pre-v0.3.21 runners do not participate in the lock, so do not launch an older `run.cmd` simultaneously.
- Each execution uses a unique package-local `_LEAN_MODULE_*_V0321.log` instead of the global shared `_last_module.log`.
- `Theorem_3_3_Signed_Product_Core` is forced to compile once and has a dedicated axiom-certificate receipt which is required for frozen reuse. A `.olean` is committed only after both axiom lines are present and there is no `sorryAx`.
- Previously certified, byte-identical sources remain eligible for frozen-pass reuse, respecting dependency fingerprints and the pinned Lean/Mathlib configuration.
- `BUILD=PASS` is emitted only on a complete run with the required certificate checks. Any Lean errors remain in the local `CHRONOLOGICAL_BUILD.log` and `CHRONOLOGICAL_AXIOMS.log`.
- This package has not been compiled on the packaging machine. Only the user's native Windows Lean 4.33.0 compiler performs verification.

If a previous process is forcibly terminated while it holds `...\zetahyperbolic_chronological_verified_v1\_exclusive_writer_lock`, the lock can remain. Make sure no compiler is still running before manually deleting the stale lock directory.
