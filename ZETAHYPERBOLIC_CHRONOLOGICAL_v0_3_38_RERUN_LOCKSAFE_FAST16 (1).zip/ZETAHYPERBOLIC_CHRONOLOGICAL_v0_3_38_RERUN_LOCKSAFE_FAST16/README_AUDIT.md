# Zetahyperbolic — source-grounded Lean audit, 24 October 2026

## Actual scope

This package preserves **the complete 60-Lean-file source graph** from the
user-supplied `Zetahyperbolic-general-assembled-lean433 (2).zip` except that
its root Lake registration has been extended for three new source modules.
Its source already reported a Lean 4.33.0 compiled proof of the unconditional
**general odd-weight spectral** endpoint and actual analytic moment identity.
The unchanged source is preserved here for reproducibility.

New modules:

- `PAPER_CORRECTIONS.lean`: exact normalization correction for Proposition
  3.2; a concrete `h=1` counterexample to the continued fraction printed in
  Corollary 3.5; finite-rank obstruction to Corollary 3.6.
- `Theorem_5_4_Even_Pole_Pair_Cancellation.lean`: unconditional algebraic
  cancellation using the original `harmonicWeight` definition.
- `PAPER_AUDIT.lean`: checked theorem declarations and transitive axiom audit.

There are **no `sorry`, `admit`, project-defined axiom declarations, or
placeholder proofs in the new Lean modules**. The attached original 60 source
modules were also scanned for theorem-affecting admissions. `#print axioms`
uses Mathlib/Lean's standard logical principles, which are not mathematical
assumptions about the zeta values.

This packet has **not** been compiled in the preparation container: no Lean
executable or compatible Mathlib dependency was installed there. The base
archive contains earlier Lean 4.33 validation reports; those reports cannot
certify the three new modules. Run the supplied Windows script to obtain a
fresh local result and inspect the printed axiom dependencies.

## Native Windows

Extract, then run from Windows CMD:

```cmd
call run.cmd
```

Requires Lean 4.33.0, Lake, and the pinned Mathlib source/cache. Offline builds
are possible if those dependencies are already installed. Build results appear
in `PAPER_AUDIT_BUILD.log` and `PAPER_AUDIT_AXIOMS.log`.

## Nonclosure of the entire PDF

The uploaded 52-page paper cannot be certified exactly as printed because
Corollaries 3.5 and 3.6, and the normalization assertion in Proposition 3.2,
require mathematical correction. The finite `h=1` check is particularly
conclusive. Other paper sectors require substantial analytic, p-adic, and
asymptotic lemmas not supplied by these modules.

The general odd-weight spectral theorem is **not** irrationality. The
conditional endpoint `all_odd_zeta_irrational` explicitly assumes
`OddWeightDecayHypothesis k` at every weight. The corresponding statement
for zeta(5) requires normalized quadratic smallness of the actual primitive
integer Hankel determinants. Neither assertion is discharged in this packet.

See `PAPER_BLOCKERS.md` and `CROSS_BRANCH_MAP.md` for faithful correspondence.
