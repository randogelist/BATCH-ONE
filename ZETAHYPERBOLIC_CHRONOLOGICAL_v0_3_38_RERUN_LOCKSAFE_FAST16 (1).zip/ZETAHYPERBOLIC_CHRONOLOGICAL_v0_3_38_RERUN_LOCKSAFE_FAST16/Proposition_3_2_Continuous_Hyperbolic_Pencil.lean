import MAIN_CHAIN_ASSEMBLED
import Theorem_2_5_Lagrange_Pole_Diagonalization
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Theorem_3_1_Hyperbolic_Weight

/-!
# Proposition 3.2 — corrected continuous-weight pencil: chronological frontier

The PDF's displayed coefficient `(2*pi)^s/(2*Gamma(s))` differs from
its odd-integer coefficient (3.1) by `pi/2`. The coefficient required
for exact agreement is `2*(2*pi)^(s-1)/Gamma(s)`.

This module proves the corrected coefficient's positivity, its *exact*
odd-integer specialization, the continuous Lagrange slope's nonsingularity,
and the hyperbolicity of the reference-base family obtained by retaining the
already proved positive Gram matrix of Theorem 3.1.

CAUTION: That reference-base family is NOT, for nonintegral `s`, the paper's
actual integral matrix `A(s)`. The exact real-s analytic Gram construction and
its positivity are the remaining components of Proposition 3.2, so the
manuscript proposition is marked PARTIAL in the register. No axiom or sorry
is used to fill this analytic gap.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory Set

namespace ManuscriptChronology.Proposition3_2

/-- Corrected continuous prefactor, matching the paper's odd-weight density. -/
def correctedPrefactor (s : ℝ) : ℝ :=
  2 * (2 * Real.pi) ^ (s - 1) / Real.Gamma s

/-- The coefficient of equation (3.1). -/
def oddPrefactor (k : ℕ) : ℝ :=
  2 * (2 * Real.pi) ^ (2 * k) / (Nat.factorial (2 * k) : ℝ)

/-- The corrected coefficient is strictly positive for `s > 1`. -/
theorem correctedPrefactor_pos {s : ℝ} (hs : 1 < s) :
    0 < correctedPrefactor s := by
  unfold correctedPrefactor
  have hgamma : 0 < Real.Gamma s := Real.Gamma_pos_of_pos (by linarith)
  have hbase : 0 < (2 * Real.pi : ℝ) := by positivity
  exact div_pos (mul_pos (by norm_num) (Real.rpow_pos_of_pos hbase (s - 1))) hgamma

/-- The real-s formula specializes exactly to the odd-integer formula. -/
theorem correctedPrefactor_at_odd (k : ℕ) :
    correctedPrefactor ((2 * k + 1 : ℕ) : ℝ) = oddPrefactor k := by
  unfold correctedPrefactor oddPrefactor
  have hexp : (((2 * k + 1 : ℕ) : ℝ) - 1) = ((2 * k : ℕ) : ℝ) := by
    push_cast
    ring
  have harg : ((2 * k + 1 : ℕ) : ℝ) = ((2 * k : ℕ) : ℝ) + 1 := by
    push_cast
    ring
  rw [hexp, Real.rpow_natCast, harg, Real.Gamma_nat_eq_factorial]


/-- The actual summand for the PDF's continuous real-order weight. -/
def continuousTerm (s : ℝ) (n : ℕ) (y : ℝ) : ℝ :=
  (((n + 1 : ℕ) : ℝ) ^ (s - 1)) *
    Real.exp (-(2 * Real.pi * y) * ((n + 1 : ℕ) : ℝ))

/-- The corrected real-order density, with no hidden analytic hypothesis. -/
def continuousDensity (s y : ℝ) : ℝ :=
  correctedPrefactor s * y ^ s * ∑' n : ℕ, continuousTerm s n y

/-- The concrete integral Gram matrix described in Proposition 3.2. It is
*defined* here; strict positivity and integrability for arbitrary real s
remain separate unproved goals. -/
def continuousIntegralGram (p : ManuscriptChain.Real.Parameters) (s : ℝ) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  fun i j => ∫ y : ℝ in Ioi 0,
    ((Zetahyperbolic.D_real p.N (y ^ 2) ^ (2 * p.m)) /
      Zetahyperbolic.D_real p.K (y ^ 2)) *
      y ^ (2 * (i.val + j.val)) * continuousDensity s y

/-- An exact summand-level identification at every odd weight. -/
theorem continuousTerm_at_odd (k n : ℕ) (y : ℝ) :
    continuousTerm ((2 * k + 1 : ℕ) : ℝ) n y =
      ManuscriptChain.Hyperbolic.exponentialTerm k n y := by
  have hexp : (((2 * k + 1 : ℕ) : ℝ) - 1) = ((2 * k : ℕ) : ℝ) := by
    push_cast
    ring
  -- Avoid a broad `simp` proof: this is exactly a cast and exponent identity.
  unfold continuousTerm ManuscriptChain.Hyperbolic.exponentialTerm
  rw [hexp, Real.rpow_natCast]

/-- The corrected density agrees with (3.1) at each odd integer weight.
Proof version: CHRONOLOGICAL_PROPOSITION_3_2_AXIOM_CERTIFIED_SOURCE_20261024_V036.
The `change` below exposes precisely the three equalities to be checked;
no automatic nonterminal simplification goals are suppressed. -/
theorem continuousDensity_at_odd (k : ℕ) (y : ℝ) :
    continuousDensity ((2 * k + 1 : ℕ) : ℝ) y =
      ManuscriptChain.Hyperbolic.density k y := by
  have hsum :
      (∑' n : ℕ, continuousTerm ((2 * k + 1 : ℕ) : ℝ) n y) =
        ∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm k n y :=
    tsum_congr (fun n => continuousTerm_at_odd k n y)
  change correctedPrefactor ((2 * k + 1 : ℕ) : ℝ) *
      y ^ (((2 * k + 1 : ℕ) : ℝ)) *
        (∑' n : ℕ, continuousTerm ((2 * k + 1 : ℕ) : ℝ) n y) =
      oddPrefactor k * y ^ (2 * k + 1) *
        (∑' n : ℕ, ManuscriptChain.Hyperbolic.exponentialTerm k n y)
  rw [correctedPrefactor_at_odd, Real.rpow_natCast, hsum]

/-- Strict positivity of the real-order summand on the positive axis. -/
theorem continuousTerm_pos (s : ℝ) (n : ℕ) {y : ℝ} (_hy : 0 < y) :
    0 < continuousTerm s n y := by
  unfold continuousTerm
  have hn : 0 < (((n + 1 : ℕ) : ℝ)) := by positivity
  exact mul_pos (Real.rpow_pos_of_pos hn (s - 1)) (Real.exp_pos _)

/-- Positivity of the density from series convergence; the convergence
proof for all real s > 1 is not part of the current checkpoint. -/
theorem continuousDensity_pos_of_summable (s y : ℝ) (hs : 1 < s)
    (hy : 0 < y) (hterm : Summable (fun n => continuousTerm s n y)) :
    0 < continuousDensity s y := by
  have hsum : 0 < ∑' n : ℕ, continuousTerm s n y :=
    hterm.tsum_pos (fun n => (continuousTerm_pos s n hy).le)
      0 (continuousTerm_pos s 0 hy)
  unfold continuousDensity
  exact mul_pos (mul_pos (correctedPrefactor_pos hs)
    (Real.rpow_pos_of_pos hy s)) hsum

/-- Real-order Lagrange coefficient using exactly the negative-square poles
of Theorem 2.5. At odd integer s, it reduces to the rational slope weight. -/
def continuousPoleWeight (p : ManuscriptChain.Real.Parameters)
    (s : ℝ) (i : Fin p.h) : ℝ :=
  (ManuscriptChain.PoleDiagonalization.poleWeight p i : ℝ) *
    (ManuscriptChain.PoleDiagonalization.poleIndex p i : ℝ) ^ (s - 1) /
    (ManuscriptChain.PoleDiagonalization.poleIndex p i : ℝ) ^ (2 * p.k)

theorem continuousPoleWeight_ne_zero (p : ManuscriptChain.Real.Parameters)
    (s : ℝ) (i : Fin p.h) : continuousPoleWeight p s i ≠ 0 := by
  have hc : (ManuscriptChain.PoleDiagonalization.poleWeight p i : ℝ) ≠ 0 := by
    exact_mod_cast ManuscriptChain.PoleDiagonalization.poleWeight_ne_zero p i
  have ha : 0 < (ManuscriptChain.PoleDiagonalization.poleIndex p i : ℝ) := by
    exact_mod_cast ManuscriptChain.PoleDiagonalization.poleIndex_pos p i
  unfold continuousPoleWeight
  exact div_ne_zero
    (mul_ne_zero hc (Real.rpow_pos_of_pos ha (s - 1)).ne')
    (pow_ne_zero _ ha.ne')

/-- Matching to equation (2.11) at all odd integer weights. -/
theorem continuousPoleWeight_at_odd (p : ManuscriptChain.Real.Parameters)
    (i : Fin p.h) :
    continuousPoleWeight p (p.weight : ℝ) i =
      (ManuscriptChain.PoleDiagonalization.poleWeight p i : ℝ) := by
  have hexp : ((p.weight : ℝ) - 1) = ((2 * p.k : ℕ) : ℝ) := by
    unfold ManuscriptChain.Real.Parameters.weight
    push_cast
    ring
  have ha : 0 < (ManuscriptChain.PoleDiagonalization.poleIndex p i : ℝ) := by
    exact_mod_cast ManuscriptChain.PoleDiagonalization.poleIndex_pos p i
  have hpow :
      (ManuscriptChain.PoleDiagonalization.poleIndex p i : ℝ) ^ (2 * p.k) ≠ 0 :=
    pow_ne_zero _ ha.ne'
  unfold continuousPoleWeight
  rw [hexp, Real.rpow_natCast]
  field_simp [hpow]

/-- Vandermonde matrix transported from the exact rational lattice. -/
def continuousVandermonde (p : ManuscriptChain.Real.Parameters) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  (ManuscriptChain.PoleDiagonalization.poleVandermonde p).map (Rat.castHom ℝ)

theorem continuousVandermonde_det_ne_zero (p : ManuscriptChain.Real.Parameters) :
    (continuousVandermonde p).det ≠ 0 := by
  have h :
      ((ManuscriptChain.PoleDiagonalization.poleVandermonde p).det : ℝ) ≠ 0 := by
    exact_mod_cast ManuscriptChain.PoleDiagonalization.poleVandermonde_det_ne_zero p
  rw [Rat.cast_det] at h
  exact h

/-- The exact real-order coefficient matrix from the Lagrange pole formula. -/
def continuousDirection (p : ManuscriptChain.Real.Parameters) (s : ℝ) :
    Matrix (Fin p.h) (Fin p.h) ℝ :=
  continuousVandermonde p * Matrix.diagonal (continuousPoleWeight p s) *
    (continuousVandermonde p).transpose

theorem continuousDirection_symmetric (p : ManuscriptChain.Real.Parameters)
    (s : ℝ) : (continuousDirection p s).IsSymm := by
  change (continuousDirection p s).transpose = continuousDirection p s
  simp [continuousDirection, Matrix.transpose_mul, Matrix.mul_assoc]

/-- This nonsingularity needs no Gram or odd-zeta hypothesis. -/
theorem continuousDirection_det_ne_zero (p : ManuscriptChain.Real.Parameters)
    (s : ℝ) : (continuousDirection p s).det ≠ 0 := by
  unfold continuousDirection
  rw [Matrix.det_mul, Matrix.det_mul, Matrix.det_transpose, Matrix.det_diagonal]
  exact mul_ne_zero
    (mul_ne_zero (continuousVandermonde_det_ne_zero p)
      (Finset.prod_ne_zero_iff.mpr
        (fun i _ => continuousPoleWeight_ne_zero p s i)))
    (continuousVandermonde_det_ne_zero p)

/-- A *reference-base* interpolation pencil. This is a proved finite spectral
bridge, but it is not presented as the paper's noninteger-weight integral Gram. -/
def referencePencil (p : ManuscriptChain.Real.Parameters) (s : ℝ) :
    ManuscriptChain.Spectral.SymmetricAffinePencil p.h where
  center := ManuscriptChain.Real.zeta p.weight
  base := ManuscriptChain.Real.gram p (ManuscriptChain.Real.zeta p.weight)
  direction := continuousDirection p s
  base_symmetric := ManuscriptChain.Real.gram_symmetric p _
  direction_symmetric := continuousDirection_symmetric p s

/-- Full spectral conclusion for the constructed reference-base pencil.
No new analytic input is assumed: the base's positive definiteness comes
from the previously proved Theorem 3.1 realization. -/
theorem referencePencil_degree (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) (s : ℝ) :
    (referencePencil p s).detPolynomial.natDegree = p.h :=
  ManuscriptChain.Spectral.theorem_3_1_degree_of_posDef
    (referencePencil p s) (ManuscriptChain.GRAM_POSITIVE p hp)
    (continuousDirection_det_ne_zero p s)

theorem referencePencil_roots_real (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) (s : ℝ) (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z
      (referencePencil p s).detPolynomial = 0) :
    z.im = 0 :=
  ManuscriptChain.Spectral.theorem_3_1_hyperbolicity_of_posDef
    (referencePencil p s) (ManuscriptChain.GRAM_POSITIVE p hp)
    (continuousDirection_det_ne_zero p s) z hz

end ManuscriptChronology.Proposition3_2

#eval "RELEASE_V036_CONTINUOUS_DENSITY_AXIOM_CERTIFICATION"
#print axioms ManuscriptChronology.Proposition3_2.correctedPrefactor_at_odd
#print axioms ManuscriptChronology.Proposition3_2.continuousTerm_at_odd
#print axioms ManuscriptChronology.Proposition3_2.continuousDensity_at_odd
#print axioms ManuscriptChronology.Proposition3_2.continuousDensity_pos_of_summable
#print axioms ManuscriptChronology.Proposition3_2.continuousTerm_pos
#print axioms ManuscriptChronology.Proposition3_2.continuousPoleWeight_ne_zero
#print axioms ManuscriptChronology.Proposition3_2.continuousPoleWeight_at_odd
#print axioms ManuscriptChronology.Proposition3_2.continuousDirection_det_ne_zero
#print axioms ManuscriptChronology.Proposition3_2.referencePencil_degree
#print axioms ManuscriptChronology.Proposition3_2.referencePencil_roots_real
