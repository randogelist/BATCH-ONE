# v0.3.34 -- det sign, direct equality transport

- Keeps the previously certified sources unchanged byte-for-byte.
- Rewrites the remaining `signed_pole_product_positive` proof as an explicit
  `congrArg` transport from positivity of the *actual* signed-product factors.
- Adds a separate certified-input module proving unconditional exact-degree,
  derivative-det nonvanishing, and leading coefficient nonvanishing directly
  from the already Lean-proved Theorem 2.5.
- Builds the independent new module before the outstanding fine sign theorem.
- Axiom scans retain a hard failure on `sorryAx`.
- The sign theorem is not certified until your Windows Lean 4.33 compiler
  reports its clean proof; absence of source-level `sorry` is insufficient.
- No local Lean compilation was performed for this package.
