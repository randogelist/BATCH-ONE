# Theorem 3.3 – v0.3.10 compiler-targeted repair

**Status:** uncompiled. Please run the single `run.cmd` on the user's Lean 4.33.0 installation.

## Fixes against the user's v0.3.9 log

1. Removed an ineffective `simp only [Nat.succ_eq_add_one]` from `weightFive_exponent_numerator`. The same successor-case arithmetic rewrites and exact `ring` identity remain.
2. Replaced the ill-parenthesized positivity expression in `first_pole_slope_signed_pos` with local abbreviations `node`, `numerator`, `denominator`, `factor`, and explicit positivity of `(sign*numerator)/denominator * factor`.
3. Used an algebraic equality between the quotient product and the signed pole weight. All assumptions are precisely the same as in v0.3.9.
4. Updated the T33 source marker, mandatory proof/axiom certificate filename, and unique release identifier.

**Frozen-pass policy:** Proposition 3.2 and other previously certified, source-identical modules are reused. T33 and the imported chronological main are compiled and certified again.

**Not claimed:** the full Theorem 3.3 (arbitrary total positivity and full inertia/signature) remains an unfinished development.

**No Lean build was executed while preparing this archive.**
