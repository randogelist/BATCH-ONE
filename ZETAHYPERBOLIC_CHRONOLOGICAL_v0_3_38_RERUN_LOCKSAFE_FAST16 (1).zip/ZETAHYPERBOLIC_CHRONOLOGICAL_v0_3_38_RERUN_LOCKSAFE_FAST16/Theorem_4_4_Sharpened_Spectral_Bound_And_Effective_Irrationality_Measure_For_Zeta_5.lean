import Theorem_2_5_Lagrange_Pole_Diagonalization
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.RingTheory.Localization.Integral
import Mathlib.RingTheory.Localization.FractionRing
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Algebra.Polynomial.Roots

/-!
# Theorem 4.4 (Sharpened spectral bound and effective irrationality measure for ζ(5))

PDF pp. 16-18. Conditional formalization for the actual K = 30n, N = 3n
determinant family. The endpoint inputs are MainNormalization, BaseValuePositive, MultiplierUpper,
ArchimedeanUpper, and MainSpectralData. IndexBudget is now proved using the
paper's rounded logarithmic index and an explicit denominator threshold.
The determinant degree and index selection are independent of spectral inputs.
The Gram route proves derivative nonsingularity using Theorem 2.5 and constructs
the spectral factors; its quantitative beta bound remains an explicit input.
The quantitative determinant estimates remain inputs. Plain denominator
clearing is constructed and proved unsuitable for MultiplierUpper. The final
endpoints also identify the target with Mathlib's named riemannZeta function.
The final primitive-family endpoints construct the normalization internally.
They require only a starting index and four uniform proof obligations: Gram
positivity, the primitive multiplier bound, the archimedean determinant bound,
and the quantitative spectral bound. Those four estimates are not proved here.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Real

def mainParameters (n : ℕ) : Parameters := ⟨2, 3, 3 * n, 30 * n⟩

def section4Scale (n : ℕ) : ℚ :=
  let p := mainParameters n
  (Nat.factorial p.K : ℚ) ^ (2 * p.h) * 4 ^ (p.h - 1) /
    ((Nat.factorial p.N : ℚ) ^ (12 * p.h) *
      ∏ i ∈ Finset.Icc 1 (p.h - 1), (Nat.factorial (2 * i) : ℚ) ^ 2)

def mainDelta (n : ℕ) : ℚ[X] := delta (mainParameters n)
def mainF (n : ℕ) : ℚ[X] := C (section4Scale n) * mainDelta n

def epsilon : ℚ := 1 / 2500
def rhoPrinted : ℚ := 11411 / 1000
def rhoRepaired : ℚ := 11407 / 1000

end ManuscriptChain.Real

namespace ManuscriptChain.MainChain

open Polynomial
open RealTransfer

def zeta5 : ℝ := Real.zeta 5

def mainK (n : ℕ) : ℝ := ((Real.mainParameters n).K : ℝ)

@[simp] theorem mainK_eq (n : ℕ) : mainK n = (30 * n : ℕ) := rfl

structure MainNormalization where
  Q : ℕ → Polynomial ℤ
  multiplier : ℕ → ℚ
  onset : ℕ
  onset_ge_one : 1 ≤ onset
  multiplier_pos : ∀ n, onset ≤ n → 0 < multiplier n
  polynomial_identity : ∀ n, onset ≤ n →
    (Q n).map (algebraMap ℤ ℚ) = C (multiplier n) * Real.mainF n

theorem MainNormalization.eval_transport (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) (x : ℝ) :
    evalReal (A.Q n) x = (A.multiplier n : ℝ) * Real.evalQ (Real.mainF n) x := by
  have hcomp : (Rat.castHom ℝ).comp (Int.castRingHom ℚ) = Int.castRingHom ℝ := by
    ext z
    simp
  calc
    evalReal (A.Q n) x = Real.evalQ ((A.Q n).map (algebraMap ℤ ℚ)) x := by
      simp [evalReal, Real.evalQ, Real.realPolynomial, Polynomial.map_map, hcomp]
    _ = Real.evalQ (C (A.multiplier n) * Real.mainF n) x :=
      congrArg (fun p : Polynomial ℚ => Real.evalQ p x) (A.polynomial_identity n hn)
    _ = (A.multiplier n : ℝ) * Real.evalQ (Real.mainF n) x := by
      simp [Real.evalQ, Real.realPolynomial]

structure BaseValuePositive (onset : ℕ) : Prop where
  positive : ∀ n, onset ≤ n → 0 < Real.evalQ (Real.mainF n) zeta5

def multiplierRate : ℝ := -232425 / 100000 + 1 / 100000

def archimedeanRate : ℝ := 232380 / 100000 + 1 / 100000

def decayBudget (n : ℕ) : ℝ := _root_.Real.exp (-(1 / 2500 : ℝ) * (mainK n) ^ 2)

structure MultiplierUpper (A : MainNormalization) : Prop where
  upper : ∀ n, A.onset ≤ n →
    (A.multiplier n : ℝ) ≤ _root_.Real.exp (multiplierRate * (mainK n) ^ 2)

structure ArchimedeanUpper (onset : ℕ) : Prop where
  upper : ∀ n, onset ≤ n →
    Real.evalQ (Real.mainF n) zeta5 ≤
      _root_.Real.exp (archimedeanRate * (mainK n) ^ 2)

theorem combined_rate_le : multiplierRate + archimedeanRate ≤ -(1 / 2500 : ℝ) := by
  norm_num [multiplierRate, archimedeanRate]

theorem normalized_value_pos (A : MainNormalization)
    (positive : BaseValuePositive A.onset) (n : ℕ) (hn : A.onset ≤ n) :
    0 < evalReal (A.Q n) zeta5 := by
  rw [A.eval_transport n hn]
  exact mul_pos (by exact_mod_cast A.multiplier_pos n hn) (positive.positive n hn)

theorem main_decay (A : MainNormalization)
    (positive : BaseValuePositive A.onset)
    (multiplier : MultiplierUpper A)
    (archimedean : ArchimedeanUpper A.onset) :
    Decay A.Q zeta5 decayBudget A.onset := by
  constructor
  · intro n hn
    exact ne_of_gt (normalized_value_pos A positive n hn)
  · intro n hn
    have hpos := normalized_value_pos A positive n hn
    rw [abs_of_pos hpos, A.eval_transport n hn]
    calc
      (A.multiplier n : ℝ) * Real.evalQ (Real.mainF n) zeta5
          ≤ _root_.Real.exp (multiplierRate * (mainK n) ^ 2) *
            _root_.Real.exp (archimedeanRate * (mainK n) ^ 2) :=
        mul_le_mul (multiplier.upper n hn) (archimedean.upper n hn)
          (le_of_lt (positive.positive n hn)) (le_of_lt (_root_.Real.exp_pos _))
      _ = _root_.Real.exp ((multiplierRate + archimedeanRate) * (mainK n) ^ 2) := by
        rw [← _root_.Real.exp_add]
        congr 1
        ring
      _ ≤ decayBudget n := by
        apply _root_.Real.exp_le_exp.mpr
        exact mul_le_mul_of_nonneg_right combined_rate_le (sq_nonneg (mainK n))

end ManuscriptChain.MainChain

namespace ManuscriptChain.MainChain

open RealTransfer

@[simp] theorem main_dimension (n : ℕ) : (Real.mainParameters n).h = 27 * n := by
  dsimp [Real.mainParameters, Real.Parameters.h]
  omega

theorem section4Scale_pos (n : ℕ) : 0 < Real.section4Scale n := by
  have hfactorial : ∀ j : ℕ, (0 : ℚ) < (Nat.factorial j : ℚ) := by
    intro j
    exact_mod_cast Nat.factorial_pos j
  dsimp only [Real.section4Scale]
  apply div_pos
  · exact mul_pos (pow_pos (hfactorial _) _) (pow_pos (by norm_num) _)
  · exact mul_pos (pow_pos (hfactorial _) _)
      (Finset.prod_pos (fun i _ => pow_pos (hfactorial _) _))

theorem section4Scale_real_pos (n : ℕ) : (0 : ℝ) < (Real.section4Scale n : ℝ) := by
  exact_mod_cast section4Scale_pos n

def normalizationScale (A : MainNormalization) (n : ℕ) : ℝ :=
  (A.multiplier n : ℝ) * (Real.section4Scale n : ℝ)

theorem normalizationScale_pos (A : MainNormalization) (n : ℕ)
    (hn : A.onset ≤ n) : 0 < normalizationScale A n := by
  exact mul_pos (by exact_mod_cast A.multiplier_pos n hn) (section4Scale_real_pos n)

theorem MainNormalization.eval_spectral_transport (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) (x : ℝ) :
    evalReal (A.Q n) x = normalizationScale A n *
      (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial.eval x := by
  rw [A.eval_transport n hn, Real.manuscriptPencil_detPolynomial]
  simp [Real.mainF, Real.mainDelta, Real.evalQ, Real.realPolynomial,
    normalizationScale, mul_assoc]

theorem MainNormalization.spectral_polynomial_identity (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) :
    (A.Q n).map (algebraMap ℤ ℝ) = C (normalizationScale A n) *
      (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial := by
  apply Polynomial.funext
  intro x
  simpa [evalReal] using A.eval_spectral_transport n hn x

theorem MainNormalization.inverse_spectral_polynomial_identity (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) :
    (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial =
      C ((normalizationScale A n)⁻¹) * (A.Q n).map (algebraMap ℤ ℝ) := by
  rw [A.spectral_polynomial_identity n hn, ← mul_assoc, ← map_mul,
    inv_mul_cancel₀ (ne_of_gt (normalizationScale_pos A n hn)), map_one, one_mul]

def printedSpectralBound (n : ℕ) : ℝ :=
  _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)

theorem printedSpectralBound_pos (n : ℕ) : 0 < printedSpectralBound n :=
  _root_.Real.exp_pos _

def mainSpectralRadius (n : ℕ) : ℝ :=
  Spectral.comparisonRadius (Real.mainParameters n).h (printedSpectralBound n)

theorem mainSpectralRadius_pos (n : ℕ) : 0 < mainSpectralRadius n :=
  Spectral.comparisonRadius_pos _ _ (printedSpectralBound_pos n)

structure MainSpectralData (onset : ℕ) where
  factorization : ∀ n, onset ≤ n →
    Spectral.RootFactorization (Real.manuscriptPencil (Real.mainParameters n))
  beta_bound : ∀ n (hn : onset ≤ n) i,
    |(factorization n hn).beta i| ≤
      _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)

/-- The degree is algebraic: it follows from the nonzero pole-slope determinant. -/
theorem MainNormalization.natDegree_eq (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) :
    (A.Q n).natDegree = 27 * n := by
  have hinj : Function.Injective (algebraMap ℤ ℚ) := by
    intro a b hab
    exact_mod_cast hab
  calc
    (A.Q n).natDegree = ((A.Q n).map (algebraMap ℤ ℚ)).natDegree :=
      (Polynomial.natDegree_map_eq_of_injective hinj (A.Q n)).symm
    _ = (C (A.multiplier n) * Real.mainF n).natDegree := by
      rw [A.polynomial_identity n hn]
    _ = (Real.mainF n).natDegree :=
      Polynomial.natDegree_C_mul (ne_of_gt (A.multiplier_pos n hn))
    _ = (Real.mainDelta n).natDegree :=
      Polynomial.natDegree_C_mul (ne_of_gt (section4Scale_pos n))
    _ = (Real.mainParameters n).h :=
      PoleDiagonalization.delta_natDegree (Real.mainParameters n)
    _ = 27 * n := main_dimension n

theorem MainNormalization.degree_rate (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) :
    ((A.Q n).natDegree : ℝ) = (9 / 10 : ℝ) * mainK n := by
  rw [A.natDegree_eq n hn, mainK_eq]
  push_cast
  ring

theorem main_localComparison (A : MainNormalization)
    (spectral : MainSpectralData A.onset) :
    LocalComparison A.Q zeta5 mainSpectralRadius A.onset := by
  apply Spectral.localComparison_of_spectral A.Q zeta5
    (fun n => (Real.mainParameters n).h)
    (fun n => Real.manuscriptPencil (Real.mainParameters n))
    printedSpectralBound (fun n => (normalizationScale A n)⁻¹) A.onset
    spectral.factorization
  · intro n _hn
    rfl
  · intro n _hn
    exact printedSpectralBound_pos n
  · intro n hn i
    exact spectral.beta_bound n hn i
  · intro n hn
    exact inv_ne_zero (ne_of_gt (normalizationScale_pos A n hn))
  · intro n hn
    exact A.inverse_spectral_polynomial_identity n hn

end ManuscriptChain.MainChain

namespace ManuscriptChain.MainChain

open RealTransfer

/-- A deliberately generous explicit logarithmic threshold. -/
def indexLogThreshold (onset : ℕ) : ℝ :=
  max 1000000 ((30 : ℝ) * onset / 2251)

/-- An explicit, noncomputable real-ceiling denominator threshold. -/
def indexDenominatorThreshold (onset : ℕ) : ℕ :=
  ⌈_root_.Real.exp (indexLogThreshold onset)⌉₊

def paperIndex (b : ℕ) : ℕ :=
  ⌈(2251 / 30 : ℝ) * _root_.Real.log b⌉₊

theorem log_ge_of_denominator_threshold (onset b : ℕ) (hb : 0 < b)
    (hthreshold : indexDenominatorThreshold onset ≤ b) :
    indexLogThreshold onset ≤ _root_.Real.log b := by
  apply (_root_.Real.le_log_iff_exp_le (by exact_mod_cast hb)).mpr
  exact (Nat.le_ceil _).trans (by exact_mod_cast hthreshold)

theorem paper_index_bounds (b : ℕ) (_hlog : 0 ≤ _root_.Real.log b) :
    2251 * _root_.Real.log b ≤ mainK (paperIndex b) ∧
    mainK (paperIndex b) ≤ 2251 * _root_.Real.log b + 30 := by
  have hlo := Nat.le_ceil ((2251 / 30 : ℝ) * _root_.Real.log b)
  have hhi := Nat.ceil_lt_add_one (show 0 ≤ (2251 / 30 : ℝ) * _root_.Real.log b by positivity)
  simp only [mainK_eq, Nat.cast_mul, Nat.cast_ofNat, paperIndex]
  constructor <;> linarith

theorem radius_exponential_margin (L K : ℝ) (hL : 1000000 ≤ L)
    (hK : K ≤ 2251 * L + 30) :
    8 * ((9 / 10 : ℝ) * K + 1) * _root_.Real.exp ((11411 / 1000 : ℝ) * K)
      ≤ _root_.Real.exp (25687 * L) := by
  have hL0 : 0 ≤ L := by linarith
  have hLsq : 1000000 * L ≤ L ^ 2 := by nlinarith [mul_nonneg (sub_nonneg.mpr hL) hL0]
  have hx : L / 2 ≤ 25687 * L - (11411 / 1000 : ℝ) * K := by linarith
  have hquad := _root_.Real.quadratic_le_exp_of_nonneg (show 0 ≤ L / 2 by positivity)
  have hfactor : 8 * ((9 / 10 : ℝ) * K + 1) ≤ _root_.Real.exp (L / 2) := by
    nlinarith
  calc
    8 * ((9 / 10 : ℝ) * K + 1) * _root_.Real.exp ((11411 / 1000 : ℝ) * K)
        ≤ _root_.Real.exp (L / 2) * _root_.Real.exp ((11411 / 1000 : ℝ) * K) :=
      mul_le_mul_of_nonneg_right hfactor (le_of_lt (_root_.Real.exp_pos _))
    _ = _root_.Real.exp (L / 2 + (11411 / 1000 : ℝ) * K) := (_root_.Real.exp_add _ _).symm
    _ ≤ _root_.Real.exp (25687 * L) := _root_.Real.exp_le_exp.mpr (by linarith)

theorem decay_exponent_margin (L K : ℝ) (hL : 1000000 ≤ L)
    (hK : 2251 * L ≤ K) :
    (9 / 10 : ℝ) * K * L - (1 / 2500 : ℝ) * K ^ 2 ≤ -2 := by
  have hL0 : 0 ≤ L := by linarith
  have hK0 : 0 ≤ K := by linarith
  have hmul : 2251 * K * L ≤ K ^ 2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hK) hK0]
  have hKL : 5000 ≤ K * L := by
    have hK1 : 5000 ≤ K := by linarith
    nlinarith [mul_nonneg (sub_nonneg.mpr hK1) (show 0 ≤ L - 1 by linarith)]
  nlinarith

/-- The paper's index choice satisfies both transfer inequalities after an
explicit threshold; IndexBudget is consequently not an independent input. -/
theorem main_indexBudget (A : MainNormalization) :
    IndexBudget A.Q mainSpectralRadius decayBudget A.onset 25687
      (indexDenominatorThreshold A.onset) := by
  constructor
  intro b hb hthreshold
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  have hlog := log_ge_of_denominator_threshold A.onset b hb hthreshold
  have hL : 1000000 ≤ _root_.Real.log b :=
    (le_max_left _ _).trans hlog
  have honset : (30 : ℝ) * A.onset / 2251 ≤ _root_.Real.log b :=
    (le_max_right _ _).trans hlog
  let n := paperIndex b
  have bounds := paper_index_bounds b (show 0 ≤ _root_.Real.log b by linarith)
  change 2251 * _root_.Real.log b ≤ mainK n ∧
    mainK n ≤ 2251 * _root_.Real.log b + 30 at bounds
  have hn : A.onset ≤ n := by
    have hreal : (A.onset : ℝ) ≤ n := by
      have hK : mainK n = 30 * (n : ℝ) := by simp [mainK_eq]
      rw [hK] at bounds
      linarith [bounds.1]
    exact_mod_cast hreal
  refine ⟨n, hn, ?_, ?_⟩
  · have hdim : ((Real.mainParameters n).h : ℝ) = (9 / 10 : ℝ) * mainK n := by
      rw [main_dimension, mainK_eq]
      push_cast
      ring
    have hexp : _root_.Real.exp (25687 * _root_.Real.log (b : ℝ)) = (b : ℝ) ^ 25687 := by
      calc
        _root_.Real.exp (25687 * _root_.Real.log (b : ℝ)) =
            (_root_.Real.exp (_root_.Real.log (b : ℝ))) ^ 25687 := by
          simpa using _root_.Real.exp_nat_mul (_root_.Real.log (b : ℝ)) 25687
        _ = (b : ℝ) ^ 25687 := by rw [_root_.Real.exp_log hbR]
    have hden := radius_exponential_margin (_root_.Real.log b) (mainK n) hL bounds.2
    rw [hexp] at hden
    change 1 / (b : ℝ) ^ 25687 ≤
      1 / (8 * (((Real.mainParameters n).h : ℝ) + 1) * printedSpectralBound n)
    apply one_div_le_one_div_of_le
    · unfold printedSpectralBound
      positivity
    · rw [hdim]
      norm_num only [printedSpectralBound, Real.rhoPrinted, Rat.cast_div, Rat.cast_ofNat]
      exact hden
  · have hexp : (b : ℝ) ^ (A.Q n).natDegree =
        _root_.Real.exp (((A.Q n).natDegree : ℝ) * _root_.Real.log b) := by
      rw [_root_.Real.exp_nat_mul, _root_.Real.exp_log hbR]
    have hmargin : ((A.Q n).natDegree : ℝ) * _root_.Real.log b -
        (1 / 2500 : ℝ) * (mainK n) ^ 2 ≤ -2 := by
      rw [A.degree_rate n hn]
      exact decay_exponent_margin (_root_.Real.log b) (mainK n) hL bounds.1
    calc
      2 * (b : ℝ) ^ (A.Q n).natDegree * decayBudget n =
          2 * _root_.Real.exp (((A.Q n).natDegree : ℝ) * _root_.Real.log b -
            (1 / 2500 : ℝ) * (mainK n) ^ 2) := by
        rw [hexp, decayBudget, mul_assoc, ← _root_.Real.exp_add]
        congr 2
        ring
      _ ≤ 2 * _root_.Real.exp (-2) :=
        mul_le_mul_of_nonneg_left (_root_.Real.exp_le_exp.mpr hmargin) (by norm_num)
      _ < 1 := by
        rw [_root_.Real.exp_neg, ← div_eq_mul_inv]
        apply (div_lt_one (_root_.Real.exp_pos 2)).mpr
        linarith [_root_.Real.add_one_le_exp (2 : ℝ)]

theorem exists_main_indexBudget (A : MainNormalization) :
    ∃ b₀, IndexBudget A.Q mainSpectralRadius decayBudget A.onset 25687 b₀ :=
  ⟨indexDenominatorThreshold A.onset, main_indexBudget A⟩

end ManuscriptChain.MainChain

namespace ManuscriptChain.MainChain

theorem exists_positive_integer_polynomial_multiple (p : ℚ[X]) :
    ∃ m : ℚ, 1 ≤ m ∧ ∃ q : ℤ[X],
      q.map (algebraMap ℤ ℚ) = C m * p := by
  obtain ⟨d, hd, hq⟩ := IsLocalization.integerNormalization_spec (nonZeroDivisors ℤ) p
  have hd0 : d ≠ 0 := mem_nonZeroDivisors_iff_ne_zero.mp hd
  have hd2 : (1 : ℤ) ≤ d ^ 2 := by
    have hpos : 0 < d ^ 2 := sq_pos_of_ne_zero hd0
    omega
  refine ⟨(d : ℚ) ^ 2, by exact_mod_cast hd2,
    C d * IsLocalization.integerNormalization (nonZeroDivisors ℤ) p, ?_⟩
  rw [Polynomial.map_mul, Polynomial.map_C, hq]
  ext i
  simp only [coeff_C_mul]
  change (d : ℚ) * (d • p).coeff i = (d : ℚ) ^ 2 * p.coeff i
  rw [coeff_smul]
  simp only [zsmul_eq_mul]
  ring

/-- Algebraic denominator clearing for the manuscript's actual family.
This particular construction has multipliers at least one and cannot satisfy
the exponentially decreasing `MultiplierUpper` required at the endpoint. -/
def denominatorClearingNormalization : MainNormalization where
  Q n := (exists_positive_integer_polynomial_multiple (Real.mainF n)).choose_spec.2.choose
  multiplier n := (exists_positive_integer_polynomial_multiple (Real.mainF n)).choose
  onset := 1
  onset_ge_one := le_rfl
  multiplier_pos n _ := lt_of_lt_of_le (by norm_num)
    (exists_positive_integer_polynomial_multiple (Real.mainF n)).choose_spec.1
  polynomial_identity n _ :=
    (exists_positive_integer_polynomial_multiple (Real.mainF n)).choose_spec.2.choose_spec

theorem mainNormalization_nonempty : Nonempty MainNormalization :=
  ⟨denominatorClearingNormalization⟩

theorem denominatorClearingNormalization_multiplier_ge_one (n : ℕ) :
    1 ≤ denominatorClearingNormalization.multiplier n :=
  (exists_positive_integer_polynomial_multiple (Real.mainF n)).choose_spec.1

theorem MultiplierUpper.lt_one_at_onset (A : MainNormalization)
    (upper : MultiplierUpper A) : (A.multiplier A.onset : ℝ) < 1 := by
  have hK : 0 < mainK A.onset := by
    rw [mainK_eq]
    exact_mod_cast (show 0 < 30 * A.onset by have h := A.onset_ge_one; omega)
  have hrate : multiplierRate < 0 := by norm_num [multiplierRate]
  have hexp : _root_.Real.exp (multiplierRate * (mainK A.onset) ^ 2) < 1 :=
    _root_.Real.exp_lt_one_iff.mpr (mul_neg_of_neg_of_pos hrate (sq_pos_of_pos hK))
  exact lt_of_le_of_lt (upper.upper A.onset le_rfl) hexp

theorem not_multiplierUpper_of_one_le_at_onset (A : MainNormalization)
    (hone : (1 : ℚ) ≤ A.multiplier A.onset) : ¬ MultiplierUpper A := by
  intro h
  have honeR : (1 : ℝ) ≤ (A.multiplier A.onset : ℝ) := by exact_mod_cast hone
  exact (not_lt_of_ge honeR) (h.lt_one_at_onset A)

theorem denominatorClearingNormalization_no_multiplierUpper :
    ¬ MultiplierUpper denominatorClearingNormalization :=
  not_multiplierUpper_of_one_le_at_onset _
    (denominatorClearingNormalization_multiplier_ge_one _)

end ManuscriptChain.MainChain

namespace ManuscriptChain.MainChain

/-- The spectral factorization is constructed from the manuscript Gram matrix
and the derivative nonsingularity proved by Theorem 2.5.
No quantitative spectral estimate is asserted here. -/
noncomputable def mainRootFactorization (onset : ℕ)
    (gram : ∀ n, onset ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (n : ℕ) (hn : onset ≤ n) :
    Spectral.RootFactorization (Real.manuscriptPencil (Real.mainParameters n)) :=
  Spectral.rootFactorizationOfPosDef
    (Real.manuscriptPencil (Real.mainParameters n)) (gram n hn)
    (PoleDiagonalization.derivativeMatrix_det_ne_zero (Real.mainParameters n))

/-- Gram positive definiteness supplies the previous determinant-positivity input. -/
theorem baseValuePositive_of_gram (onset : ℕ)
    (gram : ∀ n, onset ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef) :
    BaseValuePositive onset := by
  constructor
  intro n hn
  have hdelta : 0 < Real.evalQ (Real.mainDelta n) zeta5 := by
    rw [Real.mainDelta, Real.delta_eval_eq_det_gram]
    exact (gram n hn).det_pos
  change 0 < Real.evalQ (C (Real.section4Scale n) * Real.mainDelta n) zeta5
  simpa [Real.evalQ, Real.realPolynomial] using
    mul_pos (section4Scale_real_pos n) hdelta

/-- The quantitative spectral bound remains an explicit input after constructing
the spectral factors from positive definiteness; derivative nonsingularity
is proved by Theorem 2.5. -/
noncomputable def mainSpectralDataOfGram (onset : ℕ)
    (gram : ∀ n, onset ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (bound : ∀ n (hn : onset ≤ n) i,
      |(mainRootFactorization onset gram n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)) :
    MainSpectralData onset where
  factorization := mainRootFactorization onset gram
  beta_bound := bound

end ManuscriptChain.MainChain

namespace ManuscriptChain

open MainChain RealTransfer

theorem theorem_4_4_measure_with_index
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset)
    {b₀ : ℕ}
    (index : IndexBudget normalization.Q mainSpectralRadius decayBudget
      normalization.onset 25687 b₀) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
      1 / (b : ℝ) ^ 25687 < |Real.zeta 5 - (a : ℝ) / (b : ℝ)| := by

  have comparison := main_localComparison normalization spectral

  have decay := main_decay normalization positive multiplier archimedean

  exact conditional_measure comparison decay index

theorem theorem_4_4_irrationality_with_index
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset)
    {b₀ : ℕ}
    (index : IndexBudget normalization.Q mainSpectralRadius decayBudget
      normalization.onset 25687 b₀) :
    Irrational (Real.zeta 5) := by
  have measure : RationalMeasure (Real.zeta 5) 25687 b₀ :=
    theorem_4_4_measure_with_index normalization positive multiplier archimedean spectral index
  exact measure.irrational


/-- Theorem 4.4 with the index-selection obligation fully discharged. -/
theorem theorem_4_4_measure
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → indexDenominatorThreshold normalization.onset ≤ b →
      1 / (b : ℝ) ^ 25687 < |Real.zeta 5 - (a : ℝ) / (b : ℝ)| :=
  theorem_4_4_measure_with_index normalization positive multiplier archimedean spectral
    (main_indexBudget normalization)

theorem theorem_4_4_irrationality
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset) :
    Irrational (Real.zeta 5) :=
  theorem_4_4_irrationality_with_index normalization positive multiplier archimedean spectral
    (main_indexBudget normalization)

theorem theorem_4_4_irrationality_riemannZeta
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset) :
    Irrational (riemannZeta 5).re := by
  rw [← Real.zeta_five_eq_riemannZeta_re]
  exact theorem_4_4_irrationality normalization positive multiplier archimedean spectral


/-- The paper's Gram-matrix route to the endpoint, with spectral factorization,
derivative nonsingularity, determinant positivity, and index selection proved
internally. The five inputs are normalization data and four uniform obligations. -/
theorem theorem_4_4_irrationality_from_gram
    (normalization : MainNormalization)
    (gram : ∀ n, normalization.onset ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (bound : ∀ n (hn : normalization.onset ≤ n) i,
      |(mainRootFactorization normalization.onset gram n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)) :
    Irrational (riemannZeta 5).re :=
  theorem_4_4_irrationality_riemannZeta normalization
    (baseValuePositive_of_gram normalization.onset gram) multiplier archimedean
    (mainSpectralDataOfGram normalization.onset gram bound)

end ManuscriptChain

namespace ManuscriptChain.MainChain

theorem mainF_ne_zero (n : ℕ) : Real.mainF n ≠ 0 := by
  apply mul_ne_zero
  · exact Polynomial.C_ne_zero.mpr (ne_of_gt (section4Scale_pos n))
  · exact PoleDiagonalization.delta_ne_zero (Real.mainParameters n)

/-- Primitive normalization of each actual determinant polynomial, with positive
rational scale. This constructs the algebraic data and supplies no multiplier
bound. -/
def primitiveMainPolynomialNormalization (n : ℕ) :
    BasisInvariance.PrimitiveNormalization (Real.mainF n) :=
  BasisInvariance.primitiveNormalization (Real.mainF n) (mainF_ne_zero n)

/-- The manuscript's actual primitive integer polynomial family. `start + 1`
is the common onset for the remaining uniform analytic and arithmetic inputs. -/
def primitiveMainNormalization (start : ℕ) : MainNormalization where
  Q n := (primitiveMainPolynomialNormalization n).polynomial
  multiplier n := (primitiveMainPolynomialNormalization n).scale
  onset := start + 1
  onset_ge_one := Nat.le_add_left 1 start
  multiplier_pos n _ := (primitiveMainPolynomialNormalization n).scale_pos
  polynomial_identity n _ := (primitiveMainPolynomialNormalization n).identity

theorem primitiveMainNormalization_isPrimitive (start n : ℕ) :
    ((primitiveMainNormalization start).Q n).IsPrimitive :=
  (primitiveMainPolynomialNormalization n).primitive

theorem primitiveMainNormalization_onset (start : ℕ) :
    (primitiveMainNormalization start).onset = start + 1 := rfl

end ManuscriptChain.MainChain

namespace ManuscriptChain

open MainChain RealTransfer

/-- The paper's quantitative endpoint for the internally constructed primitive
family, with the same four uniform obligations and proved denominator threshold. -/
theorem theorem_4_4_measure_primitive_from_gram
    (start : ℕ)
    (gram : ∀ n, start + 1 ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper (primitiveMainNormalization start))
    (archimedean : ArchimedeanUpper (start + 1))
    (bound : ∀ n (hn : start + 1 ≤ n) i,
      |(mainRootFactorization (start + 1) gram n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → indexDenominatorThreshold (start + 1) ≤ b →
      1 / (b : ℝ) ^ 25687 < |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| := by
  rw [← Real.zeta_five_eq_riemannZeta_re]
  exact theorem_4_4_measure (primitiveMainNormalization start)
    (baseValuePositive_of_gram (start + 1) gram) multiplier archimedean
    (mainSpectralDataOfGram (start + 1) gram bound)

/-- The normalized determinant family is constructed internally. Exactly four
uniform proof obligations remain beyond the chosen onset: Gram positivity,
the primitive multiplier estimate, the determinant estimate, and the bound
on the constructed spectral factors. -/
theorem theorem_4_4_irrationality_primitive_from_gram
    (start : ℕ)
    (gram : ∀ n, start + 1 ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper (primitiveMainNormalization start))
    (archimedean : ArchimedeanUpper (start + 1))
    (bound : ∀ n (hn : start + 1 ≤ n) i,
      |(mainRootFactorization (start + 1) gram n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)) :
    Irrational (riemannZeta 5).re :=
  theorem_4_4_irrationality_from_gram
    (primitiveMainNormalization start) gram multiplier archimedean bound

end ManuscriptChain
