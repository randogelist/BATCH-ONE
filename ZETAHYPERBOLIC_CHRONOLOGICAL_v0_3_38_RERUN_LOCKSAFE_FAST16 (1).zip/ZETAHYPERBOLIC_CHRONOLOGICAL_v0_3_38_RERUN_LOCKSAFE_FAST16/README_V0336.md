# v0.3.36 — determinant sign: direct finite transfer

The only rewritten Lean theorem is `signed_pole_product_positive`. It now invokes the
already source-proved generic finset positivity lemma
`ManuscriptChronology.Theorem3_3_DetSign.signed_prod_positive_by_induction`, which is
`#print axioms`-checked separately and is based on `signed_prod_identity` and
`Finset.prod_pos`. For every pole, factorwise positivity is inherited from the
certified all-pole sign module, without recursing over exponent sums.

This eliminates the unnecessary `negativeOne_pow_sum` whose case split caused
an unsolved goal in v0.3.35. The formal statement is unchanged. The dependent
original derivative determinant leading-coefficient implications are unchanged.

Previously certified source bytes are identical. The user's native Lean 4.33.0
compiler is the sole compile/axiom verification authority. Exactly one run.cmd.
