-- THEOREM33_WEIGHT_FIVE_LEADING_SIGN_V0316_20261024
import Theorem_3_3_Finite_Determinant_Sign
import Mathlib.Tactic

/-!
# Theorem 3.3(2): exact signed leading coefficient, weight five

This source specializes the general signed derivative determinant theorem to
the actual PDF family K=30n,N=3n,h=27n,m=3,k=2. First the finite index
sum is evaluated exactly. Then the parity certificate already compiled in
v0.3.10 transfers the sign from E(n) to the actual delta.leadingCoeff.

Neither a numerical experiment nor a hypothetical sign premise is needed.
The construction is entirely rational, independently of the later
archimedean and p-adic estimates.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChronology.Theorem3_3_WeightFiveSign
open ManuscriptChain
open ManuscriptChronology.Theorem3_3_DetSign

/-- Finite triangular-number recurrence with Nat's truncated subtraction. -/
private theorem triangle_step (h : ℕ) :
    ((h + 1) * h) / 2 = (h * (h - 1)) / 2 + h := by
  cases h with
  | zero => norm_num
  | succ k =>
      have hs : (k + 1) - 1 = k := by omega
      rw [hs]
      have hf : ((k + 1) + 1) * (k + 1) = (k + 1) * k + 2 * (k + 1) := by ring
      rw [hf]
      omega

/-- Exact finite arithmetic progression, no limiting sum. -/
private theorem sum_range_shift (N h : ℕ) :
    (∑ i ∈ Finset.range h, N + i) = h * N + (h * (h - 1)) / 2 := by
  induction h with
  | zero => simp
  | succ h ih =>
      rw [Finset.sum_range_succ, ih]
      have hs : (h + 1) - 1 = h := by omega
      rw [hs, triangle_step h]
      ring

/-- Exact global sign exponent for all rational pole lattices. -/
theorem signExponent_closed (p : Real.Parameters) :
    signExponent p = p.h * p.N + (p.h * (p.h - 1)) / 2 := by
  have hfin :
      (∑ i : Fin p.h, p.N + i.val) =
        (∑ i ∈ Finset.range p.h, p.N + i) := by
    simpa using
      (Fin.sum_univ_eq_sum_range (fun i : ℕ => p.N + i) p.h)
  change (∑ i : Fin p.h, p.N + i.val) = _
  rw [hfin]
  exact sum_range_shift p.N p.h

/-- Specialization at K=30n, N=3n, h=27n. -/
theorem signExponent_weightFive (n : ℕ) :
    signExponent (ManuscriptChronology.Theorem3_3.weightFiveParameters n) =
      (27 * n) * (3 * n) + ((27 * n) * (27 * n - 1)) / 2 := by
  rw [signExponent_closed, ManuscriptChronology.Theorem3_3.weightFive_dimension]
  rfl

/-- Paper exponent E(n) differs from the actual all-pole exponent by 324n²,
which is always even. -/
theorem weightFive_exponent_relation (n : ℕ) :
    ManuscriptChronology.Theorem3_3.weightFiveDetExponent n =
      signExponent (ManuscriptChronology.Theorem3_3.weightFiveParameters n) +
        324 * n ^ 2 := by
  rw [signExponent_weightFive]
  dsimp [ManuscriptChronology.Theorem3_3.weightFiveDetExponent]
  ring

/-- Sign agreement with the exact parity n(n-1)/2 in Theorem 3.3(2). -/
theorem weightFive_signExponent_parity (n : ℕ) :
    (-1 : ℚ) ^
       (signExponent (ManuscriptChronology.Theorem3_3.weightFiveParameters n)) =
      (-1 : ℚ) ^ ((n * (n - 1)) / 2) := by
  have heven : (-1 : ℚ) ^ (324 * n ^ 2) = 1 := by
    have hfactor : 324 * n ^ 2 = 2 * (162 * n ^ 2) := by ring
    rw [hfactor, pow_mul]
    norm_num
  have hp := ManuscriptChronology.Theorem3_3.weightFiveDetExponent_sign n
  rw [weightFive_exponent_relation n, pow_add, heven, mul_one] at hp
  exact hp

/-- **Actual** polynomial delta_K: the sign of its leading coefficient is
(-1)^(n(n-1)/2) for K=30n,N=3n,m=3,k=2. This is not a
placeholder for an abstract matrix-pencil determinant. -/
theorem weightFive_delta_leadingCoeff_sign (n : ℕ) :
    0 < (-1 : ℚ) ^ ((n * (n - 1)) / 2) *
      (Real.delta (ManuscriptChronology.Theorem3_3.weightFiveParameters n)).leadingCoeff := by
  have hm : 0 < (ManuscriptChronology.Theorem3_3.weightFiveParameters n).m := by
    decide
  have hp := delta_leadingCoeff_signed_positive
      (ManuscriptChronology.Theorem3_3.weightFiveParameters n) hm
  rw [weightFive_signExponent_parity n] at hp
  exact hp

end ManuscriptChronology.Theorem3_3_WeightFiveSign

#print axioms ManuscriptChronology.Theorem3_3_WeightFiveSign.signExponent_closed
#print axioms ManuscriptChronology.Theorem3_3_WeightFiveSign.signExponent_weightFive
#print axioms ManuscriptChronology.Theorem3_3_WeightFiveSign.weightFive_exponent_relation
#print axioms ManuscriptChronology.Theorem3_3_WeightFiveSign.weightFive_signExponent_parity
#print axioms ManuscriptChronology.Theorem3_3_WeightFiveSign.weightFive_delta_leadingCoeff_sign
