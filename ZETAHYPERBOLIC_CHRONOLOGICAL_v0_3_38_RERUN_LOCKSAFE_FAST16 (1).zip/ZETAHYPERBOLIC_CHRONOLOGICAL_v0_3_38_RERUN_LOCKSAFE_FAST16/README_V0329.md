# v0.3.29: finite sign determinant, inductive positivity

- Replaces the strict inequality transport inside `signed_pole_product_positive` with a standalone generic finite-set induction.
- Uses only pointwise positivity, `mul_pos`, `Finset.sum_insert`, `Finset.prod_insert`, and `pow_add`, with exact algebraic reassociation.
- Adds `#print axioms signed_prod_positive_by_induction` to identify any surviving `sorryAx` at its mathematical origin.
- All previously certified sources remain byte-identical. `run.cmd` retains native Lean 4.33.0 direct FAST16 and persistent frozen-pass caching, and axiom-checks each newly compiled module.
- The source has NOT been compiled by the package author; the user’s Windows compiler is solely authoritative.
