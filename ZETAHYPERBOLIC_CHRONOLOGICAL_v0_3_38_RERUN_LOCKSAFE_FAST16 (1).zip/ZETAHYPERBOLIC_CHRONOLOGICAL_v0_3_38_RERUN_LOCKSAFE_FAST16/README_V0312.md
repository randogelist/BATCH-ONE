# v0.3.12 — Theorem 3.3 all-pole proof repair (FAST16)

Chronological PDF branch. No local Lean compilation was performed by the assistant.

Changed files: `Theorem_3_3_All_Pole_Sign_Transfer.lean`, `run.cmd`, this release note, checksums.

* `signed_div_positive`: corrected the even-power reduction to `(-1)^2 = 1`, eliminated a tactic after a completed `field_simp`, and used a no-goal-safe `all_goals ring`.
* `poleWeight_alternating`: positivity transfer now uses exact multiplicative associativity instead of a brittle `convert ... <;> ring`.
* `tail_derivative_signed_positive`: explicit positivity of the pole index supports the factor sign proof without implicit unfolding.
* The launcher requires a fresh first-time no-`sorryAx` axiom certificate for all four all-pole declarations, and reuses the older frozen 46-module proof core.
* Exactly one `run.cmd` at root, with the user's existing 16-thread Lean 4.33.0 offline setup.

The new all-pole declarations are proof candidates until confirmed by the user's native compiler. The entire Theorem 3.3 is still open (all-minor total positivity and full spectral inertia transfer remain separate).

CMD:

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_12_T33_ALL_POLES_PROOF_FIX_FAST16.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_12_T33_ALL_POLES_PROOF_FIX_FAST16\run.cmd"
```

Expected *only after* successful build: `ALLPOLE_AXIOM_CERTIFICATION=PASS`, `LEAN_BUILD=PASS`, `BUILD=PASS`.
