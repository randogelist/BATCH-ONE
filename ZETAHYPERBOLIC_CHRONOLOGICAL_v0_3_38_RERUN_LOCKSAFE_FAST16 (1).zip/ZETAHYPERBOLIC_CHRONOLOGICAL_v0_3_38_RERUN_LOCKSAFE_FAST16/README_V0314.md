# v0.3.14 – Theorem 3.3 all-pole finite-sign filter repairs

Changes only in `Theorem_3_3_All_Pole_Sign_Transfer.lean` and `run.cmd`; all previously compiler-certified mathematical sources are unchanged.

- `signed_product_positive`, positive case: explicitly rewrite `Finset.filter_insert` and `Finset.card_insert_of_not_mem` after proving the inserted index was not already in the filtered set.
- `signed_product_positive`, negative case: explicitly rewrite `Finset.filter_insert` and `if_neg`.
- `tail_derivative_signed_positive`: use the natural-number interval-cardinality theorem `Nat.card_Ico`; `Finset.card_Ico` was not the applicable Nat-specific reduction.
- Theorem signatures and mathematical statements are unchanged.
- The certified v0.3.10 Theorem 3.3 and v0.3.6 Proposition 3.2 remain frozen; the all-pole module is deliberately recompiled for its first sound axiom certificate.
- No Lean compilation has been performed in preparation of this package. Use the root `run.cmd` on your Windows Lean 4.33.0 environment.
- `ALLPOLE_AXIOM_CERTIFICATION=PASS` is required before freezing.
