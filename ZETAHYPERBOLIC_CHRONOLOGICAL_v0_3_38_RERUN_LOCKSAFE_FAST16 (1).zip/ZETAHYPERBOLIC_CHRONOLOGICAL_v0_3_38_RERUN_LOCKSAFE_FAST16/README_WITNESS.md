# Zetahyperbolic — one-witness conditional Lean chain (v0.2.0)

## Exact, native endpoint

See `PAPER_WITNESS.lean` and `MAIN_CHAIN_SINGLE_WITNESS.lean`:

```lean
theorem ManuscriptChain.Paper.MAIN_CHAIN
    (hW : ManuscriptChain.Paper.Witness) :
    Irrational (riemannZeta 5).re ∧
    ∃ b₀ : ℕ, ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
      1 / (b : ℝ) ^ 25687 <
      |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)|
```

One external input: `Witness := Nonempty PaperWitness`.
The `PaperWitness` has `start : ℕ` and *two distinct quantitative estimates*:

1. **Primitive quadratic decay:** For all sufficiently large `n`, the actual
   constructed primitive integer polynomial `Qₙ` satisfies
   `|Qₙ(ζ(5))| ≤ exp(-(30n)^2/2500)`.
2. **Spectral growth:** The actual Gram-normalized spectral coefficients of
   the original matrix pencil satisfy `|βᵢ| ≤ exp(11.411·30n)`.

These are not formally proved here. One record does not turn two mathematical
estimates into one theorem. The paper (pp.16–18) asserts these via a p-adic
normalization using `M=100000` and an analytic Legendre/stirling bound. The
printed cutoff is **not** by itself a certified uniform witness.

## What is really proved by the inherited source graph

- Definition 2.1, finite algebra, Theorems 2.4/2.5: original polynomial family,
  rational moments, derivative factorization and primitive normalization.
- Theorem 3.1 (all admissible odd weights): real/zero-free spectrum, positive
  Gram matrix, exact degree and nonvanishing at the zeta center; analytic
  pole-integral identity constructed internally.
- Theorem 4.1: quantitative transfer, rational denominator lower bound and
  explicit index budget for exponent 25687.
- Theorem 4.4: follows *conditionally* from the single `Witness` input via
  original polynomials and explicit transfer.  The irrationality subresult
  only uses `normalized_decay`, **not** `spectral_growth`.

## What this does NOT prove

This is a formalization of the Section 2 → Section 3.1 → Section 4.1/4.4
*main application chain*, **not** a complete proof of every statement in a
52-page paper. The manuscript has incorrect statements as printed: continuous
prefactor in Proposition 3.2, normalization of Corollary 3.5, and finite-rank
strictness in Corollary 3.6; see `PAPER_BLOCKERS.md` and `PAPER_CORRECTIONS.lean`.
The Sections 5–6 extension theorems (weight seven, beta, multi-weight, p-adic)
have additional standalone proofs and/or missing source lemmas, and cannot be
validated by the above ζ5-specific witness alone.

For an **all odd weights irrationality** program, the separate exact theorem
`ManuscriptChain.GeneralIrrationality.all_odd_zeta_irrational_of_affineFamilyDecay`
requires uniform witness existence for each k. The PDF claims universal
hyperbolicity, not a uniform irrationality theorem for all odd weights.

## Run and trust status

Run `run.cmd` on native Windows with Lean 4.33.0 and pinned Mathlib available.
It builds `MAIN_CHAIN_SINGLE_WITNESS`, prints transitive axiom dependencies,
and writes `SINGLE_WITNESS_BUILD.log` and `SINGLE_WITNESS_AXIOMS.log`.

**Source-only as prepared:** No Lean executable or Mathlib cache was available
in the preparation environment, therefore the two new modules have not been
compiler-checked. Their source contains no `sorry`, `admit`, or custom `axiom`.
This is not a claim of successful Lean kernel verification of the new modules.
The prior 60-module base reported compiler validation; only fresh logs from
`run.cmd` can attest to the new source graph.
