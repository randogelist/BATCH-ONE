# v0.3.33 — finite determinant sign, generic-induction proof

The v0.3.32 compiler established that `signed_prod_identity`,
`signed_prod_positive_by_induction` and the imported all-pole weight
signs were axiom-clean, while the *specialized* signed product bridge
was not. This release drops the redundant specialized equality lemma
and instantiates the already axiom-clean generic induction theorem
directly with the genuine residue weights.

Only `Theorem_3_3_Finite_Determinant_Sign.lean` has been modified.
Persistent frozen-pass snapshots of other sources are preserved.

This release changes the finite determinant sign proof, not the
mathematical goal. Requires a new axiom report from the user's native
Lean 4.33.0 compiler. No local Lean compilation has taken place.
