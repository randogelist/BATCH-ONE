# v0.3.19 — self-contained finite-product sign core

The only direct `sorryAx` origin identified in the v0.3.18 compiler response was
`signed_product_positive`; every downstream all-pole sign lemma inherited it.

This release replaces that induction-based proof with a **separate, Mathlib-only**
module `Theorem_3_3_Signed_Product_Core.lean`, which first derives a finite-product
sign identity by induction and then derives strict positivity by `Finset.prod_pos`.
`Theorem_3_3_All_Pole_Sign_Transfer.lean` reuses this exact new theorem, rather
than maintaining a second signed-product proof.

Compiler axiom reports are required for both sign-core declarations before
the all-pole module can be certified; any `sorryAx` fails the build. The Lean
sources previously confirmed by the user's v0.3.10 compiler remain unchanged.

Lean is **not compiled locally**. All proof terms in the new file are unverified
until the user's native Windows Lean 4.33.0 produces a PASS and axiom receipts.
