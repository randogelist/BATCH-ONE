# v0.3.24 — determinant-sign axiom provenance

**Native Lean verification only on the user's Windows compiler.**

Before checking the finite determinant sign bridge, the new
`Theorem_3_3_Axiom_Provenance_Probe.lean` prints kernel axioms for the
precise imported all-pole and finite product lemmas. This isolates
an inherited `sorryAx` from an error in the new determinant-sign lemma.
The determinant-sign source now also reports the axioms of its
formerly private finite product identity.

No new hypothesis, `sorry`, `admit`, or custom `axiom` has been added.
If any imported theorem carries `sorryAx`, the runner fails at the
probe; do not freeze the determinant theorem. This is a provenance
check, not a proof of the remaining integral or inertia assertions.

Unchanged certified modules are reused. Source changes rebuild
only the affected dependency chain. The cache is shared across releases.
