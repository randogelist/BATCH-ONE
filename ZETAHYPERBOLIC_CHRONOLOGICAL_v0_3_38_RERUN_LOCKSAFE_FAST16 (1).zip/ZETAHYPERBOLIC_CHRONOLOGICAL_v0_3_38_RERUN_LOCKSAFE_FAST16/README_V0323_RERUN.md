# v0.3.23 — rerun of v0.3.22 determinant-sign fix

- Native Windows Lean 4.33.0 via the single root-level run.cmd, 16 threads.
- Repackages the v0.3.22 Lean sources byte-for-byte without recompiling them here.
- New release identifier and directory guard prevent accidental execution of v0.3.21.
- Theorem_3_3_Finite_Determinant_Sign.lean retains v0.3.22 type-aligned proof at the former line-65 issue.
- Previously certified modules remain eligible for frozen-pass reuse; no failed module is certified.
- Do not infer full paper certification from passing the finite determinant-sign subtheorem.
- On failure, return the first Lean error from CHRONOLOGICAL_BUILD.log and the release string.
- No Lean compilation has been run in the packaging environment.
