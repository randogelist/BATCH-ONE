import Definition_2_1_Order_s_Rational_Moment_Functional
import Lemma_2_2_Pullback_Identity
import Lemma_2_3_Reflection_And_Difference
import Theorem_2_4_Canonical_Basis_Invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization
import MAIN_CHAIN_ASSEMBLED
import PAPER_CORRECTIONS
import Proposition_3_2_Continuous_Hyperbolic_Pencil
import Theorem_3_3_Total_Positivity_Leading_Sign_And_Universal_Signature
import Theorem_3_3_All_Pole_Sign_Transfer
import Theorem_3_3_Consecutive_Pole_Signs
import Theorem_3_3_Finite_Determinant_Sign
import Theorem_3_3_Rational_Inertia_Bridge
import Theorem_3_3_Weight_Five_Leading_Sign
import Theorem_3_4_Reciprocal_Spectral_Edge
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion
import MAIN_CHAIN_SINGLE_WITNESS
import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil
import Theorem_5_4_Even_Pole_Pair_Cancellation
import Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7
import Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4
import Zetahyperbolic.Theorem_6_9_Triple_Pole_Hermite_Repair
import Zetahyperbolic.Theorem_6_10_Finite_Determinant_Identity

/-!
# Paper theorem register, in PDF order (52 pages)

`#check` lists the *real proof terms* available from the source graph, without
inventing theorem stubs for unproved conclusions. See `CHRONOLOGICAL_THEOREM_REGISTER.md`
for ALL named items (2.1--6.18) and their exact status.

Only Section 2 and the main Section 3.1 spectral conclusion are treated as
closed full-strength source results here. The weight-five Section 4.4 endpoint
still has one explicit `Witness` input; this does NOT supply independent
conditions for other theorems. Several later sections have useful partial
lemmas only. Incorrect printed assertions are not adopted as axioms.
-/

/-! ## Section 2: definitions, pullback, reflection, basis, Lagrange -/
#check ManuscriptChain.Real.Parameters
#check ManuscriptChain.Real.pencil
#check ManuscriptChain.Real.delta
#check ManuscriptChronology.LEMMA_2_2_GENERATORS
#check ManuscriptChronology.LEMMA_2_2_FINITE_LINEAR_EXTENSION
#check ManuscriptChronology.LEMMA_2_3_GENERATORS
#check ManuscriptChronology.LEMMA_2_3_REFLECTION_POLYNOMIAL
#check ManuscriptChronology.LEMMA_2_3_REFLECTION_FINITE_POLES
#check ManuscriptChronology.LEMMA_2_3_DIFFERENCE_FINITE_POLES
#check ManuscriptChain.BasisInvariance.theorem_2_4_canonical_basis_invariance
#check Zetahyperbolic.canonical_primitive_content_invariance
#check Zetahyperbolic.lagrange_pole_diagonalization
#check Zetahyperbolic.M_deriv_det_ne_zero

/-! ## Section 3: spectral theorem and corrections, then open extensions -/
#check ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
#check Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL
#check Zetahyperbolic.ORIGINAL_EXACT_ZERO_FREE_DISK
#check ManuscriptChronology.Proposition3_2.correctedPrefactor_at_odd
#check ManuscriptChronology.Proposition3_2.continuousDirection_det_ne_zero
#check ManuscriptChronology.Proposition3_2.referencePencil_roots_real
#check ManuscriptChronology.Theorem3_3.weightFiveDetExponent_sign
#check ManuscriptChronology.Theorem3_3.D_signed_eval_positive
#check ManuscriptChronology.Theorem3_3.first_pole_slope_signed_pos
#check ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_alternating
#check ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_pos_of_even
#check ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_neg_of_odd
#check ManuscriptChronology.Theorem3_3_Consecutive.poleWeight_ne_zero
#check ManuscriptChronology.Theorem3_3_Consecutive.poleWeight_pos_iff_even
#check ManuscriptChronology.Theorem3_3_Consecutive.consecutive_pole_weights_opposite
#check PaperCorrections.continuous_prefactor_difference
#check PaperCorrections.printed_h1_continued_fraction_impossible
#check PaperCorrections.one_atom_hankel_not_strictly_positive

/-! ## Section 4: general transfer and conditional arithmetic endpoint -/
#check ManuscriptChain.Paper.THEOREM_4_1_TRANSFER
#check ManuscriptChain.Paper.Witness
#check ManuscriptChain.Paper.MAIN_CHAIN

/-! ## Section 5: available dual moments, partial cone estimates, cancellation -/
#check ManuscriptChain.Real.dualEntry
#check ManuscriptChain.Real.dualDelta
#check ManuscriptChain.Extensions.positive_of_tail_certificate
#check PaperCorrections.original_simple_pole_pair_cancellation

/-! ## Section 6: available partial constructions, not full PDF theorems -/
#check ManuscriptChain.Extensions.positive_basis_from_explicit_inputs
#check ManuscriptChain.Extensions.beta_same_weight_same_constant

noncomputable section

namespace ManuscriptChronology

/-- The fully assembled spectral endpoint has no analytic/witness input:
its only premise is the paper's mathematical admissibility of indices. -/
theorem SECTION_3_1_AFTER_SECTION_2
    (p : ManuscriptChain.Real.Parameters)
    (hp : ManuscriptChain.Real.Admissible p) :
    ManuscriptChain.General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- Reuse the source's one-witness **conditional** conclusion of Theorem 4.4.
This is deliberately not generalized into an unsupported claim that every
odd zeta value is irrational. -/
theorem SECTION_4_4_IF_WITNESS (w : ManuscriptChain.Paper.Witness) :
    Irrational (riemannZeta 5).re :=
  (ManuscriptChain.Paper.MAIN_CHAIN w).1

end ManuscriptChronology

#print axioms ManuscriptChronology.LEMMA_2_2_GENERATORS
#print axioms ManuscriptChronology.LEMMA_2_2_FINITE_LINEAR_EXTENSION
#print axioms ManuscriptChronology.LEMMA_2_3_GENERATORS
#print axioms ManuscriptChronology.LEMMA_2_3_REFLECTION_POLYNOMIAL
#print axioms ManuscriptChronology.LEMMA_2_3_REFLECTION_FINITE_POLES
#print axioms ManuscriptChronology.LEMMA_2_3_DIFFERENCE_FINITE_POLES
#print axioms Zetahyperbolic.canonical_primitive_content_invariance
#print axioms Zetahyperbolic.lagrange_pole_diagonalization
#print axioms ManuscriptChronology.SECTION_3_1_AFTER_SECTION_2
#print axioms ManuscriptChronology.Proposition3_2.referencePencil_roots_real
#print axioms ManuscriptChronology.Theorem3_3.weightFiveDetExponent_sign
#print axioms ManuscriptChronology.Theorem3_3.first_pole_slope_signed_pos
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_alternating
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_pos_of_even
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_neg_of_odd
#print axioms ManuscriptChronology.Theorem3_3_Consecutive.consecutive_pole_weights_opposite
#print axioms ManuscriptChronology.SECTION_4_4_IF_WITNESS

-- v0.3.16: finite sign certificate, rational congruence, and scalar edge transfer.
#check ManuscriptChronology.Theorem3_3_DetSign.delta_leadingCoeff_signed_positive
#check ManuscriptChronology.Theorem3_3_Inertia.congruentDirection_eq_diagonal
#check ManuscriptChronology.Theorem3_3_Inertia.bilateral_diagonal_entries
#check ManuscriptChronology.Theorem3_4_Reciprocal.spectral_gap_lower_bound
#print axioms ManuscriptChronology.Theorem3_3_DetSign.delta_leadingCoeff_signed_positive
#print axioms ManuscriptChronology.Theorem3_3_Inertia.bilateral_diagonal_entries
#print axioms ManuscriptChronology.Theorem3_4_Reciprocal.spectral_gap_lower_bound
#check ManuscriptChronology.Theorem3_3_WeightFiveSign.weightFive_delta_leadingCoeff_sign
#print axioms ManuscriptChronology.Theorem3_3_WeightFiveSign.weightFive_delta_leadingCoeff_sign
