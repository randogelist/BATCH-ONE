import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

/-!
# Theorem 6.10: the direction of the decay-rate hypothesis

This module formalizes the elementary rate calculation required by the audit.
The lower bound `height + epsilon ≥ 0.23310` is an explicit input: this module
neither identifies it with the manuscript's energy nor assumes such a bridge.
In particular, a lower bound on `epsilon` does not imply the claimed ratio bound.
-/

namespace Zeta5Merge.Theorem6_10

/-- The exact rational form of the stated energy lower bound. -/
noncomputable def energyLower : ℝ := 2331 / 10000

/-- General corrected implication. The upper bound on the positive decay rate
is necessary for this deduction from the sum bound. -/
theorem ratio_gt_of_sum_lower
    (height epsilon energy target : ℝ)
    (hepsilon : 0 < epsilon)
    (hsum : energy ≤ height + epsilon)
    (hupper : (target + 1) * epsilon < energy) :
    target < height / epsilon := by
  apply (lt_div_iff₀ hepsilon).2
  nlinarith

/-- Exact repair of the numerical `> 581` deduction. -/
theorem height_decay_ratio_gt_581
    (height epsilon : ℝ)
    (hsum : energyLower ≤ height + epsilon)
    (hepsilon : 0 < epsilon)
    (hupper : epsilon < energyLower / 582) :
    581 < height / epsilon := by
  apply ratio_gt_of_sum_lower height epsilon energyLower 581 hepsilon hsum
  have h := (lt_div_iff₀ (by norm_num : (0 : ℝ) < 582)).mp hupper
  nlinarith

/-- The convenient sufficient bound is an UPPER bound, not a lower bound. -/
theorem height_decay_ratio_gt_581_of_le_one_2500
    (height epsilon : ℝ)
    (hsum : energyLower ≤ height + epsilon)
    (hepsilon : 0 < epsilon)
    (hupper : epsilon ≤ 1 / 2500) :
    581 < height / epsilon := by
  apply height_decay_ratio_gt_581 height epsilon hsum hepsilon
  have hconstant : (1 : ℝ) / 2500 < energyLower / 582 := by
    norm_num [energyLower]
  exact lt_of_le_of_lt hupper hconstant

/-- Positivity plus a lower decay bound fails to force the proposed ratio.
The witness has nonnegative height and even equality in the sum bound. -/
theorem lower_decay_bound_counterexample :
    ∃ height epsilon : ℝ,
      0 ≤ height ∧
      0 < epsilon ∧
      (1 / 2500 : ℝ) ≤ epsilon ∧
      energyLower = height + epsilon ∧
      height / epsilon < 581 := by
  refine ⟨energyLower - 1 / 1000, 1 / 1000, ?_⟩
  norm_num [energyLower]

/-- An upper bound on a positive evaluation gives a LOWER bound on its
normalized negative logarithm. Set `scale = K^2` for the paper's convention. -/
theorem evaluation_upper_gives_rate_lower
    (value scale rate : ℝ)
    (hvalue : 0 < value) (hscale : 0 < scale)
    (heval : value ≤ Real.exp (-rate * scale)) :
    rate ≤ -Real.log value / scale := by
  have hlog := Real.log_le_log hvalue heval
  rw [Real.log_exp] at hlog
  apply (le_div_iff₀ hscale).2
  linarith

/-- To obtain an UPPER bound on the normalized negative logarithm one can
instead prove a LOWER bound on the positive evaluation. -/
theorem evaluation_lower_gives_rate_upper
    (value scale rate : ℝ)
    (hscale : 0 < scale)
    (heval : Real.exp (-rate * scale) ≤ value) :
    -Real.log value / scale ≤ rate := by
  have hlog := Real.log_le_log (Real.exp_pos (-rate * scale)) heval
  rw [Real.log_exp] at hlog
  apply (div_le_iff₀ hscale).2
  linarith

/-- Consequently the missing upper-rate hypothesis cannot be omitted, even
if a nonnegative height and the exact sum identity are supplied. -/
theorem not_ratio_from_lower_decay_bound :
    ¬ (∀ height epsilon : ℝ,
      0 ≤ height → 0 < epsilon → (1 / 2500 : ℝ) ≤ epsilon →
      energyLower ≤ height + epsilon → 581 < height / epsilon) := by
  intro h
  obtain ⟨height, epsilon, hheight, hepsilon, hlower, hsum, hratio⟩ :=
    lower_decay_bound_counterexample
  have hclaimed := h height epsilon hheight hepsilon hlower (le_of_eq hsum)
  exact (not_lt_of_ge (le_of_lt hratio)) hclaimed

end Zeta5Merge.Theorem6_10

#print axioms Zeta5Merge.Theorem6_10.height_decay_ratio_gt_581
#print axioms Zeta5Merge.Theorem6_10.height_decay_ratio_gt_581_of_le_one_2500
#print axioms Zeta5Merge.Theorem6_10.lower_decay_bound_counterexample
#print axioms Zeta5Merge.Theorem6_10.not_ratio_from_lower_decay_bound

#print axioms Zeta5Merge.Theorem6_10.evaluation_upper_gives_rate_lower
#print axioms Zeta5Merge.Theorem6_10.evaluation_lower_gives_rate_upper
