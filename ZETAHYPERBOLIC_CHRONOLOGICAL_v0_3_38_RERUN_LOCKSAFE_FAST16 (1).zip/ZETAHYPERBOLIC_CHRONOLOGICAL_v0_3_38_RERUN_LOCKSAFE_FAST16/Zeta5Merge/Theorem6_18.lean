import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Tactic.NormNum

/-!
# Theorem 6.18: exact boundary arithmetic and quotient vanishing

At the corrected boundary r = 6n, the displayed degree formula evaluates
to two and the beta-shifted numerator remains below the denominator degree.
The degree formula's applicability to the actual determinant is a separate
spectral/algebraic obligation; this file does not assume it as an axiom.
-/

namespace Zeta5Merge.Theorem6_18
open Polynomial

theorem boundary_degree_formula (n : ℕ) (hn : 0 < n) :
    2 * (6 * n) - (12 * n - 3) - 1 = 2 := by omega

theorem shifted_numerator_degree_lt (n i j : ℕ)
    (hi : i < 6 * n) (hj : j < 6 * n) :
    18 * n + (i + j + 1) < 30 * n := by omega

/-- Actual polynomial division, allowing any D and F with the specified
degrees. In the paper D = D_(3n) and F = D_(30n). -/
theorem shifted_quotient_zero (n i j : ℕ) (D F : ℚ[X])
    (hD : D.natDegree = 3 * n) (hF : F.natDegree = 30 * n)
    (hi : i < 6 * n) (hj : j < 6 * n) :
    (D ^ 6 * X ^ (i + j + 1)) / F = 0 := by
  have hn : 0 < n := by omega
  have hF0 : F ≠ 0 := by
    intro hz
    simp only [hz, natDegree_zero] at hF
    omega
  apply (Polynomial.div_eq_zero_iff hF0).2
  apply degree_lt_degree
  have hdegree := natDegree_mul_le (p := D ^ 6) (q := (X : ℚ[X]) ^ (i + j + 1))
  rw [natDegree_pow, hD, natDegree_X_pow] at hdegree
  rw [hF]
  omega

end Zeta5Merge.Theorem6_18

#print axioms Zeta5Merge.Theorem6_18.boundary_degree_formula
#print axioms Zeta5Merge.Theorem6_18.shifted_quotient_zero
