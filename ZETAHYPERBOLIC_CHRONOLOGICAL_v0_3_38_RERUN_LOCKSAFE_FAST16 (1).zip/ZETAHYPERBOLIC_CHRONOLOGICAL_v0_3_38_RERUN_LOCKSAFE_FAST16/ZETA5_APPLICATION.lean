import Definition_2_1_Order_s_Rational_Moment_Functional
import Theorem_2_4_Canonical_Basis_Invariance
import Theorem_2_5_Lagrange_Pole_Diagonalization
import Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk
import Theorem_4_1_Spectral_Irrationality_Measure_Criterion
import Theorem_4_4_Sharpened_Spectral_Bound_And_Effective_Irrationality_Measure_For_Zeta_5
import Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7
import Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil
import Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7
import Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4

/-!
# Optional zeta(5) application and legacy extension exports

Imports follow the PDF numbering. Filenames transliterate the printed titles;
each module header states its exact scope and which proof inputs remain open.
The chain follows the paper's moment pencil, spectral separation, and integer
transfer architecture. Module headers identify the proved parts and open inputs.
Theorem 6.3 and 6.4 modules hold the documented conditional replacements or
interfaces; their printed titles do not assert unconditional formal coverage.

ZETA5_APPLICATION_MEASURE and ZETA5_APPLICATION now require five inputs: IndexBudget is
proved internally with an explicit threshold. The defined zeta series is proved
to equal Mathlib's riemannZeta. The Gram route also has five inputs after
Theorem 2.5 proves derivative nonsingularity. Precisely, its remaining inputs are:
1. MainNormalization: integer polynomials, positive rational multipliers, a common
   onset >= 1, and exact polynomial identities beyond that onset;
2. positive definiteness of the actual Gram matrices;
3. MultiplierUpper for the same normalization;
4. ArchimedeanUpper for the same family and onset;
5. the quantitative bound on the constructed spectral factors.
Thus there is one normalization witness and four uniform proof obligations.
Generic normalization existence alone does not prove the multiplier estimate.
The determinant degree, primitive normalization construction, factorization,
derivative nonsingularity, and index selection add no new hypotheses.
ZETA5_APPLICATION_PRIMITIVE_FROM_GRAM and ZETA5_APPLICATION_MEASURE_PRIMITIVE_FROM_GRAM
construct the actual primitive normalization internally, leaving four uniform
hypotheses (items 2-5 above) and a starting-index parameter. Their multiplier
bound is explicitly about that constructed primitive normalization.
These specialized endpoints are independent of the default general entry point.
-/

namespace ManuscriptChain

open MainChain RealTransfer

theorem ZETA5_APPLICATION_MEASURE
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → indexDenominatorThreshold normalization.onset ≤ b →
      1 / (b : ℝ) ^ 25687 < |Real.zeta 5 - (a : ℝ) / (b : ℝ)| :=
  theorem_4_4_measure normalization positive multiplier archimedean spectral

theorem ZETA5_APPLICATION
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset) :
    Irrational (Real.zeta 5) :=
  theorem_4_4_irrationality normalization positive multiplier archimedean spectral

theorem ZETA5_APPLICATION_MATHLIB_ZETA
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset) :
    Irrational (riemannZeta 5).re :=
  theorem_4_4_irrationality_riemannZeta normalization positive multiplier archimedean spectral


/-- The paper's Gram-matrix route to the endpoint, with spectral factorization,
derivative nonsingularity, determinant positivity, and index selection proved
internally. Five inputs remain: normalization data and four uniform obligations. -/
theorem ZETA5_APPLICATION_FROM_GRAM
    (normalization : MainNormalization)
    (gram : ∀ n, normalization.onset ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (bound : ∀ n (hn : normalization.onset ≤ n) i,
      |(mainRootFactorization normalization.onset gram n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)) :
    Irrational (riemannZeta 5).re :=
  theorem_4_4_irrationality_from_gram normalization gram multiplier archimedean bound

theorem MAIN_EXTENSION_POSITIVITY {h K M : ℕ}
    (coefficients : Fin h → Fin (K + 1) → ℚ)
    (tail : Extensions.WeightSevenTailBound coefficients M)
    (certificate : Extensions.FinitePositiveCertificate coefficients M) :
    Extensions.PositiveQForm (Extensions.weightSevenGram coefficients) :=
  Extensions.weight_seven_positive_from_finite_certificate coefficients tail certificate

/-- The primitive-family endpoint: four hypotheses, with normalization constructed. -/
theorem ZETA5_APPLICATION_PRIMITIVE_FROM_GRAM
    (start : ℕ)
    (gram : ∀ n, start + 1 ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper (primitiveMainNormalization start))
    (archimedean : ArchimedeanUpper (start + 1))
    (bound : ∀ n (hn : start + 1 ≤ n) i,
      |(mainRootFactorization (start + 1) gram n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)) :
    Irrational (riemannZeta 5).re :=
  theorem_4_4_irrationality_primitive_from_gram start gram multiplier archimedean bound


theorem ZETA5_APPLICATION_MEASURE_PRIMITIVE_FROM_GRAM
    (start : ℕ)
    (gram : ∀ n, start + 1 ≤ n →
      (Real.gram (Real.mainParameters n) (Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper (primitiveMainNormalization start))
    (archimedean : ArchimedeanUpper (start + 1))
    (bound : ∀ n (hn : start + 1 ≤ n) i,
      |(mainRootFactorization (start + 1) gram n hn).beta i| ≤
        _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → indexDenominatorThreshold (start + 1) ≤ b →
      1 / (b : ℝ) ^ 25687 < |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| :=
  theorem_4_4_measure_primitive_from_gram start gram multiplier archimedean bound

end ManuscriptChain

#check ManuscriptChain.ZETA5_APPLICATION_MEASURE
#check ManuscriptChain.ZETA5_APPLICATION
#check ManuscriptChain.MAIN_EXTENSION_POSITIVITY

#print axioms ManuscriptChain.ZETA5_APPLICATION_MEASURE
#print axioms ManuscriptChain.ZETA5_APPLICATION
#print axioms ManuscriptChain.MAIN_EXTENSION_POSITIVITY

#check ManuscriptChain.theorem_4_4_measure
#check ManuscriptChain.theorem_4_4_irrationality

#check ManuscriptChain.MainChain.main_indexBudget
#check ManuscriptChain.ZETA5_APPLICATION_MATHLIB_ZETA
#print axioms ManuscriptChain.MainChain.main_indexBudget
#print axioms ManuscriptChain.ZETA5_APPLICATION_MATHLIB_ZETA
#print axioms ManuscriptChain.Real.zeta_eq_riemannZeta
#print axioms ManuscriptChain.MainChain.denominatorClearingNormalization_no_multiplierUpper

#print axioms ManuscriptChain.BasisInvariance.theorem_2_4_canonical_basis_invariance
#print axioms ManuscriptChain.Spectral.rootFactorizationOfPosDef

#check ManuscriptChain.ZETA5_APPLICATION_FROM_GRAM
#print axioms ManuscriptChain.ZETA5_APPLICATION_FROM_GRAM

#check ManuscriptChain.PoleDiagonalization.derivativeMatrix_det_ne_zero
#check ManuscriptChain.PoleDiagonalization.delta_natDegree
#print axioms ManuscriptChain.PoleDiagonalization.derivativeMatrix_det_ne_zero
#print axioms ManuscriptChain.PoleDiagonalization.delta_natDegree
#print axioms ManuscriptChain.BasisInvariance.primitiveNormalization_nonempty
#print axioms ManuscriptChain.BasisInvariance.theorem_2_4_constructed_canonical_basis_invariance

#print axioms ManuscriptChain.PoleDiagonalization.theorem_2_5_lagrange_pole_diagonalization
#print axioms ManuscriptChain.BasisInvariance.theorem_2_4_constructed_for_manuscript

#check ManuscriptChain.ZETA5_APPLICATION_PRIMITIVE_FROM_GRAM
#check ManuscriptChain.ZETA5_APPLICATION_MEASURE_PRIMITIVE_FROM_GRAM
#print axioms ManuscriptChain.MainChain.primitiveMainNormalization
#print axioms ManuscriptChain.ZETA5_APPLICATION_PRIMITIVE_FROM_GRAM
#print axioms ManuscriptChain.ZETA5_APPLICATION_MEASURE_PRIMITIVE_FROM_GRAM
