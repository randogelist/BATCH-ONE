# v0.3.37 — Theorem 3.3 finite determinant sign: explicit equality rewrite

Chronological target: Theorem 3.3(2) finite signed leading coefficient.
This release changes only `Theorem_3_3_Finite_Determinant_Sign.lean`
and the root launcher. The `signed_pole_product_eq` helper explicitly
specializes the proven generic signed-product identity, while the
positivity theorem rewrites by this exact equality, then applies the
previously certified factorwise product positivity.

The preceding chain and the paper's single-Witness endpoint remain
unaltered. Existing FROZEN_PASS modules retain their byte-identical
source and cache. Only newly modified or dependency-invalidated files
should compile, using your native Windows Lean 4.33.0 and 16-thread
startup. **No local Lean compilation has been performed.**

If verification still reports `sorryAx`, the exact intermediate
`ManuscriptChronology.Theorem3_3_DetSign.signed_pole_product_eq` is now
axiom-audited independently to pinpoint the defect.
