# v0.3.30 COVERAGE AUDIT (no Lean source change)

Open `COVERAGE_AUDIT_v0_3_30.md` for the estimated manuscript-theorem-level coverage: 8/51 substantially Leaned (~16%), around 25-30% including partial proof work. Compiled modules are not an equal-proxy for manuscript theorems.

All Lean sources and import graph match v0.3.29 byte-for-byte. The native launcher has the fresh v0.3.30 release label and preserved shared verified-cache workflow. The user alone runs the Lean 4.33.0 compiler; this package has NOT been compiled locally. The v0.3.29 determinant-sign proof is still awaiting successful axiom certification.
