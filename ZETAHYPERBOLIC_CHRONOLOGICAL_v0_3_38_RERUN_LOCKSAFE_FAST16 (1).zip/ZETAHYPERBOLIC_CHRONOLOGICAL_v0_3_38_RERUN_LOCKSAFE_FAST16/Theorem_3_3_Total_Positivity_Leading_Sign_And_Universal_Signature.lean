-- THEOREM33_PARITY_SLOPE_PROOF_FIX_V0310_20261024
import Proposition_3_2_Continuous_Hyperbolic_Pencil
import Theorem_2_5_Lagrange_Pole_Diagonalization
import Mathlib.Tactic

/-!
# Theorem 3.3 — first exact, unconditional sign certificates

Chronological manuscript p. 8-9. Theorem 3.3 contains THREE distinct
conclusions: strict total positivity of all Gram minors, the leading
coefficient sign for the 30n/3n weight-five family, and the bilateral
signature of the spectral pencil.

This file proves new FINITE sublemmas used in items (2) and (3):
* sign of D_N(-a^2), a>N, after multiplying by (-1)^N;
* strictly positive first-node tail derivative and the signed first residue;
* the exact arithmetic parity identity appearing in the printed (3.4)
  sign computation, for every n, without finite numerical checking;
* exact h=27n for the manuscript special family.

It does NOT claim full strict total positivity of arbitrary minors,
Sylvester-inertia counts for every gamma_a, nor a final theorem 3.3 proof.
There are no analytic/witness hypotheses in these finite lemmas.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChronology.Theorem3_3

open ManuscriptChain

/-- The paper's weight-five index family (K,N,h,m)=(30n,3n,27n,3). -/
def weightFiveParameters (n : ℕ) : Real.Parameters where
  k := 2
  m := 3
  N := 3 * n
  K := 30 * n

/-- Exact dimension in the manuscript family, without an asymptotic argument. -/
theorem weightFive_dimension (n : ℕ) :
    (weightFiveParameters n).h = 27 * n := by
  simp only [weightFiveParameters, Real.Parameters.h]
  omega

/-- Every consecutive product is even, including n=0. -/
theorem consecutive_product_twice (n : ℕ) :
    ∃ q : ℕ, n * (n - 1) = 2 * q := by
  have hcases : n % 2 = 0 ∨ n % 2 = 1 := by omega
  rcases hcases with he | ho
  · refine ⟨(n / 2) * (n - 1), ?_⟩
    have hn : n = 2 * (n / 2) := by omega
    calc
      n * (n - 1) = (2 * (n / 2)) * (n - 1) :=
        congrArg (fun t : ℕ => t * (n - 1)) hn
      _ = 2 * ((n / 2) * (n - 1)) := by ring
  · refine ⟨n * ((n - 1) / 2), ?_⟩
    have hn : n - 1 = 2 * ((n - 1) / 2) := by omega
    calc
      n * (n - 1) = n * (2 * ((n - 1) / 2)) :=
        congrArg (fun t : ℕ => n * t) hn
      _ = 2 * (n * ((n - 1) / 2)) := by ring

/-- Exact numerator of the determinant-sign exponent in Theorem 3.3(2). -/
theorem weightFive_exponent_numerator (n : ℕ) :
    27 * n * (27 * n - 1) + 10 * (3 * n) * (27 * n) =
      2 * (756 * n ^ 2 + 13 * n * (n - 1)) + n * (n - 1) := by
  cases n with
  | zero => norm_num
  | succ j =>
      have hprev : (j + 1) - 1 = j := by omega
      have h27 : 27 * (j + 1) - 1 = 27 * j + 26 := by omega
      rw [hprev, h27]
      ring

/-- The exact paper exponent E(n) in the leading-coefficient sign. -/
def weightFiveDetExponent (n : ℕ) : ℕ :=
  (27 * n * (27 * n - 1)) / 2 + 5 * (3 * n) * (27 * n)

/-- Pure division-by-two identity, kept abstract so omega never needs to
reason about the nonlinear products defining the determinant exponent. -/
private theorem div_two_balance (a b c d : ℕ)
    (h : a + 2 * b = 2 * c + d) :
    a / 2 + b = c + d / 2 := by
  omega

/-- Decomposition into even terms and n(n-1)/2. -/
theorem weightFiveDetExponent_eq (n : ℕ) :
    weightFiveDetExponent n =
      756 * n ^ 2 + 13 * n * (n - 1) + (n * (n - 1)) / 2 := by
  let a : ℕ := 27 * n * (27 * n - 1)
  let b : ℕ := 5 * (3 * n) * (27 * n)
  let c : ℕ := 756 * n ^ 2 + 13 * n * (n - 1)
  let d : ℕ := n * (n - 1)
  have h : a + 2 * b = 2 * c + d := by
    dsimp [a, b, c, d]
    calc
      27 * n * (27 * n - 1) + 2 * (5 * (3 * n) * (27 * n)) =
          27 * n * (27 * n - 1) + 10 * (3 * n) * (27 * n) := by ring
      _ = 2 * (756 * n ^ 2 + 13 * n * (n - 1)) + n * (n - 1) :=
        weightFive_exponent_numerator n
  exact div_two_balance a b c d h

/-- The parity relation needed for sign formula (3.4), all n >= 0. -/
theorem weightFiveDetExponent_sign (n : ℕ) :
    (-1 : ℚ) ^ (weightFiveDetExponent n) =
      (-1 : ℚ) ^ ((n * (n - 1)) / 2) := by
  obtain ⟨q, hq⟩ := consecutive_product_twice n
  have hhalf : n * (n - 1) / 2 = q := by rw [hq]; omega
  have hrearrange : 13 * n * (n - 1) = 13 * (n * (n - 1)) := by ring
  have he : 756 * n ^ 2 + 13 * n * (n - 1) + (n * (n - 1)) / 2 =
      2 * (378 * n ^ 2 + 13 * q) + q := by
    rw [hrearrange, hq]
    omega
  rw [weightFiveDetExponent_eq, he, hhalf, pow_add, pow_mul]
  norm_num

/-- Signed positivity of the actual polynomial D_N at every negative-square
pole to its right. No sign input is assumed. -/
theorem D_signed_eval_positive (a : ℕ) :
    ∀ N : ℕ, N < a →
      0 < (-1 : ℚ) ^ N * (Real.D N).eval (-(a : ℚ) ^ 2) := by
  intro N
  induction N with
  | zero =>
      intro _
      simp [Real.D]
  | succ N ih =>
      intro h
      have hprev : N < a := by omega
      have hfactor :
          (Real.D (N + 1)).eval (-(a : ℚ) ^ 2) =
          (Real.D N).eval (-(a : ℚ) ^ 2) *
            ((((N + 1 : ℕ) : ℚ) ^ 2) - (a : ℚ) ^ 2) := by
        simp only [Real.D, Finset.prod_range_succ, Polynomial.eval_mul,
          Polynomial.eval_add, Polynomial.eval_X, Polynomial.eval_C]
        ring
      have hlt : (((N + 1 : ℕ) : ℚ)) < (a : ℚ) := by exact_mod_cast h
      have hn : (0 : ℚ) ≤ (((N + 1 : ℕ) : ℚ)) := by positivity
      have ha : (0 : ℚ) ≤ (a : ℚ) := by positivity
      have hpos : 0 < (a : ℚ) ^ 2 - (((N + 1 : ℕ) : ℚ) ^ 2) := by
        have hd : 0 < (a : ℚ) - (((N + 1 : ℕ) : ℚ)) := sub_pos.mpr hlt
        have hs : 0 < (a : ℚ) + (((N + 1 : ℕ) : ℚ)) := by linarith
        nlinarith [mul_pos hd hs]
      have heq :
          (-1 : ℚ) ^ (N + 1) * (Real.D (N + 1)).eval (-(a : ℚ) ^ 2) =
          ((-1 : ℚ) ^ N * (Real.D N).eval (-(a : ℚ) ^ 2)) *
            ((a : ℚ) ^ 2 - (((N + 1 : ℕ) : ℚ) ^ 2)) := by
        rw [hfactor, pow_succ]
        ring
      rw [heq]
      exact mul_pos (ih hprev) hpos

/-- The first Lagrange node is present as soon as K>N. -/
def firstPoleIndex (p : Real.Parameters) (hp : p.N < p.K) : Fin p.h :=
  ⟨0, by dsimp [Real.Parameters.h]; omega⟩

/-- Its tail-derivative is positive because all other nodes are larger. -/
theorem firstPoleDerivative_pos (p : Real.Parameters) (hp : p.N < p.K) :
    0 < (derivative (Real.tailD p)).eval (-((p.N + 1 : ℕ) : ℚ) ^ 2) := by
  have hmem : p.N + 1 ∈ Finset.Icc (p.N + 1) p.K :=
    Finset.mem_Icc.mpr ⟨le_refl _, by omega⟩
  rw [PoleDiagonalization.tailD_derivative_eval p (p.N + 1) hmem]
  apply Finset.prod_pos
  intro b hb
  have hb' := Finset.mem_erase.mp hb
  have hgt : p.N + 1 < b := by
    have hlow := (Finset.mem_Icc.mp hb'.2).1
    omega
  have hlt : (((p.N + 1 : ℕ) : ℚ)) < (b : ℚ) := by exact_mod_cast hgt
  have hnonneg : (0 : ℚ) ≤ (((p.N + 1 : ℕ) : ℚ)) := by positivity
  have hbnonneg : (0 : ℚ) ≤ (b : ℚ) := by positivity
  have hd : 0 < (b : ℚ) - (((p.N + 1 : ℕ) : ℚ)) := sub_pos.mpr hlt
  have hs : 0 < (b : ℚ) + (((p.N + 1 : ℕ) : ℚ)) := by linarith
  nlinarith [mul_pos hd hs]

/-- Odd powers preserve the signed evaluation of the numerator for m>=1. -/
theorem signed_odd_numerator_pos (N a m : ℕ)
    (ha : N < a) (hm : 0 < m) :
    0 < (-1 : ℚ) ^ N *
      ((Real.D N).eval (-(a : ℚ) ^ 2)) ^ (2 * m - 1) := by
  let d : ℚ := (Real.D N).eval (-(a : ℚ) ^ 2)
  have hp : 0 < (-1 : ℚ) ^ N * d := D_signed_eval_positive a N ha
  have hd : d ≠ 0 := PoleDiagonalization.D_eval_ne_zero_of_lt N a ha
  have hsq : 0 < d ^ 2 := by positivity
  have hmexp : 2 * m - 1 = 2 * (m - 1) + 1 := by omega
  have heq : (-1 : ℚ) ^ N * d ^ (2 * m - 1) =
      ((-1 : ℚ) ^ N * d) * ((d ^ 2) ^ (m - 1)) := by
    rw [hmexp, pow_add, pow_one, pow_mul]
    ring
  change 0 < (-1 : ℚ) ^ N * d ^ (2 * m - 1)
  rw [heq]
  exact mul_pos hp (pow_pos hsq _)

/-- The first actual Lagrange residue has the expected sign (-1)^N.
This is a genuine coefficient of the manuscript's derivative pencil. -/
theorem first_pole_slope_signed_pos (p : Real.Parameters)
    (hK : p.N < p.K) (hm : 0 < p.m) :
    0 < (-1 : ℚ) ^ p.N *
      PoleDiagonalization.poleWeight p (firstPoleIndex p hK) := by
  -- Explicit local abbreviations avoid a long and fragile `change` expression.
  let node : ℚ := -((p.N + 1 : ℕ) : ℚ) ^ 2
  let numerator : ℚ := ((Real.D p.N).eval node) ^ (2 * p.m - 1)
  let denominator : ℚ := (derivative (Real.tailD p)).eval node
  let factor : ℚ := (((p.N + 1 : ℕ) : ℚ)) ^ (2 * p.k)
  have hnum : 0 < (-1 : ℚ) ^ p.N * numerator := by
    exact signed_odd_numerator_pos p.N (p.N + 1) p.m (by omega) hm
  have hden : 0 < denominator := by
    exact firstPoleDerivative_pos p hK
  have hfactor : 0 < factor := by
    dsimp [factor]
    positivity
  have hpositive :
      0 < (((-1 : ℚ) ^ p.N * numerator) / denominator) * factor :=
    mul_pos (div_pos hnum hden) hfactor
  have hreassociate :
      (((-1 : ℚ) ^ p.N * numerator) / denominator) * factor =
        (-1 : ℚ) ^ p.N * (numerator / denominator * factor) := by
    ring
  have hresult :
      0 < (-1 : ℚ) ^ p.N * (numerator / denominator * factor) := by
    rw [← hreassociate]
    exact hpositive
  -- This is the actual first Lagrange residue, with no extra assumption.
  change 0 < (-1 : ℚ) ^ p.N * (numerator / denominator * factor)
  exact hresult

end ManuscriptChronology.Theorem3_3

#print axioms ManuscriptChronology.Theorem3_3.weightFive_dimension
#print axioms ManuscriptChronology.Theorem3_3.consecutive_product_twice
#print axioms ManuscriptChronology.Theorem3_3.weightFive_exponent_numerator
#print axioms ManuscriptChronology.Theorem3_3.weightFiveDetExponent_eq
#print axioms ManuscriptChronology.Theorem3_3.weightFiveDetExponent_sign
#print axioms ManuscriptChronology.Theorem3_3.D_signed_eval_positive
#print axioms ManuscriptChronology.Theorem3_3.firstPoleDerivative_pos
#print axioms ManuscriptChronology.Theorem3_3.signed_odd_numerator_pos
#print axioms ManuscriptChronology.Theorem3_3.first_pole_slope_signed_pos
