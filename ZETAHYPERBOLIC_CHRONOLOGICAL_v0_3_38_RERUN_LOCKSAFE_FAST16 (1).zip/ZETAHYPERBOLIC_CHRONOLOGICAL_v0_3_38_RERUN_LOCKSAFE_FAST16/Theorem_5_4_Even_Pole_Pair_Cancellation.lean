import Zetahyperbolic.Section2Checked

/-!
# Theorem 5.4: exact cancellation for the original rational harmonic moments

This theorem uses `Zetahyperbolic.harmonicWeight` from the original
Section 2 definitions, rather than an arbitrary symbolic proxy.  It proves
that the parameter X cancels on each positive/negative simple-pole pair,
leaving the exact rational reciprocal odd power.

The result is for the two pole values in Definition 2.1 / Lemma 2.2;
it does not assert any missing higher-order-pole distribution identity.
-/

namespace PaperCorrections

/-- Lemma 2.2's pole pair, evaluated at +j and -j with j=j0+1.
    Formula (5.5), for the precise original simple-pole data. -/
theorem original_simple_pole_pair_cancellation (k j0 : ℕ) (X : ℚ) :
    ((Zetahyperbolic.harmonicWeight (2 * k + 1) (j0 + 1) - X) -
     (Zetahyperbolic.harmonicWeight (2 * k + 1) j0 - X)) =
      ((((j0 + 1 : ℕ) : ℚ) ^ (2 * k + 1))⁻¹) := by
  rw [Zetahyperbolic.harmonicWeight_succ]
  ring

end PaperCorrections

#print axioms PaperCorrections.original_simple_pole_pair_cancellation
