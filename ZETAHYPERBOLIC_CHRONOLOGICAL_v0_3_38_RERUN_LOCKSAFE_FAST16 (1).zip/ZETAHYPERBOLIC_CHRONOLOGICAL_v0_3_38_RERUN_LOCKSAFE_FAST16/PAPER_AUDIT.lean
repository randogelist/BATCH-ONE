import Zetahyperbolic
import PAPER_CORRECTIONS
import Theorem_5_4_Even_Pole_Pair_Cancellation

/-!
# Paper-wide audit entrypoint

The original general odd-weight Gram/spectral endpoint is unconditional
apart from mathematical indexing/admissibility of the parameters.
The arithmetic irrationality consequences retain an unproved decay input.
The new proof terms certify explicit repairs/counterexamples only.

This file intentionally contains no false unconditional theorem asserting
irrationality of zeta(5), every odd zeta value, or the entire printed PDF.
-/

#check Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL
#check Zetahyperbolic.ORIGINAL_EXACT_ZERO_FREE_DISK
#check ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
#check ManuscriptChain.GeneralIrrationality.all_odd_zeta_irrational
#check ManuscriptChain.GeneralIrrationality.OddWeightDecayHypothesis
#check ManuscriptChain.LeadingCoefficientGap.primitivePolynomial_eval_eq
#check PaperCorrections.continuous_prefactor_weight_three
#check PaperCorrections.continuous_prefactor_difference
#check PaperCorrections.h1_original_det_exact
#check PaperCorrections.printed_h1_continued_fraction_impossible
#check PaperCorrections.one_atom_hankel_not_strictly_positive
#check PaperCorrections.original_simple_pole_pair_cancellation

#print axioms ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL
#print axioms Zetahyperbolic.MAIN_CHAIN_UNCONDITIONAL
#print axioms ManuscriptChain.GeneralIrrationality.all_odd_zeta_irrational
#print axioms ManuscriptChain.LeadingCoefficientGap.primitivePolynomial_eval_eq
#print axioms PaperCorrections.original_simple_pole_pair_cancellation
