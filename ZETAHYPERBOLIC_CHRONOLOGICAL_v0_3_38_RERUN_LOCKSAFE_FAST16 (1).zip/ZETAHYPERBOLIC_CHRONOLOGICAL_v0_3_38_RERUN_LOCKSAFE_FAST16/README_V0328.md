# v0.3.28 — signed determinant proof split (uncompiled source)

The prior user compiler run for v0.3.27 finished with `sorryAx` on
`signed_pole_product_positive`, even though its imported all-pole sign theorem
reported no `sorryAx`.

This revision leaves all previously certified Lean modules unchanged, and
splits the failing lemma into three independent proof facts:

1. `signed_pole_factor_positive`: per-index sign via the proved all-pole lemma;
2. `signed_pole_factors_product_positive`: product of strictly positive signed factors;
3. `signed_pole_product_identity`: explicit finite product sign re-association.

`#print axioms` audits each helper and the final theorem. The runner also
checks that all eight DetSign declarations are present and `sorryAx`-free.

Only this module and affected downstream modules need recompilation. The
existing native Win64 Lean 4.33.0 FAST16 frozen-pass cache is preserved.

No local Lean compiler was used to produce this package.
