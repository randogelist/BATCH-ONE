# v0.3.27 – determinant sign / signed pole product

The previous compiler report found `sorryAx` on `signed_pole_product_positive` and hence downstream determinant sign declarations, while `signed_prod_identity` and imported all-pole sign proofs passed their independent axiom audits. This release rewrites the affected proof as two explicitly typed subgoals connected by a `calc` chain, not proposition-transport or `simpa`.

No previously certified source is modified. The new module and affected downstream imports must be compiled and axiom audited on the user's native Windows Lean 4.33.0. Neither the complete Theorem 3.3 nor the whole manuscript is claimed proved by this package.
