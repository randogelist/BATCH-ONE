# v0.3.22: exact binder normalization for Theorem 3.3 determinant sign

The previous native Lean compiler run stopped at `Theorem_3_3_Finite_Determinant_Sign.lean:65` with a type mismatch. This revision preserves all theorem statements and the imported proof chain; it replaces `exact h` with `simpa [signExponent] using h`, explicitly normalizing the generic `Finset.univ` sum and the paper's total finite-index sum. It also changes the module source marker to ensure the active package is not confused with v0.3.21.

The fixed module and its dependents are rebuilt when necessary. Previously verified identical source modules remain in the shared frozen Lean 4.33 cache. Exactly one `run.cmd` is included.

**No Lean compilation has been performed in the packaging environment.** This repair remains subject to the user's native compiler and axiom report. Report the full first type mismatch if it recurs.
