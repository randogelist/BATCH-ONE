# Rerun package ZETAHYPERBOLIC_v0_3_17_RERUN_FAST16

Native Windows Lean 4.33.0 only. Run from the extracted folder with the sole `run.cmd`.
All Lean sources are byte-for-byte identical to v0.3.16. Previously certified unchanged modules are reused from the persistent frozen-pass cache. New or unverified modules and their dependents are compiled on the user's machine.
No local Lean compilation was performed for this repackage. This rerun does not assert certification of unverified Theorem 3.3 or Theorem 3.4 modules.
Expected release log: RELEASE=ZETAHYPERBOLIC_v0_3_17_RERUN_FAST16
