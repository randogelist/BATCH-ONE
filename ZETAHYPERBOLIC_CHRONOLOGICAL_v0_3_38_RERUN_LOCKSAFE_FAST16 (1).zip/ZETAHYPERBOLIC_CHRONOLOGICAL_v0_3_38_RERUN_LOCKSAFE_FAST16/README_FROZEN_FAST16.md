# CURRENT RUNNER: v0.3.6 (targeted certificate)

See `README_P32_CERTIFICATION.md` for one-time forced proof recheck.

# CURRENT RUNNER: v0.3.5

This version reports `ACTIVE_RELEASE` and validates a unique source marker before using the incremental cache. The previous v0.3.4 instructions below are historical.

# ZETAHYPERBOLIC v0.3.4 — Proposition 3.2 axiom fix, persistent FROZEN_PASS

## Deliverable

Single ZIP, one root-level `run.cmd`. 68 tracked Lean source modules (plus `lakefile.lean`); new paper module:
`Proposition_3_2_Continuous_Hyperbolic_Pencil.lean`.
No local Lean compilation has been performed by the assistant; these new proof terms require the user's Lean 4.33.0 kernel check.

## Compiler-log repair (2026-10-24)

The user's v0.3.3 Lean 4.33.0 output reported `sorryAx` for
`ManuscriptChronology.Proposition3_2.continuousDensity_at_odd`. Its prior broad
`simp` proof was therefore not a verified derivation. The v0.3.4 patch changes
ONLY `Proposition_3_2_Continuous_Hyperbolic_Pencil.lean` among Lean source files:

- Replaces `continuousTerm_at_odd` with an explicit exponent-cast rewrite.
- Replaces `continuousDensity_at_odd` with a three-line mathematical chain:
  (1) prefactor and integer power, (2) termwise equality under `tsum_congr`,
  (3) original odd-weight density definition.
- Prints axioms separately for the termwise lemma, density lemma, and pole specialization.
- Renames the unused `hy` term-positivity argument `_hy` to avoid that warning.

**No Lean run was performed during this repackaging.** Only your pinned Windows
Lean 4.33.0 compiler can confirm the repaired proof. This release does not
claim to close the real-s Gram positivity frontier. On detection of `sorryAx`,
the Windows launcher fails before committing the affected `.olean`.

## New mathematics (chronological order)

- Correct `w_s` prefactor: `2*(2*pi)^(s-1)/Gamma(s)`; prove it specializes to equation (3.1) at every `s=2k+1`.
- Define the true real-order series/density and the paper's integral Gram matrix `A(s)`.
- Prove each real-order summand positive, and density positive **when** its series is summable.
- Construct `gamma_a(s)` from the proved rational Lagrange data, prove `gamma_a(s) != 0` and `det M_s != 0` for any real s.
- Construct a **distinct reference-base family** using the already proved odd-weight Gram, and prove it has full degree and real roots for all real s.

This does NOT claim that `A(s)` of Proposition 3.2 is proved positive definite or that the reference family equals `A(s)` for noninteger s. Those remain the chronological analytic frontier. No new axiom or hypothesis is hidden in the main paper chain.

## Persistent cache semantics

- Cache path: `%USERPROFILE%\lean-native\zetahyperbolic_chronological_verified_v1`.
- `run.cmd`: compile the chronological dependency closure; skip modules whose byte-identical source **and all direct/transitive dependencies** remain unchanged.
- `run.cmd all`: include every source module, with identical frozen-pass policy.
- `run.cmd full`: deliberately rebuild the closure (new compiler/Mathlib configuration requires it).
- Versioned ZIPs no longer discard frozen `.olean` files.
- If the previous `v0.3.2_FAST16` extraction exists with completed compatible config, compilation logs, axiom log, unchanged source snapshots, and `.olean` files, the launcher migrates those compiled modules into the new shared cache without recompilation.
- If there is no verifiable previous build on your machine, the first run will compile the dependency closure once. We do NOT label prior modules as passed without your actual build evidence.
- Any modified module or modified import is rebuilt, then affected downstream modules are invalidated. A changed Lean 4.33.0/Mathlib cache configuration triggers rebuilding.
- Compiler is `lean.exe -j 16`; no Lake, network, PowerShell, Python, or WSL in the Windows runner.

## Copy-paste Windows CMD

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_4_SORRYAX_FIX1.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_4_SORRYAX_FIX1\run.cmd"
```

Return `CHRONOLOGICAL_BUILD.log` (and `CHRONOLOGICAL_AXIOMS.log` as appropriate) for compiler-driven fixes. The launcher checks `sorryAx` in newly compiled outputs; it does not re-audit unchanged inherited modules.

## v0.3.33 note
Axiom provenance for finite determinant sign now uses direct generic induction, not the specialized equality wrapper.

## v0.3.34
Added a fully unconditional leading-coefficient nonzero extraction prior to the finer sign lemma. Cached verified modules are unchanged.
