# CURRENT RELEASE: v0.3.5 DEFINITE RERUN

Use the v0.3.5 `run.cmd` in this folder (single launcher). Previous release instructions below are historical.
The changed module includes a visible release marker and a rewritten explicit equality proof. Lean has not been run locally.

# Native Lean 4.33.0 — PDF chronology, release v0.3.4 FROZEN_FAST16

**Goal:** formalize all 51 numbered definitions, lemmas, theorems,
propositions, corollaries, remarks, and conjectures in the paper in the PDF's
order. This release is a **chronological proof checkpoint**, not a blanket
claim of closure. The inherited v0.2.0 source graph and the existing one-witness
application remain intact.

## New native Lean units

- `Lemma_2_2_Pullback_Identity.lean`: original order-s monomial and pole cases, with their full finite-linear extension on the source's decomposed rational-moment domain.
- `Lemma_2_3_Reflection_And_Difference.lean`: reflected monomials, entire finite polynomials,
  finite pole combinations, and safe finite pole-difference sums.
- `PAPER_CHRONOLOGICAL_MAIN.lean`: imports real proof terms in source order,
  checks existing theorem declarations, and prints key axioms.
- `CHRONOLOGICAL_THEOREM_REGISTER.md` and `.tsv`: **all 51** paper items, with
  exact status and source bridge.

## Native Windows workflow — direct cached Lean FAST16

The single `run.cmd` now uses the previously established fast startup: pinned
`%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0\bin\lean.exe`,
16 threads, prebuilt Mathlib `.olean` files at
`%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1`, no Lake, no downloads,
no dependency rebuilds, no PowerShell/Python/WSL/network.

The launcher builds the **updated chronological dependency closure** of the chronological
PDF endpoint by default. Invoke `run.cmd all` to check **all 68 tracked Lean modules**.
Source and imported-module changes invalidate only the affected shared cached `.olean` results;
`run.cmd full` forces a clean logical rebuild (without deleting cache). Cache survives future ZIP release folders. See `README_FROZEN_FAST16.md`.

The only compiler invocation occurs on **your Windows machine**. This release
was prepared with static source inspection, NOT by compiling any Lean code.

## Status boundaries

The fully constructed general odd-weight spectral endpoint (Theorem 3.1)
is not odd-zeta irrationality. Theorem 4.4 remains conditional on the single
`PaperWitness` structure (two distinct growth/decay estimates). We have not
introduced other assumptions to make later Sections 3–6 appear complete.

Corollaries 3.5/3.6 still require correction. Proposition 3.2 now has
a corrected prefactor, exact odd-weight specialization, real-order Gram definition
and a nonsingular real-order derivative; Gram-integral positivity is open. The source's Section 5–6 theorem
filenames are retained, but **many contain only partial algebraic reductions**;
the attached register does not mislabel them as complete.

## Next theorem

**Proposition 3.2 (continuous hyperbolic pencil, repaired normalization)**.
Normalization and odd matching are now in source, along with the derivative
and reference-family hyperbolicity. Next prove the true real-order Gram
positivity, not merely the reference family. No assumption about ζ(5) or odd irrationality
is required for this part.

## v0.3.4 accelerated persistent FROZEN_PASS runner

With the ZIP in Downloads, paste into Windows CMD:

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_3_FROZEN_FAST16.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_3_FROZEN_FAST16\run.cmd"
```

The ZIP contains exactly one `run.cmd`, root-level inside the extracted folder.
For reruns use the same `call` command; incremental local `.olean` reuse applies.
For all sources: `call "...\run.cmd" all`. For a forced rebuild: `run.cmd full`.

## v0.3.4 compiler repair

Replaced the non-closed `continuousDensity_at_odd` broad-simp proof with explicit termwise `tsum_congr`. Lean kernel confirmation pending on user compiler. Frozen-pass cache and module manifests retained unchanged.

## v0.3.33 note
Axiom provenance for finite determinant sign now uses direct generic induction, not the specialized equality wrapper.

## v0.3.34
Added a fully unconditional leading-coefficient nonzero extraction prior to the finer sign lemma. Cached verified modules are unchanged.
