# Coverage estimate - Zetahyperbolic chronological Lean, 2026-10-24

**Answer: approximately 16% of the PDF's 51 numbered items have substantial Lean formalization at the theorem/definition level.** Counting progress on the incomplete theorem frontiers proportionally, the project has approximately **25-30% meaningful mathematical formalization**. Neither percentage means the entire PDF has been verified or that every printed conclusion is proved.

## Reproducible denominator

- Source: 52-page `Zetahyperbolic (3) (1)(4).pdf` and bundled `CHRONOLOGICAL_THEOREM_REGISTER.tsv` (51 numbered items, including one definition, the author's remarks/conjecture, and 2 items requiring corrections).
- **8/51 = 15.69% substantial source coverage**, comprising 1 definition (2.1), 2 generator lemmas (2.2, 2.3), and 5 theorem statements with substantial inherited proof terms (2.4, 2.5, 3.1, 4.1, 5.4).
- **14 further items have partial or emerging Lean infrastructure**: 11 marked `PARTIAL` in the frozen register, 1 `PARTIAL_CORRECTED`, plus 3.3 and 3.4, which now have finite sign / reciprocal-edge modules but do not have full-paper certificates. This is not 14 more completed theorems.
- Weighted illustration: 8 + (0.35 to 0.50) x 14 = 12.9-15.0 'equivalent completed items' out of 51, or 25.3-29.4%. The weights are estimates, not measured proof progress.
- The final `Witness` interface (4.4) is **conditional**; its quantitative existence has not been proved. It is not counted among completed theorems.
- 2 PDF corollaries (3.5, 3.6) require correction of the *printed assertions*; no Lean tactic can prove a false statement unchanged.

## Breakdown of substantial coverage

| Part | Substantial / numbered items |
|---|---:|
| Section 2 | 5 / 5 |
| Section 3 | 1 / 10 |
| Section 4 | 1 / 11 |
| Section 5 | 1 / 7 |
| Section 6 | 0 / 18 |

## Current compiler checkpoint

- Last explicit passed baseline for the branch: `v0.3.10`, 46 modules in its dependency closure, `T33_AXIOM_CERTIFICATION=PASS`, 44 reused + 2 compiled. Those certify the **actual declarations** in the package, not every subclaim of printed Theorem 3.3.
- The subsequent `v0.3.27` build failed at `Theorem_3_3_Finite_Determinant_Sign` because `signed_pole_product_positive` and dependents still imported `sorryAx`.
- Latest source frontier bundled here: `v0.3.29` inductive determinant-sign repair, **not yet validated by a supplied compiler report**. New unverified source files must not be counted as passed.
- The `v0.3.30` archive adds only this coverage documentation. It preserves all Lean `.lean` sources byte-for-byte from v0.3.29 and retains exactly one root `run.cmd` for native Windows Lean 4.33 FAST16/frozen-pass verification.

## Scope versus proof

Current filenames, declarations, and module counts are not paper-level completion rates. In particular, sections 3, 5, and 6 contain partial finite algebraic consequences whose analytic, p-adic, integral, or asymptotic claims remain unproved in the existing Lean graph. The target of one and only one external `Witness` for all downstream claims remains an **architectural goal**, not the present unconditional full-paper state.

## Method

Counts taken from `CHRONOLOGICAL_THEOREM_REGISTER.tsv`, cross-checked against the `Theorem_3_3_*` / `Theorem_3_4_*` source list and user's most recent Lean compiler reports. No local Lean compilation was done.
