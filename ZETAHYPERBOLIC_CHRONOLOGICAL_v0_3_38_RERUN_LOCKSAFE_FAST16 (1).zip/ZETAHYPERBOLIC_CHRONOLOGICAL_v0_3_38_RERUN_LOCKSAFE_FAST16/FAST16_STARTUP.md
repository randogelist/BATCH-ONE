# FAST16 accelerated startup — native Windows Lean 4.33.0

- Single ZIP, single root `run.cmd` (CRLF, ASCII); no helper CMD scripts.
- Direct pinned `lean.exe -j 16` and `LEAN_NUM_THREADS=16`.
- Mathlib is loaded from compiled `.olean` roots of the **existing**
  `%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1` cache.
- No `lake`, network access, fetch/install/update, Python, PowerShell, or WSL.
- Local compiled outputs: `_lean_out/`; no stale global caches overwritten.
- Byte-for-byte source snapshot checks (`fc /b`) plus topologically propagated
  dirtiness make repeat runs incremental and dependency-aware.
- The chronological endpoint and the comprehensive axiom-audit module are
  always compiled on requested runs to display fresh declarations.
- Default: `44` modules required to import `PAPER_CHRONOLOGICAL_MAIN.lean`.
- `run.cmd all`: all `67` Lean modules, including `CHECK_AXIOMS.lean`.
- `run.cmd full`: force recompile for the current selection.
- `run.cmd all full`: force all modules.
- Logs: `CHRONOLOGICAL_BUILD.log`, `CHRONOLOGICAL_AXIOMS.log`.
- `Witness` remains the sole explicit arithmetic premise of the terminal
  conditional theorem; source-only audit does not certify complete paper closure.

## Command from CMD/Downloads

```cmd
cd /d "%USERPROFILE%\Downloads" && tar -xf "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_2_FAST16.zip" && call "ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_2_FAST16\run.cmd"
```

For a complete 67-file source compile pass:

```cmd
call "%USERPROFILE%\Downloads\ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_2_FAST16\run.cmd" all
```

**No Lean compilation performed during package preparation.**


## v0.3.3: persistent frozen-pass cache
The runner now uses `%USERPROFILE%\lean-native\zetahyperbolic_chronological_verified_v1` for cached compiled `.olean` files and byte-identical source snapshots, independent of the release ZIP folder. An unchanged module is not recompiled after it successfully passes with the same toolchain/Mathlib configuration and unchanged imported modules. Compatible completed v0.3.2 outputs can be migrated with source-byte verification. Read `README_FROZEN_FAST16.md`.
