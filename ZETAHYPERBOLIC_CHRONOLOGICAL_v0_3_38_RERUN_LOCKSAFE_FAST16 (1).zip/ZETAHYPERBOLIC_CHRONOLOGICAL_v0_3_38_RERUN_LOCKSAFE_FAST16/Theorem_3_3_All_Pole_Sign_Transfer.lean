-- THEOREM33_ALL_POLE_SIGN_V0319_20261024
import Theorem_3_3_Total_Positivity_Leading_Sign_And_Universal_Signature
import Theorem_3_3_Signed_Product_Core
import Mathlib.Tactic

/-!
# Theorem 3.3, finite part — sign at every Lagrange pole

Theorem 3.3(3) requires the alternating signs of the actual coefficients
`poleWeight`, not merely a statement about an arbitrary diagonal matrix.
This file supplies the missing finite sign transfer from the exact product
for `derivative (tailD p)` (Theorem 2.5). No analytic positivity or Witness
assumption is introduced.

It is not yet the full theorem: total positivity of *all* moment minors
and the inertia transport for the Gram-conjugated matrix are separate goals.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChronology.Theorem3_3_AllPoles

open ManuscriptChain

/-- For a product of signed factors, the number of negative factors
controls the sign. This lemma is over the actual finite index set, with
no bounded-size verification. -/
theorem signed_product_positive (s : Finset ℕ) (a : ℕ)
    (f : ℕ → ℚ) :
    (∀ b ∈ s, 0 < (if b < a then -(f b) else f b)) →
    0 < (-1 : ℚ) ^ ((s.filter (fun b => b < a)).card) *
      (∏ b ∈ s, f b) := by
  intro h
  exact ManuscriptChronology.Theorem3_3_SignCore.signed_product_positive s a f h

/-- The actual tail denominator has exactly `i.val` negative factors
at pole index `N+1+i`. This is the key missing input for a universal
alternating residue-sign calculation. -/
theorem tail_derivative_signed_positive
    (p : Real.Parameters) (i : Fin p.h) :
    0 < (-1 : ℚ) ^ i.val *
      (derivative (Real.tailD p)).eval (PoleDiagonalization.poleNode p i) := by
  let a : ℕ := PoleDiagonalization.poleIndex p i
  let S : Finset ℕ := (Finset.Icc (p.N + 1) p.K).erase a
  -- Obtain lattice membership by arithmetic directly, without depending on
  -- an unchecked imported theorem or its cached axiom provenance.
  have ha : a ∈ Finset.Icc (p.N + 1) p.K := by
    have hi : i.val < p.h := i.isLt
    dsimp [Real.Parameters.h] at hi
    simp only [Finset.mem_Icc, a, PoleDiagonalization.poleIndex]
    omega
  have hsub : S.filter (fun b => b < a) = Finset.Ico (p.N + 1) a := by
    ext b
    constructor
    · intro hb
      have hf := Finset.mem_filter.mp hb
      have hm := Finset.mem_erase.mp hf.1
      exact Finset.mem_Ico.mpr ⟨(Finset.mem_Icc.mp hm.2).1, hf.2⟩
    · intro hb
      have hlo := (Finset.mem_Ico.mp hb).1
      have hlt := (Finset.mem_Ico.mp hb).2
      have hhi := (Finset.mem_Icc.mp ha).2
      have hbIcc : b ∈ Finset.Icc (p.N + 1) p.K :=
        Finset.mem_Icc.mpr ⟨hlo, by omega⟩
      have hneq : b ≠ a := by omega
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_erase.mpr ⟨hneq, hbIcc⟩, hlt⟩
  have hcount : (S.filter (fun b => b < a)).card = i.val := by
    rw [hsub, Nat.card_Ico]
    dsimp [a, PoleDiagonalization.poleIndex]
    omega
  have ha_pos : (0 : ℚ) < (a : ℚ) := by
    exact_mod_cast PoleDiagonalization.poleIndex_pos p i
  have hfactor : ∀ b ∈ S,
      0 < (if b < a then -(((b : ℚ) ^ 2) - (a : ℚ) ^ 2)
        else ((b : ℚ) ^ 2) - (a : ℚ) ^ 2) := by
    intro b hb
    have hne : b ≠ a := (Finset.mem_erase.mp hb).1
    by_cases hba : b < a
    · have hbq : (b : ℚ) < (a : ℚ) := by exact_mod_cast hba
      have hd : 0 < (a : ℚ) - (b : ℚ) := sub_pos.mpr hbq
      have hs : 0 < (a : ℚ) + (b : ℚ) := by
        have hb_nonneg : (0 : ℚ) ≤ (b : ℚ) := by positivity
        linarith
      have hh : 0 < (a : ℚ) ^ 2 - (b : ℚ) ^ 2 := by
        nlinarith [mul_pos hd hs]
      simpa only [if_pos hba, neg_sub] using hh
    · have hab : a < b := by omega
      have habq : (a : ℚ) < (b : ℚ) := by exact_mod_cast hab
      have hd : 0 < (b : ℚ) - (a : ℚ) := sub_pos.mpr habq
      have hs : 0 < (b : ℚ) + (a : ℚ) := by
        have hb_nonneg : (0 : ℚ) ≤ (b : ℚ) := by positivity
        linarith
      have hh : 0 < (b : ℚ) ^ 2 - (a : ℚ) ^ 2 := by
        nlinarith [mul_pos hd hs]
      simpa only [if_neg hba] using hh
  have hprod :
      0 < (-1 : ℚ) ^ ((S.filter (fun b => b < a)).card) *
        (∏ b ∈ S, ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) :=
    signed_product_positive S a
      (fun b => ((b : ℚ) ^ 2 - (a : ℚ) ^ 2)) hfactor
  rw [hcount] at hprod
  change 0 < (-1 : ℚ) ^ i.val *
    (derivative (Real.tailD p)).eval (-(a : ℚ) ^ 2)
  rw [PoleDiagonalization.tailD_derivative_eval p a ha]
  exact hprod

/-- Division by a quantity with an independently certified signed
positive value has the expected combined sign. -/
theorem signed_div_positive (u v : ℚ) (m n : ℕ)
    (hu : 0 < (-1 : ℚ) ^ m * u)
    (hv : 0 < (-1 : ℚ) ^ n * v) :
    0 < (-1 : ℚ) ^ (m + n) * (u / v) := by
  have hsign : (-1 : ℚ) ^ n ≠ 0 := by positivity
  have hvne : v ≠ 0 := by
    intro hzero
    simp [hzero] at hv
  have hsquare : (-1 : ℚ) ^ n * (-1 : ℚ) ^ n = 1 := by
    rw [← pow_add]
    have htwo : n + n = 2 * n := by omega
    rw [htwo, pow_mul]
    norm_num
  have hcancel : (u / v) * v = u := by
    field_simp [hvne]
  have hid :
      (-1 : ℚ) ^ (m + n) * (u / v) =
        (((-1 : ℚ) ^ m * u) / ((-1 : ℚ) ^ n * v)) := by
    rw [pow_add]
    apply (eq_div_iff (mul_ne_zero hsign hvne)).2
    calc
      ((-1 : ℚ) ^ m * (-1 : ℚ) ^ n * (u / v)) *
          ((-1 : ℚ) ^ n * v) =
        ((-1 : ℚ) ^ m * ((-1 : ℚ) ^ n * (-1 : ℚ) ^ n)) *
          ((u / v) * v) := by ring
      _ = ((-1 : ℚ) ^ m * u) *
          ((-1 : ℚ) ^ n * (-1 : ℚ) ^ n) := by rw [hcancel]; ring
      _ = (-1 : ℚ) ^ m * u := by rw [hsquare]; ring
  rw [hid]
  exact div_pos hu hv

/-- **All poles**: the manuscript coefficient gamma_(N+1+i) has the
alternating sign `(-1)^(N+i)` for every index and every m>=1. This
uses the actual polynomial residue, not a surrogate model. -/
theorem poleWeight_alternating (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h) :
    0 < (-1 : ℚ) ^ (p.N + i.val) *
      PoleDiagonalization.poleWeight p i := by
  let a : ℕ := PoleDiagonalization.poleIndex p i
  let node : ℚ := PoleDiagonalization.poleNode p i
  let num : ℚ := ((Real.D p.N).eval node) ^ (2 * p.m - 1)
  let den : ℚ := (derivative (Real.tailD p)).eval node
  let fac : ℚ := (a : ℚ) ^ (2 * p.k)
  have hn : p.N < a := by
    dsimp [a, PoleDiagonalization.poleIndex]
    omega
  have hnum : 0 < (-1 : ℚ) ^ p.N * num := by
    exact ManuscriptChronology.Theorem3_3.signed_odd_numerator_pos
      p.N a p.m hn hm
  have hden : 0 < (-1 : ℚ) ^ i.val * den :=
    tail_derivative_signed_positive p i
  have hfac : 0 < fac := by
    dsimp [fac]
    have hapos : 0 < a := by
      dsimp [a, PoleDiagonalization.poleIndex]
      omega
    exact pow_pos (by exact_mod_cast hapos) _
  have hsigned :
      0 < (-1 : ℚ) ^ (p.N + i.val) * (num / den) :=
    signed_div_positive num den p.N i.val hnum hden
  have hcombined :
      0 < (-1 : ℚ) ^ (p.N + i.val) * ((num / den) * fac) := by
    simpa only [mul_assoc] using (mul_pos hsigned hfac)
  change 0 < (-1 : ℚ) ^ (p.N + i.val) * (num / den * fac)
  exact hcombined

/-- In particular, coefficients are positive at even index parity. -/
theorem poleWeight_pos_of_even (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h)
    (heven : (p.N + i.val) % 2 = 0) :
    0 < PoleDiagonalization.poleWeight p i := by
  have hpow : (-1 : ℚ) ^ (p.N + i.val) = 1 := by
    have h : p.N + i.val = 2 * ((p.N + i.val) / 2) := by omega
    rw [h, pow_mul]
    norm_num
  simpa [hpow] using poleWeight_alternating p hm i

/-- Coefficients are negative at odd index parity. -/
theorem poleWeight_neg_of_odd (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h)
    (hodd : (p.N + i.val) % 2 = 1) :
    PoleDiagonalization.poleWeight p i < 0 := by
  have hpow : (-1 : ℚ) ^ (p.N + i.val) = -1 := by
    have h : p.N + i.val = 2 * ((p.N + i.val) / 2) + 1 := by omega
    rw [h, pow_add, pow_mul]
    norm_num
  have hh := poleWeight_alternating p hm i
  rw [hpow] at hh
  nlinarith

end ManuscriptChronology.Theorem3_3_AllPoles

-- Print provenance for the precise imported inputs used by this proof.
-- This separates inherited sorryAx from a local incomplete proof.
#print axioms ManuscriptChronology.Theorem3_3_SignCore.signed_product_formula
#print axioms ManuscriptChronology.Theorem3_3_SignCore.signed_product_positive
#print axioms ManuscriptChain.PoleDiagonalization.tailD_derivative_eval
#print axioms ManuscriptChronology.Theorem3_3.signed_odd_numerator_pos
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.signed_product_positive
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.signed_div_positive
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.tail_derivative_signed_positive
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_alternating
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_pos_of_even
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_neg_of_odd
