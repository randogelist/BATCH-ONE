-- THEOREM33_AX_PROBE_V0324_20261024
import Theorem_3_3_Consecutive_Pole_Signs
import Theorem_3_3_Signed_Product_Core
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Kernel-axiom provenance for the finite determinant sign chain

Every declaration below is a concrete imported theorem, NOT an assumption.
Lean itself prints the axioms of each imported proof term. The Windows
runner fails immediately if any of these reports contain `sorryAx`.
This diagnostic is deliberately separate from the manuscript results so
previously verified mathematical modules remain byte-identical.
-/

#print axioms ManuscriptChronology.Theorem3_3_SignCore.signed_product_formula
#print axioms ManuscriptChronology.Theorem3_3_SignCore.signed_product_positive
#print axioms ManuscriptChain.PoleDiagonalization.tailD_derivative_eval
#print axioms ManuscriptChronology.Theorem3_3.signed_odd_numerator_pos
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.signed_product_positive
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.signed_div_positive
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.tail_derivative_signed_positive
#print axioms ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_alternating
#print axioms ManuscriptChronology.Theorem3_3_Consecutive.poleWeight_ne_zero
