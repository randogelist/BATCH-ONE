import PAPER_WITNESS
import MAIN_CHAIN_ASSEMBLED
import MAIN_CHAIN_IRRATIONALITY

/-!
# Manuscript native chain: one external witness, no hidden extra assumptions

Paper source: Definition 2.1 -> Theorem 2.4 -> Theorem 2.5 -> Theorem 3.1
-> Theorem 4.1 -> Theorem 4.4.

For all odd weights the unconditional spectral conclusion is imported and
remains unconditional apart from structural admissibility.  For weight five,
`Witness` consists of exact normalized decay and quantitative spectral bounds.
`THEOREM_4_4_FROM_WITNESS` has exactly ONE explicit external argument.

This is NOT a claim to have formalized all Theorems 3.3-6.18 of the PDF.
The uncorrected Corollaries 3.5 and 3.6 cannot be proved as printed.
-/

noncomputable section

namespace ManuscriptChain.Paper

open ManuscriptChain.MainChain

/-- Theorem 3.1. This is an unconditional result for every admissible weight. -/
theorem THEOREM_3_1_UNCONDITIONAL
    (p : Real.Parameters) (hp : Real.Admissible p) :
    General.GeneralStatement p :=
  ManuscriptChain.MAIN_CHAIN_UNCONDITIONAL p hp

/-- Positivity and nonvanishing are discharged, using the analytic moment
realization.  They are deliberately NOT assumptions in PaperWitness. -/
theorem NONVANISHING_FROM_THEOREM_3_1 (w : PaperWitness) :
    ∀ n : ℕ, w.start + 1 ≤ n →
      RealTransfer.evalReal
        ((primitiveMainNormalization w.start).Q n) zeta5 ≠ 0 := by
  intro n hn
  exact ne_of_gt (normalized_value_pos
    (primitiveMainNormalization w.start)
    (main_baseValuePositive (w.start + 1) (by omega)) n hn)

/-- The exact exponential decay needed by Theorem 4.1. -/
theorem DECAY_FROM_WITNESS (w : PaperWitness) :
    RealTransfer.Decay (primitiveMainNormalization w.start).Q
      zeta5 decayBudget (w.start + 1) := by
  constructor
  · exact NONVANISHING_FROM_THEOREM_3_1 w
  · exact w.normalized_decay

/-- All spectral algebra is built from the proved Gram matrix and the proved
invertible derivative matrix. Only the printed 11.411 growth estimate remains
inside the witness. -/
noncomputable def SPECTRAL_FROM_WITNESS (w : PaperWitness) :
    MainSpectralData (w.start + 1) :=
  mainSpectralDataOfGram (w.start + 1) (gramFromGeneral w.start)
    w.spectral_growth

/-- Theorem 4.1, applied to the manuscript's own normalized polynomials.
The index choice and rational-denominator budget have already been proved. -/
theorem THEOREM_4_1_TRANSFER (w : PaperWitness) :
    RealTransfer.RationalMeasure zeta5 25687
      (indexDenominatorThreshold (w.start + 1)) :=
  RealTransfer.conditional_measure
    (main_localComparison (primitiveMainNormalization w.start)
      (SPECTRAL_FROM_WITNESS w))
    (DECAY_FROM_WITNESS w)
    (main_indexBudget (primitiveMainNormalization w.start))

/-- Strong irrationality conclusion using the normalized-decay component alone.
    No quantitative spectral estimate is used in this proof. -/
theorem IRRATIONAL_FROM_WITNESS (w : PaperWitness) :
    Irrational (riemannZeta 5).re :=
  ManuscriptChain.ZETA5_IRRATIONALITY_FROM_NORMALIZED_DECAY
    w.start w.normalized_decay

/-- The paper's Theorem 4.4 irrationality-measure exponent 25687, conditional
solely on the paper witness. -/
theorem MEASURE_FROM_WITNESS (w : PaperWitness) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b →
      indexDenominatorThreshold (w.start + 1) ≤ b →
      1 / (b : ℝ) ^ 25687 <
        |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| := by
  intro a b hb hthreshold
  have h := (THEOREM_4_1_TRANSFER w) a b hb hthreshold
  simpa only [zeta5, Real.zeta_five_eq_riemannZeta_re] using h

/-- ONE conditional input to the endpoint; the concrete denominator threshold
is extracted from the witness's starting index. -/
theorem THEOREM_4_4_FROM_WITNESS (hW : Witness) :
    Irrational (riemannZeta 5).re ∧
      ∃ b₀ : ℕ, ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
        1 / (b : ℝ) ^ 25687 <
          |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| := by
  obtain ⟨w⟩ := hW
  exact ⟨IRRATIONAL_FROM_WITNESS w,
    ⟨indexDenominatorThreshold (w.start + 1), MEASURE_FROM_WITNESS w⟩⟩

/-- Final renamed entrypoint with exactly one input. -/
theorem MAIN_CHAIN (hW : Witness) :
    Irrational (riemannZeta 5).re ∧
      ∃ b₀ : ℕ, ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
        1 / (b : ℝ) ^ 25687 <
          |(riemannZeta 5).re - (a : ℝ) / (b : ℝ)| :=
  THEOREM_4_4_FROM_WITNESS hW

end ManuscriptChain.Paper

#print axioms ManuscriptChain.Paper.THEOREM_3_1_UNCONDITIONAL
#print axioms ManuscriptChain.Paper.NONVANISHING_FROM_THEOREM_3_1
#print axioms ManuscriptChain.Paper.DECAY_FROM_WITNESS
#print axioms ManuscriptChain.Paper.SPECTRAL_FROM_WITNESS
#print axioms ManuscriptChain.Paper.THEOREM_4_1_TRANSFER
#print axioms ManuscriptChain.Paper.IRRATIONAL_FROM_WITNESS
#print axioms ManuscriptChain.Paper.MEASURE_FROM_WITNESS
#print axioms ManuscriptChain.Paper.MAIN_CHAIN
