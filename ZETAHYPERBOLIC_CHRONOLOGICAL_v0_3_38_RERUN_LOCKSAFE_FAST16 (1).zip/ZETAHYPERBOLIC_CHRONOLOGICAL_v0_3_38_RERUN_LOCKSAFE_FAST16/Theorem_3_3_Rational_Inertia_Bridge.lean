-- THEOREM33_RATIONAL_INERTIA_BRIDGE_V0316_20261024
import Theorem_3_3_Finite_Determinant_Sign
import Mathlib.Tactic

/-!
# Exact finite diagonal congruence and strict bilateral directions

Theorem 2.5 gives V⁻¹ M (V⁻¹)^T = diag(gamma). Combining it with the
sign-certified coefficients yields exact positive and negative diagonal
entries and hence an elementary *bilateral direction* certificate for
matrices of size at least two. This finite result does not assume positivity
of the archimedean Gram matrix or introduce a new global hypothesis.

To obtain the full printed inertia assertion for B=G^(-1/2) M G^(-1/2),
one still needs the positive definite Gram realization and a fully formalized
Sylvester inertia transport plus an exact parity count.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChronology.Theorem3_3_Inertia
open ManuscriptChain

/-- The original derivative matrix, represented in the Lagrange coordinate
basis via an invertible rational congruence. -/
def congruentDirection (p : Real.Parameters) :
    Matrix (Fin p.h) (Fin p.h) ℚ :=
  (PoleDiagonalization.poleVandermonde p)⁻¹ *
    (PoleDiagonalization.rationalDerivativeMatrix p) *
    ((PoleDiagonalization.poleVandermonde p)⁻¹).transpose

/-- Finite exact Sylvester reduction prior to real Gram conjugation. -/
theorem congruentDirection_eq_diagonal (p : Real.Parameters) :
    congruentDirection p =
      Matrix.diagonal (PoleDiagonalization.poleWeight p) := by
  exact PoleDiagonalization.pole_slope_diagonal p

/-- The i-th diagonal entry is the exact Lagrange pole weight. -/
theorem congruentDirection_diag (p : Real.Parameters) (i : Fin p.h) :
    congruentDirection p i i = PoleDiagonalization.poleWeight p i := by
  rw [congruentDirection_eq_diagonal]
  simp

/-- Every off-diagonal entry is exactly zero. -/
theorem congruentDirection_offdiag (p : Real.Parameters) (i j : Fin p.h)
    (hij : i ≠ j) : congruentDirection p i j = 0 := by
  rw [congruentDirection_eq_diagonal]
  simp [hij]

/-- The diagonalized *actual* derivative matrix is positive at even parity. -/
theorem congruentDirection_pos_of_even (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h)
    (he : (p.N + i.val) % 2 = 0) :
    0 < congruentDirection p i i := by
  rw [congruentDirection_diag]
  exact ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_pos_of_even p hm i he

/-- It is negative at odd parity. -/
theorem congruentDirection_neg_of_odd (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h)
    (ho : (p.N + i.val) % 2 = 1) :
    congruentDirection p i i < 0 := by
  rw [congruentDirection_diag]
  exact ManuscriptChronology.Theorem3_3_AllPoles.poleWeight_neg_of_odd p hm i ho

/-- Positivity of an exact diagonal entry is equivalent to even pole parity. -/
theorem congruentDirection_pos_iff_even (p : Real.Parameters)
    (hm : 0 < p.m) (i : Fin p.h) :
    0 < congruentDirection p i i ↔ (p.N + i.val) % 2 = 0 := by
  rw [congruentDirection_diag]
  exact ManuscriptChronology.Theorem3_3_Consecutive.poleWeight_pos_iff_even p hm i

/-- If the family has at least two poles, its diagonal reduction has both a
strictly positive and a strictly negative direction. -/
theorem bilateral_diagonal_entries (p : Real.Parameters)
    (hm : 0 < p.m) (hsize : 2 ≤ p.h) :
    ∃ i j : Fin p.h,
      0 < congruentDirection p i i ∧ congruentDirection p j j < 0 := by
  let i : Fin p.h := ⟨0, by omega⟩
  let j : Fin p.h := ⟨1, by omega⟩
  have hpar : (p.N + i.val) % 2 = 0 ∨ (p.N + i.val) % 2 = 1 := by
    omega
  rcases hpar with he | ho
  · have hjo : (p.N + j.val) % 2 = 1 := by
      dsimp [i, j] at he ⊢
      omega
    exact ⟨i, j,
      congruentDirection_pos_of_even p hm i he,
      congruentDirection_neg_of_odd p hm j hjo⟩
  · have hje : (p.N + j.val) % 2 = 0 := by
      dsimp [i, j] at ho ⊢
      omega
    exact ⟨j, i,
      congruentDirection_pos_of_even p hm j hje,
      congruentDirection_neg_of_odd p hm i ho⟩

end ManuscriptChronology.Theorem3_3_Inertia

#print axioms ManuscriptChronology.Theorem3_3_Inertia.congruentDirection_eq_diagonal
#print axioms ManuscriptChronology.Theorem3_3_Inertia.congruentDirection_diag
#print axioms ManuscriptChronology.Theorem3_3_Inertia.congruentDirection_offdiag
#print axioms ManuscriptChronology.Theorem3_3_Inertia.congruentDirection_pos_of_even
#print axioms ManuscriptChronology.Theorem3_3_Inertia.congruentDirection_neg_of_odd
#print axioms ManuscriptChronology.Theorem3_3_Inertia.congruentDirection_pos_iff_even
#print axioms ManuscriptChronology.Theorem3_3_Inertia.bilateral_diagonal_entries
