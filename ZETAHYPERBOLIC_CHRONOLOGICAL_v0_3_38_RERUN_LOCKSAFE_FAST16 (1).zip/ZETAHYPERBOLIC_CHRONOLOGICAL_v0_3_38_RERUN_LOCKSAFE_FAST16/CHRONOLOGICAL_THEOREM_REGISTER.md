# Zetahyperbolic — complete chronological statement register (v0.3.0)

Source: uploaded **52-page PDF**, pp. 3–50, with section numbering preserved.

This is a **statement-by-statement audit**, not a declaration that every
printed item has a valid Lean proof. Source status codes:

- `BASE_PROOF`: a substantial corresponding theorem has a proof term in the inherited Lean source. Fresh compiler validation is still necessary.
- `GENERATOR_PROOFS`: all generator cases proved, as specified in the row.
- `DEFINITION`: faithful finite definitions, not a theorem.
- `WITNESS`: one explicit input records the outstanding arithmetic estimates.
- `PARTIAL`: exact finite/conditional components only; **not** the full printed assertion.
- `OPEN`: no faithful completed Lean proof.
- `CORRECTION`: assertion **cannot** be accepted as printed; a concrete defect is proved.
- `REVIEW`/`REMARK`/`CONJECTURE`: not established as a theorem.

No new theorem is introduced with an unproved premise other than the existing explicitly named arithmetic witness; rows marked OPEN or PARTIAL are **not** imported as assumptions.

| PDF item | Page | Status | Original title | Actual Lean coverage |
|---|---:|---|---|---|
| Definition 2.1 | 3 | **DEFINITION** | Order-s rational moment functional | Finite moments, rational pole data and Hankel determinant defined. `Definition_2_1_Order_s_Rational_Moment_Functional.lean; Zetahyperbolic/Section2Checked.lean` |
| Lemma 2.2 | 4 | **GENERATOR_PROOFS** | Pullback identity | Monomial and simple-pole identities plus their full finite-linear extension on the source-decomposed rational moment domain. `Lemma_2_2_Pullback_Identity.lean` |
| Lemma 2.3 | 5 | **GENERATOR_PROOFS** | Reflection and difference identities | Reflection on all finite polynomial and pole combinations, plus differences on safe finite pole sums. `Lemma_2_3_Reflection_And_Difference.lean` |
| Theorem 2.4 | 6 | **BASE_PROOF** | Canonical basis invariance | Determinant scaling and primitive polynomial up to sign. `Theorem_2_4_Canonical_Basis_Invariance.lean; Zetahyperbolic/Section2Checked.lean` |
| Theorem 2.5 | 6 | **BASE_PROOF** | Lagrange pole diagonalization | Off-diagonal X-independence, diagonal affine formula, Vandermonde factorization. `Theorem_2_5_Lagrange_Pole_Diagonalization.lean; Zetahyperbolic/Section2Checked.lean` |
| Theorem 3.1 | 7 | **BASE_PROOF** | Universal hyperbolicity and zero-free disk | General odd weights; analytic positive Gram realization already constructed in inherited source. `MAIN_CHAIN_ASSEMBLED.lean; Theorem_3_1_Universal_Hyperbolicity_And_Zero_Free_Disk.lean` |
| Proposition 3.2 | 8 | **PARTIAL_CORRECTED** | Continuous hyperbolic pencil for all real s > 1 | Corrected density specializes pointwise to (3.1); the real-s integral Gram is now defined (positivity unproved), its Lagrange slope is nonsingular, and a distinct reference-base spectral family is proved. `PAPER_CORRECTIONS.lean; Proposition_3_2_Continuous_Hyperbolic_Pencil.lean` |
| Theorem 3.3 | 8 | **PARTIAL** | Total positivity, leading sign, and universal signature | New exact signed D_N evaluation, first-node gamma sign, special 27n dimension and exponent parity. New all-pole signed derivative and gamma certificates submitted for Windows verification; Gram-minor total positivity and inertia transfer still open. `Theorem_2_5_Lagrange_Pole_Diagonalization.lean; Theorem_3_3_Total_Positivity_Leading_Sign_And_Universal_Signature.lean` |
| Theorem 3.4 | 9 | **OPEN** | Root interlacing and Dodgson condensation for principal minors | Requires interlacing of generalized matrix pencils and Dodgson identity for original principal minors. `` |
| Corollary 3.5 | 10 | **CORRECTION** | Stieltjes J-fraction from interlacing roots | Printed unnormalized fraction fails already at h=1; corrected recurrence and normalization required. `PAPER_CORRECTIONS.lean` |
| Corollary 3.6 | 11 | **CORRECTION** | Stieltjes reciprocal-root power sums | Finite-support moment sequences have rank at most h, so sufficiently large Hankel minors vanish. `PAPER_CORRECTIONS.lean` |
| Theorem 3.7 | 11 | **OPEN** | Turanian non-negativity and Newton log-concavity | General real-rootedness supplies some inequalities; printed full strictness needs proof/review. `` |
| Theorem 3.8 | 12 | **OPEN** | Christoffel-Darboux pole representation and Jacobi derivative identity | Kernel resolvent, determinant derivative, and dominated differentiation unformalized. `` |
| Theorem 3.9 | 13 | **PARTIAL** | Hyperbolicity for Hurwitz and Dirichlet Hankel determinants | Some finite positivity; no source proof of exact Hurwitz/Dirichlet moment realization. `Zetahyperbolic/Section3Elementary.lean` |
| Remark 3.10 | 14 | **REVIEW** | Non-classicality of the Hankel family | Printed Favard and tridiagonality argument not independently established. `` |
| Theorem 4.1 | 14 | **BASE_PROOF** | Spectral irrationality measure criterion | General transfer from integer-polynomial smallness and spectral nonzero disk. `Theorem_4_1_Spectral_Irrationality_Measure_Criterion.lean; MAIN_CHAIN_SINGLE_WITNESS.lean` |
| Proposition 4.2 | 15 | **OPEN** | Transfer criterion for algebraic approximations | Height/resultant proof not yet translated with exact root-height accounting. `` |
| Proposition 4.3 | 15 | **OPEN** | Ultrametric zero-free disk over Qp | p-adic polynomial Lipschitz bound plausible; not present as exact proof. `` |
| Theorem 4.4 | 16 | **WITNESS** | Sharpened spectral bound and irrationality measure for zeta(5) | Final application depends on explicit normalized decay and growth fields of one PaperWitness. `PAPER_WITNESS.lean; MAIN_CHAIN_SINGLE_WITNESS.lean` |
| Theorem 4.5 | 18 | **PARTIAL** | Irrationality and measure for b zeta(5)+a zeta(3) | Finite coupled identities/transfer; manuscript positivity and p-adic bounds not fully discharged. `Theorem_4_1_Linear_Odd_Zeta_Family.lean` |
| Theorem 4.6 | 19 | **OPEN** | Two-sided determinant bounds and coefficient heights | Quadratic asymptotics and height constants require analytic proof and/or additional data. `` |
| Theorem 4.7 | 21 | **OPEN** | Macroscopic exponential root collapse and separation | Needs Theorems 4.4 and 4.6 plus clustering and root-separation arguments. `` |
| Proposition 4.8 | 21 | **OPEN** | Rational root exclusion and degree bounds for cluster factors | Derived consequence of 4.4 and polynomial factors; not yet formalized. `` |
| Remark 4.9 | 22 | **REVIEW** | Spectral bounds and variational conjecture | Lower/upper potential estimates and variational reformulation to audit. `` |
| Remark 4.10 | 22 | **REVIEW** | Lee-Yang phase transition at zeta(5) | Limit free energy existence and first-order classification are not proved by zero pinching alone. `` |
| Conjecture 4.11 | 22 | **CONJECTURE** | Limit of spectral growth rate | Unproved conjecture in the source, not a theorem to make unconditional. `` |
| Theorem 5.1 | 22 | **PARTIAL** | Two-variable Beukers measure for zeta(7) | Rational dual entries encoded; exact double-integral moment equality still open in Lean. `Theorem_5_1_Two_Variable_Beukers_Measure_For_Zeta_7.lean` |
| Theorem 5.2 | 23 | **PARTIAL** | Dual hyperbolicity and Krein-space decomposition | Finite quadratic certificates imply positivity under explicit tail estimates; full claim not yet proved. `Theorem_5_2_Dual_Hyperbolicity_And_Krein_Space_Decomposition_Of_The_Two_Variable_Zeta_7_Pencil.lean` |
| Proposition 5.3 | 24 | **OPEN** | Two-variable Beukers measure and dual pencil for beta(4) | Needs analytic beta moment identity and consistent rational moment data. `` |
| Theorem 5.4 | 25 | **BASE_PROOF** | Cancellation of higher zeta values on even pole pairs | Exact simple-pole cancellation for original harmonic data, all k and j>=1. `Theorem_5_4_Even_Pole_Pair_Cancellation.lean` |
| Remark 5.5 | 25 | **REMARK** | Restriction to simple poles | Source explicitly does not treat higher-order poles. `` |
| Theorem 5.6 | 26 | **OPEN** | Weight-seven prime-sum evaluation and pole-ordered refinement | Exact piecewise integral, p-adic local basis and valuation improvement unformalized. `` |
| Theorem 5.7 | 28 | **OPEN** | Simultaneous double-pole Hankel determinant for {1,zeta(5),zeta(6)} | Full q-adic nonvanishing and all minors unproved in current source. `` |
| Theorem 6.1 | 29 | **OPEN** | Divided-difference p-adic valuation law and intrinsic barrier | Requires full moment identity from 5.1 and exact local valuations. `` |
| Theorem 6.2 | 31 | **OPEN** | Simultaneous weight-(6,7) Beukers functional | Asymmetric moment identities and denominator overhead reduction not formalized. `` |
| Theorem 6.3 | 32 | **PARTIAL** | Unconditional q-adic non-vanishing and positive-cone approximations | Finite-certificate-to-sign implication, conditional on tail control and basis existence. `Theorem_6_3_Unconditional_Q_Adic_Non_Vanishing_And_Explicit_Positive_Cone_Approximations_For_G_A_7.lean` |
| Theorem 6.4 | 33 | **PARTIAL** | Character-Vandermonde sign cancellation for beta(4) | Repair data interfaces only, not source-asserted positive beta measure. `Theorem_6_4_Character_Vandermonde_Sign_Cancellation_And_Unconditional_Hyperbolicity_For_Beta_4.lean` |
| Theorem 6.5 | 34 | **OPEN** | Unconditional q-adic non-vanishing for beta(4) determinant | Not proved in this Lean graph. `` |
| Theorem 6.6 | 35 | **OPEN** | Generalized multi-weight positive-definite pencil | Needs coefficient/weight positivity plus arithmetic distribution bridge. `` |
| Theorem 6.7 | 37 | **OPEN** | Universal multi-weight two-variable Beukers Krein decomposition | General signed-measure Krein identity and subspace existence unformalized. `` |
| Corollary 6.8 | 38 | **OPEN** | Three-term linear independence cone for {1,zeta(3),zeta(5)} | Depends on 4.5 quantitative conclusion; not an unconditional current endpoint. `` |
| Theorem 6.9 | 38 | **PARTIAL** | Triple-pole and multi-weight Hankel determinants | Finite Hermite algebra repair only; not all claimed q-adic valuations. `Zetahyperbolic/Theorem_6_9_Triple_Pole_Hermite_Repair.lean` |
| Theorem 6.10 | 39 | **PARTIAL** | Universal potential-gap identity and vanishing quadratic derivative growth | Selected finite determinant comparisons; asymptotic potential identity not fully Lean-proven. `Zetahyperbolic/Theorem_6_10_Finite_Determinant_Identity.lean; Zeta5Merge/Theorem6_10.lean` |
| Theorem 6.11 | 40 | **OPEN** | p-adic distribution growth law and 2-adic beta obstruction | Full local distribution and polynomial quotient analysis unformalized. `` |
| Theorem 6.12 | 42 | **OPEN** | Full-dimension sign-flip restoration for beta(4) | Positive weight and q-adic nonvanishing require construction. `` |
| Theorem 6.13 | 43 | **OPEN** | Central-factorial secant differential identity and unilateral signature | Laplace cancellation and full-weight spectral signature unformalized. `` |
| Theorem 6.14 | 45 | **OPEN** | Even-pole scaling and mixed zeta-beta pencils | Needs analytic coupling and positive reference weight. `` |
| Theorem 6.15 | 46 | **OPEN** | Arithmetic transcendence and rank-one Pade pencil for beta odd | Needs full degree/rank data and arithmetic endpoint; check exact source claims. `` |
| Theorem 6.16 | 47 | **PARTIAL** | Generalized multi-weight Zeta-Beta positive-definite pencil | Continuity-based comparison if strict endpoint positivity is provided; source does not construct weight. `Zeta5Merge/Theorem6_16.lean` |
| Theorem 6.17 | 48 | **PARTIAL** | Universal two-variable Zeta-Beta pencil, Krein and non-vanishing | Partial finite algebra / conditional replacement, not full source theorem. `Zeta5Merge/Theorem6_17.lean` |
| Theorem 6.18 | 49 | **PARTIAL** | Principal-minor 2-adic integrality and dyadic height bounds | Partial exact finite/dyadic lemmas; no complete source statement. `Zeta5Merge/Theorem6_18.lean` |

## Chronological build rule

Prove items in increasing PDF order. Do not move an unresolved lemma to a
`structure` field just to obtain an apparent full proof. The single
`PaperWitness` is permitted **only** for the arithmetic estimate actually
used in Theorem 4.4; it is not a generic admission for the entire manuscript.
Every theorem must use the actual manuscript objects, not an arbitrary model
with the desired conclusion already inside its assumptions.

**v0.3.3 chronological frontier:** corrected prefactor and continuous pole-slope algebra at Proposition 3.2, without claiming the real-order Gram integral has been proved.

**First audited checkpoint:** Definition 2.1; Lemma 2.2 generators; Lemma 2.3
generators; Theorems 2.4 and 2.5; Theorem 3.1. The next chronologically
unresolved statement is **Proposition 3.2**, now partially developed with corrected normalization; the true real-order integral Gram positivity is still open.

**No local Lean compilation performed on this release.** The provided
Windows `run.cmd` is the only command script and invokes your compiler.

**v0.3.7 frontier:** Theorem 3.3 first finite sign/parity lemmas submitted to user compiler. The theorem is not yet fully proved. v0.3.6 Proposition 3.2 axiom subcertification remains frozen.

**v0.3.11 frontier (compiler pending):** all-pole alternating signs for the original Lagrange residues are expressed as Lean theorems in `Theorem_3_3_All_Pole_Sign_Transfer.lean`; not marked as passed until Windows Lean kernel and axiom audit confirm.

**v0.3.15 submitted, compiler pending:** Theorem 3.3 finite inertia prerequisites: no zero pole weights, positivity iff even parity, strictly opposite signs for adjacent pole weights. These results are in `Theorem_3_3_Consecutive_Pole_Signs.lean`, which imports the all-pole theorem. The all-pole proof itself remains pending the user compiler for v0.3.14 or later. No full Theorem 3.3 assertion is made.

**v0.3.16 source frontier, compiler unverified:** New actual derivative determinant leading-coefficient sign with finite sign exponent; exact rational diagonal congruence and bilateral diagonal entries (size >=2); exact scalar reciprocal eigenvalue/root gap bound as a Theorem 3.4 prerequisite. All-pole sign v0.3.14 remains pending native certification. These are subtheorems, not completion of printed Theorems 3.3–3.4.

**v0.3.16 arithmetic specialization:** `Theorem_3_3_Weight_Five_Leading_Sign.lean` proves the proposed exact formula for the leading coefficient sign of the actual weight-five determinant, modulo native Lean certification.


### v0.3.28 DetSign split-proof checkpoint
Source-only refactor of `signed_pole_product_positive`; native compiler verification pending. No theorem from the full paper is newly claimed complete by this refactor.

### 2026-10-24 v0.3.29 finite determinant sign frontier

`Theorem_3_3_Finite_Determinant_Sign.lean`: independent finite induction for product positivity. Awaiting native compiler and axiom audit. No new unconditional whole-paper claim.

## v0.3.31 principal endpoint (new, compiler pending)

`PAPER_PRINCIPAL_ENDPOINT.lean`: formal principal *core* statement plus a theorem with exactly one `ManuscriptChain.Paper.Witness` argument. This does not upgrade any open numbered PDF theorem to PROVED.

## v0.3.32 — deterministic finite sign repair

`Theorem_3_3_Finite_Determinant_Sign.lean` uses the already proven positive Finset product plus exact signed product identity. Compiler certificate required; the original PrincipalStatement remains unchanged and conditional only on Paper.Witness.
