import Mathlib

/-!
# Corrections required for exact correspondence with the supplied manuscript

This module proves unconditional, finite counterchecks for printed claims.
It does NOT replace the original assertions by weaker definitions with the
same name. No new mathematical axiom is introduced.
-/

namespace PaperCorrections

/-- Proposition 3.2: at s=3 the displayed continuous prefactor is
    pi/2 times the odd-integer prefactor (here t stands for pi).
    The identity is polynomial in t and needs no approximation to pi. -/
theorem continuous_prefactor_weight_three (t : ℝ) :
    (2 * t) ^ 3 / (2 * (2 : ℝ)) =
      (t / 2) * (2 * (2 * t) ^ 2 / (2 : ℝ)) := by
  ring

/-- The unrepaired difference of the two coefficients. -/
theorem continuous_prefactor_difference (t : ℝ) :
    (2 * t) ^ 3 / (2 * (2 : ℝ)) -
        2 * (2 * t) ^ 2 / (2 : ℝ) =
      2 * t ^ 2 * (t - 2) := by
  ring

/-!
## Corollary 3.5: exact h=1 original pencil

Take odd weight s=3 (k=1), m=1, N=1, K=2.  Then
  D_1(t)^2 / D_2(t) = (t+1)/(t+4) = 1 - 3/(t+4).
By manuscript Definition 2.1:
  mu_X(1)=1/4,
  mu_X(1/(t+4))=4*(X-H_2^(3))+1/8-1/2,
  H_2^(3)=9/8.
The actual 1x1 determinant therefore has slope -12, not 1.
As written, the h=1 denominator of formula (3.6) has slope +1.
-/

def h1Monomial : ℚ := 1 / 4

def h1PoleAtFour (X : ℚ) : ℚ :=
  4 * (X - 9 / 8) + 1 / 8 - 1 / 2

def h1OriginalDet (X : ℚ) : ℚ :=
  h1Monomial - 3 * h1PoleAtFour X

theorem h1_original_det_exact (X : ℚ) :
    h1OriginalDet X = 119 / 8 - 12 * X := by
  dsimp [h1OriginalDet, h1Monomial, h1PoleAtFour]
  ring

theorem h1_original_det_slope :
    h1OriginalDet 1 - h1OriginalDet 0 = (-12 : ℚ) := by
  norm_num [h1_original_det_exact]

/-- No choice of a or center can make the manuscript's unnormalized
    h=1 continued-fraction denominator coincide with this determinant. -/
theorem printed_h1_continued_fraction_impossible (a center : ℚ) :
    ¬ (∀ X : ℚ, h1OriginalDet X = a + (X - center)) := by
  intro h
  have hunit : h1OriginalDet 1 - h1OriginalDet 0 = (1 : ℚ) := by
    rw [h 1, h 0]
    ring
  rw [h1_original_det_slope] at hunit
  norm_num at hunit

/-!
## Corollary 3.6: rank-one moment obstruction

For one positive point mass at u, moments are m_0=1, m_1=u,
m_2=u^2.  Their 2x2 Hankel determinant is identically zero.
Thus the printed blanket assertion of strict positivity of all Hankel
minors of finite-support measures cannot hold, even at h=1.
-/

theorem one_atom_second_hankel_minor (u : ℝ) :
    (1 : ℝ) * u ^ 2 - u * u = 0 := by
  ring

theorem one_atom_hankel_not_strictly_positive (u : ℝ) :
    ¬ (0 < (1 : ℝ) * u ^ 2 - u * u) := by
  rw [one_atom_second_hankel_minor]
  exact lt_irrefl 0

end PaperCorrections

#print axioms PaperCorrections.continuous_prefactor_weight_three
#print axioms PaperCorrections.printed_h1_continued_fraction_impossible
#print axioms PaperCorrections.one_atom_hankel_not_strictly_positive
