# v0.3.16 — structural base, first fully reasoned Lean extension

New Lean proof modules:
- Theorem_3_3_Finite_Determinant_Sign (global sign of actual det M and leadingCoeff delta via Vandermonde det square, with source all-pole sign lemma)
- Theorem_3_3_Rational_Inertia_Bridge (exact coordinate diagonalization and guaranteed positive/negative diagonal directions)
- Theorem_3_4_Reciprocal_Spectral_Edge (scalar reciprocal root distance and its order/gap transfers)

Unchanged previously certified files preserved byte-for-byte; 48 -> 51 modules in chronological CORE import closure.
FULL_PAPER_PROOF_DEPENDENCY_ARCHITECTURE.md includes all chronological section dependencies, full-theorem gaps, and witness boundary.

All new proofs are SOURCE ONLY. They are not compiler-validated here. This archive has exactly one run.cmd and should compile only new or changed modules and their affected dependents using its permanent FAST16 cache.
- Theorem_3_3_Weight_Five_Leading_Sign (finite sum formula; leading-coefficient sign for K=30n,N=3n,m=3).
CORE MODULE COUNT: 52.
