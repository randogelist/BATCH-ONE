-- THEOREM33_SIGNED_PRODUCT_CORE_V0320_20261024
import Mathlib.Tactic

/-!
# All-pole sign: a self-contained finite-product proof core

This file intentionally imports Mathlib only.  It proves the sign
accounting identity independently of the Hankel-paper development, so
its kernel axiom provenance can be audited before the analytic or
polynomial modules are imported.  Theorems contain no free premise
other than pointwise positivity of the signed factors.
-/

noncomputable section
open scoped BigOperators

namespace ManuscriptChronology.Theorem3_3_SignCore

/-- Replacing each factor below `a` by its negative contributes precisely
one factor `-1` for each index in the corresponding filter. -/
theorem signed_product_formula (s : Finset ℕ) (a : ℕ) (f : ℕ → ℚ) :
    (∏ b ∈ s, (if b < a then -(f b) else f b)) =
      (-1 : ℚ) ^ ((s.filter (fun b => b < a)).card) *
        (∏ b ∈ s, f b) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
      simp
  | @insert b s hbs ih =>
      have hnot : b ∉ s.filter (fun c => c < a) := by
        intro hmem
        exact hbs (Finset.mem_filter.mp hmem).1
      by_cases hba : b < a
      · have hcard : ((insert b s).filter (fun c => c < a)).card =
            (s.filter (fun c => c < a)).card + 1 := by
          rw [Finset.filter_insert, if_pos hba,
            Finset.card_insert_of_notMem hnot]
        calc
          (∏ c ∈ insert b s, (if c < a then -(f c) else f c)) =
              (-(f b)) * (∏ c ∈ s, (if c < a then -(f c) else f c)) := by
                rw [Finset.prod_insert hbs, if_pos hba]
          _ = (-(f b)) *
              ((-1 : ℚ) ^ ((s.filter (fun c => c < a)).card) *
                (∏ c ∈ s, f c)) := by rw [ih]
          _ = (-1 : ℚ) ^ (((insert b s).filter (fun c => c < a)).card) *
              (∏ c ∈ insert b s, f c) := by
                rw [hcard, Finset.prod_insert hbs, pow_succ]
                ring
      · have hcard : ((insert b s).filter (fun c => c < a)).card =
            (s.filter (fun c => c < a)).card := by
          rw [Finset.filter_insert, if_neg hba]
        calc
          (∏ c ∈ insert b s, (if c < a then -(f c) else f c)) =
              (f b) * (∏ c ∈ s, (if c < a then -(f c) else f c)) := by
                rw [Finset.prod_insert hbs, if_neg hba]
          _ = (f b) *
              ((-1 : ℚ) ^ ((s.filter (fun c => c < a)).card) *
                (∏ c ∈ s, f c)) := by rw [ih]
          _ = (-1 : ℚ) ^ (((insert b s).filter (fun c => c < a)).card) *
              (∏ c ∈ insert b s, f c) := by
                rw [hcard, Finset.prod_insert hbs]
                ring

/-- The signed product is strictly positive if and only if the factors
with their prescribed signs are all strictly positive (the forward
implication is not needed). -/
theorem signed_product_positive (s : Finset ℕ) (a : ℕ)
    (f : ℕ → ℚ)
    (hf : ∀ b ∈ s, 0 < (if b < a then -(f b) else f b)) :
    0 < (-1 : ℚ) ^ ((s.filter (fun b => b < a)).card) *
      (∏ b ∈ s, f b) := by
  have hpos : 0 < (∏ b ∈ s, (if b < a then -(f b) else f b)) := by
    apply Finset.prod_pos
    intro b hb
    exact hf b hb
  rw [signed_product_formula] at hpos
  exact hpos

end ManuscriptChronology.Theorem3_3_SignCore

#print axioms ManuscriptChronology.Theorem3_3_SignCore.signed_product_formula
#print axioms ManuscriptChronology.Theorem3_3_SignCore.signed_product_positive
