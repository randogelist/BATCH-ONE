import Lemma_2_2_Pullback_Identity

/-!
# Lemma 2.3 — Reflection and difference identities (PDF p. 5)

Original harmonic-number and Bernoulli data; the reflected monomial
identity is the full finite binomial expansion. The difference statement
excludes the two singular indices `r = 0,1` exactly as in the PDF.
No extra analytic or arithmetic assumption is present.
-/

noncomputable section
open Polynomial

namespace ManuscriptChronology

/-- Lemma 2.3(1), monomial part of reflection. -/
theorem LEMMA_2_3_REFLECTION_MONOMIAL (k d : ℕ) (hk : 1 ≤ k) :
    (-1 : ℚ) ^ d *
      (∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i) =
      -Zetahyperbolic.tauMonomial k d :=
  Zetahyperbolic.tau_reflection_monomial k d hk

/-- Lemma 2.3(1), reflected simple-pole generator. -/
theorem LEMMA_2_3_REFLECTION_POLE (k : ℕ) (r : ℤ) :
    -Zetahyperbolic.tauPolePoly k (-1 - r) =
      -Zetahyperbolic.tauPolePoly k r :=
  Zetahyperbolic.tau_reflection_pole k r

/-- Lemma 2.3(2), signed reciprocal-power difference on simple poles. -/
theorem LEMMA_2_3_DIFFERENCE_POLE (k : ℕ) (r : ℤ)
    (hr0 : r ≠ 0) (hr1 : r ≠ 1) :
    Zetahyperbolic.tauPolePoly k (r - 1) -
        Zetahyperbolic.tauPolePoly k r =
      Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹) :=
  Zetahyperbolic.tau_difference_pole k r hr0 hr1

/-- Combined exact generator formulation of Lemma 2.3. -/
theorem LEMMA_2_3_GENERATORS (k : ℕ) (hk : 1 ≤ k) :
    (∀ d : ℕ, (-1 : ℚ) ^ d *
      (∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i) =
      -Zetahyperbolic.tauMonomial k d) ∧
    (∀ r : ℤ, -Zetahyperbolic.tauPolePoly k (-1 - r) =
        -Zetahyperbolic.tauPolePoly k r) ∧
    (∀ r : ℤ, r ≠ 0 → r ≠ 1 →
      Zetahyperbolic.tauPolePoly k (r - 1) -
        Zetahyperbolic.tauPolePoly k r =
      Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹)) := by
  exact ⟨fun d => LEMMA_2_3_REFLECTION_MONOMIAL k d hk,
    fun r => LEMMA_2_3_REFLECTION_POLE k r,
    fun r hr0 hr1 => LEMMA_2_3_DIFFERENCE_POLE k r hr0 hr1⟩


/-- Original Bernoulli monomial functional on an arbitrary polynomial:
finite expansion in the monomial basis. -/
noncomputable def tauPolynomialScalar (k : ℕ) (p : ℚ[X]) : ℚ :=
  ∑ d ∈ Finset.range (p.natDegree + 1),
    p.coeff d * Zetahyperbolic.tauMonomial k d

/-- Applying `τ` to the reflected polynomial, computed from the binomial
expansion of `(-1-x)^d` for each monomial `x^d`. -/
noncomputable def tauReflectedPolynomialScalar (k : ℕ) (p : ℚ[X]) : ℚ :=
  ∑ d ∈ Finset.range (p.natDegree + 1), p.coeff d *
    ((-1 : ℚ) ^ d *
      ∑ i ∈ Finset.range (d + 1),
        (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i)

/-- Lemma 2.3(1) extended from monomials to *every polynomial* in the actual
Bernoulli moment domain, using only finite linearity. -/
theorem LEMMA_2_3_REFLECTION_POLYNOMIAL
    (k : ℕ) (hk : 1 ≤ k) (p : ℚ[X]) :
    tauReflectedPolynomialScalar k p = -tauPolynomialScalar k p := by
  unfold tauReflectedPolynomialScalar tauPolynomialScalar
  calc
    (∑ d ∈ Finset.range (p.natDegree + 1), p.coeff d *
      ((-1 : ℚ) ^ d *
        ∑ i ∈ Finset.range (d + 1),
          (Nat.choose d i : ℚ) * Zetahyperbolic.tauMonomial k i)) =
        ∑ d ∈ Finset.range (p.natDegree + 1),
          -(p.coeff d * Zetahyperbolic.tauMonomial k d) := by
            apply Finset.sum_congr rfl
            intro d _
            rw [LEMMA_2_3_REFLECTION_MONOMIAL k d hk]
            ring
    _ = -∑ d ∈ Finset.range (p.natDegree + 1),
        p.coeff d * Zetahyperbolic.tauMonomial k d := by
          rw [Finset.sum_neg_distrib]

/-- Lemma 2.3(1) on any finite Q-linear combination of simple poles. -/
theorem LEMMA_2_3_REFLECTION_FINITE_POLES
    (k : ℕ) (S : Finset ℤ) (c : ℤ → ℚ) :
    (∑ r ∈ S, Polynomial.C (c r) *
      (-Zetahyperbolic.tauPolePoly k (-1 - r))) =
    -(∑ r ∈ S, Polynomial.C (c r) *
      Zetahyperbolic.tauPolePoly k r) := by
  calc
    (∑ r ∈ S, Polynomial.C (c r) *
      (-Zetahyperbolic.tauPolePoly k (-1 - r))) =
      ∑ r ∈ S, -(Polynomial.C (c r) * Zetahyperbolic.tauPolePoly k r) := by
        apply Finset.sum_congr rfl
        intro r _
        rw [LEMMA_2_3_REFLECTION_POLE k r]
        ring
    _ = -(∑ r ∈ S, Polynomial.C (c r) *
          Zetahyperbolic.tauPolePoly k r) := by
        rw [Finset.sum_neg_distrib]

/-- Lemma 2.3(2) on a finite rational linear combination whose pole indices
all avoid the excluded pair 0, 1. -/
theorem LEMMA_2_3_DIFFERENCE_FINITE_POLES
    (k : ℕ) (S : Finset ℤ) (c : ℤ → ℚ)
    (hsafe : ∀ r ∈ S, r ≠ 0 ∧ r ≠ 1) :
    (∑ r ∈ S, Polynomial.C (c r) *
      (Zetahyperbolic.tauPolePoly k (r - 1) -
        Zetahyperbolic.tauPolePoly k r)) =
      ∑ r ∈ S, Polynomial.C (c r) *
        Polynomial.C (-((r : ℚ) ^ (2 * k + 1))⁻¹) := by
  apply Finset.sum_congr rfl
  intro r hr
  rcases hsafe r hr with ⟨hr0, hr1⟩
  rw [LEMMA_2_3_DIFFERENCE_POLE k r hr0 hr1]

end ManuscriptChronology

#print axioms ManuscriptChronology.LEMMA_2_3_GENERATORS
#print axioms ManuscriptChronology.LEMMA_2_3_REFLECTION_POLYNOMIAL
#print axioms ManuscriptChronology.LEMMA_2_3_REFLECTION_FINITE_POLES
#print axioms ManuscriptChronology.LEMMA_2_3_DIFFERENCE_FINITE_POLES
