# v0.3.9: parity/slope proof repair supplied; Lean compiler verification pending.

# Theorem 3.3 chronological frontier (v0.3.7)

**Source:** Theorem 3.3, PDF pages 8–9.

New Lean module: `Theorem_3_3_Total_Positivity_Leading_Sign_And_Universal_Signature.lean`.

It establishes finite algebra only: the *actual* manuscript polynomial D_N has sign (-1)^N at every right-hand negative-square pole, the derivative of the tail factor is positive at the first pole, the first Lagrange slope coefficient has sign (-1)^N for m>=1, and the complete n-dependent parity calculation for the printed weight-five leading-sign exponent.

The matrix pencil and normalization are inherited without edits, and Proposition 3.2's axiom certificate is reused. Full Theorem 3.3 is NOT yet closed: strict total positivity of arbitrary Gram minors, gamma sign at all pole indices, determinant-sign linkage, and Sylvester inertia transfer remain.

`PAPER_CHRONOLOGICAL_MAIN.lean` has new imports/checks. Only the new module and its chronological dependent need recompilation if all earlier modules passed.

**User-only Lean compilation:** I did not run Lean or Lake when preparing this archive. If the new module fails, return the **first** compiler error line and its context; the frozen modules should remain untouched.

## v0.3.11 all-pole sign extension (unverified source)

A new file `Theorem_3_3_All_Pole_Sign_Transfer.lean` proves abstract signed-product positivity, the exact derivative sign at each pole, and transfers it to the manuscript Lagrange weight. It derives positive/negative residues by index parity. No changed previously certified `.lean` files. Full Theorem 3.3 still requires arbitrary-minor positivity and Sylvester inertia transport. User native Lean 4.33.0 only; no assistant-side compilation.
