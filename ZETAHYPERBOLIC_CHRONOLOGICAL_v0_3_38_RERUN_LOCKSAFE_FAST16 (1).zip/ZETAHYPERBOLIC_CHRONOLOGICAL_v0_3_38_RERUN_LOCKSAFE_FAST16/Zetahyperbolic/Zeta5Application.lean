import Zetahyperbolic.Zeta5Compatibility
import ZETA5_APPLICATION

/-!
# Optional zeta(5) application for the uploaded package

Primitive normalization, determinant degree, pole nonsingularity, spectral
factorization and logarithmic index selection are proved in the imported chain.
Exactly four uniform estimates remain explicit below. The starting index is
data, not a proof of any of these estimates. No external irrationality theorem
is used. The compatibility module identifies the actual original determinant.
-/

namespace Zetahyperbolic
open ManuscriptChain.MainChain

/-- The specialized conditional endpoint, with the original package's zeta(5) target. -/
theorem ZETA5_APPLICATION
    (start : ℕ)
    (gram : ∀ n, start + 1 ≤ n →
      (ManuscriptChain.Real.gram (ManuscriptChain.Real.mainParameters n)
        (ManuscriptChain.Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper (primitiveMainNormalization start))
    (archimedean : ArchimedeanUpper (start + 1))
    (bound : ∀ n (hn : start + 1 ≤ n) i,
      |(mainRootFactorization (start + 1) gram n hn).beta i| ≤
        Real.exp ((ManuscriptChain.Real.rhoPrinted : ℝ) * mainK n)) :
    Irrational zetaFiveReal := by
  rw [ManuscriptCompatibility.zetaFiveReal_eq_riemannZeta_re]
  exact ManuscriptChain.ZETA5_APPLICATION_PRIMITIVE_FROM_GRAM
    start gram multiplier archimedean bound

/-- The same four estimates also imply the paper's large-denominator measure. -/
theorem ZETA5_APPLICATION_MEASURE
    (start : ℕ)
    (gram : ∀ n, start + 1 ≤ n →
      (ManuscriptChain.Real.gram (ManuscriptChain.Real.mainParameters n)
        (ManuscriptChain.Real.zeta 5)).PosDef)
    (multiplier : MultiplierUpper (primitiveMainNormalization start))
    (archimedean : ArchimedeanUpper (start + 1))
    (bound : ∀ n (hn : start + 1 ≤ n) i,
      |(mainRootFactorization (start + 1) gram n hn).beta i| ≤
        Real.exp ((ManuscriptChain.Real.rhoPrinted : ℝ) * mainK n)) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → indexDenominatorThreshold (start + 1) ≤ b →
      1 / (b : ℝ) ^ 25687 < |zetaFiveReal - (a : ℝ) / (b : ℝ)| := by
  rw [ManuscriptCompatibility.zetaFiveReal_eq_riemannZeta_re]
  exact ManuscriptChain.ZETA5_APPLICATION_MEASURE_PRIMITIVE_FROM_GRAM
    start gram multiplier archimedean bound

end Zetahyperbolic

#check Zetahyperbolic.ZETA5_APPLICATION
#check Zetahyperbolic.ZETA5_APPLICATION_MEASURE
#print axioms Zetahyperbolic.ZETA5_APPLICATION
#print axioms Zetahyperbolic.ZETA5_APPLICATION_MEASURE
