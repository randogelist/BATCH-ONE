import Zetahyperbolic.Targets
import Mathlib.NumberTheory.Real.Irrational

/-!
Legacy external-input interface. The previous unconditional admitted declaration
is archived in provenance/ExternalResults.lean.txt. No external irrationality
proof is imported here. The checked MAIN_CHAIN does not use this interface.
-/
namespace Zetahyperbolic

def ExternalZetaFiveIrrationality : Prop := Irrational zetaFiveReal

/-- Compatibility wrapper requiring the formerly admitted assertion explicitly. -/
theorem zetaFive_irrational_external (h : ExternalZetaFiveIrrationality) :
    Irrational zetaFiveReal := h

end Zetahyperbolic
