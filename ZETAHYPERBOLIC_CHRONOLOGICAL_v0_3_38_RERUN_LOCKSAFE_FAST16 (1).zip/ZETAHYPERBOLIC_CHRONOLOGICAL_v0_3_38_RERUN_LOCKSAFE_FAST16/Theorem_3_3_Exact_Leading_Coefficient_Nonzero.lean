-- THEOREM33_EXACT_LEADING_COEFFICIENT_NONZERO_V0334
import Theorem_2_5_Lagrange_Pole_Diagonalization

/-!
# Theorem 3.3: exact unconditional leading coefficient and degree

This module extracts an already established consequence of the genuine
Lagrange residue matrix. It needs no sign-product lemma, Gram positivity,
Witness or irrationality assumption. It is a separately certifiable
unconditional mathematical statement while the finer sign computation is
under proof development.
-/

noncomputable section
open Polynomial

namespace ManuscriptChronology.Theorem3_3_DetNonzero
open ManuscriptChain

theorem derivative_det_ne_zero (p : Real.Parameters) :
    (PoleDiagonalization.rationalDerivativeMatrix p).det ≠ 0 :=
  PoleDiagonalization.rationalDerivativeMatrix_det_ne_zero p

theorem delta_leadingCoeff_exact (p : Real.Parameters) :
    (Real.delta p).leadingCoeff =
      (PoleDiagonalization.rationalDerivativeMatrix p).det :=
  PoleDiagonalization.delta_leadingCoeff p

theorem delta_leadingCoeff_ne_zero (p : Real.Parameters) :
    (Real.delta p).leadingCoeff ≠ 0 := by
  rw [delta_leadingCoeff_exact]
  exact derivative_det_ne_zero p

theorem delta_exact_degree (p : Real.Parameters) :
    (Real.delta p).natDegree = p.h :=
  PoleDiagonalization.delta_natDegree p

end ManuscriptChronology.Theorem3_3_DetNonzero

#print axioms ManuscriptChronology.Theorem3_3_DetNonzero.derivative_det_ne_zero
#print axioms ManuscriptChronology.Theorem3_3_DetNonzero.delta_leadingCoeff_exact
#print axioms ManuscriptChronology.Theorem3_3_DetNonzero.delta_leadingCoeff_ne_zero
#print axioms ManuscriptChronology.Theorem3_3_DetNonzero.delta_exact_degree
