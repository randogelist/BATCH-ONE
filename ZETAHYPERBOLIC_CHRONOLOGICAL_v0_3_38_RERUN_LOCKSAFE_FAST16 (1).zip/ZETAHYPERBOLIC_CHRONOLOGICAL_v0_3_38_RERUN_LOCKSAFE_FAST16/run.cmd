@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 (
  echo BUILD=FAIL_CANNOT_ENTER_PACKAGE_DIRECTORY
  exit /b 2
)
set "RELEASE=ZETAHYPERBOLIC_v0_3_38_RERUN_LOCKSAFE_FAST16"
set "EXPECTED_PACKAGE_DIR=ZETAHYPERBOLIC_CHRONOLOGICAL_v0_3_38_RERUN_LOCKSAFE_FAST16"
for %%D in ("%CD%") do set "ACTUAL_PACKAGE_DIR=%%~nxD"
if /I not "!ACTUAL_PACKAGE_DIR!"=="!EXPECTED_PACKAGE_DIR!" (
  echo BUILD=FAIL_WRONG_PACKAGE_DIR
  echo EXPECTED=!EXPECTED_PACKAGE_DIR!
  echo ACTUAL=!ACTUAL_PACKAGE_DIR!
  exit /b 2
)
if not exist "PAPER_PRINCIPAL_ENDPOINT.lean" (
  echo BUILD=FAIL_PRINCIPAL_SOURCE_MISSING
  exit /b 2
)
findstr /C:"theorem PRINCIPAL_THEOREM (W : ManuscriptChain.Paper.Witness)" "PAPER_PRINCIPAL_ENDPOINT.lean" >NUL 2>NUL
if errorlevel 1 (
  echo BUILD=FAIL_PRINCIPAL_SOURCE_MARKER
  exit /b 2
)
rem A single writer for the persistent cache; never run two releases simultaneously.
set "SHARED=%USERPROFILE%\lean-native\zetahyperbolic_chronological_verified_v1"
if not exist "!SHARED!" mkdir "!SHARED!" >NUL 2>NUL
if not exist "!SHARED!" (
  echo BUILD=FAIL_CANNOT_MAKE_CACHE
  exit /b 2
)
set "LOCK=!SHARED!\_exclusive_writer_lock"
rem One attempt only: preserve the shared cache and never wait indefinitely.
mkdir "!LOCK!" >NUL 2>NUL
if errorlevel 1 (
  echo RELEASE=!RELEASE!
  echo CACHE_LOCK=BUSY_OR_STALE
  echo BUILD=BLOCKED_SHARED_CACHE_WRITER
  echo WAITING=NO
  echo CACHE_MODIFIED=NO
  if exist "!LOCK!\OWNER.txt" (
    echo CACHE_LOCK_OWNER_BEGIN
    type "!LOCK!\OWNER.txt"
    echo CACHE_LOCK_OWNER_END
  )
  echo ACTION=CHECK_RUNNING_COMPILER_AND_ORIGINAL_BUILD_LOG
  echo ACTION=DO_NOT_DELETE_LOCK_WHILE_COMPILER_IS_ACTIVE
  exit /b 5
)
:GOT_LOCK
>"!LOCK!\OWNER.txt" echo !RELEASE!
call :BUILD %*
set "EXITCODE=!ERRORLEVEL!"
rmdir /s /q "!LOCK!" >NUL 2>NUL
if exist "!LOCK!" (
  echo BUILD=FAIL_CACHE_LOCK_RELEASE
  exit /b 2
)
exit /b !EXITCODE!

:BUILD
set "TOOLCHAIN=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
set "LEAN_EXE=!TOOLCHAIN!\bin\lean.exe"
set "LEAN_SYSROOT=!TOOLCHAIN!"
set "LEAN_NUM_THREADS=16"
set "MATHLIB_CACHE=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
set "OUT=!SHARED!\lib"
set "SNAP_ROOT=!SHARED!\snapshots"
set "CERT_ROOT=!SHARED!\verified_axioms"
set "CERT_FILE=!CERT_ROOT!\Principal_Endpoint_v0331.txt"
set "DETSIGN_CERT_FILE=!CERT_ROOT!\Theorem_3_3_Finite_Determinant_Sign_v0337.txt"
set "CONFIG_FILE=!SHARED!\_compiler_config.txt"
set "BUILD_LOG=%CD%\CHRONOLOGICAL_BUILD.log"
set "AXIOM_LOG=%CD%\CHRONOLOGICAL_AXIOMS.log"
set "MODULE_FILE=%CD%\MODULES_FAST16_FOCUS.txt"
set "MODE=FOCUS"
if /I "%~1"=="endpoint" set "MODE=ENDPOINT"
if /I "%~2"=="endpoint" set "MODE=ENDPOINT"
set "FORCE=0"
if /I "%~1"=="all" set "MODE=ALL"
if /I "%~2"=="all" set "MODE=ALL"
if /I "%~1"=="full" set "FORCE=1"
if /I "%~2"=="full" set "FORCE=1"
if /I "!MODE!"=="ALL" set "MODULE_FILE=%CD%\MODULES_FAST16_ALL.txt"
if /I "!MODE!"=="ENDPOINT" set "MODULE_FILE=%CD%\MODULES_FAST16_ENDPOINT.txt"
echo ACTIVE_RELEASE=!RELEASE!
echo MODE=!MODE!
echo DIRECT_LEAN_THREADS=16
echo CACHE_ROOT=!SHARED!
echo LAKE=NOT_USED
echo NETWORK=NOT_USED
echo POWERSHELL=NOT_USED
echo PYTHON=NOT_USED
echo WSL=NOT_USED
if not exist "!LEAN_EXE!" (
  echo BUILD=FAIL_LEAN_433_MISSING
  exit /b 2
)
if not exist "!MODULE_FILE!" (
  echo BUILD=FAIL_MODULE_MANIFEST_MISSING
  exit /b 2
)
"!LEAN_EXE!" --version >"%CD%\_lean_version.txt" 2>&1
if errorlevel 1 (
  echo BUILD=FAIL_LEAN_VERSION_PROBE
  exit /b 2
)
findstr /C:"4.33.0" "%CD%\_lean_version.txt" >NUL 2>NUL
if errorlevel 1 (
  echo BUILD=FAIL_WRONG_LEAN_VERSION
  type "%CD%\_lean_version.txt"
  exit /b 2
)
set "MATHLIB_ROOT="
if exist "!MATHLIB_CACHE!\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean" set "MATHLIB_ROOT=!MATHLIB_CACHE!\.lake\packages\mathlib\.lake\build\lib\lean"
if exist "!MATHLIB_CACHE!\.lake\build\lib\lean\Mathlib.olean" set "MATHLIB_ROOT=!MATHLIB_CACHE!\.lake\build\lib\lean"
if not defined MATHLIB_ROOT (
  echo BUILD=FAIL_MATHLIB_CACHE_MISSING
  exit /b 2
)
for %%P in ("!OUT!" "!SNAP_ROOT!" "!CERT_ROOT!" "!OUT!\Zetahyperbolic" "!OUT!\Zeta5Merge" "!SNAP_ROOT!\Zetahyperbolic" "!SNAP_ROOT!\Zeta5Merge") do if not exist "%%~fP" mkdir "%%~fP" >NUL 2>NUL
set "LEAN_PATH=!OUT!;!TOOLCHAIN!\lib\lean"
if exist "!MATHLIB_CACHE!\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;!MATHLIB_CACHE!\.lake\build\lib\lean"
for /d %%P in ("!MATHLIB_CACHE!\.lake\packages\*") do (
  if exist "%%~fP\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fP\.lake\build\lib\lean"
  if exist "%%~fP\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fP\build\lib\lean"
)
if exist "!MATHLIB_CACHE!\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;!MATHLIB_CACHE!\build\lib\lean"
set "CACHE_SIZE="
set "CACHE_DATE="
for %%I in ("!MATHLIB_ROOT!\Mathlib.olean") do (
  set "CACHE_SIZE=%%~zI"
  set "CACHE_DATE=%%~tI"
)
rem Keep exactly the prior verified cache config format, for frozen reuse.
set "CONFIG_TAG=Lean433_Mathlib!CACHE_SIZE!_!CACHE_DATE!_!MATHLIB_ROOT!_Direct16"
set "CACHE_MISMATCH=0"
if exist "!CONFIG_FILE!" (
  set /p "PREV_CONFIG="<"!CONFIG_FILE!"
  if not "!PREV_CONFIG!"=="!CONFIG_TAG!" (
    set "FORCE=1"
    set "CACHE_MISMATCH=1"
  )
)
set "CERT_TAG=!CONFIG_TAG!_PAPER_PRINCIPAL_ENDPOINT_V0331"
set "CERT_OK=0"
set "DETSIGN_CERT_TAG=!CONFIG_TAG!_THEOREM33_DETSIGN_V0337"
set "DETSIGN_CERT_OK=0"
if exist "!DETSIGN_CERT_FILE!" (
  set /p "OLD_DETSIGN_CERT="<"!DETSIGN_CERT_FILE!"
  if "!OLD_DETSIGN_CERT!"=="!DETSIGN_CERT_TAG!" set "DETSIGN_CERT_OK=1"
)
if exist "!CERT_FILE!" (
  set /p "OLD_CERT="<"!CERT_FILE!"
  if "!OLD_CERT!"=="!CERT_TAG!" set "CERT_OK=1"
)
>"!BUILD_LOG!" echo RELEASE=!RELEASE!
>>"!BUILD_LOG!" echo MODE=!MODE!
>>"!BUILD_LOG!" echo CACHE_MISMATCH=!CACHE_MISMATCH!
>"!AXIOM_LOG!" echo RELEASE=!RELEASE!
set /a COMPILED=0 >NUL
set /a REUSED=0 >NUL
set /a TOTAL=0 >NUL
for /f "usebackq tokens=1,* delims=|" %%M in ("!MODULE_FILE!") do (
  set /a TOTAL+=1 >NUL
  set "MODULE=%%M"
  set "REL=!MODULE:.=\!"
  set "SOURCE=!REL!.lean"
  set "TARGET=!OUT!\!REL!.olean"
  set "SNAPSHOT=!SNAP_ROOT!\!REL!.lean"
  set "REBUILD=!FORCE!"
  if not exist "!SOURCE!" (
    echo BUILD=FAIL_SOURCE_NOT_FOUND:!MODULE!
    exit /b 2
  )
  if not exist "!TARGET!" set "REBUILD=1"
  if not exist "!SNAPSHOT!" set "REBUILD=1"
  if "!REBUILD!"=="0" (
    fc /b "!SOURCE!" "!SNAPSHOT!" >NUL 2>NUL
    if errorlevel 1 set "REBUILD=1"
  )
  for %%D in (%%N) do if "!DIRTY_%%D!"=="1" set "REBUILD=1"
  if /I "!MODULE!"=="PAPER_PRINCIPAL_ENDPOINT" if "!CERT_OK!"=="0" set "REBUILD=1"
  if /I "!MODULE!"=="Theorem_3_3_Finite_Determinant_Sign" if "!DETSIGN_CERT_OK!"=="0" set "REBUILD=1"
  if "!REBUILD!"=="1" (
    echo COMPILE=!MODULE!
    >>"!BUILD_LOG!" echo COMPILE=!MODULE!
    set "MODULE_LOG=%CD%\_MODULE_!RANDOM!!RANDOM!_v0338.log"
    "!LEAN_EXE!" -j 16 -o "!TARGET!.pending" "!SOURCE!" >"!MODULE_LOG!" 2>&1
    if errorlevel 1 (
      type "!MODULE_LOG!"
      type "!MODULE_LOG!" >>"!BUILD_LOG!"
      if exist "!TARGET!.pending" del /q "!TARGET!.pending" >NUL
      echo FIRST_LEAN_ERRORS_BEGIN
      findstr /N /I /C:"error:" /C:"unsolved goals" "!MODULE_LOG!"
      echo FIRST_LEAN_ERRORS_END
      echo BUILD=FAIL
      echo FAIL_MODULE=!MODULE!
      echo RELEASE=!RELEASE!
      exit /b 1
    )
    type "!MODULE_LOG!" >>"!BUILD_LOG!"
    if /I "!MODULE!"=="PAPER_PRINCIPAL_ENDPOINT" (
      type "!MODULE_LOG!" >>"!AXIOM_LOG!"
      findstr /C:"'ManuscriptChronology.Principal.PRINCIPAL_THEOREM' depends on axioms:" "!MODULE_LOG!" >NUL 2>NUL
      if errorlevel 1 (
        echo BUILD=FAIL_MISSING_PRINCIPAL_AXIOM_REPORT
        if exist "!TARGET!.pending" del /q "!TARGET!.pending" >NUL
        exit /b 1
      )
    )
    if /I "!MODULE!"=="Theorem_3_3_Finite_Determinant_Sign" (
      type "!MODULE_LOG!" >>"!AXIOM_LOG!"
      for %%T in (signed_prod_identity signed_pole_factor_positive signed_pole_factors_product_positive signed_pole_product_eq signed_pole_product_positive derivative_det_signed_positive delta_leadingCoeff_signed_positive delta_leadingCoeff_ne_zero) do (
        findstr /C:"ManuscriptChronology.Theorem3_3_DetSign.%%T' depends on axioms:" "!MODULE_LOG!" >NUL 2>NUL
        if errorlevel 1 (
          echo BUILD=FAIL_DETSIGN_MISSING_AXIOM_REPORT:%%T
          if exist "!TARGET!.pending" del /q "!TARGET!.pending" >NUL
          exit /b 1
        )
      )
    )
    findstr /I /C:"sorryAx" "!MODULE_LOG!" >NUL 2>NUL
    if not errorlevel 1 (
      echo BUILD=FAIL_SORRYAX
      echo FAIL_MODULE=!MODULE!
      type "!MODULE_LOG!"
      if exist "!TARGET!.pending" del /q "!TARGET!.pending" >NUL
      exit /b 1
    )
    move /y "!TARGET!.pending" "!TARGET!" >NUL
    if errorlevel 1 (
      echo BUILD=FAIL_OLEAN_COMMIT:!MODULE!
      exit /b 2
    )
    copy /b /y "!SOURCE!" "!SNAPSHOT!" >NUL
    if errorlevel 1 (
      echo BUILD=FAIL_SNAPSHOT_COMMIT:!MODULE!
      exit /b 2
    )
    if /I "!MODULE!"=="PAPER_PRINCIPAL_ENDPOINT" (
      >"!CERT_FILE!" echo(!CERT_TAG!
      if errorlevel 1 (
        echo BUILD=FAIL_PRINCIPAL_CERT_WRITE
        exit /b 2
      )
      set "CERT_OK=1"
      echo PRINCIPAL_AXIOM_CERTIFICATION=PASS
    )
    if /I "!MODULE!"=="Theorem_3_3_Finite_Determinant_Sign" (
      >"!DETSIGN_CERT_FILE!" echo(!DETSIGN_CERT_TAG!
      if errorlevel 1 (
        echo BUILD=FAIL_DETSIGN_CERT_WRITE
        exit /b 2
      )
      set "DETSIGN_CERT_OK=1"
      echo DETSIGN_AXIOM_CERTIFICATION=PASS
    )
    set "DIRTY_%%M=1"
    set /a COMPILED+=1 >NUL
    >>"!BUILD_LOG!" echo FROZEN_PASS=!MODULE!
  ) else (
    set "DIRTY_%%M=0"
    set /a REUSED+=1 >NUL
    echo REUSED_FROZEN_PASS=!MODULE!
    >>"!BUILD_LOG!" echo REUSED_FROZEN_PASS=!MODULE!
  )
)
if /I "!MODE!"=="FOCUS" if not "!DETSIGN_CERT_OK!"=="1" (
  echo BUILD=FAIL_DETSIGN_CERT_MISSING
  exit /b 1
)
if /I "!MODE!"=="FOCUS" if not "!CERT_OK!"=="1" (
  echo BUILD=FAIL_PRINCIPAL_AXIOM_CERT_MISSING
  exit /b 1
)
if /I "!MODE!"=="ENDPOINT" if not "!CERT_OK!"=="1" (
  echo BUILD=FAIL_PRINCIPAL_AXIOM_CERT_MISSING
  exit /b 1
)
findstr /I /C:"sorryAx" "!BUILD_LOG!" >NUL 2>NUL
if not errorlevel 1 (
  echo BUILD=FAIL_SORRYAX_IN_BUILD_LOG
  exit /b 1
)
>"!CONFIG_FILE!" echo(!CONFIG_TAG!
echo COMPILED=!COMPILED!
echo REUSED=!REUSED!
echo TOTAL_MODULES=!TOTAL!
if /I "!MODE!"=="ENDPOINT" echo PRINCIPAL_AXIOM_CERTIFICATION=PASS
if /I "!MODE!"=="FOCUS" echo PRINCIPAL_AXIOM_CERTIFICATION=PASS
if /I "!MODE!"=="FOCUS" echo DETSIGN_AXIOM_CERTIFICATION=PASS
echo AXIOM_AUDIT=PASS_FOR_COMPILED_MODULES_AND_CACHED_FROZEN
>>"!BUILD_LOG!" echo BUILD=PASS
echo LEAN_BUILD=PASS
echo BUILD=PASS
echo RELEASE=!RELEASE!
echo LOGS=CHRONOLOGICAL_BUILD.log,CHRONOLOGICAL_AXIOMS.log
exit /b 0
